CREATE OR REPLACE CONTEXT cnt_provider USING Pkg_Provider accessed GLOBALLY;
