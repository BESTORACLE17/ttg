/* VERSION: 3.1.1 */ 
--
-- ACH_AR_CASH_RECEIPT_HISTORY  (Table) 
--
CREATE TABLE AR.ACH_AR_CASH_RECEIPT_HISTORY
(
  CASH_RECEIPT_HISTORY_ID  NUMBER(12),
  MAINT_CODE               NUMBER(2),
  CREATED_BY               VARCHAR2(30 BYTE),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30 BYTE),
  UPDATED_ON               DATE,
  LATEST_REC_FLAG          VARCHAR2(1 BYTE),
  RECEIPT_ID               NUMBER(12),
  STATUS                   VARCHAR2(10 BYTE),
  GL_ACCOUNT_ID            NUMBER(12),
  AMOUNT                   NUMBER(15,2),
  GL_DATE                  DATE,
  GL_POSTED_DATE           DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          6400K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

