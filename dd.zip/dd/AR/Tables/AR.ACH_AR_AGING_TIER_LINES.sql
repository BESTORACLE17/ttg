/* VERSION: 3.1.1 */ 
--
-- ACH_AR_AGING_TIER_LINES  (Table) 
--
CREATE TABLE AR.ACH_AR_AGING_TIER_LINES
(
  AGING_TIER_ID           NUMBER(12),
  AGING_TIER_LINE_NUMBER  NUMBER(4),
  MAINT_CODE              NUMBER(4),
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATED_ON              DATE,
  UPDATED_BY              VARCHAR2(30 BYTE),
  UPDATED_ON              DATE,
  RANGE_PERIOD_TYPE       NUMBER(12),
  RANGE_FROM              NUMBER(5),
  RANGE_TO                NUMBER(5),
  COLUMN_HEADING1         VARCHAR2(15 BYTE),
  COLUMN_HEADING2         VARCHAR2(15 BYTE)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

