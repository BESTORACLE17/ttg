--VERSION: 2.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05056.01.KY Correct Payment Posting by DCS2000
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 04/11/2005 
|| Revision Desc  : Added 2 new columns:  
||                     TRX_ID 
||                     DUE_DATE 
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3
|| Service Request: S/R #07178.02.KY
|| Revision By    : Dinesh Makked 
|| Revision Date  : 03/29/2008 
|| Revision Desc  : Added new columns  
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 02/22/2011
|| Revision Desc  : Adding Product line code column
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_CASH_EDIT_RECEIPTS  (Table) 
--
TRUNCATE TABLE AR.TEMP_AR_CASH_EDIT_RECEIPTS;

DROP TABLE AR.TEMP_AR_CASH_EDIT_RECEIPTS;

CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_CASH_EDIT_RECEIPTS
(
  AR_RCPT_INTF_RECEIPT_ID  NUMBER(12),
  SEQUENCE_NO              VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER      VARCHAR2(30 BYTE),
  DEPOSIT_DATE             DATE,
  SUBR_ID                  VARCHAR2(9 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE),
  SUBLOC_ID                VARCHAR2(8 BYTE),
  DIV_ID                   VARCHAR2(4 BYTE),
  BILLING_YEAR_MONTH       NUMBER(6),
  RECEIPT_NUMBER           VARCHAR2(20 BYTE),
  DEPOSIT_AMOUNT           NUMBER(15,2),
  AMOUNT_DUE               NUMBER(15,2),
  INIT_PAYMENT_FLAG        VARCHAR2(1 BYTE),
  ORIGINAL_ROW_FLAG        VARCHAR2(1 BYTE),
  AMOUNT_APPLIED           NUMBER(15,2),
  COMMENTS                 VARCHAR2(512 BYTE),
  COMPANY_ID               NUMBER(4),
  RECEIPT_METHOD_ID        NUMBER(12),
  TRX_NUMBER               VARCHAR2(15),
  DUE_DATE                 DATE
)
ON COMMIT PRESERVE ROWS;

--
-- TEMP_AR_CASH_EDIT_RECEIPTS  (Synonym) 
--
--CREATE SYNONYM DCS2000.TEMP_AR_CASH_EDIT_RECEIPTS FOR AR.TEMP_AR_CASH_EDIT_RECEIPTS;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_RECEIPTS TO AR_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_RECEIPTS TO DCS2000 WITH GRANT OPTION;


-- SR07178.02.KY
alter table ar.temp_ar_cash_edit_receipts add (auto_create_rcpt_dist_flag varchar2(1));
alter table ar.temp_ar_cash_edit_receipts add (ar_rcpt_intf_batch_id number(12));
alter table ar.temp_ar_cash_edit_receipts add (batch_type_code varchar2(30));
alter table ar.temp_ar_cash_edit_receipts add (receipt_id number(12));
alter table ar.temp_ar_cash_edit_receipts add (is_first_time_flag varchar2(1));
alter table ar.temp_ar_cash_edit_receipts add (product_line_code number(4)); -- 2.1.4 

