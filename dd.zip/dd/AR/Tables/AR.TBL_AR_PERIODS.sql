/* VERSION: 3.1.1 */ 
--
-- TBL_AR_PERIODS  (Table) 
--
CREATE TABLE AR.TBL_AR_PERIODS
(
  PERIOD_ID           NUMBER(12)                NOT NULL,
  MAINT_CODE          NUMBER(4),
  CREATED_BY          VARCHAR2(30 BYTE),
  CREATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  PERIOD_NAME         VARCHAR2(30 BYTE)         NOT NULL,
  PERIOD_START_DATE   DATE                      NOT NULL,
  PERIOD_END_DATE     DATE                      NOT NULL,
  PERIOD_YEAR         VARCHAR2(5 BYTE)          NOT NULL,
  PERIOD_QUARTER      NUMBER(4)                 NOT NULL,
  PERIOD_STATUS_CODE  NUMBER(4)                 NOT NULL,
  CALENDAR_ID         NUMBER(12)                NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_AR_PERIODS  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_PERIODS ON AR.TBL_AR_PERIODS
(PERIOD_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_PERIODS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_PERIODS FOR AR.TBL_AR_PERIODS;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_PERIODS TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_PERIODS TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_PERIODS TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_PERIODS 
-- 
ALTER TABLE AR.TBL_AR_PERIODS ADD (
  CONSTRAINT PK_AR_PERIODS PRIMARY KEY (PERIOD_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_PERIODS 
-- 
ALTER TABLE AR.TBL_AR_PERIODS ADD (
  CONSTRAINT FK1_AR_PERIODS FOREIGN KEY (CALENDAR_ID) 
    REFERENCES AR.TBL_AR_ACCOUNTING_CALENDARS (CALENDAR_ID));


