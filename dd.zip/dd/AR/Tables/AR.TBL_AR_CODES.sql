/* VERSION: 3.1.1 */ 
--
-- TBL_AR_CODES  (Table) 
--
CREATE TABLE AR.TBL_AR_CODES
(
  CODE_ID                 NUMBER(12)            NOT NULL,
  MAINT_CODE              NUMBER(4),
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATED_ON              DATE,
  UPDATED_BY              VARCHAR2(30 BYTE),
  UPDATED_ON              DATE,
  ACTIVE_FLAG             VARCHAR2(1 BYTE),
  CODE                    VARCHAR2(30 BYTE)     NOT NULL,
  DESCRIPTION             VARCHAR2(512 BYTE)    NOT NULL,
  CODE_TYPE_ID            NUMBER(12)            NOT NULL,
  USER_MAINTAINABLE_FLAG  VARCHAR2(1 BYTE)      NOT NULL,
  START_DATE              DATE,
  END_DATE                DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CODE_PERIOD_STATUS  (Index) 
--
CREATE UNIQUE INDEX AR.PK_CODE_PERIOD_STATUS ON AR.TBL_AR_CODES
(CODE_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_CODES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_CODES FOR AR.TBL_AR_CODES;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_CODES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_CODES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_CODES TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_CODES 
-- 
ALTER TABLE AR.TBL_AR_CODES ADD (
  CONSTRAINT CHK1_AR_CODES CHECK ( USER_MAINTAINABLE_FLAG IN ( 'Y', 'N')));

ALTER TABLE AR.TBL_AR_CODES ADD (
  CONSTRAINT PK_CODE_PERIOD_STATUS PRIMARY KEY (CODE_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


