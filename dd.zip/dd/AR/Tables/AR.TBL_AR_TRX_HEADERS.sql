/* VERSION: 3.1.3 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
-- TBL_AR_TRX_HEADERS  (Table) 
--
CREATE TABLE AR.TBL_AR_TRX_HEADERS
(
  TRX_ID                   NUMBER(12)           NOT NULL,
  MAINT_CODE               NUMBER(2),
  CREATED_BY               VARCHAR2(30 BYTE),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30 BYTE)    DEFAULT USER,
  UPDATED_ON               DATE                 DEFAULT SYSDATE,
  BATCH_ID                 NUMBER(12),
  TRX_NUMBER               VARCHAR2(15 BYTE)    NOT NULL,
  TRX_DATE                 DATE                 NOT NULL,
  TRX_SOURCE_CODE          NUMBER(12)           NOT NULL,
  BILLING_CODE             NUMBER(12)           NOT NULL,
  GL_DATE                  DATE                 NOT NULL,
  SUBR_ID                  VARCHAR2(9 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE)     NOT NULL,
  SUBLOC_ID                VARCHAR2(8 BYTE)     NOT NULL,
  DIV_ID                   VARCHAR2(4 BYTE)     NOT NULL,
  REC_ACCOUNT_CODE         NUMBER(12)           NOT NULL,
  UNEARN_REV_ACCOUNT_CODE  NUMBER(12)           NOT NULL,
  PRODUCT_CODE             NUMBER(4)            NOT NULL,
  ASO_RISK_TYPE            NUMBER(2)            NOT NULL,
  REASON_CODE              NUMBER(12),
  COMMENTS                 VARCHAR2(512 BYTE),
  REV_ACCOUNT_CODE         NUMBER(12)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          11440K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- N5_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N5_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(GL_DATE)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2080K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N6_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N6_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(TRX_NUMBER)
LOGGING
TABLESPACE AR_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1880K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N4_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N4_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(BATCH_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1280K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N3_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N3_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(SUBR_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1000K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N1_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N1_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          4440K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N2_AR_TRX_HEADERS  (Index) 
--
CREATE INDEX AR.N2_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(TRX_DATE)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2600K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- PK_AR_TRX_HEADERS  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_TRX_HEADERS ON AR.TBL_AR_TRX_HEADERS
(TRX_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2080K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_TRX_HEADERS MODIFY SUBR_ID VARCHAR2(30);

--
-- TBL_AR_TRX_HEADERS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_TRX_HEADERS FOR AR.TBL_AR_TRX_HEADERS;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_HEADERS TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_HEADERS TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_TRX_HEADERS TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_TRX_HEADERS 
-- 
ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT PK_AR_TRX_HEADERS PRIMARY KEY (TRX_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          2080K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_TRX_HEADERS 
-- 
ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK10_AR_TRX_HEADERS FOREIGN KEY (ASO_RISK_TYPE) 
    REFERENCES DCS2000.TBL_CODE_ASO_RISK_TYPE (CODE));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK11_AR_TRX_HEADERS FOREIGN KEY (REASON_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK12_AR_TRX_HEADERS FOREIGN KEY (BATCH_ID) 
    REFERENCES AR.TBL_AR_TRX_BATCHES (BATCH_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK1_AR_TRX_HEADERS FOREIGN KEY (TRX_SOURCE_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK2_AR_TRX_HEADERS FOREIGN KEY (BILLING_CODE) 
    REFERENCES AR.TBL_AR_BILLING_CODES (BILLING_CODE_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK3_AR_TRX_HEADERS FOREIGN KEY (SUBR_ID) 
    REFERENCES DCS2000.TBL_SUBR (SUBR_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK4_AR_TRX_HEADERS FOREIGN KEY (GRP_ID, SUBLOC_ID, DIV_ID) 
    REFERENCES DCS2000.TBL_GSD (GRP_ID,SUBLOC_ID,DIV_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK5_AR_TRX_HEADERS FOREIGN KEY (REC_ACCOUNT_CODE) 
    REFERENCES DCS2000.TBL_COA_ACCOUNTS (ACCOUNT_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK6_AR_TRX_HEADERS FOREIGN KEY (UNEARN_REV_ACCOUNT_CODE) 
    REFERENCES DCS2000.TBL_COA_ACCOUNTS (ACCOUNT_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK7_AR_TRX_HEADERS FOREIGN KEY (REV_ACCOUNT_CODE) 
    REFERENCES DCS2000.TBL_COA_ACCOUNTS (ACCOUNT_ID));

ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD (
  CONSTRAINT FK8_AR_TRX_HEADERS FOREIGN KEY (PRODUCT_CODE) 
    REFERENCES DCS2000.TBL_CODE_PRODUCT (CODE));


ALTER TABLE AR.TBL_AR_TRX_HEADERS ADD(PRODUCT_LINE_CODE NUMBER(4)) ; -- 3.1.3 

ALTER TABLE AR.TBL_AR_TRX_HEADERS 
        ADD CONSTRAINT FK_AR_TRX_HEADERS_2_PL
FOREIGN KEY (PRODUCT_LINE_CODE) REFERENCES DCS2000.TBL_CODE_PRODUCT_LINE (CODE); -- 3.1.3 