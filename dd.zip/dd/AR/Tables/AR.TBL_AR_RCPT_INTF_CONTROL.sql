/* VERSION: 3.1.1 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.1 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Added this table which will be used to lock the Receipt Interface Process   
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_RCPT_INTF_CONTROL (Table) 
--
CREATE TABLE AR.TBL_AR_RCPT_INTF_CONTROL
(
  LOCKED_ON             DATE,
  LOCKED_BY             VARCHAR2(30)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1K
            NEXT             1K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_CONTROL TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_CONTROL TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_CONTROL TO OPENCON;
