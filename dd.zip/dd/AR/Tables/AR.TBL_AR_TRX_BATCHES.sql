/* VERSION: 3.1.1 */ 
--
-- TBL_AR_TRX_BATCHES  (Table) 
--
CREATE TABLE AR.TBL_AR_TRX_BATCHES
(
  BATCH_ID           NUMBER(12)                 NOT NULL,
  MAINT_CODE         NUMBER(2),
  CREATED_BY         VARCHAR2(30 BYTE),
  CREATED_ON         DATE,
  UPDATED_BY         VARCHAR2(30 BYTE)          DEFAULT USER,
  UPDATED_ON         DATE                       DEFAULT SYSDATE,
  BATCH_NAME         VARCHAR2(100 BYTE)         NOT NULL,
  BATCH_SOURCE_CODE  NUMBER(12)                 NOT NULL,
  BATCH_DATE         DATE                       NOT NULL,
  CONTROL_AMOUNT     NUMBER(15,2),
  CONTROL_COUNT      NUMBER(8)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_AR_TRX_BATCHES  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_TRX_BATCHES ON AR.TBL_AR_TRX_BATCHES
(BATCH_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_TRX_BATCHES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_TRX_BATCHES FOR AR.TBL_AR_TRX_BATCHES;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_BATCHES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_BATCHES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_TRX_BATCHES TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_TRX_BATCHES 
-- 
ALTER TABLE AR.TBL_AR_TRX_BATCHES ADD (
  CONSTRAINT PK_AR_TRX_BATCHES PRIMARY KEY (BATCH_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


