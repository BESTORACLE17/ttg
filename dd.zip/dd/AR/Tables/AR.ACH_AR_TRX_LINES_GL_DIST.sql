/* VERSION: 3.1.1 */ 
--
-- ACH_AR_TRX_LINES_GL_DIST  (Table) 
--
CREATE TABLE AR.ACH_AR_TRX_LINES_GL_DIST
(
  TRX_LINE_GL_DIST_ID   NUMBER(12),
  MAINT_CODE            NUMBER(2),
  CREATED_BY            VARCHAR2(30 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30 BYTE),
  UPDATED_ON            DATE,
  TRX_LINE_ID           NUMBER(12),
  TRX_ID                NUMBER(12),
  ACCOUNT_TYPE          VARCHAR2(6 BYTE),
  GL_ACCOUNT_CODE       NUMBER(12),
  AMOUNT                NUMBER(15,2),
  GL_DATE               DATE,
  GL_POSTED_DATE        DATE,
  REV_RECOGNITION_FLAG  VARCHAR2(1 BYTE)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          80080K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

