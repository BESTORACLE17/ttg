/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_RPT_RECEIPT_UNAPPLIED  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_RPT_RECEIPT_UNAPPLIED
(
  RECEIPT_ID          NUMBER(12),
  SUBR_ID             VARCHAR2(9 BYTE),
  GRP_ID              VARCHAR2(9 BYTE),
  SUBLOC_ID           VARCHAR2(8 BYTE),
  DIV_ID              VARCHAR2(4 BYTE),
  CUSTOMER_TYPE       VARCHAR2(1 BYTE),
  DISP_SUBR_GRP_ID    VARCHAR2(255 BYTE),
  DISP_NAME           VARCHAR2(255 BYTE),
  COMPANY_CODE        VARCHAR2(5 BYTE),
  RECEIPT_NUMBER      VARCHAR2(20 BYTE),
  DEPOSIT_DATE        DATE,
  GL_DATE             DATE,
  AMOUNT_ORIGINAL     NUMBER(15,2),
  AMOUNT_BALANCE      NUMBER(15,2),
  STATUS              VARCHAR2(50 BYTE),
  MASTER_SUBR_GRP_ID  VARCHAR2(255 BYTE),
  GROUP_TYPE_CODE     NUMBER(5)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_RPT_RECEIPT_UNAPPLIED MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_RPT_RECEIPT_UNAPPLIED TO AR_USERS_ALL;

