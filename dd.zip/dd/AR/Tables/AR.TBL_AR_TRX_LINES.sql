/* VERSION: 3.1.1 */ 
--
-- TBL_AR_TRX_LINES  (Table) 
--
CREATE TABLE AR.TBL_AR_TRX_LINES
(
  TRX_LINE_ID         NUMBER(12)                NOT NULL,
  MAINT_CODE          NUMBER(2),
  CREATED_ON          DATE,
  CREATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  TRX_ID              NUMBER(12)                NOT NULL,
  BILLING_YEAR_MONTH  NUMBER(6)                 NOT NULL,
  BILLING_AMOUNT      NUMBER(15,2)              NOT NULL,
  AMOUNT_DUE          NUMBER(15,2)              NOT NULL,
  AMOUNT_APPLIED      NUMBER(15,2)              DEFAULT 0                     NOT NULL,
  AMOUNT_CREDITED     NUMBER(15,2)              DEFAULT 0                     NOT NULL,
  STATUS              VARCHAR2(5 BYTE)          NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          8080K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- UNQ_TRX_ID_BILLING_YEAR_MONTH  (Index) 
--
CREATE UNIQUE INDEX AR.UNQ_TRX_ID_BILLING_YEAR_MONTH ON AR.TBL_AR_TRX_LINES
(TRX_ID, BILLING_YEAR_MONTH)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2360K
            NEXT             1120K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      50
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- PK_AR_TRX_LINES  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_TRX_LINES ON AR.TBL_AR_TRX_LINES
(TRX_LINE_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1840K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_TRX_LINES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_TRX_LINES FOR AR.TBL_AR_TRX_LINES;

GRANT UPDATE ON  AR.TBL_AR_TRX_LINES TO DINESHM;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_LINES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_TRX_LINES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_TRX_LINES TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_TRX_LINES 
-- 
ALTER TABLE AR.TBL_AR_TRX_LINES ADD (
  CONSTRAINT PK_AR_TRX_LINES PRIMARY KEY (TRX_LINE_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1840K
                NEXT             512K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));

ALTER TABLE AR.TBL_AR_TRX_LINES ADD (
  CONSTRAINT UNQ_TRX_ID_BILLING_YEAR_MONTH UNIQUE (TRX_ID, BILLING_YEAR_MONTH)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          2360K
                NEXT             1120K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      50
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_TRX_LINES 
-- 
ALTER TABLE AR.TBL_AR_TRX_LINES ADD (
  CONSTRAINT FK1_AR_TRX_LINES FOREIGN KEY (TRX_ID) 
    REFERENCES AR.TBL_AR_TRX_HEADERS (TRX_ID));


