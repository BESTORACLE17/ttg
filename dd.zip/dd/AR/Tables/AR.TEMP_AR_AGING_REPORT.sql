/* VERSION: 3.1.2 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_AGING_REPORT  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_AGING_REPORT
(
  SUBR_ID                    VARCHAR2(9 BYTE),
  GRP_ID                     VARCHAR2(9 BYTE),
  SUBLOC_ID                  VARCHAR2(8 BYTE),
  DIV_ID                     VARCHAR2(4 BYTE),
  DISPLAY_ID                 VARCHAR2(100 BYTE),
  DISPLAY_NAME               VARCHAR2(255 BYTE),
  PRODUCT_CODE               NUMBER(12),
  BILLING_CODE               NUMBER(12),
  TRX_NUMBER                 VARCHAR2(15 BYTE),
  TRX_TYPE                   VARCHAR2(5 BYTE),
  DUE_DATE                   DATE,
  DAYS_OLD                   NUMBER(10),
  COMPANY_CODE               VARCHAR2(50 BYTE),
  AMOUNT                     NUMBER(15,2),
  AGING_TIER_ID              NUMBER(12),
  AGING_TIER_LINE_NUMBER     NUMBER(12),
  BUCKET_AMOUNT              NUMBER(15,2),
  CUSTOMER_TYPE              VARCHAR2(1 BYTE),
  REPORT_TYPE                VARCHAR2(1 BYTE),
  AGING_TIER_COLUMN_HEADING  VARCHAR2(35 BYTE),
  SHOW_SUBLOC_FLAG           VARCHAR2(1 BYTE),
  DISPLAY_DETAIL_LINE        VARCHAR2(256 BYTE),
  DISPLAY_DETAIL_HEADER      VARCHAR2(256 BYTE),
  REC_ACCOUNT_CODE           VARCHAR2(30 BYTE),
  GROUP_TYPE_CODE            NUMBER(4),
  GROUP_TYPE_DESC            VARCHAR2(255 BYTE),
  RECORD_TYPE                NUMBER(4),
  PRODUCT_DESC               VARCHAR2(200 BYTE)
)
ON COMMIT PRESERVE ROWS;

--
-- TEMP_AR_AGING_REPORT  (Synonym) 
--
CREATE SYNONYM DCS2000.TEMP_AR_AGING_REPORT FOR AR.TEMP_AR_AGING_REPORT;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_AGING_REPORT MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_REPORT TO DCS_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_REPORT TO AR_USERS_ALL;

