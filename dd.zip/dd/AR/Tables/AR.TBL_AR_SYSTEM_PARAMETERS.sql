/* VERSION: 2.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Added PK Constraint on PARAMETER_ID column  
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_SYSTEM_PARAMETERS  (Table) 
--
CREATE TABLE AR.TBL_AR_SYSTEM_PARAMETERS
(
  PARAMETER_ID           NUMBER(12)             NOT NULL,
  MAINT_CODE             NUMBER(4),
  CREATED_BY             VARCHAR2(30 BYTE),
  CREATED_ON             DATE,
  UPDATED_BY             VARCHAR2(30 BYTE),
  UPDATED_ON             DATE,
  ACTIVE_FLAG            VARCHAR2(1 BYTE),
  PARAMETER_NAME         VARCHAR2(30 BYTE)      NOT NULL,
  PARAMETER_DESCRIPTION  VARCHAR2(512 BYTE)     NOT NULL,
  CURRENT_VALUE          VARCHAR2(512 BYTE)     NOT NULL,
  DEFAULT_VALUE          VARCHAR2(512 BYTE)     NOT NULL,
  IS_MODIFIABLE          VARCHAR2(1 BYTE)       NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


-- 
-- Version: 2.1.2  
-- Primary Key Constraints for Table TBL_AR_SYSTEM_PARAMETERS 
-- 
ALTER TABLE AR.TBL_AR_SYSTEM_PARAMETERS ADD (
  CONSTRAINT PK_AR_SYSTEM_PARAMETERS PRIMARY KEY (PARAMETER_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1K
                NEXT             1K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


--
-- TBL_AR_SYSTEM_PARAMETERS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_SYSTEM_PARAMETERS FOR AR.TBL_AR_SYSTEM_PARAMETERS;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_SYSTEM_PARAMETERS TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_SYSTEM_PARAMETERS TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_SYSTEM_PARAMETERS TO OPENCON;

