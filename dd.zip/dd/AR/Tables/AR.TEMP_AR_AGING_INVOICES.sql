/* VERSION: 3.1.3 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_AGING_INVOICES  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_AGING_INVOICES
(
  SUBR_ID                 VARCHAR2(9 BYTE),
  GRP_ID                  VARCHAR2(9 BYTE),
  SUBLOC_ID               VARCHAR2(8 BYTE),
  DIV_ID                  VARCHAR2(4 BYTE),
  TRX_ID                  NUMBER(12),
  TRX_NUMBER              VARCHAR2(15 BYTE),
  TRX_DATE                DATE,
  GL_DATE                 DATE,
  REC_ACCOUNT_CODE        NUMBER(12),
  TRX_TYPE                VARCHAR2(5 BYTE),
  DUE_DATE                DATE,
  AMOUNT_ORIG             NUMBER(15,2),
  AMOUNT_DUE              NUMBER(15,2),
  AMOUNT_APPLIED          NUMBER(15,2),
  AMOUNT_CREDITED         NUMBER(15,2),
  DAYS_OLD                NUMBER(10),
  AGING_TIER_ID           NUMBER(12),
  AGING_TIER_LINE_NUMBER  NUMBER(4),
  COLUMN_HEADING          VARCHAR2(35 BYTE)
)
ON COMMIT PRESERVE ROWS;

--
-- N1_AR_AGING_INVOICES  (Index) 
--
CREATE INDEX AR.N1_AR_AGING_INVOICES ON AR.TEMP_AR_AGING_INVOICES
(TRX_ID);

--
-- TEMP_AR_AGING_INVOICES_IX  (Index) 
--
CREATE INDEX AR.TEMP_AR_AGING_INVOICES_IX ON AR.TEMP_AR_AGING_INVOICES
(TRX_ID, TRX_TYPE);

--
-- TEMP_AR_AGING_INVOICES  (Synonym) 
--
CREATE SYNONYM DCS2000.TEMP_AR_AGING_INVOICES FOR AR.TEMP_AR_AGING_INVOICES;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_AGING_INVOICES MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_INVOICES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_INVOICES TO DINESHM;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_INVOICES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TEMP_AR_AGING_INVOICES TO OPENCON;

ALTER TABLE AR.TEMP_AR_AGING_INVOICES ADD(PRODUCT_LINE_CODE NUMBER(4)) ; -- 3.1.3 