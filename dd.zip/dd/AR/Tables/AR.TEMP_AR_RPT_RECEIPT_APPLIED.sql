/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_RPT_RECEIPT_APPLIED  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_RPT_RECEIPT_APPLIED
(
  COMPANY_CODE              VARCHAR2(5 BYTE),
  RECEIPT_SUBR_ID           VARCHAR2(9 BYTE),
  RECEIPT_GRP_ID            VARCHAR2(9 BYTE),
  RECEIPT_SUBLOC_ID         VARCHAR2(8 BYTE),
  RECEIPT_DIV_ID            VARCHAR2(4 BYTE),
  RECEIPT_DISP_SUBR_GRP_ID  VARCHAR2(255 BYTE),
  RECEIPT_DISP_NAME         VARCHAR2(255 BYTE),
  RECEIPT_CUSTOMER_TYPE     VARCHAR2(10 BYTE),
  RECEIPT_DEPOSIT_DATE      DATE,
  RECEIPT_NUMBER            VARCHAR2(20 BYTE),
  RECEIPT_AMOUNT            NUMBER(15,2),
  TRX_SUBR_ID               VARCHAR2(9 BYTE),
  TRX_GRP_ID                VARCHAR2(9 BYTE),
  TRX_SUBLOC_ID             VARCHAR2(8 BYTE),
  TRX_DIV_ID                VARCHAR2(4 BYTE),
  TRX_DISP_SUBR_GRP_ID      VARCHAR2(255 BYTE),
  TRX_NUMBER                VARCHAR2(20 BYTE),
  TRX_DUE_DATE              DATE,
  AMOUNT_APPLIED            NUMBER(15,2),
  APPLIED_DATE              DATE,
  APPLIED_GL_DATE           DATE,
  TRX_ASO_RISK_TYPE         NUMBER(4)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_RPT_RECEIPT_APPLIED MODIFY RECEIPT_SUBR_ID VARCHAR2(30);
-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_RPT_RECEIPT_APPLIED MODIFY TRX_SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_RPT_RECEIPT_APPLIED TO AR_USERS_ALL;

