/* VERSION: 3.1.2 */ 

/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_OPENING_TRX_BALANCES  (Table) 
--
CREATE TABLE AR.TBL_AR_OPENING_TRX_BALANCES
(
  SUBR_ID                 VARCHAR2(9 BYTE),
  GRP_ID                  VARCHAR2(9 BYTE)      NOT NULL,
  SUBLOC_ID               VARCHAR2(8 BYTE)      NOT NULL,
  DIV_ID                  VARCHAR2(4 BYTE)      NOT NULL,
  TRX_TYPE                VARCHAR2(3 BYTE)      NOT NULL,
  TRX_DATE                NUMBER(8)             NOT NULL,
  TRX_DUE_DATE            NUMBER(8)             NOT NULL,
  BILL_YEAR_MONTH         NUMBER(6)             NOT NULL,
  AMOUNT                  NUMBER(15,2)          NOT NULL,
  PRODUCT_CODE            VARCHAR2(1 BYTE),
  BILLING_CODE            VARCHAR2(1 BYTE),
  REC_ACCOUNT_CODE        VARCHAR2(50 BYTE),
  REV_ACCOUNT_CODE        VARCHAR2(50 BYTE),
  UNEARN_ACCOUNT_CODE     VARCHAR2(50 BYTE),
  ADJUSTMENT_REASON_CODE  VARCHAR2(20 BYTE),
  COMMENTS                VARCHAR2(100 BYTE),
  PROCESSED_FLAG          VARCHAR2(1 BYTE),
  PROCESSED_ERROR         VARCHAR2(4000 BYTE),
  NO_OF_MONTHS            NUMBER(3),
  GL_DATE                 DATE,
  ORIG_TRX_ID             VARCHAR2(30 BYTE),
  ORIG_TRX_NUMBER         VARCHAR2(30 BYTE),
  CONV_TRX_ID             NUMBER(12),
  CONV_TRX_NUMBER         VARCHAR2(30 BYTE),
  DATA_TYPE_COMMENTS      VARCHAR2(2000 BYTE),
  ASO_RISK_TYPE           NUMBER(2),
  DATA_POPULATED_ON       DATE                  DEFAULT SYSDATE,
  APPLICATION_ID          NUMBER
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          2080K
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- N1_AR_OPENING_TRX_BALANCES  (Index) 
--
CREATE INDEX AR.N1_AR_OPENING_TRX_BALANCES ON AR.TBL_AR_OPENING_TRX_BALANCES
(GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE AR_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N2_AR_OPENING_TRX_BALANCES  (Index) 
--
CREATE INDEX AR.N2_AR_OPENING_TRX_BALANCES ON AR.TBL_AR_OPENING_TRX_BALANCES
(ORIG_TRX_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             280K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N3_AR_OPENING_TRX_BALANCES  (Index) 
--
CREATE INDEX AR.N3_AR_OPENING_TRX_BALANCES ON AR.TBL_AR_OPENING_TRX_BALANCES
(ORIG_TRX_NUMBER)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             280K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N4_AR_OPENING_TRX_BALANCES  (Index) 
--
CREATE INDEX AR.N4_AR_OPENING_TRX_BALANCES ON AR.TBL_AR_OPENING_TRX_BALANCES
(CONV_TRX_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N5_AR_OPENING_TRX_BALANCES  (Index) 
--
CREATE INDEX AR.N5_AR_OPENING_TRX_BALANCES ON AR.TBL_AR_OPENING_TRX_BALANCES
(CONV_TRX_NUMBER)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_OPENING_TRX_BALANCES MODIFY SUBR_ID VARCHAR2(30);

--
-- TBL_AR_OPENING_TRX_BALANCES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_OPENING_TRX_BALANCES FOR AR.TBL_AR_OPENING_TRX_BALANCES;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_OPENING_TRX_BALANCES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_OPENING_TRX_BALANCES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_OPENING_TRX_BALANCES TO OPENCON;

