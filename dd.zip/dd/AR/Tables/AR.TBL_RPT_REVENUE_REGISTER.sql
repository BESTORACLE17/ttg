/* VERSION: 3.1.2 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_RPT_REVENUE_REGISTER  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TBL_RPT_REVENUE_REGISTER
(
  PARENT_ID             NUMBER(4),
  COMPANY_ID            NUMBER(4),
  TRX_NUMBER            VARCHAR2(15 BYTE),
  TRX_TYPE              VARCHAR2(5 BYTE),
  TRX_DATE              DATE,
  GL_DATE               DATE,
  GROUP_TYPE_CODE       NUMBER(2),
  GROUP_TYPE_DESC       VARCHAR2(30 BYTE),
  PRODUCT_DESC          VARCHAR2(200 BYTE),
  BILLING_CODE          VARCHAR2(30 BYTE),
  IS_PREMIUM_FLAG       VARCHAR2(1 BYTE),
  REASON_CODE           NUMBER(12),
  STATUS                VARCHAR2(5 BYTE),
  CUSTOMER_TYPE         VARCHAR2(200 BYTE),
  SUBR_ID               VARCHAR2(9 BYTE),
  GRP_ID                VARCHAR2(9 BYTE),
  SUBLOC_ID             VARCHAR2(8 BYTE),
  DIV_ID                VARCHAR2(4 BYTE),
  DISP_SUBR_GRP_ID      VARCHAR2(255 BYTE),
  DISP_NAME             VARCHAR2(255 BYTE),
  AMOUNT                NUMBER(15,2),
  DEBIT_AMT             NUMBER(15,2),
  CREDIT_AMT            NUMBER(15,2),
  REVENUE_ACCOUNT_ID    NUMBER(12),
  REVENUE_ACCOUNT_CODE  VARCHAR2(305 BYTE),
  REVENUE_ACCOUNT_NAME  VARCHAR2(255 BYTE),
  BATCH_NAME            VARCHAR2(100 BYTE)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_RPT_REVENUE_REGISTER MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_RPT_REVENUE_REGISTER TO DCS_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_RPT_REVENUE_REGISTER TO DCS2000 WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_RPT_REVENUE_REGISTER TO AR_USERS_ALL;

