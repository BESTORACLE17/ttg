/* VERSION: 2.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Initial Creation  
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_RCPT_INTF_IMAGES  (Table) 
--
CREATE TABLE AR.TBL_AR_RCPT_INTF_IMAGES
(
  AR_RCPT_INTF_IMAGE_ID    NUMBER(12)           NOT NULL,
  MAINT_CODE               NUMBER(2),
  CREATED_BY               VARCHAR2(30),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30),
  UPDATED_ON               DATE,
  AR_RCPT_INTF_BATCH_ID    NUMBER(12)           NOT NULL,
  SUPPLIED_BATCH_ID        VARCHAR2 (5),
  SUPPLIED_SEQ_NO          VARCHAR2 (5),
  LOCKBOX_NUMBER           VARCHAR2(10),
  DEPOSIT_DATE             DATE                 NOT NULL,
  CHECK_NUMBER             VARCHAR2(12),
  CHECK_AMOUNT             NUMBER(12,2),
  CURRENT_IMAGE_PATH       VARCHAR2(100)        NOT NULL,
  CURRENT_IMAGE_NAME       VARCHAR2(100)        NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          7880K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- 
-- PK for TBL_AR_RCPT_INTF_IMAGES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_IMAGES ADD (
  CONSTRAINT PK_AR_RCPT_INTF_IMAGES PRIMARY KEY (AR_RCPT_INTF_IMAGE_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1160K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_RCPT_INTF_IMAGES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_IMAGES ADD (
  CONSTRAINT FK1_AR_RCPT_INTF_IMAGES FOREIGN KEY (AR_RCPT_INTF_BATCH_ID) 
    REFERENCES AR.TBL_AR_RCPT_INTF_BATCHES (AR_RCPT_INTF_BATCH_ID));

-- 
-- Unique Key Constraints for Table TBL_AR_RCPT_INTF_IMAGES 
--
ALTER TABLE AR.TBL_AR_RCPT_INTF_IMAGES
 ADD (CONSTRAINT UK1_AR_RCPT_INTF_IMAGES
 UNIQUE (AR_RCPT_INTF_BATCH_ID, CURRENT_IMAGE_NAME));

--
-- TBL_AR_RCPT_INTF_RECEIPTS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_RCPT_INTF_IMAGES FOR AR.TBL_AR_RCPT_INTF_IMAGES;


GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_IMAGES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_IMAGES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_IMAGES TO OPENCON;
