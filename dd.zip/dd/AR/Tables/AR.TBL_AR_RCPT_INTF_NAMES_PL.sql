/*  VERSION 3.1.0 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
-- AR.TBL_AR_RCPT_INTF_NAMES_PL  (TABLE)

CREATE TABLE AR.TBL_AR_RCPT_INTF_NAMES_PL
(
  AR_RCPT_INTF_NAME_ID  NUMBER(12)              NOT NULL,
  PRODUCT_LINE_CODE     NUMBER(4)               NOT NULL,
  MAINT_CODE            NUMBER(4),
  CREATED_BY            VARCHAR2(30 BYTE)       NOT NULL,
  CREATED_ON            DATE                    NOT NULL,
  UPDATED_BY            VARCHAR2(30 BYTE)       NOT NULL,
  UPDATED_ON            DATE                    NOT NULL,
  PARENT_ID             NUMBER(4)               NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE UNIQUE INDEX AR.PK_AR_RCPT_INTF_NAMES_PL ON AR.TBL_AR_RCPT_INTF_NAMES_PL
(AR_RCPT_INTF_NAME_ID, PRODUCT_LINE_CODE)
LOGGING
TABLESPACE AR_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES_PL ADD (
  CONSTRAINT PK_AR_RCPT_INTF_NAMES_PL
 PRIMARY KEY
 (AR_RCPT_INTF_NAME_ID, PRODUCT_LINE_CODE)
    USING INDEX 
    TABLESPACE AR_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));

ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES_PL ADD (
  CONSTRAINT FK_AR_RCPT_INTF_NAMES_2_PL 
 FOREIGN KEY (PRODUCT_LINE_CODE) 
 REFERENCES DCS2000.TBL_CODE_PRODUCT_LINE (CODE));

GRANT DELETE, INSERT, SELECT, UPDATE ON AR.TBL_AR_RCPT_INTF_NAMES_PL TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON AR.TBL_AR_RCPT_INTF_NAMES_PL TO DCS2000 WITH GRANT OPTION;
