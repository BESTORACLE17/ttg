/* VERSION: 2.1.4 */ 

/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 02/22/2011
|| Revision Desc  : Adding Product line code column
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL  (Table) 
--
CREATE TABLE AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL
(
  BATCH_NUMBER             VARCHAR2 (3),
  ITEM_NUMBER              VARCHAR2 (3),
  LOCKBOX_NUMBER           VARCHAR2 (7),
  GROUP_NUMBER             VARCHAR2 (21),
  SUBR_ID                  VARCHAR2 (21),
  BILLING_PERIOD           VARCHAR2 (8),
  CHECK_AMOUNT             VARCHAR2 (9),
  CHECK_NUMBER             VARCHAR2 (6)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          500K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL TO OPENCON;

ALTER TABLE AR.TBL_AR_RCPT_INTF_RAW_BATCH_DTL ADD ( PRODUCT_LINE_CODE NUMBER(4)); -- 2.1.4 