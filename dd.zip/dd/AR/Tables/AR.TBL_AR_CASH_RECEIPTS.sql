/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: SR# 07178.03.KY
|| Revision By    : Dinesh Makked
|| Revision Date  : 03/29/2008
|| Revision Desc  : Added column IS_FIRST_TIME_FLAG
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_CASH_RECEIPTS  (Table) 
--
CREATE TABLE AR.TBL_AR_CASH_RECEIPTS
(
  RECEIPT_ID                   NUMBER(12)       NOT NULL,
  MAINT_CODE                   NUMBER(2),
  CREATED_BY                   VARCHAR2(30 BYTE),
  CREATED_ON                   DATE,
  UPDATED_BY                   VARCHAR2(30 BYTE),
  UPDATED_ON                   DATE,
  BATCH_ID                     NUMBER(12),
  RECEIPT_NUMBER               VARCHAR2(20 BYTE) NOT NULL,
  DEPOSIT_DATE                 DATE             NOT NULL,
  RECEIPT_METHOD_CODE          NUMBER(12)       NOT NULL,
  RECEIPT_AMOUNT               NUMBER(15,2)     NOT NULL,
  SUBR_ID                      VARCHAR2(9 BYTE),
  GRP_ID                       VARCHAR2(9 BYTE),
  SUBLOC_ID                    VARCHAR2(8 BYTE),
  DIV_ID                       VARCHAR2(4 BYTE),
  COMMENTS                     VARCHAR2(512 BYTE),
  REVERSAL_DATE                DATE,
  REVERSAL_REASON_CODE         NUMBER(12),
  REVERSAL_COMMENTS            VARCHAR2(512 BYTE),
  STATUS                       VARCHAR2(10 BYTE) NOT NULL,
  INIT_PAYMENT_FLAG            VARCHAR2(1 BYTE),
  INIT_PAYMENT_FOR_YEAR_MONTH  DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          6520K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_CASH_RECEIPTS TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_CASH_RECEIPTS TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_CASH_RECEIPTS TO OPENCON;

--
-- N1_AR_CASH_RECEIPTS  (Index) 
--
CREATE INDEX AR.N1_AR_CASH_RECEIPTS ON AR.TBL_AR_CASH_RECEIPTS
(GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1920K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N2_AR_CASH_RECEIPTS  (Index) 
--
CREATE INDEX AR.N2_AR_CASH_RECEIPTS ON AR.TBL_AR_CASH_RECEIPTS
(SUBR_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          640K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- PK_AR_CASH_RECEIPTS  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_CASH_RECEIPTS ON AR.TBL_AR_CASH_RECEIPTS
(RECEIPT_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_CASH_RECEIPTS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_CASH_RECEIPTS FOR AR.TBL_AR_CASH_RECEIPTS;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_CASH_RECEIPTS 
-- 
ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT PK_AR_CASH_RECEIPTS PRIMARY KEY (RECEIPT_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_CASH_RECEIPTS 
-- 
ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT FK1_AR_CASH_RECEIPTS FOREIGN KEY (REVERSAL_REASON_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT FK2_AR_CASH_RECEIPTS FOREIGN KEY (RECEIPT_METHOD_CODE) 
    REFERENCES AR.TBL_AR_RECEIPT_METHODS (RECEIPT_METHOD_ID));

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT FK3_AR_CASH_RECEIPTS FOREIGN KEY (SUBR_ID) 
    REFERENCES DCS2000.TBL_SUBR (SUBR_ID));

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT FK4_AR_CASH_RECEIPTS FOREIGN KEY (GRP_ID, SUBLOC_ID, DIV_ID) 
    REFERENCES DCS2000.TBL_GSD (GRP_ID,SUBLOC_ID,DIV_ID));

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD (
  CONSTRAINT FK5_AR_CASH_RECEIPTS FOREIGN KEY (BATCH_ID) 
    REFERENCES AR.TBL_AR_CASH_RECEIPT_BATCHES (BATCH_ID));

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_CASH_RECEIPTS MODIFY SUBR_ID VARCHAR2(30);

-- SR07178.02.KY
ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD IS_FIRST_TIME_FLAG VARCHAR2(1);

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS ADD(PRODUCT_LINE_CODE NUMBER(4)) ; -- 3.1.3 

ALTER TABLE AR.TBL_AR_CASH_RECEIPTS 
        ADD CONSTRAINT FK_AR_CASH_RECEIPTS_2_PL
FOREIGN KEY (PRODUCT_LINE_CODE) REFERENCES DCS2000.TBL_CODE_PRODUCT_LINE (CODE); --3.1.3 