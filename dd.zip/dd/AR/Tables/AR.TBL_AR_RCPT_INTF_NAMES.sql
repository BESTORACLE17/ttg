/* VERSION: 2.1.4 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Added 2 new columns:  
||                     LOAD_PROGRAM_TYPE_CODE  
                       LOAD_PROGRAM_NAME    
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/17/2005 
|| Revision Desc  : Added 2 new columns for the Image load  
||                     LOAD_IMAGES_FLAG 
                       LOAD_IMAGES_PROGRAM_NAME    
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

|| Revision Type  : Enhancement 
|| Version #      : 2.1.4 
|| Service Request: S/R #07271.17.CO 
|| Revision By    : KAJAL PATEL
|| Revision Date  : 06/23/2008 
|| Revision Desc  : Added 1 new column
||                     LOAD_PROC_NAME    
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_RCPT_INTF_NAMES  (Table) 
--
CREATE TABLE AR.TBL_AR_RCPT_INTF_NAMES
(
  AR_RCPT_INTF_NAME_ID  NUMBER(12)              NOT NULL,
  MAINT_CODE            NUMBER(2),
  CREATED_BY            VARCHAR2(30 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30 BYTE),
  UPDATED_ON            DATE,
  NAME                  VARCHAR2(50 BYTE)       NOT NULL,
  DESCRIPTION           VARCHAR2(100 BYTE)      NOT NULL,
  START_DATE            DATE                    NOT NULL,
  END_DATE              DATE,
  RCPT_INTF_TYPE_CODE   NUMBER(12)              NOT NULL,
  RCPT_INTF_FORMAT_ID   NUMBER(12)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_AR_RCPT_INTF_NAMES  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_RCPT_INTF_NAMES ON AR.TBL_AR_RCPT_INTF_NAMES
(AR_RCPT_INTF_NAME_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_RCPT_INTF_NAMES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_RCPT_INTF_NAMES FOR AR.TBL_AR_RCPT_INTF_NAMES;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_NAMES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_NAMES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_NAMES TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_RCPT_INTF_NAMES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES ADD (
  CONSTRAINT PK_AR_RCPT_INTF_NAMES PRIMARY KEY (AR_RCPT_INTF_NAME_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          24K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


--
-- S/R#04328.03.VA 
--
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES 
   ADD LOAD_PROGRAM_TYPE_CODE  NUMBER(12);
   
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES 
   ADD LOAD_PROGRAM_NAME      VARCHAR2(100);

-- 
-- Foreign Key Constraints for Table TBL_AR_RCPT_INTF_NAMES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES ADD (
  CONSTRAINT FK1_AR_RCPT_INTF_NAMES FOREIGN KEY (RCPT_INTF_TYPE_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));

ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES ADD (
  CONSTRAINT FK2_AR_RCPT_INTF_NAMES FOREIGN KEY (RCPT_INTF_FORMAT_ID) 
    REFERENCES AR.TBL_AR_RCPT_INTF_FORMATS (RCPT_INTF_FORMAT_ID));

ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES ADD (
  CONSTRAINT FK3_AR_RCPT_INTF_NAMES FOREIGN KEY (LOAD_PROGRAM_TYPE_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));

-- 
-- S/R#04328.03.VA 
-- Version: 2.1.3 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES 
   ADD LOAD_IMAGES_FLAG  VARCHAR2(1);
   
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES 
   ADD LOAD_IMAGES_PROGRAM_NAME  VARCHAR2(100);


--S/R#07271.17.CO 
-- 2.1.4
ALTER TABLE AR.TBL_AR_RCPT_INTF_NAMES 
   ADD  LOAD_PROC_NAME VARCHAR2(100);


