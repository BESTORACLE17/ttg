/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_AR_CASH_RECEIPTS  (Table) 
--
CREATE TABLE AR.ACH_AR_CASH_RECEIPTS
(
  RECEIPT_ID                   NUMBER(12),
  MAINT_CODE                   NUMBER(2),
  CREATED_BY                   VARCHAR2(30 BYTE),
  CREATED_ON                   DATE,
  UPDATED_BY                   VARCHAR2(30 BYTE),
  UPDATED_ON                   DATE,
  BATCH_ID                     NUMBER(12),
  RECEIPT_NUMBER               VARCHAR2(20 BYTE),
  DEPOSIT_DATE                 DATE,
  RECEIPT_METHOD_CODE          NUMBER(12),
  RECEIPT_AMOUNT               NUMBER(15,2),
  SUBR_ID                      VARCHAR2(9 BYTE),
  GRP_ID                       VARCHAR2(9 BYTE),
  SUBLOC_ID                    VARCHAR2(8 BYTE),
  DIV_ID                       VARCHAR2(4 BYTE),
  COMMENTS                     VARCHAR2(512 BYTE),
  REVERSAL_DATE                DATE,
  REVERSAL_REASON_CODE         NUMBER(12),
  REVERSAL_COMMENTS            VARCHAR2(512 BYTE),
  STATUS                       VARCHAR2(10 BYTE),
  INIT_PAYMENT_FLAG            VARCHAR2(1 BYTE),
  INIT_PAYMENT_FOR_YEAR_MONTH  DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          8400K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.ACH_AR_CASH_RECEIPTS MODIFY SUBR_ID VARCHAR2(30);

ALTER TABLE AR.ACH_AR_CASH_RECEIPTS ADD(PRODUCT_LINE_CODE NUMBER(4)) ; -- 3.1.3 