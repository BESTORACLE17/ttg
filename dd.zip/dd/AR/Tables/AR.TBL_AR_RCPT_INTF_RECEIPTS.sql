/* VERSION: 2.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Added 3 new columns for Image Load:  
||                     SUPPLIED_BATCH_ID 
||                     SUPPLIED_SEQ_NO 
||                     AR_RCPT_INTF_IMAGE_ID (FK to TBL_AR_RCPT_INTF_IMAGES)   
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4  
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Eric Lichtman
|| Revision Date  : 10/09/2006.
|| Revision Desc  : Altered table added column submitted_subr_id 
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.5 
|| Service Request: SR#07178.02.KY Individual Product Processing Enhancements
|| Revision By    : Dinesh Makked
|| Revision Date  : 03/04/2008
|| Revision Desc  : Added column AUTO_CREATE_RCPT_DIST_FLAG & RECEIPT_ID.
||                  Add constraint FK3_AR_RCPT_INTF_RECEIPTS.
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 02/22/2011
|| Revision Desc  : Adding Product line code column
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_RCPT_INTF_RECEIPTS  (Table) 
--
CREATE TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS
(
  AR_RCPT_INTF_RECEIPT_ID  NUMBER(12)           NOT NULL,
  MAINT_CODE               NUMBER(2),
  CREATED_BY               VARCHAR2(30 BYTE),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30 BYTE),
  UPDATED_ON               DATE,
  AR_RCPT_INTF_BATCH_ID    NUMBER(12)           NOT NULL,
  SEQUENCE_NO              VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER      VARCHAR2(30 BYTE),
  DEPOSIT_DATE             DATE,
  SUBR_ID                  VARCHAR2(9 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE),
  SUBLOC_ID                VARCHAR2(8 BYTE),
  DIV_ID                   VARCHAR2(4 BYTE),
  BILL_YEAR_MONTH          DATE,
  RECEIPT_NUMBER           VARCHAR2(20 BYTE),
  DEPOSIT_AMOUNT           NUMBER(15,2),
  INIT_PAYMENT_FLAG        VARCHAR2(1 BYTE),
  ORIGINAL_ROW_FLAG        VARCHAR2(1 BYTE),
  CASH_EDIT_ERRORS         VARCHAR2(4000 BYTE),
  PROCESSED_FLAG           VARCHAR2(1 BYTE)     DEFAULT 'N',
  AMOUNT_DUE               NUMBER(15,2),
  COMMENTS                 VARCHAR2(512 BYTE),
  COMPANY_ID               NUMBER(4)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          7880K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_RECEIPTS TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_RECEIPTS TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_RECEIPTS TO OPENCON;

--
-- N1_AR_RCPT_INTF_RECEIPTS  (Index) 
--
CREATE INDEX AR.N1_AR_RCPT_INTF_RECEIPTS ON AR.TBL_AR_RCPT_INTF_RECEIPTS
(AR_RCPT_INTF_BATCH_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1136K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- PK_AR_RCPT_INTF_RECEIPTS  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_RCPT_INTF_RECEIPTS ON AR.TBL_AR_RCPT_INTF_RECEIPTS
(AR_RCPT_INTF_RECEIPT_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1160K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_RCPT_INTF_RECEIPTS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_RCPT_INTF_RECEIPTS FOR AR.TBL_AR_RCPT_INTF_RECEIPTS;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_RCPT_INTF_RECEIPTS 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS ADD (
  CONSTRAINT PK_AR_RCPT_INTF_RECEIPTS PRIMARY KEY (AR_RCPT_INTF_RECEIPT_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1160K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_RCPT_INTF_RECEIPTS 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS ADD (
  CONSTRAINT FK1_AR_RCPT_INTF_RECEIPTS FOREIGN KEY (AR_RCPT_INTF_BATCH_ID) 
    REFERENCES AR.TBL_AR_RCPT_INTF_BATCHES (AR_RCPT_INTF_BATCH_ID));

-- 
-- S/R#04328.03.VA 
-- Version: 2.1.2 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS 
   ADD SUPPLIED_BATCH_ID  VARCHAR2(100);
   
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS 
   ADD SUPPLIED_SEQ_NO  VARCHAR2(100);

ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS 
   ADD AR_RCPT_INTF_IMAGE_ID  NUMBER(12);


-- 
-- Foreign Key Constraints for Table TBL_AR_RCPT_INTF_RECEIPTS 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS ADD (
  CONSTRAINT FK2_AR_RCPT_INTF_RECEIPTS FOREIGN KEY (AR_RCPT_INTF_IMAGE_ID) 
    REFERENCES AR.TBL_AR_RCPT_INTF_IMAGES (AR_RCPT_INTF_IMAGE_ID));

-- 
-- S/R#04328.03.VA 
-- Version: 2.1.4  ERL 10/09/2006  
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS 
   ADD SUBMITTED_SUBR_ID  VARCHAR2(30);

-- Version 2.1.5   
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS
   ADD AUTO_CREATE_RCPT_DIST_FLAG VARCHAR2(1) CHECK ( AUTO_CREATE_RECEIPT_DIST_FLAG IN ('Y', 'N'));

-- Version 2.1.5   
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS
   ADD RECEIPT_ID NUMBER(12);


ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS 
   ADD IS_FIRST_TIME_FLAG VARCHAR2(1) ;
   
-- Version 2.1.5 
ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS ADD (
  CONSTRAINT FK3_AR_RCPT_INTF_RECEIPTS FOREIGN KEY (RECEIPT_ID) 
    REFERENCES AR.TBL_AR_CASH_RECEIPTS (RECEIPT_ID));

ALTER TABLE AR.TBL_AR_RCPT_INTF_RECEIPTS ADD ( PRODUCT_LINE_CODE NUMBER(4)); -- 2.1.4 