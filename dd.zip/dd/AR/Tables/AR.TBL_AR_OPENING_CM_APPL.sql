/* VERSION: 3.1.1 */ 
--
-- TBL_AR_OPENING_CM_APPL  (Table) 
--
CREATE TABLE AR.TBL_AR_OPENING_CM_APPL
(
  RECEIVABLE_APPLICATION_ID  NUMBER(15)         NOT NULL,
  AMOUNT_APPLIED             NUMBER             NOT NULL,
  AMOUNT_APPLIED_FROM        NUMBER,
  APPLY_DATE                 DATE               NOT NULL,
  APPLY_GL_DATE              DATE               NOT NULL,
  DISPLAY                    VARCHAR2(1 BYTE)   NOT NULL,
  APPLICATION_TYPE           VARCHAR2(20 BYTE)  NOT NULL,
  STATUS                     VARCHAR2(30 BYTE)  NOT NULL,
  PAYMENT_SCHEDULE_ID        NUMBER(15)         NOT NULL,
  CASH_RECEIPT_ID            NUMBER(15),
  CUSTOMER_TRX_ID            NUMBER(15),
  CUSTOMER_NUMBER            VARCHAR2(30 BYTE)  NOT NULL,
  TRX_NUMBER                 VARCHAR2(20 BYTE)  NOT NULL,
  TRX_DUE_DATE               DATE               NOT NULL,
  CLASS                      VARCHAR2(20 BYTE)  NOT NULL,
  APP_TO_CUSTOMER_TRX_ID     NUMBER(15),
  APP_TO_TRX_NUMBER          VARCHAR2(20 BYTE)  NOT NULL,
  APP_TO_CUSTOMER_NUMBER     VARCHAR2(30 BYTE)  NOT NULL,
  APP_TO_DUE_DATE            DATE               NOT NULL,
  APP_TO_CLASS               VARCHAR2(20 BYTE)  NOT NULL,
  APP_TO_GL_DATE             DATE               NOT NULL,
  PROCESSED_FLAG             CHAR(1 BYTE),
  DATA_POPULATED_ON          DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

