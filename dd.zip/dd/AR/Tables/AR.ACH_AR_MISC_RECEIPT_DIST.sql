/* VERSION: 3.1.1 */ 
--
-- ACH_AR_MISC_RECEIPT_DIST  (Table) 
--
CREATE TABLE AR.ACH_AR_MISC_RECEIPT_DIST
(
  MISC_RECEIPT_DIST_ID  NUMBER(12),
  MAINT_CODE            NUMBER(2),
  CREATED_BY            VARCHAR2(30 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30 BYTE),
  UPDATED_ON            DATE,
  RECEIPT_ID            NUMBER(12),
  CATEGORY_ID           NUMBER(12),
  GL_ACCOUNT_CODE       NUMBER(12),
  AMOUNT                NUMBER(15,2),
  GL_DATE               DATE,
  GL_POSTED_DATE        DATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

