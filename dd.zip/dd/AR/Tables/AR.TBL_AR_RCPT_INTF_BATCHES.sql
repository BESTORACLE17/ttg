/* VERSION: 2.1.2 */ 
--
-- TBL_AR_RCPT_INTF_BATCHES  (Table) 
--
/* 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2 
|| Revision Type  : Enhancement 
|| Service Request: S/R #04328.03.VA - EFT and Electronic Imaging, Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/17/2005 
|| Revision Desc  : Initial Creation 
||                  This table will be used as the interface table between the
||                  bank and the DCS2000 system for processing lockbox check images 
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

CREATE TABLE AR.TBL_AR_RCPT_INTF_BATCHES
(
  AR_RCPT_INTF_BATCH_ID  NUMBER(12)             NOT NULL,
  MAINT_CODE             NUMBER(2),
  CREATED_BY             VARCHAR2(30 BYTE),
  CREATED_ON             DATE,
  UPDATED_BY             VARCHAR2(30 BYTE),
  UPDATED_ON             DATE,
  BATCH_NAME             VARCHAR2(50 BYTE)      NOT NULL,
  BATCH_DATE             DATE                   NOT NULL,
  CONTROL_AMOUNT         NUMBER(15,2)           NOT NULL,
  CONTROL_COUNT          NUMBER(8)              NOT NULL,
  AR_RCPT_INTF_NAME_ID   NUMBER(12),
  DATA_FILE_NAME         VARCHAR2(100 BYTE),
  STATUS_CODE            NUMBER(12)             NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          320K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_BATCHES TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TBL_AR_RCPT_INTF_BATCHES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TBL_AR_RCPT_INTF_BATCHES TO OPENCON;

--
-- PK_AR_RCPT_INTF_BATCHES  (Index) 
--
CREATE UNIQUE INDEX AR.PK_AR_RCPT_INTF_BATCHES ON AR.TBL_AR_RCPT_INTF_BATCHES
(AR_RCPT_INTF_BATCH_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          304K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_AR_RCPT_INTF_BATCHES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_RCPT_INTF_BATCHES FOR AR.TBL_AR_RCPT_INTF_BATCHES;

-- 
-- Non Foreign Key Constraints for Table TBL_AR_RCPT_INTF_BATCHES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES ADD (
  CONSTRAINT PK_AR_RCPT_INTF_BATCHES PRIMARY KEY (AR_RCPT_INTF_BATCH_ID)
    USING INDEX 
    TABLESPACE AR_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          304K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_AR_RCPT_INTF_BATCHES 
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES ADD (
  CONSTRAINT FK1_AR_RCPT_INTF_BATCHES FOREIGN KEY (AR_RCPT_INTF_NAME_ID) 
    REFERENCES AR.TBL_AR_RCPT_INTF_NAMES (AR_RCPT_INTF_NAME_ID));

ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES ADD (
  CONSTRAINT FK2_AR_RCPT_INTF_BATCHES FOREIGN KEY (STATUS_CODE) 
    REFERENCES AR.TBL_AR_CODES (CODE_ID));


-- 
-- S/R#04328.03.VA 
-- Version: 2.1.2
-- 
ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES 
   ADD IMAGES_FILE_NAME  VARCHAR2(100);
   
ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES 
   ADD IMAGES_POSTED_FLAG  VARCHAR2(1);

ALTER TABLE AR.TBL_AR_RCPT_INTF_BATCHES 
   ADD IMAGES_POSTED_DATE  DATE;

