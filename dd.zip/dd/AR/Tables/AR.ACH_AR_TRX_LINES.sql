/* VERSION: 3.1.1 */ 
--
-- ACH_AR_TRX_LINES  (Table) 
--
CREATE TABLE AR.ACH_AR_TRX_LINES
(
  AMOUNT_DUE          NUMBER(15,2),
  AMOUNT_APPLIED      NUMBER(15,2),
  AMOUNT_CREDITED     NUMBER(15,2),
  STATUS              VARCHAR2(5 BYTE),
  TRX_LINE_ID         NUMBER(12),
  MAINT_CODE          NUMBER(2),
  CREATED_ON          DATE,
  CREATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  TRX_ID              NUMBER(12),
  BILLING_YEAR_MONTH  NUMBER(6),
  BILLING_AMOUNT      NUMBER(15,2)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          9320K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

