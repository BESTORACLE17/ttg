/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: S/R #07178.02.KY Individual Product Processing Enhancements 
|| Revision By    : Ketan Patel 
|| Revision Date  : 03/19/2008 
|| Revision Desc  : Added columns TOTAL_AMOUNT_DUE, OTHER_DIST_EXISTS_FLAG 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+   
*/
--
-- TEMP_AR_CASH_EDIT_APPLICATIONS  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_CASH_EDIT_APPLICATIONS
(
  AR_RCPT_INTF_RECEIPT_ID  NUMBER(12),
  TRX_ID                   NUMBER(12),
  BILLING_YEAR_MONTH       NUMBER(6),
  AMOUNT_APPLIED           NUMBER(15,2)
)
ON COMMIT PRESERVE ROWS;

--
-- TEMP_AR_CASH_EDIT_APPLICATIONS  (Synonym) 
--
CREATE SYNONYM DCS2000.TEMP_AR_CASH_EDIT_APPLICATIONS FOR AR.TEMP_AR_CASH_EDIT_APPLICATIONS;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_APPLICATIONS TO AR_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_APPLICATIONS TO DCS2000 WITH GRANT OPTION;

-- 3.1.2

ALTER TABLE AR.TEMP_AR_CASH_EDIT_APPLICATIONS ADD TOTAL_AMOUNT_DUE NUMBER(15,2);

ALTER TABLE AR.TEMP_AR_CASH_EDIT_APPLICATIONS ADD OTHER_DIST_EXISTS_FLAG VARCHAR2(1);
