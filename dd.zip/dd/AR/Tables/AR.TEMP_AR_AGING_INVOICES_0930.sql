/* VERSION: 3.1.1 */ 
--
-- TEMP_AR_AGING_INVOICES_0930  (Table) 
--
CREATE TABLE AR.TEMP_AR_AGING_INVOICES_0930
(
  SUBR_ID                 VARCHAR2(9 BYTE),
  GRP_ID                  VARCHAR2(9 BYTE),
  SUBLOC_ID               VARCHAR2(8 BYTE),
  DIV_ID                  VARCHAR2(4 BYTE),
  TRX_ID                  NUMBER(12),
  TRX_NUMBER              VARCHAR2(15 BYTE),
  TRX_DATE                DATE,
  GL_DATE                 DATE,
  REC_ACCOUNT_CODE        NUMBER(12),
  TRX_TYPE                VARCHAR2(5 BYTE),
  DUE_DATE                DATE,
  AMOUNT_ORIG             NUMBER(15,2),
  AMOUNT_DUE              NUMBER(15,2),
  AMOUNT_APPLIED          NUMBER(15,2),
  AMOUNT_CREDITED         NUMBER(15,2),
  DAYS_OLD                NUMBER(10),
  AGING_TIER_ID           NUMBER(12),
  AGING_TIER_LINE_NUMBER  NUMBER(4),
  COLUMN_HEADING          VARCHAR2(35 BYTE)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

