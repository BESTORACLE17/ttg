/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_RPT_RECEIPT_REGISTER  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_RPT_RECEIPT_REGISTER
(
  RECEIPT_TYPE         VARCHAR2(5 BYTE),
  RECEIPT_ID           NUMBER(12),
  SUBR_ID              VARCHAR2(9 BYTE),
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  CUSTOMER_TYPE        VARCHAR2(2 BYTE),
  DISP_SUBR_GRP_ID     VARCHAR2(30 BYTE),
  DISP_NAME            VARCHAR2(255 BYTE),
  COMPANY_CODE         VARCHAR2(10 BYTE),
  RECEIPT_NUMBER       VARCHAR2(20 BYTE),
  DEPOSIT_DATE         DATE,
  GL_DATE              DATE,
  RECEIPT_METHOD_DESC  VARCHAR2(255 BYTE),
  RECEIPT_METHOD_CODE  NUMBER(12),
  RECEIPT_AMOUNT       NUMBER(15,2),
  GROUP_TYPE_CODE      NUMBER(4),
  INIT_PAYMENT_FLAG    VARCHAR2(1 BYTE),
  PARENT_ID            NUMBER(4)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_RPT_RECEIPT_REGISTER MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_RPT_RECEIPT_REGISTER TO AR_USERS_ALL;

