/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_JOURNAL_VOUCHER_REPORT  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_JOURNAL_VOUCHER_REPORT
(
  GL_DATE         DATE,
  ACCOUNT_ID      NUMBER(12),
  ACCOUNT_NUMBER  VARCHAR2(50 BYTE),
  DEBIT_AMOUNT    NUMBER(15,2),
  CREDIT_AMOUNT   NUMBER(15,2),
  BALANCE         NUMBER(15,2),
  REMARKS         VARCHAR2(128 BYTE),
  SUBR_ID1        VARCHAR2(9 BYTE),
  GRP_ID1         VARCHAR2(9 BYTE),
  SUBLOC_ID1      VARCHAR2(8 BYTE),
  DIV_ID1         VARCHAR2(4 BYTE),
  SUBR_ID2        VARCHAR2(9 BYTE),
  GRP_ID2         VARCHAR2(9 BYTE),
  SUBLOC_ID2      VARCHAR2(9 BYTE),
  DIV_ID2         VARCHAR2(4 BYTE)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_JOURNAL_VOUCHER_REPORT MODIFY SUBR_ID1 VARCHAR2(30);
-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_JOURNAL_VOUCHER_REPORT MODIFY SUBR_ID2 VARCHAR2(30);

GRANT SELECT ON  AR.TEMP_AR_JOURNAL_VOUCHER_REPORT TO AR_USERS_ALL;

