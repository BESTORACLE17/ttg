/* VERSION: 3.1.2 */ 

/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_AR_OPENING_RCPT_BALANCES  (Table) 
--
CREATE TABLE AR.TBL_AR_OPENING_RCPT_BALANCES
(
  SUBR_ID              VARCHAR2(9 BYTE),
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  RECEIPT_NUMBER       VARCHAR2(20 BYTE)        NOT NULL,
  DEPOSIT_DATE         DATE                     NOT NULL,
  RECEIPT_METHOD_CODE  VARCHAR2(1 BYTE)         NOT NULL,
  RECEIPT_AMOUNT       NUMBER(15,2)             NOT NULL,
  COMMENTS             VARCHAR2(100 BYTE),
  PROCESSED_FLAG       VARCHAR2(1 BYTE),
  PROCESSED_ERROR      VARCHAR2(4000 BYTE),
  GL_DATE              DATE,
  ORIG_RECEIPT_ID      VARCHAR2(30 BYTE),
  ORIG_RECEIPT_NUMBER  VARCHAR2(30 BYTE),
  CONV_RECEIPT_ID      NUMBER(12),
  CONV_RECEIPT_NUMBER  VARCHAR2(30 BYTE),
  DATA_TYPE_COMMENTS   VARCHAR2(2000 BYTE),
  APPLICATION_ID       NUMBER,
  DATA_POPULATED_ON    DATE                     DEFAULT SYSDATE
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- N1_AR_OPENING_RCPT_BALANCES  (Index) 
--
CREATE INDEX AR.N1_AR_OPENING_RCPT_BALANCES ON AR.TBL_AR_OPENING_RCPT_BALANCES
(ORIG_RECEIPT_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N2_AR_OPENING_RCPT_BALANCES  (Index) 
--
CREATE INDEX AR.N2_AR_OPENING_RCPT_BALANCES ON AR.TBL_AR_OPENING_RCPT_BALANCES
(ORIG_RECEIPT_NUMBER)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N3_AR_OPENING_RCPT_BALANCES  (Index) 
--
CREATE INDEX AR.N3_AR_OPENING_RCPT_BALANCES ON AR.TBL_AR_OPENING_RCPT_BALANCES
(CONV_RECEIPT_ID)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N4_AR_OPENING_RCPT_BALANCES  (Index) 
--
CREATE INDEX AR.N4_AR_OPENING_RCPT_BALANCES ON AR.TBL_AR_OPENING_RCPT_BALANCES
(CONV_RECEIPT_NUMBER)
LOGGING
TABLESPACE AR_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TBL_AR_OPENING_RCPT_BALANCES MODIFY SUBR_ID VARCHAR2(30);

--
-- TBL_AR_OPENING_RCPT_BALANCES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_AR_OPENING_RCPT_BALANCES FOR AR.TBL_AR_OPENING_RCPT_BALANCES;

