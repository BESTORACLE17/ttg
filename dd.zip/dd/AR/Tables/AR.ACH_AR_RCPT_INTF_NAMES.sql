/* VERSION: 2.1.2 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #04328.03.VA Electronic Imaging with Wachovia 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 02/18/2005 
|| Revision Desc  : Added 2 new columns:  
||                     LOAD_PROGRAM_TYPE_CODE  
                       LOAD_PROGRAM_NAME    
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_AR_RCPT_INTF_NAMES  (Table) 
--
CREATE TABLE AR.ACH_AR_RCPT_INTF_NAMES
(
  AR_RCPT_INTF_NAME_ID    NUMBER(12),
  MAINT_CODE              NUMBER(2),
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATED_ON              DATE,
  UPDATED_BY              VARCHAR2(30 BYTE),
  UPDATED_ON              DATE,
  NAME                    VARCHAR2(50 BYTE),
  DESCRIPTION             VARCHAR2(100 BYTE),
  START_DATE              DATE,
  END_DATE                DATE,
  RCPT_INTF_TYPE_CODE     NUMBER(12),
  RCPT_INTF_FORMAT_ID     NUMBER(12),
  RECEIPT_METHOD_ID       NUMBER(12)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


ALTER TABLE AR.ACH_AR_RCPT_INTF_NAMES
   ADD LOAD_PROGRAM_TYPE_CODE  NUMBER(12);

ALTER TABLE AR.ACH_AR_RCPT_INTF_NAMES
   ADD LOAD_PROGRAM_NAME       VARCHAR2(100);

