/* VERSION: 3.1.1 */ 
--
-- ACH_AR_RECEIPT_METHODS  (Table) 
--
CREATE TABLE AR.ACH_AR_RECEIPT_METHODS
(
  BANK_ACCOUNT_NUMBER           VARCHAR2(50 BYTE),
  BANK_ADDRESS1                 VARCHAR2(30 BYTE),
  BANK_ADDRESS2                 VARCHAR2(30 BYTE),
  BANK_ADDRESS3                 VARCHAR2(30 BYTE),
  BANK_CITY                     VARCHAR2(30 BYTE),
  BANK_STATE                    VARCHAR2(30 BYTE),
  BANK_POSTAL_CODE              VARCHAR2(30 BYTE),
  BANK_COUNTRY                  VARCHAR2(30 BYTE),
  BANK_TELEPHONE                VARCHAR2(30 BYTE),
  BANK_FAX                      VARCHAR2(30 BYTE),
  BANK_CONTACT                  VARCHAR2(100 BYTE),
  BANK_CONTACT_TELEPHONE        VARCHAR2(30 BYTE),
  BANK_CONTACT_FAX              VARCHAR2(30 BYTE),
  CASH_ACCOUNT_ID               NUMBER(12),
  UNAPPLIED_CASH_ACCOUNT_ID     NUMBER(12),
  UNIDENTIFIED_CASH_ACCOUNT_ID  NUMBER(12),
  START_DATE                    DATE,
  END_DATE                      DATE,
  RECEIPT_METHOD_ID             NUMBER(12),
  MAINT_CODE                    NUMBER(4),
  CREATED_BY                    VARCHAR2(30 BYTE),
  CREATED_ON                    DATE,
  UPDATED_BY                    VARCHAR2(30 BYTE),
  UPDATED_ON                    DATE,
  ACTIVE_FLAG                   VARCHAR2(1 BYTE),
  NAME                          VARCHAR2(50 BYTE),
  DESCRIPTION                   VARCHAR2(512 BYTE),
  BANK_NAME                     VARCHAR2(100 BYTE),
  BANK_BRANCH_NAME              VARCHAR2(100 BYTE)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

