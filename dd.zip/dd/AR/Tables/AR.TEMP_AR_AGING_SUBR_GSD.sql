/* VERSION: 3.1.2 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_AGING_SUBR_GSD  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_AGING_SUBR_GSD
(
  SUBR_ID    VARCHAR2(9 BYTE),
  GRP_ID     VARCHAR2(9 BYTE),
  SUBLOC_ID  VARCHAR2(8 BYTE),
  DIV_ID     VARCHAR2(4 BYTE)
)
ON COMMIT PRESERVE ROWS;

--
-- TEMP_AR_AGING_SUBR_GSD  (Synonym) 
--
CREATE SYNONYM DCS2000.TEMP_AR_AGING_SUBR_GSD FOR AR.TEMP_AR_AGING_SUBR_GSD;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_AGING_SUBR_GSD MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_SUBR_GSD TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_SUBR_GSD TO DINESHM;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_AGING_SUBR_GSD TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TEMP_AR_AGING_SUBR_GSD TO OPENCON;

