/* VERSION: 3.1.1 */ 
--
-- ACH_AR_PERIODS  (Table) 
--
CREATE TABLE AR.ACH_AR_PERIODS
(
  PERIOD_STATUS_CODE  NUMBER(4),
  CALENDAR_ID         NUMBER(12),
  PERIOD_ID           NUMBER(12),
  MAINT_CODE          NUMBER(4),
  CREATED_BY          VARCHAR2(30 BYTE),
  CREATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  PERIOD_NAME         VARCHAR2(30 BYTE),
  PERIOD_START_DATE   DATE,
  PERIOD_END_DATE     DATE,
  PERIOD_YEAR         VARCHAR2(5 BYTE),
  PERIOD_QUARTER      NUMBER(4)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

