/* VERSION: 3.1.1 */ 
--
-- ACH_AR_CODE_TYPES  (Table) 
--
CREATE TABLE AR.ACH_AR_CODE_TYPES
(
  CODE_TYPE_ID            NUMBER(12),
  MAINT_CODE              NUMBER(4),
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATED_ON              DATE,
  UPDATED_BY              VARCHAR2(30 BYTE),
  UPDATED_ON              DATE,
  ACTIVE_FLAG             VARCHAR2(1 BYTE),
  CODE_TYPE_CODE          VARCHAR2(30 BYTE),
  CODE_TYPE_DESCRIPTION   VARCHAR2(512 BYTE),
  USER_MAINTAINABLE_FLAG  VARCHAR2(1 BYTE)
)
TABLESPACE AR_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

