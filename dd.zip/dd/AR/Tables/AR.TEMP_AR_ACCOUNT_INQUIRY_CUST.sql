/* VERSION: 3.1.2 */ 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_ACCOUNT_INQUIRY_CUST  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_ACCOUNT_INQUIRY_CUST
(
  SUBR_ID    VARCHAR2(9 BYTE),
  GRP_ID     VARCHAR2(9 BYTE),
  SUBLOC_ID  VARCHAR2(8 BYTE),
  DIV_ID     VARCHAR2(4 BYTE)
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE AR.TEMP_AR_ACCOUNT_INQUIRY_CUST MODIFY SUBR_ID VARCHAR2(30);

--
-- N2_AR_ACCOUNT_INQUIRY_CUST  (Index) 
--
CREATE INDEX AR.N2_AR_ACCOUNT_INQUIRY_CUST ON AR.TEMP_AR_ACCOUNT_INQUIRY_CUST
(SUBR_ID);

--
-- N1_AR_ACCOUNT_INQUIRY_CUST  (Index) 
--
CREATE INDEX AR.N1_AR_ACCOUNT_INQUIRY_CUST ON AR.TEMP_AR_ACCOUNT_INQUIRY_CUST
(GRP_ID, SUBLOC_ID, DIV_ID);

--
-- TEMP_AR_ACCOUNT_INQUIRY_CUST  (Synonym) 
--
CREATE SYNONYM DCS2000.TEMP_AR_ACCOUNT_INQUIRY_CUST FOR AR.TEMP_AR_ACCOUNT_INQUIRY_CUST;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_ACCOUNT_INQUIRY_CUST TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  AR.TEMP_AR_ACCOUNT_INQUIRY_CUST TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  AR.TEMP_AR_ACCOUNT_INQUIRY_CUST TO OPENCON;

