/* VERSION: 2.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05056.01.KY Correct Payment Posting by DCS2000
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 01/10/2006 
|| Revision Desc  : Added 1 new column:  
||                     TRX_NUMBER 
|| Production Date: 
|| Production By  : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 02/22/2011
|| Revision Desc  : Adding Product line code column
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_AR_CASH_EDIT_TRANSACTIONS  (Table) 
--
TRUNCATE TABLE AR.TEMP_AR_CASH_EDIT_TRANSACTIONS;

DROP TABLE AR.TEMP_AR_CASH_EDIT_TRANSACTIONS;

CREATE GLOBAL TEMPORARY TABLE AR.TEMP_AR_CASH_EDIT_TRANSACTIONS
(
  SUBR_ID             VARCHAR2(9),
  GRP_ID              VARCHAR2(9),
  SUBLOC_ID           VARCHAR2(8),
  DIV_ID              VARCHAR2(4),
  TRX_ID              NUMBER(12),
  TRX_NUMBER          VARCHAR2(15),
  DUE_DATE            DATE,
  BILLING_YEAR_MONTH  NUMBER(6),
  AMOUNT_DUE          NUMBER(15,2)
)
ON COMMIT PRESERVE ROWS;

--
-- TEMP_AR_CASH_EDIT_TRANSACTIONS  (Synonym) 
--
--CREATE SYNONYM DCS2000.TEMP_AR_CASH_EDIT_TRANSACTIONS FOR AR.TEMP_AR_CASH_EDIT_TRANSACTIONS;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_TRANSACTIONS TO AR_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  AR.TEMP_AR_CASH_EDIT_TRANSACTIONS TO DCS2000 WITH GRANT OPTION;

alter table ar.temp_ar_cash_edit_transactions add (product_line_code number(4)); -- 2.1.3