/*  VERSION 3.1.0 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: 10067.02.ALL Multi Product
|| Revision By    : Satya Sai
|| Revision Date  : 10/27/2010
|| Revision Desc  : Product Line Code column added
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
-- AR.ACH_AR_RCPT_INTF_NAMES_PL  (TABLE)

CREATE TABLE AR.ACH_AR_RCPT_INTF_NAMES_PL
(
  AR_RCPT_INTF_NAME_ID  NUMBER(12)              NOT NULL,
  PRODUCT_LINE_CODE     NUMBER(4)               NOT NULL,
  MAINT_CODE            NUMBER(4),
  CREATED_BY            VARCHAR2(30 BYTE)       NOT NULL,
  CREATED_ON            DATE                    NOT NULL,
  UPDATED_BY            VARCHAR2(30 BYTE)       NOT NULL,
  UPDATED_ON            DATE                    NOT NULL,
  ACTION_CODE           VARCHAR2(1 BYTE),
  ACTION_BY             VARCHAR2(30 BYTE),
  ACTION_ON             DATE,
  PARENT_ID             NUMBER(4)               NOT NULL
)
TABLESPACE AR_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


GRANT DELETE, INSERT, SELECT, UPDATE ON AR.ACH_AR_RCPT_INTF_NAMES_PL TO AR_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON AR.ACH_AR_RCPT_INTF_NAMES_PL TO DCS2000 WITH GRANT OPTION;
