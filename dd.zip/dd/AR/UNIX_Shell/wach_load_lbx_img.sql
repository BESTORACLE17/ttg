declare

    ln_errorcode  number;
    lv_errortext  varchar2(1000);

begin

    opencon.prc_load_wach_lockbox_images
	(p_errorcode => ln_errorcode
	,p_errortext => lv_errortext);

end;
/
exit;
/
