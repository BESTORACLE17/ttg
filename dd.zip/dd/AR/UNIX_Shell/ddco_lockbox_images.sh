#!/usr/bin/ksh
. /home/oracle8/.devrelenv
#
sqlload / control=../ctl/ddco_lockbox_images.ctl log=$1.log data=$1
sqlplus / @/scripts/oracle/sh/ddco_lockbox_images.sql
