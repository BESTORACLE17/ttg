#!/usr/bin/ksh
. /home/oracle8/.vadevenv
#
sqlload / control=/scripts/oracle/ctl/wach_load_lbx_img.ctl log=$1.log data=$1
sqlplus / @/scripts/oracle/sh/wach_load_lbx_img.sql
