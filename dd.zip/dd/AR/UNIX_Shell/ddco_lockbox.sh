#!/usr/bin/ksh
. /home/oracle/.devrelenv
#
sqlload / control=/scripts/oracle/ctl/ddco_lockbox.ctl log=$1.log data=$1