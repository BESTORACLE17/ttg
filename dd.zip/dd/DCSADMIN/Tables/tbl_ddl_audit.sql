CREATE TABLE TBL_DDL_AUDIT
(
   audit_id               NUMBER( 5 ),
   audit_date             DATE,
   database_name          VARCHAR2( 50 ),
   trigger_action         VARCHAR2( 20 ),
   object_owner           VARCHAR2( 30 ),
   object_name            VARCHAR2( 30 ),
   object_type            VARCHAR2( 20 ),
   oracle_user            VARCHAR2( 30 ),
   client_ip_address      VARCHAR2( 20 ),
   os_user                VARCHAR2( 30 ),
   terminal               VARCHAR2( 10 ),
   logon_time             DATE
)
TABLESPACE tools;

ALTER TABLE TBL_DDL_AUDIT ADD
(
   CONSTRAINT pk_ddl_audit PRIMARY KEY ( audit_id )
   USING INDEX
   TABLESPACE tools
);