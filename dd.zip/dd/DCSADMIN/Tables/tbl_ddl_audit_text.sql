CREATE TABLE tbl_ddl_audit_text
(
   audit_id               NUMBER( 5 ),
   text_seq               NUMBER( 5 ),
   text                   VARCHAR2( 4000 )
)
TABLESPACE tools;

ALTER TABLE tbl_ddl_audit_text ADD
(
   CONSTRAINT pk_ddl_audit_text PRIMARY KEY ( audit_id, text_seq )
   USING INDEX
   TABLESPACE tools
);

ALTER TABLE tbl_ddl_audit_text ADD
(
   CONSTRAINT fk_ddl_audit_text_2_ddl_audit FOREIGN KEY ( audit_id )
   REFERENCES tbl_ddl_audit ( audit_id )
);
   