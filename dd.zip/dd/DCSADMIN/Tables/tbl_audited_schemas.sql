CREATE TABLE tbl_audited_schemas
(
   ADD_USER             VARCHAR2(30)             NOT NULL,
   ADD_DATE             DATE                     NOT NULL,
   UPDATE_USER          VARCHAR2(30)             NOT NULL,
   UPDATE_DATE          DATE                     NOT NULL,
   schema_owner         VARCHAR2( 30 ),
   active_flag          VARCHAR2( 1 ) CHECK ( active_flag IN ( 'Y', 'N' ) )
)
TABLESPACE tools;

ALTER TABLE tbl_audited_schemas ADD
(
   CONSTRAINT pk_audited_schemas PRIMARY KEY ( schema_owner )
   USING INDEX
   TABLESPACE tools
); 


