/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_ERROR  (Table) 
--
CREATE TABLE DCSADMIN.TBL_CODE_ERROR
(
  MAINT_CODE         NUMBER(1),
  MOD_DATE           DATE,
  MOD_OP             VARCHAR2(12 BYTE),
  ERROR_TYPE_ID      NUMBER(5)                  NOT NULL,
  ERROR_CODE         VARCHAR2(30 BYTE)          NOT NULL,
  ERROR_DESCRIPTION  VARCHAR2(200 BYTE)         NOT NULL
)
TABLESPACE TOOLS
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CODE_ERROR  (Index) 
--
CREATE UNIQUE INDEX DCSADMIN.PK_CODE_ERROR ON DCSADMIN.TBL_CODE_ERROR
(ERROR_TYPE_ID, ERROR_CODE)
LOGGING
TABLESPACE TOOLS
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_ERROR 
-- 
ALTER TABLE DCSADMIN.TBL_CODE_ERROR ADD (
  CONSTRAINT PK_CODE_ERROR PRIMARY KEY (ERROR_TYPE_ID, ERROR_CODE)
    USING INDEX 
    TABLESPACE TOOLS
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          32K
                NEXT             32K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_CODE_ERROR 
-- 
ALTER TABLE DCSADMIN.TBL_CODE_ERROR ADD (
  CONSTRAINT FK_CODE_ERROR_2_ERROR_TYPE FOREIGN KEY (ERROR_TYPE_ID) 
    REFERENCES DCSADMIN.TBL_CODE_ERROR_TYPE (ERROR_TYPE_ID));


