declare
   g_LogFileDir               VARCHAR2(30) ;
   g_LogFileName              VARCHAR2(30) ;
   g_LogFileHandle            UTL_FILE.FILE_TYPE ;
   
   
   LV_PROC_NAME               VARCHAR2(30);
   LV_PKG_CALL                VARCHAR2(5000) := NULL;
   cursor cur1
   is
   select 'TYP_' || SUBSTR(TABLE_NAME,5) RECORD_TYPE
        , TABLE_NAME
        , owner
     from dba_tables
    where table_name in ( 'TBL_GSD_CARRY_OVER_PRCS'
                        , 'TBL_GSD_PROCEDURE_OVERRIDE'
                        )
       order by owner, table_name;
       
   cursor c_pkg_calls (p_owner varchar2, p_table_name varchar2)
   is
   select argument_name, data_type , in_out , sequence
     from ALL_ARGUMENTS
    where owner = p_owner
      and package_name = 'PKG_DCS_DEL_GRP'
      and object_name  = 'PRC_DEL_'||SUBSTR(P_TABLE_NAME,5)
      and argument_name not in ('P_TABLEOWNER','P_TABLENAME')
    order by sequence ;    
       
begin
   
   g_LogFileDir := DCS2000.Pkg_Dcs_Utl_File.FNC_utl_file_dir ;

   IF  g_LogFileDir IS NULL
   THEN
      RAISE_APPLICATION_ERROR( -20001, 'Log file Directory name could not be found');
   END IF ;
      
   g_LogFileName  := 'GROUPS.PKG_DELETE.PKB';

   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_open
      ( g_LogFileHandle
       ,g_LogFileDir
       ,g_LogFileName
       ,DCS2000.Pkg_Dcs_Utl_File.DCS_OEPN_FILE_WRITE_MODE ) ;
          
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--==================================================================');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--S/R 09069.02.AR Load Group from DDAR''s Proposal System');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Version       2.1.1');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Date          MM/DD/YYYY');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Created By    <<NAME>>');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Description   <<DESCRIPTION>>');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--==================================================================');
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '');
          
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' CREATE OR REPLACE PACKAGE /* VERSION 2.1.1 */ BODY GROUPS.PKG_DELETE ');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' IS ');
   
   FOR REC IN CUR1
   LOOP
      IF LENGTH('PRC_DEL_' || SUBSTR(REC.TABLE_NAME,5)) <= 30
      THEN
         DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    PROCEDURE PRC_DEL_' || SUBSTR(REC.TABLE_NAME,5));
         LV_PROC_NAME := 'PRC_DEL_' || SUBSTR(REC.TABLE_NAME,5);
      ELSE
         DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    PROCEDURE PRC_DEL_' || SUBSTR(REC.TABLE_NAME,9));
         LV_PROC_NAME := 'PRC_DEL_' || SUBSTR(REC.TABLE_NAME,9);
      END IF;
      
            LV_PKG_CALL := null;
      FOR rec_pkg_call IN c_pkg_calls (REC.OWNER,REC.TABLE_NAME )
      LOOP
          lv_pkg_call := lv_pkg_call
                         ||case when rec_pkg_call.sequence = 1 
                                then ' '
                                else '             ,' 
                           end
                         ||rpad(rec_pkg_call.argument_name,35,' ')
                         ||'=>'||chr(9)
                         ||case when upper(rec_pkg_call.argument_name) = 'P_ERRORCODE' 
                                then 'ln_error_code'
                                when upper(rec_pkg_call.argument_name) = 'P_ERRORTEXT' 
                                then 'lv_error_text'
                                when upper(rec_pkg_call.argument_name) = 'P_DATE' 
                                then 'ld_date'
                                when upper(rec_pkg_call.argument_name) = 'P_COMMITFLAG' 
                                then 'FALSE'
                                when upper(rec_pkg_call.argument_name) like '%TRM_%_FLAG' 
                                then 'FALSE'
                                else 'p_record.'||substr(rec_pkg_call.argument_name,3)
                           end
                         ||chr(10);
      END LOOP;
            
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       ( P_RECORD      IN GROUPS.PKG_TYPES.' || REC.RECORD_TYPE || '%TYPE');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       )');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    IS ');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       lt_ERRORS      GROUPS.PKG_TYPES.TAB_ERRORS;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       ln_error_code  number;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       lv_error_text  varchar2(4000);');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       ld_date        date;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    BEGIN ');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       groups.pkg_validate_record.prc_val_gsd (p_record => p_record , p_action_code => GROUPS.pkg_load.c_delete);');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       IF (groups.pkg_load.g_tab_errors.count = 0)');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       THEN') ;
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           groups.pkg_validate_fields.prc_val_gsd (p_record => p_record);');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           IF (groups.pkg_load.g_tab_errors.count = 0)');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           THEN') ;
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '              dcs2000.pkg_dcs_del_grp.prc_del_'||lower(SUBSTR(REC.TABLE_NAME,5)));
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '                 ('||LV_PKG_CALL);
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '                 ); ');         
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           NULL; ');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           ELSE');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           -- Populate errors');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           NULL;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           END IF;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           IF (ln_error_code != 0)');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           THEN');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           -- Populate errors');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '              GROUPS.PKG_LOAD.G_TAB_ERRORS(1).recordpk    := p_record.record_pk;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '              GROUPS.PKG_LOAD.G_TAB_ERRORS(1).tablename   := ''RAW_'||(SUBSTR(REC.TABLE_NAME,5))||''';');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '              GROUPS.PKG_LOAD.G_TAB_ERRORS(1).errorcode   := ln_error_code;');      
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '              GROUPS.PKG_LOAD.G_TAB_ERRORS(1).description := lv_error_text;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '           END IF;');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       END IF;');      
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    END ' || LV_PROC_NAME || '; ');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '');
   END LOOP;
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' END PKG_DELETE;');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' /');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_close ( g_LogFileHandle );
END;
   
   
      
   