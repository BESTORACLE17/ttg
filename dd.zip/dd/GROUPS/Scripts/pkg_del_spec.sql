declare
   g_LogFileDir               VARCHAR2(30) ;
   g_LogFileName              VARCHAR2(30) ;
   g_LogFileHandle            UTL_FILE.FILE_TYPE ;
   
   cursor cur1
   is
   select 'TYP_' || SUBSTR(TABLE_NAME,5) RECORD_TYPE
        , TABLE_NAME
     from dba_tables
    where table_name in (  'TBL_GRP'
                        , 'TBL_GSD'
                        , 'TBL_GSD_BENEFIT_POINTERS'
                        , 'TBL_GSD_ADDRESS'
                        , 'TBL_GSD_AGE_LMT'
                        , 'TBL_GSD_BILLING'
                        , 'TBL_GSD_CARRY_OVER_BENEFITS'
                        , 'TBL_GSD_CLASS'
                        , 'TBL_GSD_CONDITION'
                        , 'TBL_GSD_CONTACTS'
                        , 'TBL_GSD_CONTRACT'
                        , 'TBL_GSD_CONTRACT_PERIODS'
                        , 'TBL_GSD_COVERAGE'
                        , 'TBL_GSD_DEDUCTIBLE_RULE'
                        , 'TBL_GSD_MAXIMUM_RULE'
                        , 'TBL_GSD_OPEN_ENROLL'
                        , 'TBL_GSD_POOL_NO'
                        , 'TBL_GSD_PRD_PLAN'
                        , 'TBL_GSD_PRODUCER'
                        , 'TBL_GSD_RATE'
                        , 'TBL_GSD_RELIABILITY'
                        , 'TBL_GSD_UNDERWRITING'
                       )
       or (owner = 'EEP' and table_name = 'TBL_EE_FEED_SUBMITTED_GSD') 
       order by owner, table_name;
begin
   
   g_LogFileDir := DCS2000.Pkg_Dcs_Utl_File.FNC_utl_file_dir ;

   IF  g_LogFileDir IS NULL
   THEN
      RAISE_APPLICATION_ERROR( -20001, 'Log file Directory name could not be found');
   END IF ;
      
   g_LogFileName  := 'GROUPS.PKG_DELETE.PKS';

   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_open
      ( g_LogFileHandle
       ,g_LogFileDir
       ,g_LogFileName
       ,DCS2000.Pkg_Dcs_Utl_File.DCS_OEPN_FILE_WRITE_MODE ) ;
          
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--==================================================================');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--S/R 09069.02.AR Load Group from DDAR''s Proposal System');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Version       2.1.1');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Date          MM/DD/YYYY');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Created By    <<NAME>>');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--Description   <<DESCRIPTION>>');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '--==================================================================');
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '');
          
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' CREATE OR REPLACE PACKAGE /* VERSION 2.1.1 */ GROUPS.PKG_DELETE ');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' IS ');
   
   FOR REC IN CUR1
   LOOP
      
      IF LENGTH('PRC_DEL_' || SUBSTR(REC.TABLE_NAME,5)) <= 30
      THEN
         DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    PROCEDURE PRC_DEL_' || SUBSTR(REC.TABLE_NAME,5));
      ELSE
         DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '    PROCEDURE PRC_DEL_' || SUBSTR(REC.TABLE_NAME,9));
      END IF;
      
      
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       ( P_RECORD      IN GROUPS.PKG_TYPES.' || REC.RECORD_TYPE || '%TYPE');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       , P_ERRORS     OUT GROUPS.PKG_TYPES.TAB_ERRORS');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '       );');
      DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, '');
   END LOOP;
   
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' END PKG_DELETE;');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( g_LogFileHandle, ' /');
   DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_close ( g_LogFileHandle );
END;
   
   
      
   