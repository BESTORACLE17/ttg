declare
   g_logfiledir                  varchar2(30) ;
   g_logfilename                 varchar2(30) ;
   g_logfilehandle               utl_file.file_type ;
   
   
   lv_proc_name                  varchar2(30);
   lv_pkg_load_add               varchar2(5000) := null;
   
   cursor cur1
   is
   select 'TYP_' || substr(table_name,5) record_type
        , table_name
        , owner
     from dba_tables
    where table_name in ( 'TBL_GSD_CARRY_OVER_PRCS'
                        , 'TBL_GSD_PROCEDURE_OVERRIDE'
                       )
       order by owner, table_name;

begin
   
   g_logfiledir := dcs2000.pkg_dcs_utl_file.fnc_utl_file_dir ;

   if  g_logfiledir is null
   then
      raise_application_error( -20001, 'Log file Directory name could not be found');
   end if ;
      
   g_logfilename  := 'GROUPS.PKG_PROCESS_ADD.PKB';

   dcs2000.pkg_dcs_utl_file.prc_utl_file_open
      ( g_logfilehandle
       ,g_logfiledir
       ,g_logfilename
       ,dcs2000.pkg_dcs_utl_file.dcs_oepn_file_write_mode ) ;
          
   
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--==================================================================');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--S/R 09069.02.AR Load Group from DDAR''s Proposal System');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--Version       2.1.1');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--Date          MM/DD/YYYY');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--Created By    <<NAME>>');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--Description   <<DESCRIPTION>>');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '--==================================================================');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, ' CREATE OR REPLACE PACKAGE /* VERSION 2.1.1 */ BODY GROUPS.PKG_PROCESS_ADD ');
   dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, ' IS ');

   for rec in cur1
   loop
      if length('PRC_ADD_' || substr(rec.table_name,5)) <= 30
      then
         lv_pkg_load_add   := 'PROCEDURE PRC_ADD_'|| substr(rec.table_name,5);
         lv_proc_name :=  substr(rec.table_name,5);

      else
         lv_pkg_load_add   := '    PROCEDURE PRC_ADD_'|| substr(rec.table_name,9);
         lv_proc_name :=  substr(rec.table_name,9);
      end if;


      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    '||lv_pkg_load_add);            
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        ( p_grp_id           dcs2000.tbl_gsd.grp_id%type'); 
--      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        , p_errors     out   groups.pkg_types.tab_errors'); 
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        )');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    IS ');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    ln_count        number;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    lv_skip_process        varchar2(1) := ''N'';');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    BEGIN ');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       groups.pkg_load.g_debug_info := ''Process '||upper(replace(substr(rec.table_name,5),'_',' '))||'.'' || p_grp_id || ''-'' || p_ben_subloc_id || ''-'' || p_ben_div_id;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       ltab_'||substr(rec.table_name,5)||'.delete;');      
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       if p_grp_id is null');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, '' '');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, ''=========================== '');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, ''PROCESS '||upper(replace(substr(rec.table_name,5),'_',' '))||''');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, ''=========================== '');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, '' '');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          DCS2000.Pkg_Dcs_Utl_File.PRC_utl_file_write ( groups.pkg_load.g_LogFileHandle, ''Started at: '' || TO_CHAR(SYSDATE, ''MM-DD-YYYY HH:MI:SS AM'' ));');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          if groups.pkg_load.fnc_get_step_status(groups.pkg_load.c_process_'||substr(rec.table_name,9)||' = ''F'')');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '             groups.pkg_load.prc_start_step(groups.pkg_load.c_process_'||substr(rec.table_name,9)||');');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          else');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '             lv_skip_process := ''Y'';');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '            ');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       if lv_skip_process = ''N''');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          begin');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '              select *');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                bulk collect into ltab_'||substr(rec.table_name,5)); 
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                from groups.raw_'||substr(rec.table_name,5));
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '               where (p_grp_id is null or grp_id = p_grp_id)');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                 and action_code   = c_add ');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                 and error_code    is null ;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          exception');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '             when no_data_found then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                null;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          end;');        
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');      
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        if ltab_'||substr(rec.table_name,5)||'.count > 0 then ');      
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '           for idx_gsd in ltab_'||substr(rec.table_name,5)||'.first .. ltab_'||substr(rec.table_name,5)||'.last');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '           loop');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '              groups.pkg_add.prc_add_'||substr(rec.table_name,5)||' (ltab_'||substr(rec.table_name,5)||'(idx_gsd));');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  if groups.pkg_load.g_tab_errors.count = 0');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     g_count := g_count + 1;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     g_tab_record_pks(g_count).table_name := '''||rec.table_name||''';');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     g_tab_record_pks(g_count).record_pk := ltab_'||substr(rec.table_name,5)||' (idx_gsd).record_pk;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  if p_grp_id is null');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     prc_update_raw_record_status;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  else');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     if p_grp_id is not null');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                        exit;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     else');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                        g_error_codes := groups.pkg_process_add.fnc_get_error_codes(pkg_load.g_tab_errors);');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                       prc_cascade_err_to_child_tabs');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                            ( p_cascade_from      => g_entry_point');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                            , p_errorCode         => g_error_codes');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                            , p_record_pk         => ltab_'||substr(rec.table_name,5)||' (idx_gsd).record_pk');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                            , p_table_name        => '''||rec.table_name||'''');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                            );');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                     end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '                  end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '            end loop;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       if p_grp_id is null');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          groups.pkg_load.prc_update_step_status(groups.pkg_load.c_process_billing, groups.pkg_load.c_success);');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '          dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( groups.pkg_load.g_LogFileHandle, ''Finished at: '' || to_char(sysdate, ''MM-DD-YYYY HH:MI:SS AM'' ));');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '       end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    exception');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    when others then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        groups.pkg_load.g_debug_info := '''||upper(replace(substr(rec.table_name,5),'_',' '))||' :: '' || sqlerrm || ''::'' || p_grp_id || ''-'' || p_subloc_id || ''-'' || p_div_id;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        if p_ben_grp_id is not null');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        then');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '           raise;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        else');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '           groups.pkg_load.g_tab_errors(1).recordpk := -1;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '        end if;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '    end prc_add_'||lv_proc_name ||'; ');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, '');
end loop;
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, ' end pkg_process_add;');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write ( g_logfilehandle, ' /');
      dcs2000.pkg_dcs_utl_file.prc_utl_file_close ( g_logfilehandle);
end;
      
   