/* CREATE TABLESPACES GROUP_DATA, GROUP_INDEX  
--create tablespace group_data 
--  datafile '/u10/oradata/DEVREL/group_data01.dbf' size 1000M autoextend off
--  logging
--  extent management local uniform size 1M;

--create tablespace group_index 
--  datafile '/u10/oradata/DEVREL/group_index01.dbf' size 1000M autoextend off
--  logging
--  extent management local uniform size 1M; 
*/ 

/* CREATE USER GROUPS 
--create user groups identified by groups default tablespace group_data temporary tablespace temp;
*/

/* CREATE TABLE SCRIPTS AND CONTROL FILE */
declare
   cursor c_group_tables
   is
      select *
        from dba_tables
       where (owner       = 'DCS2000'
         and table_name in (  'TBL_GRP'
                            , 'TBL_GSD'
                            , 'TBL_GSD_BENEFIT_POINTERS'
                            , 'TBL_GSD_ADDRESS'
                            , 'TBL_GSD_AGE_LMT'
                            , 'TBL_GSD_BILLING'
                            , 'TBL_GSD_CARRY_OVER_BENEFITS'
                            , 'TBL_GSD_CLASS'
                            , 'TBL_GSD_CONDITION'
                            , 'TBL_GSD_CONTACTS'
                            , 'TBL_GSD_CONTRACT'
                            , 'TBL_GSD_CONTRACT_PERIODS'
                            , 'TBL_GSD_COVERAGE'
                            , 'TBL_GSD_DEDUCTIBLE_RULE'
                            , 'TBL_GSD_MAXIMUM_RULE'
                            , 'TBL_GSD_OPEN_ENROLL'
                            , 'TBL_GSD_POOL_NO'
                            , 'TBL_GSD_PRD_PLAN'
                            , 'TBL_GSD_PRODUCER'
                            , 'TBL_GSD_RATE'
                            , 'TBL_GSD_RELIABILITY'
                            , 'TBL_GSD_UNDERWRITING'
                           ))
           or (owner = 'EEP' and table_name = 'TBL_EE_FEED_SUBMITTED_GSD') 
           order by owner, table_name;
   cursor c_group_table_columns (  p_owner            dba_tables.owner%type
                                 , p_table_name       dba_tables.table_name%type)
   is
      select a.*
           , case when data_type in ('CHAR', 'VARCHAR2') then CASE WHEN data_length >200 THEN 200 ELSE data_length end
                  when data_type in ('NUMBER')           then CASE WHEN TABLE_NAME = 'TBL_GSD_BILLING' AND COLUMN_NAME ='ELIG_END_DAY' THEN  1
                                                                   WHEN TABLE_NAME = 'TBL_GSD_PRD_PLAN' AND COLUMN_NAME ='ID_CARD_PRINT_EOC' THEN 1
                                                                   ELSE ( NVL(data_precision, 12)) END
                  when data_type in ('DATE')             then 14
                  else                                        100
              end  column_length
        from dba_tab_columns a
       where owner      = p_owner
         and table_name = p_table_name
         and column_name not like substr(table_name, 5) || '_PK'
       order by column_id;
   lv_table_name        varchar2(30);
   lv_sql_string        varchar2(8000);
   lv_file_name         varchar2(100) ;
   lv_ctl_file_name     varchar2(100)      := 'grs.ctl';
   lv_pkg_file_name     varchar2(100)      := 'GROUPS.PKG_TYPES.pks';
   f_handle             utl_file.file_type;
   f_ctl_handle         utl_file.file_type;
   f_pkg_handle         utl_file.file_type;
   LN_NEXT_COUNTER      number; 
   LN_CURR_COUNTER      number;
   procedure inp_write_options
   is
   begin
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'OPTIONS (ERRORS=50)');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'LOAD DATA');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'DISCARDMAX 50');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'INSERT');
   end;
   procedure inp_write_package_create
   is
   begin
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_PKG_handle, 'CREATE OR REPLACE PACKAGE GROUPS.PKG_TYPES ');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_PKG_handle, 'IS ');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_PKG_handle, '   ' || RPAD('TYP_ERRORS', 35, ' ') || 'GROUPS.TBL_ERRORS%ROWTYPE;');
   end;
begin
   DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_OPEN 
      (   p_filehandle           => f_pkg_handle
        , p_filedir              => dcs2000.pkg_dcs_utl_file.fnc_utl_file_dir
        , p_filename             => lv_pkg_file_name
        , p_openmode             => dcs2000.pkg_dcs_utl_file.DCS_OPEN_FILE_WRITE_MODE
        , p_max_linesize         => 8000
      );
   DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_OPEN 
      (   p_filehandle           => f_ctl_handle
        , p_filedir              => dcs2000.pkg_dcs_utl_file.fnc_utl_file_dir
        , p_filename             => lv_ctl_file_name
        , p_openmode             => dcs2000.pkg_dcs_utl_file.DCS_OPEN_FILE_WRITE_MODE
        , p_max_linesize         => 8000
      );
   inp_write_options;
   inp_write_package_create;
   for rec_tables in c_group_tables
   loop
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_pkg_handle, RPAD('   TYP_' || SUBSTR(REC_TABLES.TABLE_NAME, 5), 35, ' ') || '   GROUPS.' || 'TYP_' || SUBSTR(REC_TABLES.TABLE_NAME, 5) || '%ROWTYPE;');
      LN_CURR_COUNTER := 7;
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'INTO TABLE ' || 'GROUPS.RAW_' || substr(rec_tables.table_name, 5));
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'WHEN (1:4)="1001"');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, 'TRAILING  NULLCOLS');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, '(');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, '  ' || RPAD('ID',   35, ' ') || 'CONSTANT ' || '''' || '1' || '''');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ', ' || RPAD('RECORD_PK',   35, ' ') || 'GROUPS.SEQ_GROUP_LOAD.NEXTVAL');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ', ' || RPAD('RECORD_ID',   35, ' ') || 'POSITION ( 1:4) CHAR');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ', ' || RPAD('ACTION_CODE', 35, ' ') || 'POSITION ( 5:5) CHAR');
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ', ' || RPAD('ERROR_FLAG',  35, ' ') || 'POSITION ( 6:6) CHAR');
      lv_file_name  := 'GROUPS.RAW_' || substr(rec_tables.table_name, 5) || '.sql';
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_OPEN 
         (   p_filehandle           => f_handle
           , p_filedir              => dcs2000.pkg_dcs_utl_file.fnc_utl_file_dir
           , p_filename             => lv_file_name
           , p_openmode             => dcs2000.pkg_dcs_utl_file.DCS_OPEN_FILE_WRITE_MODE
           , p_max_linesize         => 8000
         );
      lv_sql_string := 'CREATE TABLE GROUPS.RAW_' || substr(rec_tables.table_name, 5) || ' ( ';
      lv_sql_string := lv_sql_string || chr(10) || '   ' || rpad('ID', 35, ' ') || 'NUMBER(2) NOT NULL,';
      lv_sql_string := lv_sql_string || chr(10) || '   ' || rpad('RECORD_PK', 35, ' ') || 'NUMBER(12) NOT NULL,';
      lv_sql_string := lv_sql_string || chr(10) || '   ' || rpad('RECORD_ID', 35, ' ') || 'CHAR(4),';
      lv_sql_string := lv_sql_string || chr(10) || '   ' || rpad('ACTION_CODE', 35, ' ') || 'CHAR(1),';
      lv_sql_string := lv_sql_string || chr(10) || '   ' || rpad('ERROR_FLAG', 35, ' ') || 'CHAR(1),';
      for rec_table_columns in c_group_table_columns (rec_tables.owner, rec_tables.table_name)
      loop
         lv_sql_string := lv_sql_string || CHR(10) || '   ' || rpad(rec_table_columns.column_name, 35, ' ') || 'CHAR ( ' || rec_table_columns.column_length || '),'; 
         if rec_table_columns.column_name not in ('MAINT_CODE', 'MOD_DTE', 'MOD_OP')
         then
            LN_NEXT_COUNTER := LN_CURR_COUNTER + rec_table_columns.column_length - 1; 
            DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ', ' || rpad(rec_table_columns.column_name, 35, ' ') || 'POSITION ( ' || LN_CURR_COUNTER || ':' || LN_NEXT_COUNTER || ') CHAR');
            LN_CURR_COUNTER := LN_NEXT_COUNTER + 1;
         end if;
      end loop;
      lv_sql_string := rtrim(lv_sql_string, ',');
      lv_sql_string := lv_sql_string || CHR(10) || ')' || CHR(10)
                    || ' TABLESPACE GROUP_DATA '                            || CHR(10) 
                    || ' PARTITION BY LIST (ID) '                           || CHR(10) 
                    || ' ( '                                                || CHR(10) 
                    || ' PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,' || CHR(10) 
                    || ' PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA ' || CHR(10) || ' );';
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_handle, lv_sql_string);
      if utl_file.is_open (f_handle)
      then
         utl_file.fclose (f_handle);
      end if; 
      DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_ctl_handle, ')');
   end loop;
   DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_PKG_handle, '   ' || RPAD('TAB_ERRORS', 35, ' ') || 'IS TABLE OF TYP_ERRORS;');
   DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_pkg_handle, 'END PKG_TYPES;');
   DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_WRITE (f_pkg_handle, '/');
   if utl_file.is_open (f_ctl_handle)
   then
      utl_file.fclose (f_ctl_handle);
   end if;    
   if utl_file.is_open (f_pkg_handle)
   then
      utl_file.fclose (f_pkg_handle);
   end if;    
end;
/
