#. /home/oracle/.devrelenv
ENV_LOC=`echo .$2 |  tr 'A-Z' 'a-z'`
. /home/oracle/${ENV_LOC}env
FPATH="/scripts/oracle/sh/$2/groupload"
#
#Script to validate load file
#
#FILENAME=`echo $1 | cut -d/ -f7`
echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
echo "Shell script validation log" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
echo "FPATH $FPATH " >> $UTL_DIR/GroupLoadProcess.$2.$1.log

if [ "$1" ]
then
  if [ -f $FPATH/dat/*$1.dat ]
  then
    echo "File exists with sequence $1 " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    FILENAME=`ls $FPATH/dat/*.$1.dat | cut -d/ -f8 | cut -d. -f1,2`
    echo "FILENAME $FILENAME " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    FILEROWCNT=`wc -l $FPATH/dat/$FILENAME.dat | awk '{ print $1 }'`
    echo "FILEROWCNT $FILEROWCNT " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
#   FILESEQ=`echo $FILENAME | cut -d. -f2`
    FILESEQ=$1
    echo "FILESEQ $FILESEQ " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    HDRSEQ=`head -1 $FPATH/dat/$FILENAME.dat | awk '{ print $2 }' | cut -c-15-`
    echo "HDRSEQ $HDRSEQ " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    TAILCNT=`tail -1 $FPATH/dat/$FILENAME.dat | awk '{ print $2 }'`
    echo "TAILCNT $TAILCNT " >> $UTL_DIR/GroupLoadProcess.$2.$1.log
   LOADCNT=`expr $FILEROWCNT - 2`
   echo "Test 1" >>$UTL_DIR/GroupLoadProcess.$2.$1.log
   echo "Test 2" >>$UTL_DIR/GroupLoadProcess.$2.$1.log
   echo "LOADCNT $LOADCNT" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
   echo "Test 3" >>$UTL_DIR/GroupLoadProcess.$2.$1.log
    if [ $FILEROWCNT -eq $TAILCNT ]
    then 
       echo "Record Count matched" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    else
       echo "Record Count not matching" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    exit 1
    fi
    if [ $HDRSEQ -ne $FILESEQ ]
    then
    	ERRMSG="File sequence did not match with header sequence.\n"
    	echo $ERRMSG  >> $UTL_DIR/ARLOAD.$1.log
    	exit 1
    fi
    echo "FILEROW CNT $FILEROWCNT" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    SEQNO=`sqlplus -s /  <<EOF
	SET ECHO OFF
	SET FEEDBACK OFF
	SET HEADING OFF
	SELECT nvl(max(file_seq),0) FROM groups.tbl_data_load_header;
	EXIT
	EOA
	`
#    echo "count $SEQNO"  >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    SEQNO=`expr $SEQNO + 1`
#    echo "INCREMENT count $SEQNO"  >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    if [ $SEQNO -ne $FILESEQ ]
    then
    	ERRMSG="Sequence File already loaded.\n"
    	echo $ERRMSG  >> $UTL_DIR/GroupLoadProcess.$2.$1.log
    	exit 1
    fi
   sqlldr / control=$FPATH/ctl/GroupDataLoad.ctl skip=1 log=$UTL_DIR/$FILENAME.log bad=$FPATH/log/$FILENAME.BAD data=$FPATH/dat/$FILENAME.dat load=$LOADCNT

#   echo `$?` >> $UTL_DIR/GroupLoadProcess.$2.$1.log
   	if [[ $? != 0 ]]
   	then
   		cat $UTL_DIR/$FILENAME.log >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "There were errors during the load process." >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "Please check the log file for details." >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		exit 1
   	else
     		echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "Sql Loader log" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		echo "***********************************************************" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		cat $UTL_DIR/$FILENAME.log >> $UTL_DIR/GroupLoadProcess.$2.$1.log
     		sqlout=`sqlplus -s / @$FPATH/sql/Insert_header.sql $FILENAME $FILESEQ $FILEROWCNT`
     		echo "sqlout : $sqlout" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
  	fi
  else
   ERRMSG="File not found with sequence $1 .\n"
   echo $ERRMSG >> $UTL_DIR/GroupLoadProcess.$2.$1.log
   exit 1
  fi
else 
echo "not a valid Sequence number.\n" >> $UTL_DIR/GroupLoadProcess.$2.$1.log
exit 1
fi
