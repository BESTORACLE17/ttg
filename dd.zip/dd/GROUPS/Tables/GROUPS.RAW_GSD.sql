CREATE TABLE GROUPS.RAW_GSD ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   EFF_DTE                            CHAR ( 8),
   TRM_DTE                            CHAR ( 8),
   GRP_NME                            CHAR ( 100),
   RELIABILITY                        CHAR ( 1),
   RELIABILITY_GRC_PERIOD             CHAR ( 2),
   OCCUPATION_CDE                     CHAR ( 4),
   INDUSTRY_NO                        CHAR ( 4),
   BUS_TYPE                           CHAR ( 2),
   SIC_CODE                           CHAR ( 4),
   ST_WITHHOLD_OVERRIDE               CHAR ( 1),
   AOB_OVERRIDE                       CHAR ( 1),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   NEI                                CHAR ( 9),
   MEDICAL_COB_RVW                    CHAR ( 1),
   IS_SENSITIVE_GROUP                 CHAR ( 1),
   NAICS_CODE                         CHAR ( 6),
   GSD_EFF_DTE                        CHAR ( 8),
   ALT_GRP_NME_1                      CHAR ( 100),
   ALT_GRP_NME_2                      CHAR ( 100),
   ORTHO_CONT_MM                      CHAR ( 4),
   GRP_SUBMITTED_MBR_ID_TYP_CDE       CHAR ( 4),
   GRP_CORRESP_MBR_ID_TYP_CDE         CHAR ( 4),
   OTHER_CORRESP_MBR_ID_TYP_CDE       CHAR ( 4),
   MASK_SUBRID_GRP_CORRESP_FLAG       CHAR ( 1),
   MASK_SUBRID_OTHER_CORRESP_FLAG     CHAR ( 1),
   IVR_OUTPUT_FLAG                    CHAR ( 1)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
