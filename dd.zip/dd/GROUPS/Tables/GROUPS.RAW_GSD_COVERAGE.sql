CREATE TABLE GROUPS.RAW_GSD_COVERAGE ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   COVER_PERIOD_ID                    CHAR ( 4),
   COVER_BEGIN_DTE                    CHAR ( 8),
   COVER_END_DTE                      CHAR ( 8),
   COMB_DED_WITHIN_GRP                CHAR ( 1),
   COMB_MAX_WITHIN_GRP                CHAR ( 1),
   COMB_WITH_GRP_ID                   CHAR ( 9),
   COMB_WITH_SUBLOC_ID                CHAR ( 8),
   COMB_WITH_DIV_ID                   CHAR ( 4),
   COMB_WITH_COVER_PERIOD_ID          CHAR ( 4),
   COMB_DED_WITH_GRP                  CHAR ( 1),
   COMB_MAX_WITH_GRP                  CHAR ( 1),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   SUBR_ELIG_EFF                      CHAR ( 1)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
