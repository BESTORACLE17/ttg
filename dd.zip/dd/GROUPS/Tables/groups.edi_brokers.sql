-- Create table
create table GROUPS.EDI_BROKERS
(
  GROUPS_PK          NUMBER(12) not null,
  GROUPS_BROKER_PK   NUMBER(12) not null,
  BROKER_NAME        VARCHAR2(60) not null,
  BROKER_TIN         VARCHAR2(9) not null,
  BROKER_ACCOUNT_NBR VARCHAR2(35),
  CONTACT_FIRST_NAME VARCHAR2(35),
  CONTACT_LAST_NAME  VARCHAR2(60),
  PRIMARY_TEL_NUM    VARCHAR2(10),
  PRIMARY_TEL_XNUM   VARCHAR2(4),
  ALTERNATE_TEL_NUM  VARCHAR2(10),
  EMAIL_ADDRESS      VARCHAR2(256),
  FAX_NUMBER         VARCHAR2(10),
  PREF_CONTACT_MODE  VARCHAR2(10),
  MAINT_CODE         NUMBER(4) not null,
  CREATED_BY         VARCHAR2(30) not null,
  CREATED_ON         DATE not null,
  UPDATED_BY         VARCHAR2(30) not null,
  UPDATED_ON         DATE not null,
  PARENT_ID          NUMBER(4) not null,
  BROKER_ADDRESS1    VARCHAR2(55),
  BROKER_ADDRESS2    VARCHAR2(55),
  BROKER_CITY        VARCHAR2(30),
  BROKER_STATE       VARCHAR2(2),
  BROKER_ZIP         VARCHAR2(10)
)
tablespace GROUP_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table GROUPS.EDI_BROKERS
  add constraint PK_EDI_BROKERS primary key (GROUPS_PK, GROUPS_BROKER_PK, PARENT_ID)
  using index 
  tablespace GROUP_INDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
alter table GROUPS.EDI_BROKERS
  add constraint FK_EDI_BROKERS foreign key (GROUPS_PK, PARENT_ID)
  references GROUPS.EDI_GROUPS (GROUPS_PK, PARENT_ID);
-- Grant/Revoke object privileges 
grant select, insert, update, delete on GROUPS.EDI_BROKERS to DCS_USERS_ALL;
