
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.0.0
|| Revision Type  : Enhancement
|| Service Request: 11077.01.VA 
|| Revision By    : SATYA SAI
|| Revision Date  : 04/22/2011 
|| Revision Desc  : Added LOSS_RATIO_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

CREATE TABLE GROUPS.RAW_GSD_PRD_PLAN ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   PRD_CDE                            CHAR ( 4),
   PLN_CDE                            CHAR ( 4),
   GSD_PP_BEGIN_DTE                   CHAR ( 8),
   GSD_PP_END_DTE                     CHAR ( 8),
   AUTO_ADD_DPND                      CHAR ( 1),
   DELTAUSA                           CHAR ( 1),
   MULTI_ST_ACC_IND                   CHAR ( 1),
   DEDUCT_CALC                        CHAR ( 1),
   COB_COVER_TYPE_CDE                 CHAR ( 2),
   GL_PREM_ACCT_NO                    CHAR ( 20),
   GL_CLAIM_ACCT_NO                   CHAR ( 20),
   GL_ADMIN_ACCT_NO                   CHAR ( 20),
   PRICING_SET_NO                     CHAR ( 4),
   HIST_XCHK_SET_NO                   CHAR ( 8),
   PAR_PERCENT_CDE                    CHAR ( 4),
   NONPAR_PERCENT_CDE                 CHAR ( 4),
   NONFILED_PERCENT_CDE               CHAR ( 4),
   PAR_TOA                            CHAR ( 4),
   NONPAR_TOA                         CHAR ( 4),
   PAR_RTOA                           CHAR ( 4),
   NONPAR_RTOA                        CHAR ( 4),
   DC_REIMBURSE_PERCENT               CHAR ( 5),
   ID_CARD_CDE                        CHAR ( 2),
   ID_CARD_MAILTO_CDE                 CHAR ( 2),
   ID_CARD_INT_ISSUE_DTE              CHAR ( 8),
   ID_CARD_EFF_DTE_IND                CHAR ( 1),
   ID_CARD_COMP_NAME                  CHAR ( 2),
   EOC_BOOKLET_NO                     CHAR ( 8),
   ID_CARD_PRINT_EOC                  CHAR ( 1),
   ACCIDENT_CDE                       CHAR ( 2),
   ASO_RISK_TYPE                      CHAR ( 2),
   GRP_CONTRIB_TYPE                   CHAR ( 2),
   GRP_CONTRIB_PERCENT                CHAR ( 10),
   CONTROL_PLN_CDE                    CHAR ( 4),
   DDPV_LTIME_CARRYOVER               CHAR ( 1),
   GRP_LTIME_CARRYOVER                CHAR ( 1),
   DUAL_COVER_CDE                     CHAR ( 2),
   SUBR_CORRESP_CDE                   CHAR ( 2),
   GRP_REPORT_CATEGORY                CHAR ( 4),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   ALTERNATE_BENEFIT_SET_NO           CHAR ( 4),
   COMPANY_ID                         CHAR ( 4),
   ALT_FEE_IND                        CHAR ( 1),
   LATE_SUBMIT_TYPE                   CHAR ( 4),
   LATE_SUBMIT_VALUE                  CHAR ( 4),
   PROCESS_POLICY_SET                 CHAR ( 4),
   PROCEDURE_SET                      CHAR ( 4),
   CEDED_PLN_CDE                      CHAR ( 4),
   PLAN_ID                            CHAR ( 6),
   DEFAULT_REGION_CODE                CHAR ( 4),
   SEND_STUDENT_VER_LETTER_FLAG       CHAR ( 1),
   COB_SAME_GROUP                     CHAR ( 1)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
ALTER TABLE GROUPS.RAW_GSD_PRD_PLAN ADD (LOSS_RATIO_CODE  NUMBER(4));--2.0.0