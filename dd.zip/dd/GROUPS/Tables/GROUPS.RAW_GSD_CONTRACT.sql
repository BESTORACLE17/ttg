CREATE TABLE GROUPS.RAW_GSD_CONTRACT ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   CONTRACT_EFF_DTE                   CHAR ( 8),
   CONTRACT_TRM_DTE                   CHAR ( 8),
   ASSOCIATION_ID                     CHAR ( 4),
   CONTRACT_CDE                       CHAR ( 4),
   CONTRACT_COMMENTS                  CHAR ( 200),
   LOSS_RATIO_CDE                     CHAR ( 4),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   ANNIVERSARY_DTE                    CHAR ( 4),
   RENEWAL_MONTH                      CHAR ( 2),
   TERM_REASON_CODE                   CHAR ( 2),
   COMPETITOR_NAME                    CHAR ( 100),
   PROCESSED_BY                       CHAR ( 30),
   PROCESSED_ON                       CHAR ( 14),
   CONTRACT_STATE                     CHAR ( 2)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
