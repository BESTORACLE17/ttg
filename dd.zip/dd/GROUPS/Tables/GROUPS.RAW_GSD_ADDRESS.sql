CREATE TABLE GROUPS.RAW_GSD_ADDRESS ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   ADDR_CDE                           CHAR ( 2),
   CONTACT_SALUTATION                 CHAR ( 2),
   LNME                               CHAR ( 30),
   FNME                               CHAR ( 30),
   ADDR1                              CHAR ( 30),
   ADDR2                              CHAR ( 30),
   ADDR3                              CHAR ( 30),
   CITY                               CHAR ( 30),
   STATE                              CHAR ( 2),
   ZIP                                CHAR ( 5),
   ZIP4                               CHAR ( 4),
   COUNTRY_CDE                        CHAR ( 4),
   REGION_OVERRIDE_CDE                CHAR ( 4),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   E_BILLING_EMAIL_1                  CHAR ( 200),
   BILLING_DISTRIBUTION_CODE          CHAR ( 2)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
