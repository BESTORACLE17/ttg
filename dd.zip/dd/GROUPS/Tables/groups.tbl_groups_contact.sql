CREATE TABLE GROUPS.TBL_GROUPS_CONTACT 
( CREATED_BY               VARCHAR2(30)     NOT NULL,
  CREATED_ON               DATE             NOT NULL,
  UPDATED_BY               VARCHAR2(30)     NOT NULL,
  UPDATED_ON               DATE             NOT NULL,
  MAINT_CODE               NUMBER(4)        NOT NULL,
  GROUPS_CONTACT_PK        NUMBER(12)       NOT NULL,
  PARENT_ID                NUMBER(4)        NOT NULL,
  GROUPS_PK                NUMBER(12)       NOT NULL,
  GROUP_ID                 VARCHAR2(9),
  SUBLOCATION_ID           VARCHAR2(8),
  DIVISION_ID              VARCHAR2(4),
  FIRST_NAME               VARCHAR2(30)    NOT NULL,
  LAST_NAME                VARCHAR2(30)    NOT NULL,
  EMAIL_ADDRESS            VARCHAR2(60),
  FAX_NUMBER               VARCHAR2(30),
  PHONE_NUMBER             VARCHAR2(30)
)
TABLESPACE GROUP_DATA;
/
create sequence groups.SEQ_GROUPS_CONTACT start with 1 increment by 1 nocache nocycle
/
alter table groups.tbl_groups_contact
        add constraint pk_groups_contact
primary key (groups_contact_pk,parent_id)
      using index tablespace group_index;
/
alter table groups.tbl_groups_contact
        add constraint fk_groups_contact
foreign key (groups_pk, parent_id)
 references groups.tbl_groups (groups_pk, parent_id);
/