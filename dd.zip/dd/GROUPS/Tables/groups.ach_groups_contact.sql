CREATE TABLE GROUPS.ACH_GROUPS_CONTACT 
   ( CREATED_BY               VARCHAR2(30),
     CREATED_ON               DATE,
     UPDATED_BY               VARCHAR2(30),
     UPDATED_ON               DATE,
     MAINT_CODE               NUMBER(4),
     ACTION_CODE              VARCHAR2(1),
     ACTION_BY                VARCHAR2(30),
     ACTION_ON                DATE,
     GROUPS_CONTACT_PK        NUMBER(12),
     PARENT_ID                NUMBER(4),
     GROUPS_PK                NUMBER(12),
     GROUP_ID                 VARCHAR2(9),
     SUBLOCATION_ID           VARCHAR2(8),
     DIVISION_ID              VARCHAR2(4),
     FIRST_NAME               VARCHAR2(30),
     LAST_NAME                VARCHAR2(30),
     EMAIL_ADDRESS            VARCHAR2(60),
     FAX_NUMBER               VARCHAR2(30),
     PHONE_NUMBER             VARCHAR2(30)
   )
TABLESPACE GROUP_DATA;
/