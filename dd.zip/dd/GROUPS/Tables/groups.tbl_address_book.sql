CREATE TABLE GROUPS.TBL_ADDRESS_BOOK 
( CREATED_BY               VARCHAR2(30)     NOT NULL,
  CREATED_ON               DATE             NOT NULL,
  UPDATED_BY               VARCHAR2(30)     NOT NULL,
  UPDATED_ON               DATE             NOT NULL,
  MAINT_CODE               NUMBER(4)        NOT NULL,
  ADDRESS_BOOK_PK          NUMBER(12)       NOT NULL,
  PARENT_ID                NUMBER(4)        NOT NULL,
  GROUPS_PK                NUMBER(12)       NOT NULL,
  GROUPS_CONTACT_PK        NUMBER(12)       NOT NULL,
  GROUPS_ADDRESS_PK        NUMBER(12)       
 )
TABLESPACE GROUP_DATA;
/
create sequence groups.seq_address_book start with 1 increment by 1 nocache nocycle
/
alter table groups.TBL_ADDRESS_BOOK
        add constraint pk_address_book
primary key (address_book_pk,parent_id)
using index tablespace group_index;
/
alter table groups.TBL_ADDRESS_BOOK
     add constraint fk_address_book
foreign key (groups_contact_pk, parent_id)
references groups.tbl_groups_contact (groups_contact_pk, parent_id);
/
alter table groups.TBL_ADDRESS_BOOK
  add constraint fk2_address_book
foreign key (groups_address_pk, parent_id)
references groups.tbl_groups_address (groups_address_pk, parent_id);
/
                         