CREATE TABLE GROUPS.RAW_GRP ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   ASSOCIATION_ID                     CHAR ( 4)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
