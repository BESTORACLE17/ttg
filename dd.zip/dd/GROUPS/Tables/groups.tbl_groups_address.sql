CREATE TABLE GROUPS.TBL_GROUPS_ADDRESS 
( CREATED_BY               VARCHAR2(30)     NOT NULL,
  CREATED_ON               DATE             NOT NULL,
  UPDATED_BY               VARCHAR2(30)     NOT NULL,
  UPDATED_ON               DATE             NOT NULL,
  MAINT_CODE               NUMBER(4)        NOT NULL,
  GROUPS_ADDRESS_PK        NUMBER(12)       NOT NULL,
  PARENT_ID                NUMBER(4)        NOT NULL,
  GROUPS_PK                NUMBER(12)       NOT NULL,
  ADDRESS_LINE1            VARCHAR2(30)     NOT NULL,
  ADDRESS_LINE2            VARCHAR2(30),
  ADDRESS_LINE3            VARCHAR2(30),
  CITY                     VARCHAR2(30),
  STATE                    VARCHAR2(2),
  ZIP                      NUMBER(5),
  ZIP4                     NUMBER(4),
  COUNTRY_CODE             NUMBER(4),
  CORRESPONDENCE_FLAG      VARCHAR2(1),
  REGION_OVERRIDE_CODE     NUMBER(4)
)
TABLESPACE GROUP_DATA;
/
create sequence groups.SEQ_GROUPS_ADDRESS start with 1 increment by 1 nocache nocycle
/
alter table groups.TBL_GROUPS_ADDRESS
     add constraint pk_groups_address
primary key (groups_address_pk,parent_id)
   using index tablespace group_index;
/
alter table groups.TBL_GROUPS_ADDRESS
        add constraint fk_groups_address
foreign key (groups_pk, parent_id)
 references groups.tbl_groups (groups_pk, parent_id);
/