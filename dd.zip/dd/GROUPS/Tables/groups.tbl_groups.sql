ALTER TABLE GROUPS.TBL_GROUPS
 DROP PRIMARY KEY CASCADE;
DROP TABLE GROUPS.TBL_GROUPS CASCADE CONSTRAINTS;

CREATE TABLE GROUPS.TBL_GROUPS
(
  GROUPS_PK                    NUMBER(12),
  GROUP_ID                     VARCHAR2(9 BYTE),
  SUBLOCATION_ID               VARCHAR2(8 BYTE),
  DIVISION_ID                  VARCHAR2(4 BYTE),
  NAME                         VARCHAR2(100 BYTE),
  EFF_DATE                     DATE,
  RECEIVED_DATE                DATE,
  CONTRACT_TYPE                NUMBER(2),
  RATING_TYPE                  NUMBER(2),
  CONTRIBUTION_TYPE            NUMBER(2),
  PLAN_ID                      NUMBER(6),
  ASSOCIATION_ID               NUMBER(4),
  IS_SINGLE_SUBLOCATION        NUMBER(1),
  IS_ASC_FUNDED                NUMBER(1),
  IS_RISK_FUNDED               NUMBER(1),
  FUNDING_RATES_AVAILABLE      NUMBER(1),
  NAICS_CODE                   VARCHAR2(6 BYTE),
  EMPLOYEE_COUNT               NUMBER(6),
  ENROLLEE_COUNT               NUMBER(6),
  OUT_OF_STATE_ENROLLEE_COUNT  NUMBER(6),
  CONTRIBUTION_PERCENTAGE      NUMBER(6,2),
  INTERNAL_PRODUCER_ID         NUMBER(5),
  EXTERNAL_PRODUCER_ID         NUMBER(5),
  EE_SUBMISSION_AVAILABLE      NUMBER(1),
  MAX_DEPENDENT_AGE            NUMBER(2),
  MAX_STUDENT_AGE              NUMBER(2),
  DEPENDENT_COVERAGE_ENDS      NUMBER(3),
  ELIGIBILITY_WAIT_PERIOD      NUMBER(4),
  ELIGIBILITY_WAIT_UOM         NUMBER(2),
  START_ON_FIRST_DAY_OF_MONTH  NUMBER(1),
  END_ON_LAST_DAY_OF_MONTH     NUMBER(1),
  GROUP_SOURCE                 NUMBER(2),
  CREATED_BY                   VARCHAR2(30 BYTE),
  CREATED_ON                   DATE             DEFAULT SYSDATE,
  UPDATED_BY                   VARCHAR2(30 BYTE),
  UPDATED_ON                   DATE             DEFAULT SYSDATE,
  MAINT_CODE                   NUMBER(4),
  PARENT_ID                    NUMBER(4)
)
TABLESPACE GROUP_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE INDEX GROUPS.GROUPS_UPDATED_BY_IX ON GROUPS.TBL_GROUPS
(UPDATED_BY)
LOGGING
TABLESPACE GROUP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX GROUPS.PK_GROUPS ON GROUPS.TBL_GROUPS
(GROUPS_PK, PARENT_ID)
LOGGING
TABLESPACE GROUP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX GROUPS.UK_GROUPS ON GROUPS.TBL_GROUPS
(PARENT_ID, GROUP_ID, SUBLOCATION_ID, DIVISION_ID)
LOGGING
TABLESPACE GROUP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE OR REPLACE TRIGGER GROUPS.TRG_GROUPS
before insert or update or delete ON GROUPS.TBL_GROUPS   for each row
declare
   l_parent_id      NUMBER := sys_context('CNT_PARENT_ID','PARENT_ID');
begin
   if inserting
   then
      :new.parent_id  := l_parent_id;
      :new.maint_code := nvl( :new.maint_code, 0 );
      select groups.seq_groups.nextval
        into :new.groups_pk
        from dual;
      :new.created_on := sysdate;
      :new.created_by := common.pkg_parent_id_utils.fnc_get_app_username;
      :new.updated_on := sysdate;
      :new.updated_by := common.pkg_parent_id_utils.fnc_get_app_username;
   elsif updating
   then
      :new.parent_id  := l_parent_id;
      :new.maint_code := nvl( :new.maint_code, 0 );
      :new.updated_on := sysdate;
      :new.updated_by := common.pkg_parent_id_utils.fnc_get_app_username;
      insert into groups.ach_groups
      (
        action_code,
        action_by,
        action_on,
        groups_pk,
        group_id,
        sublocation_id,
        division_id,
        name,
        eff_date,
        received_date,
        contract_type,
        rating_type,
        contribution_type,
        plan_id,
        association_id,
        is_single_sublocation,
        is_asc_funded,
        is_risk_funded,
        funding_rates_available,
        naics_code,
        employee_count,
        enrollee_count,
        out_of_state_enrollee_count,
        contribution_percentage,
        internal_producer_id,
        external_producer_id,
        ee_submission_available,
        max_dependent_age,
        max_student_age,
        dependent_coverage_ends,
        eligibility_wait_period,
        eligibility_wait_uom,
        start_on_first_day_of_month,
        end_on_last_day_of_month,
        group_source,
        created_by,
        created_on,
        updated_by,
        updated_on,
        maint_code,
        parent_id
      )
      values
      (
         'U',
         common.pkg_parent_id_utils.fnc_get_app_username,
         sysdate,
        :old.groups_pk,
        :old.group_id,
        :old.sublocation_id,
        :old.division_id,
        :old.name,
        :old.eff_date,
        :old.received_date,
        :old.contract_type,
        :old.rating_type,
        :old.contribution_type,
        :old.plan_id,
        :old.association_id,
        :old.is_single_sublocation,
        :old.is_asc_funded,
        :old.is_risk_funded,
        :old.funding_rates_available,
        :old.naics_code,
        :old.employee_count,
        :old.enrollee_count,
        :old.out_of_state_enrollee_count,
        :old.contribution_percentage,
        :old.internal_producer_id,
        :old.external_producer_id,
        :old.ee_submission_available,
        :old.max_dependent_age,
        :old.max_student_age,
        :old.dependent_coverage_ends,
        :old.eligibility_wait_period,
        :old.eligibility_wait_uom,
        :old.start_on_first_day_of_month,
        :old.end_on_last_day_of_month,
        :old.group_source,
        :old.created_by,
        :old.created_on,
        :old.updated_by,
        :old.updated_on,
        :old.maint_code,
        :old.parent_id
      );
   else
      insert into groups.ach_groups
      (
        action_code,
        action_by,
        action_on,
        groups_pk,
        group_id,
        sublocation_id,
        division_id,
        name,
        eff_date,
        received_date,
        contract_type,
        rating_type,
        contribution_type,
        plan_id,
        association_id,
        is_single_sublocation,
        is_asc_funded,
        is_risk_funded,
        funding_rates_available,
        naics_code,
        employee_count,
        enrollee_count,
        out_of_state_enrollee_count,
        contribution_percentage,
        internal_producer_id,
        external_producer_id,
        ee_submission_available,
        max_dependent_age,
        max_student_age,
        dependent_coverage_ends,
        eligibility_wait_period,
        eligibility_wait_uom,
        start_on_first_day_of_month,
        end_on_last_day_of_month,
        group_source,
        created_by,
        created_on,
        updated_by,
        updated_on,
        maint_code,
        parent_id
      )
      values
      (
         'D',
         common.pkg_parent_id_utils.fnc_get_app_username,
         sysdate,
        :old.groups_pk,
        :old.group_id,
        :old.sublocation_id,
        :old.division_id,
        :old.name,
        :old.eff_date,
        :old.received_date,
        :old.contract_type,
        :old.rating_type,
        :old.contribution_type,
        :old.plan_id,
        :old.association_id,
        :old.is_single_sublocation,
        :old.is_asc_funded,
        :old.is_risk_funded,
        :old.funding_rates_available,
        :old.naics_code,
        :old.employee_count,
        :old.enrollee_count,
        :old.out_of_state_enrollee_count,
        :old.contribution_percentage,
        :old.internal_producer_id,
        :old.external_producer_id,
        :old.ee_submission_available,
        :old.max_dependent_age,
        :old.max_student_age,
        :old.dependent_coverage_ends,
        :old.eligibility_wait_period,
        :old.eligibility_wait_uom,
        :old.start_on_first_day_of_month,
        :old.end_on_last_day_of_month,
        :old.group_source,
        :old.created_by,
        :old.created_on,
        :old.updated_by,
        :old.updated_on,
        :old.maint_code,
        :old.parent_id
      );
   end if;
end;
/


ALTER TABLE GROUPS.TBL_GROUPS ADD (
  CONSTRAINT PK_GROUPS
 PRIMARY KEY
 (GROUPS_PK, PARENT_ID)
    USING INDEX 
    TABLESPACE GROUP_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          64K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       UNLIMITED
                PCTINCREASE      0
               ));
