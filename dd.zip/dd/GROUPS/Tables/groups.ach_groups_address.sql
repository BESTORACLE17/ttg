CREATE TABLE GROUPS.ACH_GROUPS_ADDRESS 
( CREATED_BY               VARCHAR2(30),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1),
  ACTION_BY                VARCHAR2(30),
  ACTION_ON                DATE,
  GROUPS_ADDRESS_PK        NUMBER(12),
  PARENT_ID                NUMBER(4),
  GROUPS_PK                NUMBER(12),
  ADDRESS_LINE1            VARCHAR2(30),
  ADDRESS_LINE2            VARCHAR2(30),
  ADDRESS_LINE3            VARCHAR2(30),
  CITY                     VARCHAR2(30),
  STATE                    VARCHAR2(2),
  ZIP                      NUMBER(5),
  ZIP4                     NUMBER(4),
  COUNTRY_CODE             NUMBER(4),
  CORRESPONDENCE_FLAG      VARCHAR2(1)
)
TABLESPACE GROUP_DATA;
/