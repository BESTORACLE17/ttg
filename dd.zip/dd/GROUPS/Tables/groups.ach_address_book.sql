CREATE TABLE GROUPS.ACH_ADDRESS_BOOK 
( CREATED_BY               VARCHAR2(30),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1),
  ACTION_BY                VARCHAR2(30),
  ACTION_ON                DATE,
  ADDRESS_BOOK_PK          NUMBER(12),
  PARENT_ID                NUMBER(4),
  GROUPS_PK                NUMBER(12),
  GROUPS_CONTACT_PK        NUMBER(12),
  GROUPS_ADDRESS_PK        NUMBER(12)
)
TABLESPACE GROUP_DATA;
/