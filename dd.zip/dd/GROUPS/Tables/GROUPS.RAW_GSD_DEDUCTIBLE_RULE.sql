CREATE TABLE GROUPS.RAW_GSD_DEDUCTIBLE_RULE ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   PRD_CDE                            CHAR ( 4),
   PLN_CDE                            CHAR ( 4),
   RULE_ID                            CHAR ( 4),
   PAR_NPAR_PRV_IND                   CHAR ( 1),
   BENEFIT_CLASS_CDE                  CHAR ( 4),
   DEDUCTIBLE_TYPE                    CHAR ( 2),
   GSD_DEDMAX_EFF_DTE                 CHAR ( 8),
   GSD_DEDMAX_TRM_DTE                 CHAR ( 8),
   DEDUCTIBLE_AMT                     CHAR ( 8),
   FWD_DEDUCT_PERIOD                  CHAR ( 2),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   REL_CDE                            CHAR ( 4),
   PRODUCT_TIER_CODE                  CHAR ( 4),
   PAR_NONPAR_SEPARATE                CHAR ( 4),
   BEGIN_AGE                          CHAR ( 4),
   END_AGE                            CHAR ( 4)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
