CREATE TABLE GROUPS.RAW_GSD_PRODUCER ( 
   ID                                 NUMBER(2) NOT NULL,
   RECORD_PK                          NUMBER(12) NOT NULL,
   RECORD_ID                          CHAR(4),
   ACTION_CODE                        CHAR(1),
   ERROR_FLAG                         CHAR(1),
   MAINT_CODE                         CHAR ( 4),
   MOD_DTE                            CHAR ( 14),
   MOD_OP                             CHAR ( 12),
   GRP_ID                             CHAR ( 9),
   SUBLOC_ID                          CHAR ( 8),
   DIV_ID                             CHAR ( 4),
   PRODUCER_ID                        CHAR ( 15),
   GRP_PRODUCER_EFF_DTE               CHAR ( 8),
   GRP_PRODUCER_TRM_DTE               CHAR ( 8),
   COMMISSION_TYPE_CODE               CHAR ( 4),
   COMMISSION_SCHEDULE_CODE           CHAR ( 4),
   COMMISSION_SLIDING_SCALE_ID        CHAR ( 4),
   COMMISSION_FIXED_PERCENT           CHAR ( 6),
   COMMISSION_FIXED_AMOUNT            CHAR ( 9),
   NEGOTIATED_COMMISSION_FLAG         CHAR ( 1),
   PAY_TO_PRODUCER_ID                 CHAR ( 15),
   PAY_TO_LOCATION_ID                 CHAR ( 15),
   ADJUSTMENT_MONTH                   CHAR ( 2),
   ADJUSTMENT_YEAR                    CHAR ( 4),
   REMARKS                            CHAR ( 200),
   SEND_DELINQUENCY_LETTER_FLAG       CHAR ( 1)
)
 TABLESPACE GROUP_DATA 
 PARTITION BY LIST (ID) 
 ( 
 PARTITION PAR_1 VALUES (1) TABLESPACE GROUP_DATA,
 PARTITION PAR_2 VALUES (2) TABLESPACE GROUP_DATA 
 );
