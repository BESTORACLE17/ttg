CREATE OR REPLACE VIEW /* VERSION: 2.1.1 */ DCSREPORTS.VEW_RPT_QUEUE_LIST
AS
SELECT (select parent_id from dcs2000.tbl_company where nvl(company_id,-1) = wh.company_id) as parent_id
     , wh.claim_no
     , WH.GRP_ID
     , common.pkg_date_utils.fnc_to_date(wh.receive_dte) AS received_date
     , wh.subr_id
     , wh.subr_lnme || ', '||wh.subr_fnme AS subr_name
     , wh.prv_id
     , DECODE(wh.xray_attached,0,NULL,'YES') AS XRAY_ATTACHED
     , wh.current_queue
     , qd.DESCRIPTION                     AS QUEUE_DESC
     , WH.MOD_OP
     , grp_id||subloc_id||div_no||claim_no   AS grp_sort_by
     , claim_no||grp_id||subloc_id||div_no   AS claim_sort_by
  FROM dcs2000.tbl_wip_header          wh
  join dcs2000.tbl_queue_definitions   qd on (wh.current_queue = qd.queue)
 WHERE NVL(wh.maint_code,0)   = 0
   AND NVL(qd.maint_code,0)   = 0
   AND resubmittal            = 0
 WITH READ ONLY;

