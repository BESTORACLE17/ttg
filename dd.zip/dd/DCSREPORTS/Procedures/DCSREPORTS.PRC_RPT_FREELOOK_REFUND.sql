CREATE OR REPLACE PROCEDURE /* Version: 2.1.12 */ DCSREPORTS.PRC_RPT_FREELOOK_REFUND (
   P_REPORT_CURSOR   IN OUT PKG_RPT_UTILS.TYP_REPORT_CURSOR,
   P_PRODUCT_LINE    IN     DCS2000.TBL_BILLING_INDV_EXTRACT_RPT.PRODUCT_LINE_CODE%TYPE)
IS
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   || Revision Type  : Creation
   || Version #      : 1.0
   || Service Request: 06156.02.VA Story 45
   || Revision By    : Joe O'Dell
   || Revision Date  : 05/16/2014
   || Revision Desc  : Created procedure
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
   --Constants
   C_SUBR_INDV_ID              CONSTANT NUMBER := 1; --INDV ID for primary subscriber on each account
   C_REFUND_LETTER_FORM_TYPE   CONSTANT NUMBER := 206; --Code associated with Refund Letter Form Type
   C_PROG_KEY                  CONSTANT VARCHAR2 (30)
                                           := 'PRC_RPT_FREELOOK_REFUND' ; --Needed by error reporting procedure

   --Local Variables
   lv_errorcode                         NUMBER;
   lv_errortext                         VARCHAR2 (2000);
   lv_debug_info                        VARCHAR2 (32676);
   lv_curr_date                         NUMBER
      := TO_NUMBER (TO_CHAR (SYSDATE, 'YYYYMMDD'));
BEGIN
   OPEN P_REPORT_CURSOR FOR
      SELECT DISTINCT TSIB.PARENT_ID AS PARENT_ID,
             TSC.GRP_ID AS GRP_ID,
             TSC.SUBLOC_ID AS SUBLOC_ID,
             TSC.DIV_ID AS DIV_ID,
             TSI.SUBR_ID AS SUBR_ID,
             TSI.LNME AS LAST_NAME,
             TSI.FNME AS FIRST_NAME,
             TSIALT.CREATED_ON AS ENROLL_DATE,
             SYSDATE AS TERM_DATE,
             TSIB.AMOUNT AS REFUND_AMOUNT
        FROM DCS2000.TBL_SUBR_INDV_FORM TSIF
             INNER JOIN
             DCS2000.TBL_SUBR_INDV_BILLING TSIB
                --NEED TO ACCOUNT FOR MULTIPLE FREELOOK CANCELLATIONS?
                ON     TSIB.SUBR_ID = TSIF.SUBR_ID
                   AND TSIB.TERM_DATE < TSIB.EFF_DATE
                   AND NVL (TSIB.MAINT_CODE, 0) = 0
             INNER JOIN
             DCS2000.TBL_SUBR_INDV TSI
                --NEED TO ACCOUNT FOR INDIVIDUAL EFF/TRM DATES?
                ON     TSI.SUBR_ID = TSIF.SUBR_ID
                   AND TSI.INDV_ID = C_SUBR_INDV_ID
                   AND NVL (TSI.MAINT_CODE, 0) = 0
             INNER JOIN DCS2000.TBL_SUBR_COVERAGE TSC
                --NEED TO ACCOUNT FOR COVERAGE EFF/TRM DATES?
                ON TSC.SUBR_ID = TSIF.SUBR_ID AND NVL (TSI.MAINT_CODE, 0) = 0
             INNER JOIN
             DCS2000.TBL_SUBR_INDV_ALTERNATE_ID TSIALT
                --NEED TO ACCOUNT FOR ALT ID EFF/TRM DATES?
                ON     TSIALT.SUBR_ID = TSIF.SUBR_ID
                   AND TSIALT.INDV_ID = C_SUBR_INDV_ID
                   AND NVL (TSIALT.MAINT_CODE, 0) = 0
       WHERE     TSIF.FRM_TYP_CDE = C_REFUND_LETTER_FORM_TYPE
             AND NVL (TSIF.MAINT_CODE, 0) = 0;
EXCEPTION
   WHEN OTHERS
   THEN
      lv_errorcode := SQLCODE;
      lv_errortext := SQLERRM;

      INSERT INTO dcsreports.tbl_report_errors (request_id,
                                                prog_key,
                                                run_date,
                                                executed_by,
                                                error_number,
                                                ERROR_TEXT,
                                                debug_info)
           VALUES (NULL,
                   c_prog_key,
                   SYSDATE,
                   USER,
                   lv_errorcode,
                   lv_errortext,
                   lv_debug_info);

      COMMIT;
END PRC_RPT_FREELOOK_REFUND;
/

GRANT EXECUTE ON DCSREPORTS.PRC_RPT_FREELOOK_REFUND TO DCS_USERS_ALL;
/