CREATE OR REPLACE procedure /* 2.0.3 */     DCSREPORTS.PRC_EXTRACT_TPA_BILL_SUM
                          (  P_ERRORCODE               IN OUT   NUMBER
                           , P_ERRORTEXT               IN OUT   VARCHAR2
                           , P_REQUEST_ID              IN       DCS2000.TBL_RPTG_REQUESTS.REQ_ID%TYPE
                           , P_RUN_MODE                IN       CHAR DEFAULT 'W'
                           , P_BILLING_RUN             IN       CHAR
                           , P_TO_DATE                 IN       NUMBER 
                           , P_PRODUCT_LINE            IN       dcs2000.tbl_code_product_line.code%type
                           )
as 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
||                          Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
| Version        :  2.0.0 
|| Revision Type  : Intail Creation 
|| Service Request: 10340.01.VA 
|| Revision By    : Satya Sai
|| Revision Date  : 01/21/2011
|| Revision Desc  : To run this report from Ra as well as BA applications
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.0.1
|| Revision Type  : Enhancement
|| SR/WO          : SR10340.01.VA TPA Billing
|| Revision By    : Satya Sai
|| Revision Date  : 03/21/2011
|| Revision Desc  : Added Company ID and Name to the ref cursor
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.2
|| Revision Type  : Enhancement
|| SR/WO          : SR10067.02.ALL Multi Product
|| Revision By    : Amit Dahra
|| Revision Date  : 03/23/2011
|| Revision Desc  : Context for Product line is cleared.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.3
|| Revision Type  : Enhancement
|| SR/WO          : SR11165.02.VA
|| Revision By    : Arun Pottammal
|| Revision Date  : 04/04/2012
|| Revision Desc  : Added Invoice_Date, Invoice_Number, Display_Invoice_Info.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
*/
  -- LN_DUMMY                      NUMBER                 := COMMON.PKG_PRODUCT_LINE.FNC_SET_PRODUCT_LINE_CONTEXT(p_product_line); 
   
   -- ==============================
   --    Declaration Section
   -- ==============================
   C_PROG_KEY        CONSTANT VARCHAR2(30) := 'EXTRACT_TPA_BILL_SUMMARY';
      
   CURSOR c_parameters IS
      SELECT UPPER(PA.TOKEN) AS token
           , PP.DISPLAY_ORDER
        FROM dcs2000.tbl_rptg_programs           PR
        JOIN DCS2000.TBL_RPTG_PROGRAM_PARAMETERS PP USING (PROG_ID)
        JOIN DCS2000.TBL_RPTG_PARAMETERS         PA USING (PARAM_ID)
       WHERE NVL(PA.MAINT_CODE,0) = 0
         AND NVL(PR.MAINT_CODE,0) = 0
         AND NVL(PP.MAINT_CODE,0) = 0
         AND prog_key             = C_PROG_KEY
       ORDER BY PP.DISPLAY_ORDER;
   
   ln_errorcode      NUMBER;
   lv_errortext      VARCHAR2(4000);
   ln_request_id     NUMBER;
   lv_parameter_list VARCHAR2(2000);
   lv_value          VARCHAR2(200); 
   lv_file_name      VARCHAR2(40);
   lv_wrkbook_header VARCHAR2(35);
   -- *****************************
   ln_count          number;
   ln_claims_count   number := 0;
   ln_claims_amount  number := 0;
   ln_admin_expenses number := 0;
   ln_subr_count     number := 0;
   
   lv_parent_name       dcs2000.tbl_parent_company.parent_name%type;
   ld_billing_from_date dcs2000.tbl_asc_billing_process_header.bill_from_date%type;
   ld_billing_end_date  dcs2000.tbl_asc_billing_process_header.bill_to_date %type;
   
   ln_company_id        DCS2000.TBL_COMPANY.COMPANY_ID%TYPE;  -- 2.0.1 
   lv_company_name      DCS2000.TBL_COMPANY.COMPANY_NAME%TYPE;-- 2.0.1 
   
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                                   REPORT HEADER
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/  
     
      report_rc      sys_refcursor; 
  
      TYPE rtp_rec IS RECORD 
        (
          parent_id         dcs2000.tbl_asc_billing_header.parent_id%type, 
          parent_name       dcs2000.tbl_parent_company.parent_name%type,
          grp_id            varchar2(25), 
          group_name        dcs2000.tbl_asc_billing_header.group_name%type,
          reporting_code    dcs2000.tbl_asc_billing_header.reporting_code%type,
          billing_from_date dcs2000.tbl_asc_billing_process_header.bill_from_date%type,
          billing_end_date  dcs2000.tbl_asc_billing_process_header.bill_to_date %type,
          billing_due_date  dcs2000.tbl_asc_billing_process_header.bill_due_date%type,
          total_subr_count  NUMBER(12),
          total_admin_amt   NUMBER(15,2),
          total_claims_cnt  NUMBER(12),
          total_claims_amt  NUMBER(15,2),
          total_tax_amt     number(15,2),
          admin_subloc_id   dcs2000.tbl_asc_billing_header.admin_subloc_id%type,-- 2.0.1 
          asc_billing_process_header_pk dcs2000.tbl_asc_billing_header.asc_billing_process_header_pk%type, -- 2.0.1 
          company_id        dcs2000.tbl_company.company_id%type,    -- 2.0.1 
          billing_address_full  varchar2(200),           -- 2.0.3
          invoice_number        varchar2(10),            -- 2.0.3
          Invoice_Date          varchar2(10),            -- 2.0.3
          display_invoice_info  varchar2(1),             -- 2.0.3
          total_due             dcs2000.tbl_asc_billing_detail.bill_amount%type,      -- 2.0.3
          Prior_Amount_Billed   dcs2000.tbl_asc_billing_header.past_due%type,         -- 2.0.3
          ytd                   dcs2000.tbl_asc_billing_header.ytd%type,              -- 2.0.3
          mtd                   dcs2000.tbl_asc_billing_header.mtd%type,              -- 2.0.3
          Payment_Due_On        varchar2(10),            -- 2.0.3
          company_name          dcs2000.tbl_company.company_name%type  -- 2.0.1
        );

      TYPE tbl_report      IS TABLE OF rtp_rec;
      report_recs           tbl_report;

   procedure inp_print_header 
     ( p_parent_name        IN  dcs2000.tbl_parent_company.parent_name%type
     , p_billing_from_date  IN  dcs2000.tbl_asc_billing_process_header.bill_from_date%type
     , p_billing_end_date   IN  dcs2000.tbl_asc_billing_process_header.bill_to_date %type
     , p_bill_run           IN  VARCHAR2
     )
   is
   begin
     /*
      || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                             DISPLAY Parent Name 
      ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
      */    
            pkg_xml_utils.write_excel_row_header;

         -- Column Header Cells
         -- ---------------------------------------------------------
            pkg_xml_utils.write_excel_cell ('Bill To',
                                            'String',
                                            pkg_xml_utils.g_styleid_hdr_la
                                           );
            pkg_xml_utils.write_excel_cell (p_parent_name, 'String', pkg_xml_utils.g_styleid_hdr_la);

         -- END ROW
         -- ----------------------------------------------------------
            pkg_xml_utils.write_excel_row_footer;
            
       /*
      || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                             DISPLAY From Date 
      ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
      */    
            pkg_xml_utils.write_excel_row_header;

         -- Column Header Cells
         -- ---------------------------------------------------------
            pkg_xml_utils.write_excel_cell ('From Date',
                                            'String',
                                            pkg_xml_utils.g_styleid_hdr_la
                                           );
            pkg_xml_utils.write_excel_cell (p_billing_from_date, 'String', pkg_xml_utils.g_styleid_hdr_la);
            
         -- END ROW
         -- ----------------------------------------------------------
            pkg_xml_utils.write_excel_row_footer;
               
      /*
      || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                             DISPLAY TO Date 
      ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
      */    
            pkg_xml_utils.write_excel_row_header;

         -- Column Header Cells
         -- ---------------------------------------------------------
            pkg_xml_utils.write_excel_cell ('To Date',
                                            'String',
                                            pkg_xml_utils.g_styleid_hdr_la
                                           );
            pkg_xml_utils.write_excel_cell (p_billing_end_date, 'String', pkg_xml_utils.g_styleid_hdr_la);
            
         -- END ROW
         -- ----------------------------------------------------------
            pkg_xml_utils.write_excel_row_footer;
       
      
       /*
      || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                             DISPLAY Bill Run
      ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
      */    
            pkg_xml_utils.write_excel_row_header;

         -- Column Header Cells
         -- ---------------------------------------------------------
            pkg_xml_utils.write_excel_cell ('Bill Run',
                                            'String',
                                            pkg_xml_utils.g_styleid_hdr_la
                                           );
            pkg_xml_utils.write_excel_cell (p_bill_run, 'String', pkg_xml_utils.g_styleid_hdr_la);
            
         -- END ROW
         -- ----------------------------------------------------------
            pkg_xml_utils.write_excel_row_footer;
            
   end inp_print_header;
      
begin
  -- ***********************************************
  -- This will help the report to run fron RA or BA
  -- ***********************************************   
  
  COMMON.PKG_PRODUCT_LINE.PRC_CLEAR_PRODUCT_LINE_CONTEXT;
  
   IF nvl(p_request_id,-1) = -1 THEN

      lv_parameter_list := NULL;

      FOR R_PARAMETER IN C_PARAMETERS LOOP

         CASE r_parameter.Token
            WHEN UPPER('P_RUN_MODE')     THEN
               lv_value := P_RUN_MODE;            
            WHEN UPPER('P_BILLING_RUN')  THEN
               lv_value := P_BILLING_RUN;
            WHEN UPPER('P_TO_DATE')  THEN
               lv_value := P_TO_DATE;
            WHEN UPPER('P_PRODUCT_LINE') THEN
               lv_value := P_PRODUCT_LINE;
            ELSE
               lv_value := '';
         END CASE;

         lv_parameter_list := common.fnc_append_string(lv_parameter_list,lv_value,'~');

      END LOOP;
      
      -- Not being run through Ra, so call the submit request procedure
      -- ---------------------------------------------------------------
      DCS2000.pkg_rptg_requests.prc_submit_request(p_errorcode       => ln_errorcode,
                                                   p_errortext       => lv_errortext,
                                                   p_req_id          => ln_request_id,
                                                   p_prog_id         => dcs2000.pkg_rptg_requests.fnc_get_prog_id(c_prog_key),
                                                   p_priority_cde    => 975,
                                                   p_requested_by    => USER,
                                                   p_start_on        => SYSDATE,
                                                   p_parameter_list  => lv_parameter_list,
                                                   p_source_req_id   => NULL,
                                                   p_wait_for_req_id => NULL);
         
   ELSE
   
      ln_request_id := p_request_id;
      
   END IF;

   --
   -- Reset the error code and error text
   -- ------------------------------------------------------
      P_ERRORCODE := 0;
      P_ERRORTEXT := NULL;
      
  --
  -- File Name 
  -- --------------------------------------------------
   if P_BILLING_RUN = 'W'
   then
       lv_file_name      :=  'TPA_Weekly_Billing_Summary_'|| P_TO_DATE||'.xml'; --TO_NUMBER(TO_CHAR(TRUNC(P_TO_DATE),'YYYYMMDD'));
       lv_wrkbook_header := 'WEEKLY REPORT';
   else
       lv_file_name      :=  'TPA_Monthly_Billing_Summary_'|| P_TO_DATE||'.xml'; --TO_NUMBER(TO_CHAR(TRUNC(P_TO_DATE),'YYYYMMDD'));
       lv_wrkbook_header := 'MONTHLY REPORT';
   end if; 
  
  --  Open the file only if running from BA 
  -- --------------------------------------------------  
   if nvl(p_request_id,-1) = -1
   then
      DCSREPORTS.PKG_XML_UTILS.G_XML_FILE := NULL; -- 2.0.1
      
      DCSREPORTS.PKG_XML_UTILS.OPEN_XML_FILE (lv_file_name);
   else
      pkg_xml_utils.g_xml_file := dcs2000.pkg_rptg_requests.g_out_file;
   end if;
   
   pkg_xml_utils.write_excel_workbook_header;
   PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_HEADER(lv_wrkbook_header);

   --
   -- Column Widths
   -- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(150);    -- Company Id    -- 2.0.1 
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(250);    -- Company Name  -- 2.0.1 
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(150);    -- Grp Id
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(200);    -- Group Name
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);    -- Claims Count
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);    -- Calims Amount
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);    -- Employee Count
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);    -- Admin expenses
   
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY DETAILS
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('DETAILS', 'String',pkg_xml_utils.g_styleid_hdr_la);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
   
   -- Blank line to separate the deatials of report table header
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;     
      
  -- **********************
  -- Call in procedure
  -- **********************
   DCSREPORTS.PRC_RPT_ASO_BILL_SUM_TPA 
     (p_report_cursor   => report_rc,
      p_run_mode        => p_run_mode,
      p_billing_run     => p_billing_run,
      p_product_line    => p_product_line,
      p_company_id      => NULL
     );
     
    FETCH report_rc
     BULK COLLECT INTO report_recs;   

   FOR i IN 1 .. report_recs.COUNT
   LOOP
     lv_parent_name       := report_recs(1).parent_name;
     ld_billing_from_date := report_recs(1).billing_from_date;
     ld_billing_end_date  := report_recs(1).billing_end_date;
       
     -- Process to print the Parameter list
     if i = 1 
     then
        inp_print_header 
           ( p_parent_name        => lv_parent_name
           , p_billing_from_date  => ld_billing_from_date
           , p_billing_end_date   => ld_billing_end_date
           , p_bill_run           => lv_wrkbook_header
           );
           
         -- Blank line to separate the deatials of report table header
            pkg_xml_utils.write_excel_row_header;
            pkg_xml_utils.write_excel_row_footer; 
            pkg_xml_utils.write_excel_row_header;
            pkg_xml_utils.write_excel_row_footer; 
            
         --
         -- Begin Row
         -- ---------------------------------------------------------
         pkg_xml_utils.WRITE_EXCEL_ROW_HEADER;

         --
         -- Column Header Cells
         -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell('Company Id','String',pkg_xml_utils.G_STYLEID_HDR_LA         ); -- 2.0.1 
         pkg_xml_utils.write_excel_cell('Company Name','String',pkg_xml_utils.G_STYLEID_HDR_LA       ); -- 2.0.1 
         pkg_xml_utils.write_excel_cell('Grp Id','String',pkg_xml_utils.G_STYLEID_HDR_LA             );
         pkg_xml_utils.write_excel_cell('Group Name','String',pkg_xml_utils.G_STYLEID_HDR_LA         );
         pkg_xml_utils.write_excel_cell('Claims Count','String',pkg_xml_utils.G_STYLEID_HDR_LA       );
         pkg_xml_utils.write_excel_cell('Claims Amount','String',pkg_xml_utils.G_STYLEID_HDR_LA      );
         pkg_xml_utils.write_excel_cell('Enrollee Count','String',pkg_xml_utils.G_STYLEID_HDR_LA     );
         pkg_xml_utils.write_excel_cell('Admin Expenses','String',pkg_xml_utils.G_STYLEID_HDR_LA     );

         pkg_xml_utils.WRITE_EXCEL_ROW_FOOTER;
     
     end if;  
     
     --  Total's 
     ln_claims_count   := ln_claims_count   + nvl(report_recs(i).total_claims_cnt,0);     
     ln_claims_amount  := ln_claims_amount  + nvl(report_recs(i).total_claims_amt,0);     
     ln_admin_expenses := ln_admin_expenses + nvl(report_recs(i).total_admin_amt,0);     
     ln_subr_count     := ln_subr_count     + nvl(report_recs(i).total_subr_count,0);
     --  Total's
    -- get company Id -- 2.0.1 
    ln_company_id := DCSREPORTS.PKG_UTILITIES.fnc_get_company_id
                       ( substr(report_recs(i).grp_id,0,9)
                       , report_recs(i).admin_subloc_id
                       , report_recs(i).asc_billing_process_header_pk
                       );
                       
     -- get company name -- 2.0.1 
      Select company_name 
        into lv_company_name
        from dcs2000.tbl_company
       where company_id        = ln_company_id
         and nvl(maint_code,0) = 0;

     -- Write each Group detail 
     pkg_xml_utils.WRITE_EXCEL_ROW_HEADER;
     
     pkg_xml_utils.write_excel_cell(ln_company_id); -- 2.0.1 
     pkg_xml_utils.write_excel_cell(lv_company_name); -- 2.0.1 
     pkg_xml_utils.write_excel_cell(report_recs(i).grp_id);
     pkg_xml_utils.write_excel_cell(report_recs(i).group_name);
     pkg_xml_utils.write_excel_cell(report_recs(i).total_claims_cnt,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);
     pkg_xml_utils.write_excel_cell(report_recs(i).total_claims_amt,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);
     pkg_xml_utils.write_excel_cell(report_recs(i).total_subr_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);
     pkg_xml_utils.write_excel_cell(report_recs(i).total_admin_amt,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);

     pkg_xml_utils.WRITE_EXCEL_ROW_FOOTER;

   END LOOP;
   
     pkg_xml_utils.WRITE_EXCEL_ROW_HEADER;
     
     pkg_xml_utils.write_excel_cell(null);
     pkg_xml_utils.write_excel_cell('TOTALS','String', pkg_xml_utils.g_styleid_hdr_la);
     pkg_xml_utils.write_excel_cell(ln_claims_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);
     pkg_xml_utils.write_excel_cell(ln_claims_amount,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);
     pkg_xml_utils.write_excel_cell(ln_subr_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);
     pkg_xml_utils.write_excel_cell(ln_admin_expenses,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);
    
     pkg_xml_utils.WRITE_EXCEL_ROW_FOOTER;
   --
   -- End the WorkSheet
   -- ------------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_FOOTER(0,1);
   
   -- ************************************************************************************************
   -- ********************New Work Sheet "Summary"******************************************
   -- *************************************************************************
   -- ***************************************
       PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_HEADER('SUMMARY');
   
   --
   -- Column Widths
   -- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);    -- Name 
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(200);    -- Value
   
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY SUMMARY
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('SUMMARY', 'String',pkg_xml_utils.g_styleid_hdr_la);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
   
   -- Blank line to separate the deatials of report table header
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer; 
        
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Parent Name 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Bill To',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (lv_parent_name, 'String', pkg_xml_utils.g_styleid_hdr_la);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
    /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY From Date 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('From Date',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ld_billing_from_date, 'String', pkg_xml_utils.g_styleid_hdr_la);
         
      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
            
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY TO Date 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('To Date',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ld_billing_end_date, 'String', pkg_xml_utils.g_styleid_hdr_la);
         
      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
    
   
    /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Bill Run
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Bill Run',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (lv_wrkbook_header, 'String', pkg_xml_utils.g_styleid_hdr_la);
         
      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
   
   
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Total number of groups 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         ln_count := report_recs.count;

         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Total Number of Groups',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ln_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
               
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Total Claims count 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Total Number of Claims',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ln_claims_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Total Claims Amount 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Total Claims Amount',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ln_claims_amount,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Total Claims Amount 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Total Enrollee Count',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ln_subr_count,'Number',PKG_XML_UTILS.G_STYLEID_COMMA_0);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
   
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Total Admin Expenses 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Total Admin Expenses',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (ln_admin_expenses,'Number',PKG_XML_UTILS.G_STYLEID_CURRENCY);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer; 
   
   --
   -- End the WorkSheet
   -- ------------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_FOOTER(0,1);
   -- *******************************************************************************************
   -- ***********************************************************************
   -- ********************************************************
   
   --
   -- End the WorkBook
   -- ------------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_WORKBOOK_FOOTER;
 
   --  Close the file only if running from BA 
   -- -------------------------------------------------- 
   if nvl(p_request_id,-1) = -1
   then
    DCSREPORTS.PKG_XML_UTILS.CLOSE_XML_FILE();
   end if;
  
EXCEPTION
   WHEN OTHERS THEN
      ln_ERRORCODE := -1;
      lv_ERRORTEXT := SQLERRM;
      
      P_ERRORCODE := -1;
      P_ERRORTEXT := SQLERRM;
      
   --  Close the file only if running from BA 
   -- -------------------------------------------------- 
   if nvl(p_request_id,-1) = -1
   then
    DCSREPORTS.PKG_XML_UTILS.CLOSE_XML_FILE();
   end if;

end PRC_EXTRACT_TPA_BILL_SUM;
/
GRANT EXECUTE ON DCSREPORTS.PRC_RPT_ASO_BILL_SUM_TPA TO DCS_USERS_ALL, VADEVELOPER;
/