CREATE OR REPLACE PROCEDURE /* VERSION: 2.1.8 */ DCSREPORTS.prc_rpt_real_time_eligibility (
   p_report_cursor   IN OUT   dcsreports.pkg_rpt_utils.typ_report_cursor,
   p_seq_id          IN       dcsreports.temp_rpt_realtime_eligibility.seq_id%TYPE,
   p_product_line    IN       dcs2000.tbl_code_product_line.code%TYPE
)
IS
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.1.
|| Revision Type  : Initial Version.
|| SR/WO          : SR 11195.09.CO
|| Revision By    : Stephen Ince
|| Revision Date  : 01/06/2012.
|| Revision Desc  : INitial Revision
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.3,2.1.2
|| Revision Type  : Enhancement
|| SR/WO          : SR 11195.09.CO
|| Revision By    : Sudheer Dadivela 
|| Revision Date  : 01/06/2012.
|| Revision Desc  : Modified Cursor query, to retrieve GSD from temp_rpt_realtime_eligibility
||                  based on p_seq_id
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.4
|| Revision Type  : Enhancement
|| SR/WO          : SR 11195.09.CO
|| Revision By    : Dinesh Makked 
|| Revision Date  : 01/26/2012.
|| Revision Desc  : 1) The column INDV_TRM_DTE existed twice in the query. 
||                  2) Changed the sort order to include cover_eff_dte & indv_eff_dte.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.5
|| Revision Type  : Bug Fix
|| SR/WO          : SR 11195.09.CO
|| Revision By    : Stephen Ince 
|| Revision Date  : 01/27/2012.
|| Revision Desc  : 1) procedure was filtering on 20120113 instead of SYSTEM date to filter out
||                     subs who have termed. Fixed to use SYSTEM DATE
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.6
|| Revision Type  : Enhancement
|| SR/WO          : SR 11195.09.CO
|| Revision By    : Stephen Ince 
|| Revision Date  : 02/02/2012.
|| Revision Desc  : added two columms to report cursor so report dates will reflect dates( As of and
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.8,2.1.7
|| Revision Type  : Enhancement
|| SR/WO          : Trac#10268
|| Revision By    : Sudheer Dadivela 
|| Revision Date  : 01/06/2012.
|| Revision Desc  : Retrieving Subr id from cursor query has been modified to retrieve based on 
||                   Correspondence with Group
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
   c_prog_key   CONSTANT VARCHAR2 (30)   := 'RPT_REAL_TIME_ELIGIBILITY';
   ln_errorcode          NUMBER;
   lv_errortext          VARCHAR2 (4000);
BEGIN
   common.pkg_product_line.prc_clear_product_line_context;

   OPEN p_report_cursor
   FOR
        SELECT b.grp_id
             , b.subloc_id
             , b.div_id
             , g.grp_nme
             --, a.subr_id
             --             , dcs2000.pkg_subr_utils.fnc_get_submitted_subr_id_grp
             --               (
             --                   b.subr_id
             --                 , b.grp_id
             --                 , b.subloc_id
             --                 , b.div_id
             --                 , b.indv_id
             --                 , SYSDATE
             --                 , g.grp_submitted_mbr_id_typ_cde
             --               ) AS subr_id                            --2.1.27
             , dcs2000.pkg_subr_utils.fnc_get_disp_subr_id_grp
               (
                   b.subr_id
                 , b.grp_id
                 , b.subloc_id
                 , b.div_id
                 , b.indv_id
                 , SYSDATE
                 , g.grp_submitted_mbr_id_typ_cde
                 , g.grp_corresp_mbr_id_typ_cde
                 , g.mask_subrid_grp_corresp_flag
               ) AS subr_id                                           --2.1.27
             , a.indv_id
             , a.lnme
             , a.fnme
             , DECODE (LENGTH (a.dob), 8, TO_DATE (a.dob, 'YYYYMMDD')) dob
             , a.sex_cde
             , a.relshp_cde
             , c.description AS relationship_desc
             , TO_DATE (b.indv_eff_dte, 'YYYYMMDD') indv_eff_dte
             , TO_DATE(DECODE(NVL(b.indv_trm_dte, 0), 0, NULL, b.indv_trm_dte), 'YYYYMMDD') AS indv_trm_dte
             , 
--               DECODE (b.indv_trm_dte,
--                       0, ' ',
--                       TO_DATE (b.indv_trm_dte, 'YYYYMMDD')
--                      ) indv_trm_dte,
               -- indv_trm_dte,
               b.prd_cde
             , d.description AS product_desc
             , b.pln_cde
             , e.description AS plan_desc
             , b.rte_cde
             , f.description AS rate_desc
             , a.subr_id     AS dai
             , TO_CHAR(sysdate, 'MM/DD/YYYY') as as_of_date
             , TO_CHAR(sysdate, 'MM/DD/YYYY HH:MI AM') as run_date
          FROM dcsreports.temp_rpt_realtime_eligibility  i,
               dcs2000.tbl_subr_indv a,
               dcs2000.tbl_subr_cover_indv b,
               dcs2000.tbl_code_relship c,
               dcs2000.tbl_code_product d,
               dcs2000.tbl_code_plan e,
               dcs2000.tbl_code_rate f,
               dcs2000.tbl_gsd g,
               dcs2000.tbl_subr_indv h
         WHERE i.grp_id = b.grp_id
           and i.subloc_id = b.subloc_id 
           AND i.div_id = b.div_id
           AND i.seq_id = p_seq_id
           AND a.subr_id = b.subr_id
           AND a.indv_id = b.indv_no
           AND a.subr_id = h.subr_id
           AND h.indv_id = 1
           AND (
                    b.indv_trm_dte = 0 
                 OR b.indv_trm_dte >= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD'))
               )
           AND b.indv_eff_dte <
                     DECODE (NVL (indv_trm_dte, 0),
                             0, 99999999,
                             indv_trm_dte
                            )
           AND b.indv_eff_dte <
                  DECODE (NVL (b.indv_trm_dte, 0),
                          0, 99999999,
                          b.indv_trm_dte
                         )
           AND b.grp_id = g.grp_id
           AND b.subloc_id = g.subloc_id
           AND b.div_id = g.div_id
           AND a.relshp_cde = c.code
           AND b.prd_cde = d.code
           AND (b.prd_cde = e.prod_code AND b.pln_cde = e.code)
           AND b.rte_cde = f.code
           AND NVL (a.maint_code, 0) = 0
           AND NVL (b.maint_code, 0) = 0
           AND NVL (c.maint_code, 0) = 0
           AND NVL (d.maint_code, 0) = 0
           AND NVL (e.maint_code, 0) = 0
           AND NVL (f.maint_code, 0) = 0
           AND NVL (h.maint_code, 0) = 0
           AND b.product_line_code =
                  DECODE (NVL (p_product_line, -1),
                          -1, b.product_line_code,
                          p_product_line
                         )
      ORDER BY b.grp_id,
               b.subloc_id,
               b.div_id,
               h.lnme,
               h.subr_id,
               a.relshp_cde,
               b.cover_eff_dte, 
               b.indv_eff_dte,
               a.indv_id;
               
    DELETE dcsreports.temp_rpt_realtime_eligibility 
     WHERE seq_id = p_seq_id;
     
    COMMIT;
                
EXCEPTION
   WHEN OTHERS
   THEN
      ln_errorcode := SQLCODE;
      lv_errortext := SQLERRM;

      INSERT INTO dcsreports.tbl_report_errors
                  (prog_key, run_date, executed_by, error_number,
                   ERROR_TEXT, debug_info
                  )
           VALUES (c_prog_key, SYSDATE, USER, ln_errorcode,
                   lv_errortext, 'Error Executing Query'
                  );

      COMMIT;
END prc_rpt_real_time_eligibility;
/

GRANT EXECUTE ON dcsreports.prc_rpt_real_time_eligibility to VADEVELOPER ;
GRANT EXECUTE ON dcsreports.prc_rpt_real_time_eligibility to DCS_USERS_ALL ;
