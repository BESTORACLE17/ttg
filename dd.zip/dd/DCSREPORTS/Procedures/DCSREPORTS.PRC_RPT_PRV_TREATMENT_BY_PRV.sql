CREATE OR REPLACE PROCEDURE /* VERSION 2.0.0 */   DCSREPORTS.PRC_RPT_PRV_TREATMENT_BY_PRV
     (P_REPORT_CURSOR IN OUT dcsreports.pkg_rpt_utils.typ_report_cursor
     ,P_BEGIN_DTE     IN     DCS2000.VEW_CLAIMS_HIST.CHECK_DATE%TYPE
     ,P_END_DTE       IN     DCS2000.VEW_CLAIMS_HIST.CHECK_DATE%TYPE
     ,P_PRV_ID        IN     DCS2000.VEW_CLAIMS_HIST.PRV_ID%TYPE
     ,P_PRODUCT_LINE  IN     DCS2000.TBL_CODE_PRODUCT_LINE.CODE%TYPE  
     ,P_NETWORK_ID    IN     DCS2000.TBL_PARENT_NETWORK.NETWORK_ID%TYPE 
     )
IS
 ln_dummy                         NUMBER        := COMMON.PKG_PRODUCT_LINE.FNC_SET_PRODUCT_LINE_CONTEXT(p_product_line); 
 lv_network_id                    VARCHAR2(10); 
 g_number_all            CONSTANT NUMBER        := DCSREPORTS.PKG_UTILITIES.G_NUMBER_ALL; 
 g_parent_id                      NUMBER        := COMMON.PKG_PARENT_ID_UTILS.fnc_parent_id(); 
 
BEGIN

   IF P_NETWORK_ID = g_number_all
   THEN
    NULL;
   ELSIF P_NETWORK_ID IS NULL
   THEN
      lv_network_id := COMMON.PKG_NETWORK_ID.FNC_SET_PREFERRED_NETWORK();      
   ELSE
      COMMON.PKG_NETWORK_ID.PRC_SET_NETWORK_ID(p_network_id);
   END IF;
      
  OPEN P_REPORT_CURSOR FOR
     SELECT CLAIM_NO
          , CHECK_DATE
          , PRV_ID
          , GRP_ID
          , SUBLOC_ID
          , DIV_NO
          , PATIENT_SUFX
          , PATIENT_DOB
          , SUBR_ID
          , PRC_CDE
          , TREATMENT_DTE
          , INCIDENCE_CNT
          , SUBMITED_FEE
          , NET
          , PATIENT_FNME
          , PATIENT_LNME
          , PARENT_ID
          , NETWORK_ID
          , PROVIDER.PKG_NETWORK.FNC_GET_NETWORK_DESC(NETWORK_ID)  AS NETWORK_DESC
       FROM DCS2000.VEW_CLAIMS_HIST 
      WHERE PRV_ID = P_PRV_ID
        AND (    CHECK_DATE >= P_BEGIN_DTE
             AND CHECK_DATE <= P_END_DTE
            )
        AND NETWORK_ID IN ( SELECT NETWORK_ID FROM DCS2000.TBL_PARENT_NETWORK WHERE PARENT_ID = G_PARENT_ID)
   ORDER BY NETWORK_ID,
            PARENT_ID,
            PRV_ID,
            GRP_ID,
            SUBLOC_ID,
            DIV_NO,
            SUBR_ID,
            CLAIM_NO;
-- 2.1.6
   COMMON.PKG_NETWORK_ID.PRC_CLEAR_NETWORK_ID_CONTEXT();
          
END PRC_RPT_PRV_TREATMENT_BY_PRV;
/
GRANT EXECUTE ON DCSREPORTS.PRC_RPT_PRV_TREATMENT_BY_PRV TO  DCS_USERS_ALL, VADEVELOPER, DCS2000;
/