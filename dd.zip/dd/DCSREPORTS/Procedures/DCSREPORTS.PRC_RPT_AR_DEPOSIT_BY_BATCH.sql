/* Formatted on 2010/01/14 09:32 (Formatter Plus v4.8.8) */
CREATE OR REPLACE PROCEDURE /* VERSION: 1.0.1 */  dcsreports.prc_rpt_ar_deposit_by_batch (
   p_errorcode          IN OUT   NUMBER,
   p_errortext          IN OUT   VARCHAR2,
   p_deposit_dte_from   IN       DATE,
   p_deposit_dte_to     IN       DATE,
   p_product_line       IN       DCS2000.TBL_CODE_PRODUCT_LINE.CODE%TYPE -- Version 1.0.1
)
IS
   /*
   +*****************************************************************************+
   *   Revision History                                                          *
   +*****************************************************************************+
   *   Version        : 1.0.0
   *   Revision Type  : Creation
   *   Service Request: SR 09261.02.AR
   *   Revision By    : Ganesh Srivatsav
   *   Revision Date  : 12/016/2009
   *   Revision Desc  : Cash Deposit Summary by batch
   +*****************************************************************************+
   *  Version        : 1.0.1.
   *  Revision Type  : Enhancement
   *  SR/WO          : SR 10067.02.ALL
   *  Revision By    : Madhusudan Sharma
   *  Revision Date  : 07/16/2010.
   *  Revision Desc  : p_product_line parameter added
   *                   LN_DUMMY is created to set the context of Product Line
   +*****************************************************************************+   
   */

   -- Variables
   LN_DUMMY      NUMBER        := COMMON.PKG_PRODUCT_LINE.FNC_SET_PRODUCT_LINE_CONTEXT(p_product_line); -- Version 1.0.1
   l_rec_found   NUMBER        := 0;
   v_date_from   VARCHAR2 (10) := TO_CHAR (p_deposit_dte_from, 'MM/DD/YYYY');
   v_date_to     VARCHAR2 (10) := TO_CHAR (p_deposit_dte_to, 'MM/DD/YYYY');
   v_date        VARCHAR2 (10);

   -- Cursors

   -- Below cursor is used o genrate output for the Cash Deposits by Batch and the output fields are
   -- batch date,control amount and actual amount
   CURSOR c_dep_by_batch (c_deposit_dte_from IN DATE, c_deposit_dte_to IN DATE)
   IS
      SELECT   a.batch_date, a.batch_name, b.NAME AS batch_type, a.control_amount, a.control_count, c.code
          FROM ar.tbl_ar_rcpt_intf_batches a, ar.tbl_ar_rcpt_intf_names b, ar.tbl_ar_codes c
         WHERE a.ar_rcpt_intf_name_id = b.ar_rcpt_intf_name_id
           AND a.status_code = c.code_id
           AND TRUNC (a.batch_date) BETWEEN c_deposit_dte_from AND c_deposit_dte_to
      ORDER BY a.batch_date, a.batch_name;

   -- Below cursor is used o genrate output for the Receipts not associated to any batch and the output fields are
   -- Receipt Number,Subr ID,Grp ID ,Subloc ID,Div ID ,Deposit Date and Amount
   CURSOR c_dep_without_batch (c_deposit_dte_from IN DATE, c_deposit_dte_to IN DATE)
   IS
      SELECT   *
          FROM ar.tbl_ar_cash_receipts
         WHERE TRUNC (deposit_date) BETWEEN c_deposit_dte_from AND c_deposit_dte_to
           AND batch_id IS NULL
           AND maint_code = 0
           AND status != 'R'
      ORDER BY deposit_date;

   -- Local Procedure
   PROCEDURE writeout (p_output_string IN VARCHAR)
   IS
   BEGIN
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write (dcs2000.pkg_rptg_requests.g_out_file, p_output_string);
   END writeout;
BEGIN
   -- Reset the error variables
   p_errorcode := 0;
   p_errortext := NULL;
   --Start Writing the parameters to the file
   writeout (' ');
   writeout ('PARAMETERS');
   writeout ('======================');
   writeout ('Deposit Date From : ' || v_date_from);
   writeout ('Deposit Date To   : ' || v_date_to);
   -- Start writing the report for CASH DEPOSITS BY BATCH
   writeout (' ');
   writeout ('RECEIPT INTERFACE BATCH SUMMARY');
   writeout ('===============================');
   writeout (' ');
   writeout (   RPAD ('Batch Date', 11, ' ')
             || RPAD ('Batch Name', 40, ' ')
             || RPAD ('Batch Type', 40, ' ')
             || LPAD ('Control Amount', 17, ' ')
             || LPAD ('Control Count', 15, ' ')
             || RPAD (' Batch Status', 30, ' ')
            );
   writeout (   RPAD ('----------', 11, ' ')
             || RPAD ('-------------------------------------- ', 40, ' ')
             || RPAD ('---------------------------------------', 40, ' ')
             || LPAD ('----------------', 17, ' ')
             || LPAD ('-------------', 15, ' ')
             || RPAD (' --------------------------', 30, ' ')
            );
   writeout (' ');

   FOR c_rec_batch IN c_dep_by_batch (c_deposit_dte_from      => p_deposit_dte_from,
                                      c_deposit_dte_to        => p_deposit_dte_to
                                     )
   LOOP
      --Increment the record counter
      l_rec_found := l_rec_found + 1;
      v_date := TO_CHAR (c_rec_batch.batch_date, 'MM/DD/YYYY');
      writeout (   RPAD (v_date, 11, ' ')
                || RPAD (TRIM (c_rec_batch.batch_name), 40, ' ')
                || RPAD (TRIM (c_rec_batch.batch_type), 40, ' ')
                || LPAD (TRIM (TO_CHAR (c_rec_batch.control_amount, '999G999G999G999G990D99')), 17, ' ')
                || LPAD (TRIM (c_rec_batch.control_count), 15, ' ')
                || ' '
                || RPAD (TRIM (c_rec_batch.code), 30, ' ')
               );
   END LOOP;

   -- If no records found then write it.
   IF l_rec_found = 0
   THEN
      writeout (' ');
      writeout ('No Records Found');
   END IF;

   -- Reset the records found for the next report
   l_rec_found := 0;
   writeout (' ');
   writeout (' ');
   -- Start writing the report for RECEIPTS NOT ASSOCIATED TO ANY BATCH
   writeout ('RECEIPTS NOT ASSOCIATED WITH ANY BATCH');
   writeout ('======================================');
   writeout (' ');
   writeout (   RPAD ('Receipt No', 13, ' ')
             || RPAD ('Subr ID', 31, ' ')
             || RPAD ('Grp ID', 10, ' ')
             || RPAD ('Subloc ID', 10, ' ')
             || RPAD ('Div ID', 7, ' ')
             || RPAD ('Deposit Date', 13, ' ')
             || LPAD ('Amount', 18, ' ')
            );
   writeout (   RPAD ('------------', 13, ' ')
             || RPAD ('------------------------------', 31, ' ')
             || RPAD ('---------', 10, ' ')
             || RPAD ('---------', 10, ' ')
             || RPAD ('------', 7, ' ')
             || RPAD ('------------', 13, ' ')
             || LPAD ('-----------------', 18, ' ')
            );

   FOR c_rec_without_batch IN c_dep_without_batch (c_deposit_dte_from      => p_deposit_dte_from,
                                                   c_deposit_dte_to        => p_deposit_dte_to
                                                  )
   LOOP
      -- Increment the record counter
      l_rec_found := l_rec_found + 1;
      v_date := TO_CHAR (c_rec_without_batch.deposit_date, 'MM/DD/YYYY');
      writeout (   RPAD (NVL (TO_CHAR (c_rec_without_batch.receipt_number), ' '), 13, ' ')
                || RPAD (NVL (c_rec_without_batch.subr_id, ' '), 31, ' ')
                || RPAD (NVL (c_rec_without_batch.grp_id, ' '), 10, ' ')
                || RPAD (NVL (c_rec_without_batch.subloc_id, ' '), 10, ' ')
                || RPAD (NVL (c_rec_without_batch.div_id, ' '), 7, ' ')
                || RPAD (NVL (v_date, ' '), 13, ' ')
                || LPAD (TRIM (TO_CHAR (c_rec_without_batch.receipt_amount, '999G999G999G999G999D99')),
                         18,
                         ' '
                        )
               );
   END LOOP;

   -- If no records found then write it.
   IF l_rec_found = 0
   THEN
      writeout (' ');
      writeout ('No Records Found');
   END IF;

   writeout (' ');
   writeout ('Report Completed Successfully.');
EXCEPTION
   WHEN OTHERS
   THEN
      p_errorcode := 1;
      p_errortext := 'Error Occured ::' || SQLERRM;
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write (dcs2000.pkg_rptg_requests.g_log_file,
                                                   'Error Encountered while processing record:: '
                                                  );
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write (dcs2000.pkg_rptg_requests.g_log_file, SQLERRM);
END prc_rpt_ar_deposit_by_batch;
/