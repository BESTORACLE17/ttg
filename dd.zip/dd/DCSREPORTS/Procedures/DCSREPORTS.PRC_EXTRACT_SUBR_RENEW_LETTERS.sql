CREATE OR REPLACE PROCEDURE /* 3.1.1 */ dcsreports.prc_extract_subr_renew_letters (
   p_errorcode      IN OUT   NUMBER,
   p_errortext      IN OUT   VARCHAR2,
   p_company_id     IN       NUMBER DEFAULT 1,
   p_product_line   IN       dcs2000.tbl_code_product_line.code%TYPE
)
AS
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
||                          Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| SR             SR10161.03.CO Story 3
|| Created On     01/21/2011
|| Revision Type  Creation.
|| Created By     Prasad Jampana
|| Description    This procedure is used to create an extract that
||                displays bounced email report for Subscriber renewal Letters
|| Release        
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
   ln_dummy              NUMBER
      := common.pkg_product_line.fnc_set_product_line_context (p_product_line);
   -- ==============================
   --    Declaration Section
   -- ==============================
   c_prog_key   CONSTANT VARCHAR2 (30) := 'PRC_EXTRACT_SUBR_RENEW_LETTERS';
   ln_company_id         dcs2000.tbl_company.company_id%TYPE;

-- ==============================
--  Cursor Declaration Section
-- ==============================
   CURSOR subscribers
   IS
      SELECT DISTINCT indv.subr_id, indv.fnme, indv.lnme, cvg.grp_id,
                      cvg.subloc_id, cvg.div_id, contact.email_addr,
                      dcsreports.fnc_build_address
                                              (indv.fnme || ' ' || indv.lnme,
                                               address.addr1,
                                               address.addr2,
                                               address.addr3,
                                               address.city,
                                               address.state,
                                               address.zip,
                                               address.zip4
                                              ) AS subr_address,
                      'Unable to send email' comments
                 FROM dcs2000.tbl_subr_indv indv,
                      dcs2000.tbl_subr_indv_contact contact,
                      dcs2000.tbl_subr_coverage cvg,
                      dcs2000.tbl_eob_emails email,
                      dcs2000.tbl_subr_indv_addr address
                WHERE TO_NUMBER (TO_CHAR (SYSDATE, 'YYYYMMDD'))
                         BETWEEN cvg.cover_eff_dte
                             AND DECODE (cvg.cover_trm_dte,
                                         0, 99999999,
                                         cvg.cover_trm_dte
                                        )
                  AND contact.subr_id = indv.subr_id
                  AND contact.indv_id = indv.indv_id
                  AND cvg.subr_id = indv.subr_id
                  AND cvg.indv_id = indv.indv_id
                  AND indv.subr_id =
                         DECODE (address.subr_id,
                                 NULL, indv.subr_id,
                                 address.subr_id
                                )
                  AND indv.indv_id =
                         DECODE (address.indv_id,
                                 NULL, indv.indv_id,
                                 address.indv_id
                                )
                  AND indv.indv_id = 1
                  AND NVL (indv.maint_code, 0) = 0
                  AND NVL (contact.maint_code, 0) = 0
                  AND indv.dcs_assigned_id =
                         CONCAT (SUBSTR(indv.dcs_assigned_id,0,6),
                                 SUBSTR (email.subject,
                                         (instrc (email.subject, '-', 1, 1)
                                          + 1
                                         ),
                                         8
                                        )
                                )
                  AND email.bounce_type = 'SRL'
                  AND NVL (indv.maint_code, 0) = 0
                  AND NVL (contact.maint_code, 0) = 0
      UNION
      SELECT DISTINCT indv.subr_id, indv.fnme, indv.lnme, cvg.grp_id,
                      cvg.subloc_id, cvg.div_id, contact.email_addr,
                      dcsreports.fnc_build_address
                                              (indv.fnme || ' ' || indv.lnme,
                                               address.addr1,
                                               address.addr2,
                                               address.addr3,
                                               address.city,
                                               address.state,
                                               address.zip,
                                               address.zip4
                                              ) AS subr_address,
                      'E-Mail address not found' comments
                 FROM dcs2000.tbl_subr_indv indv,
                      dcs2000.tbl_subr_indv_contact contact,
                      dcs2000.tbl_subr_coverage cvg,
                      dcs2000.tbl_subr_renewal_exceptions exc,
                      dcs2000.tbl_subr_indv_addr address
                WHERE TO_NUMBER (TO_CHAR (SYSDATE, 'YYYYMMDD'))
                         BETWEEN cvg.cover_eff_dte
                             AND DECODE (cvg.cover_trm_dte,
                                         0, 99999999,
                                         cvg.cover_trm_dte
                                        )
                  AND contact.subr_id = indv.subr_id
                  AND contact.indv_id = indv.indv_id
                  AND cvg.subr_id = indv.subr_id
                  AND cvg.indv_id = indv.indv_id
                  AND indv.subr_id = address.subr_id
                  AND indv.indv_id = address.indv_id
                  AND indv.indv_id = 1
                  AND NVL (indv.maint_code, 0) = 0
                  AND NVL (contact.maint_code, 0) = 0
                  AND indv.subr_id = exc.subr_id
                  AND exc.email_addr IS NULL
                  AND NVL (indv.maint_code, 0) = 0
                  AND NVL (contact.maint_code, 0) = 0;
                  
                  
   lutl_file_handle      UTL_FILE.file_type;
BEGIN
   p_errorcode := 0;
   p_errortext := NULL;
   pkg_xml_utils.g_xml_file := dcs2000.pkg_rptg_requests.g_out_file;
   PKG_XML_UTILS.WRITE_EXCEL_WORKBOOK_HEADER;
   PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_HEADER('Subscriber Renewal Letters Status Report');
--
-- Column Widths
-- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (100);        -- SUBSCRIBER ID
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (90);         -- GROUP ID
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (70);         -- SUBLOCATION ID
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (70);         -- DIVISION ID
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (100);        -- SUBR FIRST NAME
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (100);        -- SUBR LAST NAME
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (180);        -- SUBR EMAIL ADDRESS
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (320);        -- SUBR ADDRESS
   PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH (200);        -- COMMENTS
   
  
  --Display Input Parameters
   PKG_XML_UTILS.WRITE_EXCEL_ROW_HEADER;
--
-- Column Header Cells
-- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Run Date','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL (SYSDATE,'String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   
   PKG_XML_UTILS.WRITE_EXCEL_ROW_FOOTER;
   
   PKG_XML_UTILS.WRITE_EXCEL_ROW_HEADER;
--
-- Column Header Cells
-- ---------------------------------------------------------
   pkg_xml_utils.write_excel_cell ('User','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   pkg_xml_utils.write_excel_cell (USER,'String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   
   PKG_XML_UTILS.WRITE_EXCEL_ROW_FOOTER;
--
-- Begin Row
-- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_ROW_HEADER;
--
-- Column Header Cells
-- ---------------------------------------------------------
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Subscriber Id','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Group Id','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Subloc Id','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Div Id','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('First Name','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Last Name','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('E-Mail','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Address','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);
   PKG_XML_UTILS.WRITE_EXCEL_CELL ('Comments','String',PKG_XML_UTILS.G_STYLEID_HDR_LA);   
                                                              
   PKG_XML_UTILS.WRITE_EXCEL_ROW_FOOTER;

   FOR rec IN subscribers
   LOOP
      PKG_XML_UTILS.WRITE_EXCEL_ROW_HEADER;
      
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.SUBR_ID);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.GRP_ID);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.SUBLOC_ID);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.DIV_ID);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.FNME);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.LNME);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.EMAIL_ADDR);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.SUBR_ADDRESS);
      PKG_XML_UTILS.WRITE_EXCEL_CELL (REC.COMMENTS);
      
      PKG_XML_UTILS.WRITE_EXCEL_ROW_FOOTER;
   END LOOP;

   --DCS2000.PKG_DCS_UTL_FILE.PRC_UTL_FILE_CLOSE (LUTL_FILE_HANDLE);
   --
   -- End the WorkSheet
   -- ------------------------------------------------------------

   PKG_XML_UTILS.WRITE_EXCEL_WORKSHEET_FOOTER(0,1);
   --
   -- End the WorkBook
   -- ------------------------------------------------------------

   PKG_XML_UTILS.WRITE_EXCEL_WORKBOOK_FOOTER;
EXCEPTION
   WHEN OTHERS
   THEN
      p_errorcode := -1;
      p_errortext := SQLERRM;
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write
                              (dcs2000.pkg_rptg_requests.g_log_file,
                               'Error Encountered while processing record:: '
                              );
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write
                                        (dcs2000.pkg_rptg_requests.g_log_file,
                                         SQLERRM
                                        );
END prc_extract_subr_renew_letters;
/

GRANT EXECUTE ON dcsreports.prc_extract_subr_renew_letters TO dcs_users_all;
GRANT EXECUTE ON dcsreports.prc_extract_subr_renew_letters TO dcs2000;
/