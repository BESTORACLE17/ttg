CREATE OR REPLACE PROCEDURE /* VERSION: 2.0.7 */ dcsreports.prc_rpt_aso_bill_sum_tpa (
   p_report_cursor   IN OUT   dcsreports.pkg_rpt_utils.typ_report_cursor,
   p_run_mode        IN       CHAR DEFAULT 'W',
   p_billing_run     IN       CHAR,
   p_product_line    IN       dcs2000.tbl_code_product_line.code%TYPE,
   p_company_id      IN       dcs2000.tbl_company.company_id%TYPE                                               -- 2.0.2
)
IS
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Initial Creation
|| Version #      : 2.0.0
|| Service Request: SR
|| Revision By    : Satya Sai
|| Revision Date  : 12/30/2010
|| Revision Desc  : Initial Creation
||                  Source from DCSREPORTS.PRC_RPT_ASO_BILLING_SUMMARY
||                  as of 12/30/2010
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.0.1
|| Revision Type  : Enhancement
|| SR/WO          : SR 10067.02.ALL
|| Revision By    : Amit Dahra
|| Revision Date  : 02/18/2011
|| Revision Desc  : Added product line check in the where clause.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.2
|| Revision Type  : Enhancement
|| SR/WO          : SR10340.01.VA TPA Billing
|| Revision By    : Satya Sai
|| Revision Date  : 03/21/2011
|| Revision Desc  : Added Company ID and Name to the ref cursor
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.3
|| Revision Type  : Enhancement
|| SR/WO          : SR10067.02.ALL Multi Product
|| Revision By    : Amit Dahra
|| Revision Date  : 03/23/2011
|| Revision Desc  : Context for Product line is cleared.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.4
|| Revision Type  : Enhancement
|| SR/WO          : SR11342.13.VA
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 02/02/2012
|| Revision Desc  : Added tax amount
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.5
|| Revision Type  : Enhancement
|| SR/WO          : SR11165.02.VA
|| Revision By    : Arun Pottammal
|| Revision Date  : 03/20/2012
|| Revision Desc  : Added Invoice_Date, Invoice_Number, Display_Invoice_Info.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.6
|| Revision Type  : Enhancement
|| SR/WO          : SR11165.02.VA
|| Revision By    : Arun Pottammal
|| Revision Date  : 04/10/2012
|| Revision Desc  : Passed Company.company_name to billing address full..
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.0.7
|| Revision Type  : Bug Fix
|| SR/WO          : Trac10675
|| Revision By    : Dinesh Makked
|| Revision Date  : 05/24/2012
|| Revision Desc  : Display Tax Amount if Bill Claims Flag is Y.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
*/ -- Error Reporting Variables
   c_prog_key   CONSTANT VARCHAR2 (30)                                 := 'RPT_ASO_BILLING_SUMMARY_TPA';
   ln_request_id         dcs2000.tbl_rptg_requests.req_id%TYPE;
   ln_errorcode          NUMBER;
   lv_errortext          VARCHAR2 (4000);
   lv_debug              VARCHAR2 (32676);
   --ln_dummy              NUMBER                   := COMMON.PKG_PRODUCT_LINE.FNC_SET_PRODUCT_LINE_CONTEXT(p_product_line);
   l_parent_id           NUMBER                                        := SYS_CONTEXT ('CNT_PARENT_ID', 'PARENT_ID');
   lv_parent_name        dcs2000.tbl_parent_company.parent_name%TYPE;
   lv_installation       VARCHAR2(40);  -- 2.0.5
   C_DISPLAY_INVOICE_INFO_IN_ASC CONSTANT VARCHAR2(1):= dcs2000.Fnc_Get_System_Parameter('DISPLAY_INVOICE_INFO_IN_ASC');  -- 2.0.5
BEGIN
   common.pkg_product_line.prc_clear_product_line_context;

   BEGIN
      SELECT parent_name
        INTO lv_parent_name
        FROM dcs2000.tbl_parent_company
       WHERE parent_id = l_parent_id AND NVL (maint_code, 0) = 0;
   EXCEPTION
      WHEN OTHERS
      THEN
         lv_parent_name             := NULL;
   END;

   OPEN p_report_cursor FOR
      SELECT hdr.parent_id, lv_parent_name parent_name,
             hdr.grp_id || '-' || hdr.reporting_subloc_id || '-' || hdr.reporting_div_id AS grp_id,
             hdr.group_name, hdr.reporting_code, phdr.bill_from_date AS billing_from_date,
             phdr.bill_to_date AS billing_end_date, phdr.bill_due_date AS billing_due_date,
             admin_dtl.total_subr_count, nvl(admin_dtl.total_admin_amt,0) total_admin_amt,
             DECODE (hdr.bill_claims, 'Y',claim_dtl.total_claims_cnt, NULL) AS total_claims_cnt,
             DECODE (hdr.bill_claims, 'Y', nvl(claim_dtl.total_claims_amt,0), NULL) AS total_claims_amt,
             DECODE (hdr.bill_claims, 'Y', nvl(claim_dtl.total_tax_amt,0), 0) AS total_tax_amt,
             hdr.admin_subloc_id,                           -- 2.0.2
             hdr.asc_billing_process_header_pk,
             (SELECT dcsreports.pkg_utilities.fnc_get_company_id
                                                                (hdr.grp_id,
                                                                 hdr.admin_subloc_id,
                                                                 hdr.asc_billing_process_header_pk
                                                                )
                FROM DUAL) company_id,
             dcsreports.fnc_build_address (company.company_name,
                                 addr.first_name || ' ' || addr.last_name,
                                 addr.address1,
                                 addr.address2 || ' ' || addr.address3,
                                 addr.city,
                                 addr.state,
                                 addr.zip,
                                 addr.zip4
                                ) AS billing_address_full,                                                    -- 2.0.5 
             hdr.parent_id ||LPAD(TO_NUMBER(TO_CHAR(SYSDATE, 'DDD')),3,0)|| DCS2000.PKG_DCS_COMPANY_ID.FNC_GET_COMPANY_ID
                                                                                 (hdr.grp_id,
                                                                                  hdr.admin_subloc_id,
                                                                                  hdr.reporting_div_id,
                                                                                  TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMMDD')),
                                                                                  'Y'
                                                                                 ) as Invoice_Number,         -- 2.0.5
             TO_CHAR (SYSDATE, 'MM/DD/YYYY') AS Invoice_Date,                                                 -- 2.0.5
             C_DISPLAY_INVOICE_INFO_IN_ASC as Display_Invoice_Info,                                           -- 2.0.5 
             (DECODE(bill_claims, 'Y', nvl(claim_dtl.total_claims_amt,0), 0) 
               + nvl(admin_dtl.total_admin_amt,0) 
               + DECODE(bill_claims, 'Y', nvl(claim_dtl.total_tax_amt,0), 0)) as Total_Due,  
             hdr.past_due AS Prior_Amount_Billed,
             HDR.YTD as YTD,                                                                                  -- 2.0.5 
             HDR.MTD as MTD,                                                                                  -- 2.0.5 
             TO_CHAR (phdr.BILL_DUE_DATE, 'MM/DD/YYYY') as Payment_Due_On,                                    -- 2.0.5 
             company.company_name                                                                             -- 2.0,5
        FROM dcs2000.tbl_asc_billing_header hdr,
             dcs2000.tbl_asc_billing_address addr,
             dcs2000.tbl_asc_billing_process_header phdr,
             (SELECT dtl.asc_billing_header_pk, SUM (bill_count) AS total_claims_cnt,
                     SUM (bill_amount) AS total_claims_amt, SUM (tax_amt) AS total_tax_amt
                FROM dcs2000.tbl_asc_billing_detail dtl
               WHERE NVL (dtl.maint_code, 0) = 0
               GROUP BY dtl.asc_billing_header_pk) claim_dtl,
             (SELECT dtl.asc_billing_header_pk, SUM (admin_count) AS total_subr_count,
                     SUM (admin_amount) AS total_admin_amt
                FROM dcs2000.tbl_asc_admin_billing_detail dtl
               WHERE NVL (dtl.maint_code, 0) = 0
               GROUP BY dtl.asc_billing_header_pk) admin_dtl,
            dcs2000.tbl_company company
      WHERE NVL (hdr.maint_code, 0) = 0
        AND NVL (phdr.maint_code, 0) = 0
        AND NVL (addr.maint_code, 0) = 0
        AND hdr.asc_billing_header_pk = addr.asc_billing_header_pk
        AND hdr.asc_billing_process_header_pk = phdr.asc_billing_process_header_pk
        AND hdr.asc_billing_header_pk = claim_dtl.asc_billing_header_pk(+)
        AND hdr.asc_billing_header_pk = admin_dtl.asc_billing_header_pk(+)
        AND hdr.product_line_code =
                                  DECODE (NVL (p_product_line, -1),
                                          -1, hdr.product_line_code,
                                          p_product_line
                                         )
       AND company.company_id = dcsreports.pkg_utilities.fnc_get_company_id
                                                              (hdr.grp_id,
                                                               hdr.admin_subloc_id,
                                                               hdr.asc_billing_process_header_pk
                                                              ) 
      AND company.company_id = NVL (p_company_id, company.company_id)
    ORDER BY company_id, grp_id, group_name;
EXCEPTION
   WHEN OTHERS
   THEN
--
-- Store the error code and message in the local variables
-- ---------------------------------------------------------
      ln_errorcode               := SQLCODE;
      lv_errortext               := SQLERRM;

--
-- Log the error message in the report error table
-- ---------------------------------------------------
      INSERT INTO dcsreports.tbl_report_errors
                  (request_id, prog_key, run_date, executed_by, error_number,
                   ERROR_TEXT, debug_info
                  )
           VALUES (ln_request_id, c_prog_key, SYSDATE, common.pkg_parent_id_utils.fnc_get_app_username, ln_errorcode,
                   lv_errortext, lv_debug
                  );
--
END prc_rpt_aso_bill_sum_tpa;
/

GRANT EXECUTE ON dcsreports.prc_rpt_aso_bill_sum_tpa TO dcs_users_all, vadeveloper;
/