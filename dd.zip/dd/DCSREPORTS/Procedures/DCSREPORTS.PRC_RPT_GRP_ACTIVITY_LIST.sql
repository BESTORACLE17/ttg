CREATE OR REPLACE PROCEDURE /* VERSION: 2.1.7 */                       DCSREPORTS.PRC_RPT_GRP_ACTIVITY_LIST
   (  p_report_cursor   IN OUT   DCSREPORTS.PKG_RPT_UTILS.TYP_REPORT_CURSOR
   ,  p_grp_id          IN       DCS2000.TBL_GSD.grp_id%TYPE      DEFAULT 'ALL'
   ,  p_subloc_id       IN       DCS2000.TBL_GSD.subloc_id%TYPE   DEFAULT 'ALL'   
   ,  p_div_id          IN       DCS2000.TBL_GSD.div_id%TYPE      DEFAULT 'ALL'
   ,  p_start_dte       IN       DATE  := NULL
   ,  p_end_dte         IN       DATE  := NULL
   ,  p_category        IN       DCS2000.VEW_GRP_ACTIVITY_LIST.REP_CATEGORY%TYPE DEFAULT NULL    
   ,  p_gar_version     IN       VARCHAR2 -- 2.1.2
   ,  p_grouping_id     IN       DCS2000.VEW_GRP_ACTIVITY_LIST_GROUPING.GROUPING_ID%TYPE  DEFAULT NULL
   ,  p_product_line    IN       DCS2000.TBL_CODE_PRODUCT_LINE.CODE%TYPE        -- Version 2.1.6
   )
IS
/*
|| -----------------------------------------------------------------------------
|| Version        : 2.1.1 
|| Revision Type  : Creation
|| Service Request: SR#04033.03.VA ASO Billing Enhancements
|| Revision By    : Manoj Sathe
|| Revision Date  : 03/09/2008
|| Revision Desc  : Initial Development
|| -----------------------------------------------------------------------------
|| Version        : 2.1.2
|| Revision Type  : Enhancement
|| Service Request: SR#04033.03.VA ASO Billing Enhancements
|| Revision By    : Dinesh Makked
|| Revision Date  : 03/11/2008
|| Revision Desc  : Added parameter p_gar_version.
|| -----------------------------------------------------------------------------
|| Version        : 2.1.3
|| Revision Type  : Enhancement
|| Service Request: SR#04033.03.VA ASO Billing Enhancements
|| Revision By    : Deborah Yates
|| Revision Date  : 03/13/2008
|| Revision Desc  : Updated to use the new SUMMARY_GROUP_NAME column.
|| -----------------------------------------------------------------------------
|| Version        : 2.1.4
|| Revision Type  : Enhancement
|| Service Request: SR#04033.03.VA ASO Billing Enhancements
|| Revision By    : Deborah Yates
|| Revision Date  : 03/13/2008
|| Revision Desc  : Modified to get the data from VEW_RPT_GRP_ACTIVITY_LIST.
|| -----------------------------------------------------------------------------
|| Version        : 2.1.5
|| Revision Type  : Enhancement
|| Service Request: SR#04033.03.VA ASO Billing Enhancements
|| Revision By    : Manoj Sathe
|| Revision Date  : 03/16/2008
|| Revision Desc  : 1. Added check to validate for GSD /Category parameter values
||                  2. Added Insert for Report detail  if pkg_utilities is set 
||                    in debug mode  
|| -----------------------------------------------------------------------------
|| Version        : 2.1.6
|| Revision Type  : Enhancement
|| SR/WO          : SR 10067.02.ALL
|| Revision By    : Madhusudan Sharma
|| Revision Date  : 07/23/2010.
|| Revision Desc  : p_product_line parameter added
||                  LN_DUMMY is created to set the context of Product Line
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
|| Version        : 2.1.7
|| Revision Type  : Enhancement
|| SR/WO          : SR11342.13.VA
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 02/08/2012
|| Revision Desc  : Added tax amount
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
*/ 
   ln_dummy                NUMBER := COMMON.PKG_PRODUCT_LINE.FNC_SET_PRODUCT_LINE_CONTEXT(p_product_line); -- Version 2.1.6
   -- =============================
   -- Constant Declaration Section
   -- =============================
   c_prog_key              CONSTANT VARCHAR2(30)   := 'RPT_GROUP_ACTIVITY_LIST';
   c_all_gsd_values        CONSTANT VARCHAR2(30)   := 'ALL';                     -- 2.1.5
   -- =============================
   -- Variable Declaration Section
   -- =============================
   
   ln_errorcode            NUMBER;
   lv_errortext            VARCHAR2(4000);
   ln_request_id           dcs2000.tbl_rptg_requests.req_id%TYPE := -1;          -- 2.1.5
   
   lv_sql_statement        VARCHAR2(4000);
   lv_sql_from_clause      VARCHAR2(1000);
   lv_sql_where_clause     VARCHAR2(1000);                   
   v_debug_info            common.Pkg_Error_Handling.typ_debug_info ;
   
   ln_start_dte            DCS2000.TBL_WIP_HIST_HEADER.CHECK_DATE%TYPE ;
   ln_end_dte              DCS2000.TBL_WIP_HIST_HEADER.CHECK_DATE%TYPE ;
   lv_grp_id               DCS2000.TBL_GSD.GRP_ID%TYPE ;
   lv_subloc_id            DCS2000.TBL_GSD.SUBLOC_ID%TYPE ;
   lv_div_id               DCS2000.TBL_GSD.DIV_ID%TYPE ;

BEGIN

   lv_grp_id      := PKG_RPT_UTILS.FNC_RPT_EVAL_LIKE_GRP_ID(p_grp_id);
   lv_subloc_id   := PKG_RPT_UTILS.FNC_RPT_EVAL_LIKE_SUBLOC_ID(p_subloc_id);
   lv_div_id      := PKG_RPT_UTILS.FNC_RPT_EVAL_LIKE_DIV_ID(p_div_id);

   --
   -- check the check date from
   -- =====================================================
   IF p_start_dte IS NULL THEN
      ln_start_dte := 0;
   ELSE
      ln_start_dte := TO_NUMBER(TO_CHAR(p_start_dte,'yyyymmdd'));
   END IF;

   --
   -- check the check date to
   -- =====================================================
   IF p_end_dte IS NULL THEN
      ln_end_dte := 99991231;
   ELSE
      ln_end_dte := TO_NUMBER(TO_CHAR(p_end_dte,'yyyymmdd'));
   END IF;
   --- Checking for the Report parameters    
   v_debug_info := 'PRC_RPT_ACT_GRP :: Inside procedure';
   
   lv_sql_statement := ' SELECT 
                               gal.CLAIM_NO
                             , gal.GRP_ID
                             , gal.SUBLOC_ID
                             , gal.DIV_ID
                             , gal.GRP_NAME
                             , gal.SUBR_NAME
                             , gal.SUBR_ID
                             , gal.TREATMENT_DTE
                             , gal.SUBMITED_FEE
                             , gal.NET
                             , gal.PATIENT_PAYS
                             , gal.DEDUCTIBLE
                             , gal.OVER_MAX
                             , gal.COB
                             , gal.PROCESS_POLICY_CODE1
                             , gal.PROCESS_POLICY_CODE2
                             , gal.PROCESS_POLICY_CODE3
                             , gal.PROCESS_POLICY1
                             , gal.PROCESS_POLICY2
                             , gal.PROCESS_POLICY3
                             , gal.RATE_CODE
                             , gal.REL_CODE
                             , gal.PARTICIPATING
                             , gal.CHECK_DATE
                             , gal.REP_CATEGORY
                             , gal.REP_CATEGORY_DESC
                             , gal.COMPANY_ID
                             , gal.PARENT_ID
                             , gal.relationship
                             , gal.summary_group_name
                             , gal.mstr_grp_id
                             , gal.mstr_subloc_id
                             , gal.mstr_div_id
                             , gal.subr_heading
                             , gal.tax_amt ';
   
   lv_sql_from_clause :=' FROM DCS2000.vew_rpt_grp_activity_list     gal';
   
   lv_sql_where_clause :=' WHERE gal.CHECK_DATE         BETWEEN '||ln_start_dte   
                                                                 || ' AND '
                                                                 ||ln_end_dte ;

   IF (p_grp_id <> c_all_gsd_values)                                             -- 2.1.5
   THEN 
      lv_sql_where_clause := lv_sql_where_clause
                             || ' AND gal.grp_id like '
                             || '''' ||lv_grp_id || '''';
   END IF;                                             
   
   IF (p_subloc_id <> c_all_gsd_values)                                          -- 2.1.5
   THEN 
      lv_sql_where_clause := lv_sql_where_clause
                             || ' AND gal.subloc_id like ' 
                             || '''' ||lv_subloc_id || '''';                                             
   END IF;
   
   IF (p_div_id <> c_all_gsd_values)                                             -- 2.1.5
   THEN 
      lv_sql_where_clause := lv_sql_where_clause
                             || ' AND gal.div_id like ' 
                             || '''' ||lv_div_id || '''' ;                                             
   END IF;
   
   IF (NVL(p_category, 0) > 0 )                                                   -- 2.1.5
   THEN 
      lv_sql_where_clause := lv_sql_where_clause
                             || ' AND gal.REP_CATEGORY = ' 
                             || p_category ;                                             
   END IF;
   
   IF (NVL(p_grouping_id, 0) > 0)                                                -- 2.1.5
   THEN 
      lv_sql_from_clause  := lv_sql_from_clause  
                             ||', DCS2000.VEW_GRP_ACTIVITY_LIST_GROUPING  act_grp';
                            
      lv_sql_where_clause := lv_sql_where_clause
                             || ' AND act_grp.GRP_ACTIVITY_LIST_PK = gal.GRP_ACTIVITY_LIST_PK
                                  AND act_grp.GROUPING_ID ='
                             || p_grouping_id ;
   END IF;                                             

  lv_sql_statement :=  lv_sql_statement
                     || lv_sql_from_clause
                     || lv_sql_where_clause ;    

   -- ------------------------------------------------------------------------------
   -- Store the dynamic sql if the pkg_utilities is set in debug mode.
   -- 2.1.5
   -- ------------------------------------------------------------------------------
   BEGIN

      IF PKG_UTILITIES.SAVE_DYNAMIC_SQL_STATEMENT THEN
         INSERT INTO DCSREPORTS.TBL_RPT_DYNAMIC_SOURCE
            (REQUEST_ID, PROG_KEY, RUN_DATE, EXECUTED_BY, SOURCE_SQL, EXECUTED_FLAG)
         VALUES
            (ln_request_id, c_prog_key, SYSDATE, USER, lv_sql_statement, 'Y');

         COMMIT;

      END IF;

   EXCEPTION
      WHEN OTHERS THEN
         NULL;
   END;  

   OPEN p_report_cursor 
    FOR lv_sql_statement ;
   
EXCEPTION
   WHEN OTHERS THEN
      --
      -- Store the error code and message in the local variables
      -- ---------------------------------------------------------
      ln_errorcode := SQLCODE;
      lv_errortext := SQLERRM;

      --
      -- Log the error message in the report error table
      -- ---------------------------------------------------
      INSERT INTO DCSREPORTS.tbl_report_errors
        (request_id, prog_key, run_date, executed_by, error_number, error_text, debug_info)
      VALUES
        (ln_request_id, c_prog_key, SYSDATE, USER, ln_errorcode, lv_errortext, v_debug_info);

      COMMIT;

END PRC_RPT_GRP_ACTIVITY_LIST ;
/