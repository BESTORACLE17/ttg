CREATE OR REPLACE PROCEDURE /* VERSION: 2.0.0 */  DCSREPORTS.prc_prv_par_statistics_rpt 
(  p_errorcode       IN OUT   NUMBER,
   p_errortext       IN OUT   VARCHAR2,
   p_begin_date      IN       DATE,
   p_end_date        IN       DATE,
   p_report_type     IN       NUMBER := 2,                                                
   p_product_line    IN       dcs2000.tbl_code_product_line.code%TYPE,
   p_network_id      IN       dcs2000.tbl_parent_network.network_id%TYPE
)
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.0.0
|| Revision Type  : Intial Development
|| SR/WO          : SR 11105.02.ALL
|| Revision By    : Satya Sai
|| Revision Date  : 09/16/2011
|| Revision Desc  : Changing Report to Generate Excel, instead of 
||                  Crystal Report
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-.
*/
IS
   ln_dummy                NUMBER         := common.pkg_product_line.fnc_set_product_line_context (p_product_line);
   g_number_all   CONSTANT NUMBER         := dcsreports.pkg_utilities.g_number_all;
   lv_network_id           VARCHAR2 (10);
   ln_tot_no_prv           NUMBER;
   ln_tot_vol_prv_term     NUMBER;
   ln_tot_invol_prv_term   NUMBER;
   ln_tot_cnt_begin_dte    NUMBER;
   ln_tot_cnt_end_dte      NUMBER;
   ln_avg_turnober         NUMBER;         
   lv_reporty_type         VARCHAR2(20);
   lv_product_line_desc    VARCHAR2(80);
   lv_network_desc         VARCHAR2(520);
   lv_work_sheet_name      provider.tbl_code_network.NETWORK_INITIAL%type;
   
  CURSOR C_PRODUCTS
      IS 
     select DISTINCT PRD_CDE,PRODUCT
       from DCS2000.TBL_PRV_STATISTICS 
      order by PRD_CDE;
   
  CURSOR C_DATA ( lp_product IN DCS2000.TBL_PRV_STATISTICS.PRD_CDE%TYPE)
      IS 
     select  PRD_CDE, SPC_CDE, SPECIALTY, NO_OF_PROVIDERS, VOL_TERM_CNT, INVOL_TERM_CNT, COUNT_AS_BEGIN_DTE, COUNT_AS_END_DTE
          , TURNOVER
       from DCS2000.TBL_PRV_STATISTICS
      where PRD_CDE = lp_product
   group by PRD_CDE
          , SPC_CDE, SPECIALTY, NO_OF_PROVIDERS, VOL_TERM_CNT, INVOL_TERM_CNT, COUNT_AS_BEGIN_DTE, COUNT_AS_END_DTE, TURNOVER;
          
  
  CURSOR C_TOTALS ( lp_product IN DCS2000.TBL_PRV_STATISTICS.PRD_CDE%TYPE)
      IS 
     select sum(NO_OF_PROVIDERS)           TOT_NO_OF_PROVIDERS
          , sum(VOL_TERM_CNT)              TOT_VOL_TERM_CNT
          , sum(INVOL_TERM_CNT)            TOT_INVOL_TERM_CNT 
          , sum(COUNT_AS_BEGIN_DTE)        TOT_COUNT_AS_BEGIN_DTE
          , sum(COUNT_AS_END_DTE)          TOT_COUNT_AS_END_DTE
          , CASE WHEN  sum(COUNT_AS_BEGIN_DTE) > 0
                 THEN  ROUND(((sum(COUNT_AS_END_DTE) * 100) / sum(COUNT_AS_BEGIN_DTE)) - 100.2) 
                 ELSE  0
              END AVG_TURNOVER
       from DCS2000.TBL_PRV_STATISTICS 
      where PRD_CDE = nvl(lp_product,PRD_CDE);
        
   PROCEDURE writeout (p_output_string IN VARCHAR)
   IS
   BEGIN
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write
                                       (dcs2000.pkg_rptg_requests.g_out_file,
                                        p_output_string
                                       );
   END writeout;


   PROCEDURE writelog (p_output_string IN VARCHAR)
   IS

   BEGIN
      dcs2000.pkg_dcs_utl_file.prc_utl_file_write
                                       (dcs2000.pkg_rptg_requests.g_log_file,
                                        p_output_string
                                       );
   END writelog;
   
   FUNCTION FNC_GET_WORK_SHEET_NAME 
     ( p_network_id      IN       dcs2000.tbl_parent_network.network_id%TYPE 
     ) RETURN VARCHAR2
   IS
   lv_name  varchar2(2);
   begin 
     select NETWORK_INITIAL
       into lv_name
       from provider.tbl_code_network
      where code =  p_network_id;
      
      RETURN (lv_name);
      
   exception
       WHEN NO_DATA_FOUND THEN
          lv_name := 'ZZ';
          
          RETURN (lv_name);
   end FNC_GET_WORK_SHEET_NAME;
       
   PROCEDURE INP_WRITE_PARAMETERS
   IS
   
   BEGIN
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY BEGIN DATE
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Begin Date',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (p_begin_date);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
      
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY End DATE
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('End Date',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (p_end_date);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
    /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Report Type 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
         IF P_REPORT_TYPE = 1
         THEN
            LV_REPORTY_TYPE   := 'INTERNAL';
         ELSE
             LV_REPORTY_TYPE  := 'EXTERNAL';
         END IF;
   
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('ReportType',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (LV_REPORTY_TYPE);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
         
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Product Line 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */
       begin 
        select code || ' - '||description
          into lv_product_line_desc
          from dcs2000.tbl_code_product_line
         where code =  p_product_line;
       exception
          WHEN NO_DATA_FOUND THEN
             lv_product_line_desc := NULL;
       end;
         
   
         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Product Line',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (lv_product_line_desc);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
         
   /*
   || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                          DISPLAY Network 
   ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
   */    
         if  p_network_id = g_number_all
          then
            lv_network_desc := 'All Network ID''s';
         else
             begin 
              select code || ' - '||description
                into lv_network_desc
                from provider.tbl_code_network
               where code =  p_network_id;
             exception
                WHEN NO_DATA_FOUND THEN
                   lv_network_desc := NULL;
             end;
         end if;

         pkg_xml_utils.write_excel_row_header;

      -- Column Header Cells
      -- ---------------------------------------------------------
         pkg_xml_utils.write_excel_cell ('Network ID',
                                         'String',
                                         pkg_xml_utils.g_styleid_hdr_la
                                        );
         pkg_xml_utils.write_excel_cell (lv_network_desc);

      -- END ROW
      -- ----------------------------------------------------------
         pkg_xml_utils.write_excel_row_footer;
         
   END INP_WRITE_PARAMETERS;
   
   PROCEDURE INP_BLANK_ROWS
   IS
   BEGIN
     -- Blank line to separate the deatials of report table header
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;
   END INP_BLANK_ROWS;
   
   PROCEDURE INP_REPORT_BY_NETWORK 
     ( p_network_id      IN       dcs2000.tbl_parent_network.network_id%TYPE )
   IS
   BEGIN
       lv_work_sheet_name := NULL;
       
       -- GET Work Sheet Name
       lv_work_sheet_name := FNC_GET_WORK_SHEET_NAME ( p_network_id => P_NETWORK_ID );
        
       -- Work Sheet Name 
       pkg_xml_utils.write_excel_worksheet_header ('Provider Par Statistics '|| '('||lv_work_sheet_name ||')');

      --
      -- Column Widths
      -- ---------------------------------------------------------
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(200);   --  Specialty
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Number of Providers Added
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Number of Providers Voluntarily Terminated
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Number of Providers Involuntarily Terminated
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Count as of Begin Date
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Count as of End Date
      PKG_XML_UTILS.WRITE_EXCEL_COLUMN_WIDTH(100);   --  Turnover 
     
      --
      -- Write Paraters Passed
      -- --------------------------------------------------------- 
       INP_WRITE_PARAMETERS();
            
      -- Blank line to separate the deatials of report table header
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;
      pkg_xml_utils.write_excel_row_header;
      pkg_xml_utils.write_excel_row_footer;

       for REC_PRODUCTS in C_PRODUCTS
       loop
       
               pkg_xml_utils.write_excel_row_header;

            -- Column Header Cells
            -- ---------------------------------------------------------
               pkg_xml_utils.write_excel_cell ('PRODUCT',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell (REC_PRODUCTS.PRODUCT, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);

            -- END ROW
            -- ----------------------------------------------------------
               pkg_xml_utils.write_excel_row_footer;
               
         /*
            || +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
                                DISPLAY  ORDER
           ||+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
        */
               pkg_xml_utils.write_excel_row_header;
               
            --
            --
            -- Column Header Cells
            -- ---------------------------------------------------------
            --
                pkg_xml_utils.write_excel_cell ('Specialty',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell ('Number of Providers Added',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
                pkg_xml_utils.write_excel_cell ('Number of Providers Voluntarily Terminated',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell ('Number of Providers Involuntarily Terminated',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell ('Count as of Begin Date',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell ('Count as of End Date',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
               pkg_xml_utils.write_excel_cell ('Turnover',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );

         -- END ROW
         -- ----------------------------------------------------------
            pkg_xml_utils.write_excel_row_footer;


           for REC_DATA in C_DATA( lp_product => REC_PRODUCTS.prd_cde)
           loop
            --
            -- Begin Row
            -- -----------------------------------------------------------
                  pkg_xml_utils.write_excel_row_header;

            --
            -- Write Row Data
            -- -----------------------------------------------------------
            --
                  pkg_xml_utils.write_excel_cell (REC_DATA.SPECIALTY);
                  pkg_xml_utils.write_excel_cell (REC_DATA.NO_OF_PROVIDERS);
                  pkg_xml_utils.write_excel_cell (REC_DATA.VOL_TERM_CNT);
                  pkg_xml_utils.write_excel_cell (REC_DATA.INVOL_TERM_CNT);
                  pkg_xml_utils.write_excel_cell (REC_DATA.COUNT_AS_BEGIN_DTE);
                  pkg_xml_utils.write_excel_cell (REC_DATA.COUNT_AS_END_DTE);
                  IF REC_DATA.TURNOVER IS NOT NULL
                  THEN
                   pkg_xml_utils.write_excel_cell (REC_DATA.TURNOVER || '%');
                  ELSE
                   pkg_xml_utils.write_excel_cell (NULL);
                  END IF;
            --
            -- END ROW
            -- ----------------------------------------------------------
                  pkg_xml_utils.write_excel_row_footer;

           end loop;-- Specialties  By product
           
           for REC_TOTALS in C_TOTALS ( lp_product => REC_PRODUCTS.prd_cde)
           loop
           
            --
            -- Begin Row
            -- -----------------------------------------------------------
                  pkg_xml_utils.write_excel_row_header;

            --
            -- Write Row Data
            -- -----------------------------------------------------------
            --    
                  pkg_xml_utils.write_excel_cell ('Product Total'
                                                 ,'String'
                                                 , pkg_xml_utils.g_styleid_hdr_la
                                                 );
                  pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_NO_OF_PROVIDERS, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_VOL_TERM_CNT, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_INVOL_TERM_CNT, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_COUNT_AS_BEGIN_DTE, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_COUNT_AS_END_DTE, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  IF REC_TOTALS.AVG_TURNOVER IS NOT NULL
                  THEN
                    pkg_xml_utils.write_excel_cell (REC_TOTALS.AVG_TURNOVER || '%', NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
                  ELSE
                    pkg_xml_utils.write_excel_cell (NULL);
                  END IF;
            --
            -- END ROW
            -- ----------------------------------------------------------
                  pkg_xml_utils.write_excel_row_footer;
           
           end loop; -- Totals By Product
           
            -- **** INSERT BLANK ROWS ****
           INP_BLANK_ROWS();
       end loop; -- ALL Product
       
       -- **** INSERT BLANK ROWS ****
          INP_BLANK_ROWS();
       -- *********** Grand Totals ***********************************************
       for REC_TOTALS in C_TOTALS ( lp_product => NULL)
       loop
           
         --
         -- Begin Row
         -- -----------------------------------------------------------
               pkg_xml_utils.write_excel_row_header;

         --
         -- Write Row Data
         -- -----------------------------------------------------------
         --    
             if REC_TOTALS.TOT_NO_OF_PROVIDERS is not NULL
             then
               pkg_xml_utils.write_excel_cell ('Combined Product Total',
                                               'String',
                                               pkg_xml_utils.g_styleid_hdr_la
                                              );
             end if;
               pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_NO_OF_PROVIDERS, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_VOL_TERM_CNT, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_INVOL_TERM_CNT, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_COUNT_AS_BEGIN_DTE, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               pkg_xml_utils.write_excel_cell (REC_TOTALS.TOT_COUNT_AS_END_DTE, NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               
               IF REC_TOTALS.AVG_TURNOVER IS NOT NULL
               THEN
                 pkg_xml_utils.write_excel_cell (REC_TOTALS.AVG_TURNOVER || '%', NULL, pkg_xml_utils.G_STYLEID_TITLE_CELL);
               ELSE
                 pkg_xml_utils.write_excel_cell (NULL);
               END IF;
             
         --
         -- END ROW
         -- ----------------------------------------------------------
               pkg_xml_utils.write_excel_row_footer;
           
       end loop; -- Grand Totals 
            
      --
      -- End the WorkSheet
      -- ------------------------------------------------------------
         pkg_xml_utils.write_excel_worksheet_footer (0, 1);
   END INP_REPORT_BY_NETWORK; 
   
   
BEGIN

   IF p_network_id = g_number_all
   THEN
      NULL;
   ELSIF p_network_id IS NULL
   THEN
      lv_network_id              := common.pkg_network_id.fnc_set_preferred_network ();
   ELSE
      common.pkg_network_id.prc_set_network_id (p_network_id);
   END IF;
   -- --------------------------------------------------
   --
   -- Parse/convert the parameters
   -- --------------------------------------------------
      pkg_xml_utils.g_xml_file := dcs2000.pkg_rptg_requests.g_out_file;
      pkg_xml_utils.write_excel_workbook_header;
   --
   -- Create Worrk Sheet By Network
   -- --------------------------------------------------
   
   IF p_network_id = g_number_all -- ALL Networks
   THEN
     -- Loop for Networks 
     for rec_networks in ( select code  
                             from provider.tbl_code_network
                            where maint_code = 0 
                           order by code
                         )
     loop
        dcs2000.prc_prv_par_statistics
          (
            p_errorcode      => p_errorcode,
            p_errortext      => p_errortext,
            p_begin_date     => p_begin_date,
            p_end_date       => p_end_date,
            p_report_type    => p_report_type,
            p_product_line   => p_product_line,
            p_network_id     =>  rec_networks.code
          );
    
       INP_REPORT_BY_NETWORK ( p_network_id  =>  rec_networks.code);
     end loop;
   
   ELSIF p_network_id IS NULL
   THEN
      dcs2000.prc_prv_par_statistics
          (
            p_errorcode      => p_errorcode,
            p_errortext      => p_errortext,
            p_begin_date     => p_begin_date,
            p_end_date       => p_end_date,
            p_report_type    => p_report_type,
            p_product_line   => p_product_line,
            p_network_id     => TO_NUMBER(lv_network_id)
          );
      -- Populate Work Sheet
      INP_REPORT_BY_NETWORK ( p_network_id  =>  TO_NUMBER(lv_network_id));
      
   ELSE
       dcs2000.prc_prv_par_statistics
          (
            p_errorcode      => p_errorcode,
            p_errortext      => p_errortext,
            p_begin_date     => p_begin_date,
            p_end_date       => p_end_date,
            p_report_type    => p_report_type,
            p_product_line   => p_product_line,
            p_network_id     => p_network_id
          );
    
      INP_REPORT_BY_NETWORK ( p_network_id  => p_network_id);
      
   END IF;

   --
   -- End the WorkBook
   -- ------------------------------------------------------------
      pkg_xml_utils.write_excel_workbook_footer;
END;
/