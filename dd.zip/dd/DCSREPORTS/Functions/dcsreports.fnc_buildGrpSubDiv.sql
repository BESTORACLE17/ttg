create or replace function /* VERSION: 3.1.0 */ dcsreports.fnc_buildGrpSubDiv
(
    p_GroupId         in dcs2000.tbl_gsd_billing .grp_id%type 
  , p_SublocationId   in dcs2000.tbl_gsd_billing .subloc_id%type
  , p_DivisionId      in dcs2000.tbl_gsd_billing .div_id%type
  , p_ProductLineCode in dcs2000.tbl_gsd_billing .product_line_code%type
  , p_BillingEndDate  in date
)
return varchar2
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Initial Revision 
|| Version #      : 3.1.0
|| Service Request: SR11308.11.OC
|| Revision By    : Stephen Ince
|| Revision Date  : 04/20/2012
|| Revision Desc  : Added to calculate check digit stirng for risk bills generated in ONline Billing
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
is

   lv_grpSubDiv        varchar2(50) := null ;
   lv_combine_bills    varchar2(1)  := null ;
   ln_BillingPeriodEnd number       :=  to_number(to_char(p_BillingEndDate,'yyyymmdd')) ;

   lrec_gsd_prd_pln    dcs2000.tbl_gsd_prd_plan%rowtype ;

   g_state             varchar2 (5) := dcs2000.pkg_dcs_system_parameters.fnc_get_system_parameter ('INSTALLATION');
   g_printcheckdigit   char (1)     := dcs2000.pkg_dcs_system_parameters.fnc_get_system_parameter ('PRINT_CHECK_DIGIT');
   lv_enable_multi_pls dcs2000.tbl_system_parameters_dtl .current_value%type := dcs2000.fnc_get_system_parameter('ENABLE_MULTI_PL_IN_RISK_BILLS');

begin
   lv_grpSubDiv := LPAD (p_GroupId, 9, '0')
                   || ' '
                   || LPAD (p_SublocationId, 8, '0')
                   || ' '
                   || LPAD (p_DivisionId, 4, '0')
                   || ' ' ;

   lv_combine_bills := dcs2000.pkg_dcs_billing.fnc_generate_combine_bills
                       (
                           p_GroupId
                         , p_SublocationId
                         , p_DivisionId
                         , ln_BillingPeriodEnd
                       ) ;

   lrec_gsd_prd_pln := dcs2000.pkg_dcs_benefit_pointer_utils.FNC_GSD_PRD_PLAN2
                       (
                           p_grp_id    => p_GroupId
                         , p_subloc_id => p_SublocationId
                         , p_div_id    => p_DivisionId
                       ) ;

   if lv_enable_multi_pls = 'Y' -- 2.1.82
   then
       if nvl(lv_combine_bills, 'N') = 'Y'
       then
          lv_grpSubDiv := lv_grpSubDiv || '0' || ' ';
       else
          lv_grpSubDiv := lv_grpSubDiv || to_char(p_ProductLineCode) || ' ';
       end if;
   end if;
               
   if g_state = 'DDPVA'
   then
      if g_printcheckdigit = 'Y'
      then
               
         if nvl(lv_combine_bills,'N') = 'Y'
         then
            lv_grpSubDiv := lv_grpSubDiv 
                            || dcs2000.fnc_gen_mod10 (p_GroupId || p_SublocationId || p_DivisionId || '0');
         else
            lv_grpSubDiv := lv_grpSubDiv 
                            || dcs2000.fnc_gen_mod10 (p_GroupId || p_SublocationId || p_DivisionId || p_ProductLineCode);
         end if;
                                                 
      else
         lv_grpSubDiv := lv_grpSubDiv || LPAD (lrec_gsd_prd_pln.prd_cde, 4, '0');
      end if;
   else
      lv_grpSubDiv := lv_grpSubDiv || LPAD (lrec_gsd_prd_pln.prd_cde, 4, '0');
   end if;

   return lv_grpSubDiv ;

exception

   when others
   then
      return lv_grpSubDiv ;

end fnc_buildGrpSubDiv ;
/
