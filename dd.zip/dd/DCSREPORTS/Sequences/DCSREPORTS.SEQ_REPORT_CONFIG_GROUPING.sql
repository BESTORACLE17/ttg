-- Create sequence 
create sequence SEQ_REPORT_CONFIG_GROUPINGS;
