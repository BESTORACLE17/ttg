-- Create table
create table DCSREPORTS.TBL_RPT_PROMPT_PAY
(
  PARENT_ID          NUMBER(4),
  CLAIM_NO           VARCHAR2(14),
  RECEIVE_DATE       DATE,
  ORIG_RECEIVE_DATE  DATE,
  CHECK_DATE         DATE,
  TOTAL_SUBMITTED    NUMBER,
  TOTAL_NET          NUMBER,
  CLAIM_STATUS       VARCHAR2(30),
  TIME_TO_ADJUDICATE NUMBER,
  TIME_TO_PAY        NUMBER,
  INTEREST           NUMBER(12,2),
  REPORT_BEGIN_DATE  DATE,
  REPORT_END_DATE    DATE
);
-- Grant/Revoke object privileges 
grant select, insert, update, delete, references, alter, index on DCSREPORTS.TBL_RPT_PROMPT_PAY to DCS2000 with grant option;
grant select on DCSREPORTS.TBL_RPT_PROMPT_PAY to DCS_USERS_ALL;
