DROP TABLE DCSREPORTS.TEMP_RPT_DCS_BILLING CASCADE CONSTRAINTS;

CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_DCS_BILLING
(
  description              VARCHAR2(30 byte),
  paper_cnt                NUMBER(8),
  fax_cnt                  NUMBER(8),
  paper_fax_cnt            NUMBER(8),
  electronic_cnt           NUMBER(8),
  web_cnt                  NUMBER(8),
  system_generated_cnt     NUMBER(8),
  e_realtime_cnt           NUMBER(8),
  other_cnt                NUMBER(8),
  ortho_cnt                NUMBER(8),
  automated_adjustment_cnt NUMBER(8),
  paper_sbt                NUMBER(16,2),
  fax_sbt                  NUMBER(16,2),
  paper_fax_sbt            NUMBER(16,2),
  electronic_sbt           NUMBER(16,2),
  web_sbt                  NUMBER(16,2),
  system_generated_sbt     NUMBER(16,2),
  e_realtime_sbt           NUMBER(16,2),
  other_sbt                NUMBER(16,2),
  ortho_sbt                NUMBER(16,2),
  automated_adjustment_sbt NUMBER(16,2),
  paper_net                NUMBER(16,2),
  fax_net                  NUMBER(16,2),
  paper_fax_net            NUMBER(16,2),
  electronic_net           NUMBER(16,2),
  web_net                  NUMBER(16,2),
  system_generated_net     NUMBER(16,2),
  e_realtime_net           NUMBER(16,2),
  other_net                NUMBER(16,2),
  ortho_net                NUMBER(16,2),
  automated_adjustment_net NUMBER(16,2)
)
ON COMMIT PRESERVE ROWS
NOCACHE;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCSREPORTS.TEMP_RPT_DCS_BILLING TO DCS_USERS_ALL




