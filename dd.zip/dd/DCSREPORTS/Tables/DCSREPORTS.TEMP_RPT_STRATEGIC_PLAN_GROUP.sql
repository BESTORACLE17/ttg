-- Create table
create global temporary table DCSREPORTS.TEMP_RPT_STRATEGIC_PLAN_GROUP
(
  PARENT_ID           NUMBER(4),
  GRP_ID              VARCHAR2(9),
  SUBLOC_ID           VARCHAR2(8),
  DIV_ID              VARCHAR2(4),
  PERIOD              NUMBER(8),
  REPORT_RATING       NUMBER(4),
  ASO_RISK_TYPE       NUMBER(4),
  IS_ASO_ADMIN_SUBLOC VARCHAR2(1)
) on commit preserve rows;
-- Create/Recreate indexes 
create index RPT_STRATEGIC_PLAN_GROUP_IX on TEMP_RPT_STRATEGIC_PLAN_GROUP (GRP_ID, SUBLOC_ID, DIV_ID, PERIOD);
create index RPT_STRATEGIC_PLAN_GROUP_IX2 on TEMP_RPT_STRATEGIC_PLAN_GROUP (GRP_ID, SUBLOC_ID, DIV_ID, SUBSTR(PERIOD,1,6));
