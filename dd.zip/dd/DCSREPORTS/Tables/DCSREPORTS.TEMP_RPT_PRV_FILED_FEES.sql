CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_PRV_FILED_FEES
(
   TAX_ID            VARCHAR2(9),
   LOC               NUMBER(4),
   FAC_STATE         VARCHAR2(2),
   PRC_CDE           VARCHAR2(5),
   PRODUCT_CODE      NUMBER(4),
   PRODUCT_DESC      VARCHAR2(200),
   SPECIALTY_CODE    NUMBER(4),  
   SPECIALTY_DESC    VARCHAR2(500),
   FEE               NUMBER(7,2),
   EFF_DTE           NUMBER(8),
   TRM_DTE           NUMBER(8),
   MOD_OP            VARCHAR2(12),
   MOD_DTE           DATE,
   PRV_ID            VARCHAR2(32),
   MAINT_CODE        NUMBER(4),
   MAINT_DESC        VARCHAR2(30),
   ROW_ID            VARCHAR2(50)
) 
ON COMMIT PRESERVE ROWS;

