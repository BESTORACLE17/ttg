create table DCSREPORTS.TBL_REPORT_CONFIG_GROUPINGS
(
   CREATED_BY                  VARCHAR2(30),
   CREATED_ON                  DATE,
   UPDATED_BY                  VARCHAR2(30),
   UPDATED_ON                  DATE,
   MAINT_CODE                  NUMBER(4),
   REPORT_CONFIG_GROUPING_PK   NUMBER(4),
   PROG_KEY                    VARCHAR2(30),
   GROUPING_NAME               VARCHAR2(25),
   GROUPING_LEVEL              NUMBER(4),
   GROUPING_ORDER              NUMBER(4),
   GROUPING_CODE               NUMBER(4),
   GROUPING_DESCRIPTION        VARCHAR2(100),
   GROUPING_RULE               VARCHAR2(2000)
)
TABLESPACE DCSREPORTS_DATA;

