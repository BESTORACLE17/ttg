-- Create table
create global temporary table DCSREPORTS.TEMP_RPT_PRV_CREDENTIALING
(
  PARENT_ID       NUMBER(4),
  PARENT_NAME     VARCHAR2(30),
  PRV_ID          VARCHAR2(32),
  TAX_ID          VARCHAR2(9),
  FAC_STATE       VARCHAR2(2),
  LOCATION_NUMBER NUMBER(4),
  PRV_NME         VARCHAR2(100),
  LICENSE_NUMBER  VARCHAR2(30),
  FACILITY_NAME   VARCHAR2(100),
  PRD_CDE         NUMBER(4),
  NETWORK_NAME    VARCHAR2(30),
  ADDR1           VARCHAR2(50),
  ADDR2           VARCHAR2(50),
  CITY            VARCHAR2(30),
  STATE           VARCHAR2(30),
  ZIP             VARCHAR2(5),
  PHONE           VARCHAR2(20),
  INFO_EFF_DTE    VARCHAR2(10),
  INFO_TRM_DTE    VARCHAR2(10),
  DAYS_LEFT       NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(30)
)
on commit preserve rows;
-- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DCSREPORTS.TEMP_RPT_PRV_CREDENTIALING modify 
  (ADDR1    VARCHAR2(64 ),
   ADDR1    VARCHAR2(64 )
  );