/* VERSION: 3.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : New Table
|| Version #      : 3.1.1
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 12/22/2006.
|| Revision Desc  : Table creation script for the a new report. 
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

DROP TABLE DCSREPORTS.TEMP_MATCHING_INDV_EXTRACT;

CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_MATCHING_INDV_EXTRACT
(
   RESULT_TYPE           NUMBER
 , SUBR_ID               VARCHAR2(30)
 , INDV_ID               NUMBER(2)
 , INDV_EFF_DTE          NUMBER(8)
 , TRM_DTE               NUMBER(8)
 , TRM_REASON_CDE        NUMBER(2)
 , SSN                   VARCHAR2(9)
 , RELSHP_CDE            NUMBER(2)
 , LNME                  VARCHAR2(30)
 , FNME                  VARCHAR2(30)
 , DOB                   NUMBER(8)
 , GRP_ID                VARCHAR2(9)
 , SUBLOC_ID             VARCHAR2(8)
 , DIV_ID                VARCHAR2(4)
 , COVER_EFF_DTE         NUMBER(8)
 , COVER_TRM_DTE         NUMBER(8)
 , DCS_INDIVIDUAL_IDENTIFIER VARCHAR2(30)
)
ON COMMIT PRESERVE ROWS ;

