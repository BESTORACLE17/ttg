-- Create table
CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_GRP_CLAIM_DED_MAX
(
  GRP_ID                   VARCHAR2(  9) not null,
  SUBLOC_ID                VARCHAR2(  8) not null,
  DIV_ID                   VARCHAR2(  4) not null,
  GRP_NME                  VARCHAR2(100) not null,
  SUBR_ID                  VARCHAR2( 30) not null,
  PATIENT_REL_CDE          NUMBER(1),
  PATIENT_FNME             VARCHAR2( 30),
  PATIENT_LNME             VARCHAR2( 30),
  PATIENT_SUFX             NUMBER(2),
  PATIENT_DOB              VARCHAR2( 10),
  COVERAGE_PERIOD          NUMBER(4),
  COVERAGE_PERIOD_DESC     VARCHAR2( 50),
  SUBMITED_FEE             NUMBER(15,2),
  APPROVED_FEE             NUMBER(15,2),
  ALLOWED_FEE              NUMBER(15,2),
  NET                      NUMBER(15,2),
  PATIENT_PAYS             NUMBER(15,2),
  YTD_DEDUCTIBLE           NUMBER(10,2),
  MAXIMUM_AMOUNT           NUMBER(10,2),
  MAXIMUM_USED             NUMBER(10,2),
  MAXIMUM_LEFT             NUMBER(10,2),
  MAXIMUM_OVERAGE          NUMBER(10,2),
  COMPANY_ID               NUMBER(4),
  PARENT_ID                NUMBER(4),
  INDV_ID                  NUMBER(2),
  CARRY_OVER_BENEFIT_YEAR  NUMBER(4)
)
on commit preserve rows;
-- Grant/Revoke object privileges
grant select on DCSREPORTS.TEMP_RPT_GRP_CLAIM_DED_MAX to DCS2000 with grant option;
grant select on DCSREPORTS.TEMP_RPT_GRP_CLAIM_DED_MAX to DCS_USERS_ALL;
