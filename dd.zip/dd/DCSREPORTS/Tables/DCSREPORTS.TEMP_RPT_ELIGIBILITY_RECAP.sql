DROP TABLE DCSREPORTS.TEMP_RPT_ELIGIBILITY_RECAP;
-- Create table
create global temporary table dcsreports.TEMP_RPT_ELIGIBILITY_RECAP
(
  ORDER_BY           VARCHAR2(100),
  PARENT_ID          NUMBER(4),
  GRP_ID             VARCHAR2(9) not null,
  SUBLOC_ID          VARCHAR2(8) not null,
  DIV_ID             VARCHAR2(4) not null,
  SUBR_ID            VARCHAR2(30) not null,
  INDV_ID            NUMBER(2) not null,
  SSN                NUMBER(12),
  LAST_NAME          VARCHAR2(30) not null,
  FIRST_NAME         VARCHAR2(30) not null,
  DOB                DATE,
  COVERAGE_EFF_DATE  DATE,
  COVERAGE_TERM_DATE DATE,
  PRODUCT_CODE       NUMBER(4) not null,
  PLAN_CODE          NUMBER(4) not null,
  RATE_CODE          NUMBER(4) not null,
  RATE_DESCRIPTION   VARCHAR2(100) not null,
  MISC_INFO          VARCHAR2(10),
  G_GROUP_NAME       VARCHAR2(100),
  GS_GROUP_NAME      VARCHAR2(100),
  GSD_GROUP_NAME     VARCHAR2(100),
  IS_ACTIVE_RECORD   NUMBER(2),
  MOD_DATE           DATE,
  REPORTING_CODE     NUMBER(4)
)
on commit preserve rows;
-- Grant/Revoke object privileges 
grant select, insert, update, delete, references, alter, index on DCSREPORTS.TEMP_RPT_ELIGIBILITY_RECAP to DCS2000 with grant option;

alter table DCSREPORTS.TEMP_RPT_ELIGIBILITY_RECAP add POOL_NO number(4);
alter table DCSREPORTS.TEMP_RPT_ELIGIBILITY_RECAP add COMPANY_ID number(4)