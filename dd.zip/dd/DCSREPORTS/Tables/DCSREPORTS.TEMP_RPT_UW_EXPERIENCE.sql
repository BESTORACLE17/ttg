DROP TABLE DCSREPORTS.TEMP_RPT_UW_EXPERIENCE;

create global temporary table DCSREPORTS.TEMP_RPT_UW_EXPERIENCE
(
  PARENT_ID          NUMBER(4),
  COMPANY_ID         NUMBER(4), --Added 05129.01.NE 09/11/2006 SHB
  MASTER_GRP_ID      VARCHAR2(9), 
  MASTER_SUBLOC_ID   VARCHAR2(8), 
  MASTER_DIV_ID      VARCHAR2(4), 
  MASTER_GRP_NME     VARCHAR2(100),
  GRP_ID             VARCHAR2(9)   not null,
  SUBLOC_ID          VARCHAR2(8)   not null,
  DIV_ID             VARCHAR2(4)   not null,
  GRP_NME            VARCHAR2(100),
  PRD_CDE            NUMBER(4),  --Added 05129.01.NE 09/11/2006 SHB
  PLN_CDE            NUMBER(4),  --Added 05129.01.NE 09/11/2006 SHB
  POOL_NO            NUMBER(4),  --Added 05129.01.NE 09/11/2006 SHB   
  YYYYMM             NUMBER(6),
  MMYYYY             VARCHAR2(7),
  PREMIUM            NUMBER(11,2),
  BILLED             NUMBER(11,2),
  CLAIMS_CNT         NUMBER(11,2),
  CLAIMS_AMT         NUMBER(11,2),
  TOT_SUBR_CNT       NUMBER(6),
  SUBR_CNT1          NUMBER(6),
  SUBR_CNT2          NUMBER(6),
  SUBR_CNT3          NUMBER(6),
  SUBR_CNT4          NUMBER(6),
  SUBR_CNT5          NUMBER(6),  
  SUBR_CNT6          NUMBER(6),
  COVERAGE1          NUMBER(2),
  COVERAGE2          NUMBER(2),
  COVERAGE3          NUMBER(2),
  COVERAGE4          NUMBER(2),
  COVERAGE5          NUMBER(2),
  COVERAGE6          NUMBER(2),
  GROUP_BREAK        VARCHAR2(1) default 'N',
  GSD_TOTALS         VARCHAR2(1) default 'N',
  DISPLAY_BILLED     VARCHAR2(1) default 'N',
  GRAND_TOTAL        VARCHAR2(1) default 'N'
)
on commit preserve rows;
-- Grant/Revoke object privileges 
grant select, insert, update, delete, references, alter, index on DCSREPORTS.TEMP_RPT_UW_EXPERIENCE to DCSADMIN with grant option;
grant select, insert, update on DCSREPORTS.TEMP_RPT_UW_EXPERIENCE to DCS_USERS_ALL;