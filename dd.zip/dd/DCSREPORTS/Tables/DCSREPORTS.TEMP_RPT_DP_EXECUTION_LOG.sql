-- Create table
/* 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.1
|| Revision Type  : Enhancement
|| SR/WO          : SR 10067.02.ALL DP changes
|| Revision By    : SATYA SAI
|| Revision Date  : 03/07/2011
|| Revision Desc  : Adding Product line code column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_DP_EXECUTION_LOG
(
  PARENT_ID                  NUMBER(4),
  PARENT_NAME                VARCHAR2(200),
  DELINQUENCY_BATCH_ID       NUMBER(12),
  DISP_SUBR_GRP_ID           VARCHAR2(100),
  DISP_SUBR_GRP_NAME         VARCHAR2(255),
  DELINQUENCY_PROFILE_NAME   VARCHAR2(50),
  TOTAL_AMOUNT_ORIG          NUMBER(16,2),
  TOTAL_AMOUNT_DUE           NUMBER(16,2),
  TOTAL_AMOUNT_UNAPPLIED     NUMBER(16,2),
  HOLD_TERM_DATE             DATE,
  DELINQ_ACTION_DISPLAY_CODE VARCHAR2(30),
  DELINQ_ACTION_DESC         VARCHAR2(255),
  REPORT_TYPE                VARCHAR2(50),
  GROUP_BY_DATA              VARCHAR2(100)
)
on commit preserve rows;
-- Grant/Revoke object privileges 
grant select on DCSREPORTS.TEMP_RPT_DP_EXECUTION_LOG to DCS2000 with grant option;
grant select on DCSREPORTS.TEMP_RPT_DP_EXECUTION_LOG to DCS_USERS_ALL;

-- 
ALTER TABLE DCSREPORTS.TEMP_RPT_DP_EXECUTION_LOG ADD( PRODUCT_LINE_CODE NUMBER(4)); -- 2.1.1 