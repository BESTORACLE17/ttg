DROP TABLE temp_rpt_rowids;
create table DCSREPORTS.TEMP_RPT_ROWIDS
(
  REPORT_GUID  VARCHAR2(32) not null,
  REPORT_ROWID ROWID        not null
)
tablespace DCSREPORTS_DATA
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
