-- Create table
create global temporary table DCSREPORTS.TEMP_RPT_PRV_LPF_SEARCH
(
  PARENT_ID            NUMBER(4),
  PROVIDER_ID          VARCHAR2(11),
  STATE_ID             VARCHAR2(2),
  LOCATION             NUMBER(4),
  FACILITY_NAME        VARCHAR2(60),
  TAX_ID               VARCHAR2(9),
  FAC_STATE            VARCHAR2(2),
  EFFECTIVE_DATE       DATE,
  TERMINATION_DATE     DATE,
  LICENSE_NUMBER       VARCHAR2(30),
  LAST_NAME            VARCHAR2(60),
  FIRST_NAME           VARCHAR2(35),
  MIDDLE_NAME          VARCHAR2(30),
  SUFFIX               VARCHAR2(30),
  ADDRESS1             VARCHAR2(30),
  ADDRESS2             VARCHAR2(30),
  CITY                 VARCHAR2(30),
  STATE                VARCHAR2(2),
  ZIP                  VARCHAR2(5),
  PHONE                VARCHAR2(30),
  PAR_NPAR             CHAR(1),
  PROVIDER_LOCATION_PK NUMBER(12),
  PROVIDER_PK          NUMBER(12),
  FACILITY_PK          NUMBER(10),
  FACILITY_LOCATION_PK NUMBER(12),
  SPECIALTY_CODE       NUMBER(4),
  SPECIALTY_DESC       VARCHAR2(500),
  PRODUCT_CODE         NUMBER(4),
  PRODUCT_DESC         VARCHAR2(200),
  REGION_CODE          NUMBER(4),
  REGION_DESC          VARCHAR2(30)
)
on commit preserve rows;


-- SR06214.01.ALL - NPI - 04/09/2007 - SHB - Added Provider NPI column
-- Add/modify columns 
alter table DCSREPORTS.TEMP_RPT_PRV_LPF_SEARCH add PROVIDER_NPI number(10);
-- Add comments to the columns 
comment on column TEMP_RPT_PRV_LPF_SEARCH.PROVIDER_NPI
  is 'National Provider Identifier for the Provider';
-- Added for SR07121.01.ALL
ALTER TABLE	DCSREPORTS.TEMP_RPT_PRV_LPF_SEARCH	MODIFY (PROVIDER_ID  VARCHAR2(32) ); 
-- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DCSREPORTS.TEMP_RPT_PRV_LPF_SEARCH modify 
  (ADDRESS1    VARCHAR2(64 ),
   ADDRESS2    VARCHAR2(64 )
  );