/* VERSION: 2.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
DROP TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL;

--CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL
--CREATE TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL
CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL
( PARENT_ID       NUMBER(4),
  GRP_ID          VARCHAR2(9),
  PRD_CDE         NUMBER(4),
  SUBR_ID         VARCHAR2(9),
  ENROLL_01       NUMBER,
  ENROLL_02       NUMBER,
  ENROLL_03       NUMBER,
  ENROLL_04       NUMBER,
  ENROLL_05       NUMBER,
  ENROLL_06       NUMBER,
  ENROLL_07       NUMBER,
  ENROLL_08       NUMBER,
  ENROLL_09       NUMBER,
  ENROLL_10       NUMBER,
  ENROLL_11       NUMBER,  
  ENROLL_12       NUMBER
) ON COMMIT PRESERVE ROWS;
--);  
--) ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL TO DCS_USERS_ALL;

-- Add/modify columns 
alter table DCSREPORTS.TEMP_RPT_UW_PMPM_ENROLL add GROUP_NAME varchar2(100);
-- Add comments to the columns 
comment on column TEMP_RPT_UW_PMPM_ENROLL.GROUP_NAME
  is 'NAME OF THE GROUP OR ASSOCIATION BEING REPORTED';
