CREATE GLOBAL TEMPORARY TABLE /*VERSION 2.1.1*/ DCSREPORTS.TEMP_RPT_OBJECT_SECURITY
(  USER_PK                  NUMBER(10),
   COMPONENT_ID             NUMBER(10),
   COMPONENT_NAME           VARCHAR2(100),
   ORDER_BY                 NUMBER(10),
   OBJECT_TYPE_PK           NUMBER(10),
   OBJECT_TYPE_DESCRIPTION  VARCHAR2(100),
   inquiry_access           VARCHAR2(1),
   add_access               VARCHAR2(1),
   modify_access            VARCHAR2(1),
   delete_access            VARCHAR2(1),
   execute_access           VARCHAR2(1),
   sensitive_data_access    VARCHAR2(1),
   legacy                   NUMBER(6),
   legacy_description       VARCHAR2(50),
   NESTED_LEVEL             NUMBER
);

GRANT SELECT ON DCSREPORTS.TEMP_RPT_OBJECT_SECURITY TO DCS_USERS_ALL;
/

-- HD30168 add object_id column to support code tables in report
ALTER TABLE DCSREPORTS.TEMP_RPT_OBJECT_SECURITY
   ADD OBJECT_ID NUMBER;
   