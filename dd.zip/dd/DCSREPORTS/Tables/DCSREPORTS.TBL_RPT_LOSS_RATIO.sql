-- Create table
create table DCSREPORTS.TBL_RPT_LOSS_RATIO
(
  REPORT_AS_OF_DATE       DATE,
  REPORT_PERIOD           VARCHAR2(100),
  PARENT_ID               NUMBER(10),
  LOSS_RATIO_CDE          NUMBER(4),
  LOSS_RATIO_CATEGORY_CDE NUMBER(4),
  GRP_ID                  VARCHAR2(9),
  GRP_NME                 VARCHAR2(100),
  CUR_PREMIUMS            NUMBER(18,2),
  YTD_PREMIUMS            NUMBER(18,2),
  USER_PREMIUMS           NUMBER(18,2),
  CUR_CLAIMS              NUMBER(18,2),
  YTD_CLAIMS              NUMBER(18,2),
  USER_CLAIMS             NUMBER(18,2),
  CUR_CAP                 NUMBER(18,2),
  YTD_CAP                 NUMBER(18,2),
  USER_CAP                NUMBER(18,2),
  ERROR_CODE              CLOB,
  ERROR_DESC              CLOB
)
tablespace DCSREPORTS_DATA
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index IX_RPT_LOSS_RATIO on TBL_RPT_LOSS_RATIO (PARENT_ID, LOSS_RATIO_CDE, LOSS_RATIO_CATEGORY_CDE, GRP_ID)
  tablespace DCSREPORTS_DATA
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
