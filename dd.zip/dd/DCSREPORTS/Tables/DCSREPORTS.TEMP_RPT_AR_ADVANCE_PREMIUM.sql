/* VERSION: 2.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: WO #13763 - Advance Premium Report 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/09/2005 
|| Revision Desc  : Initial Creation   
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
TRUNCATE TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM;

DROP TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM;

CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM
(
  RECEIPT_ID                NUMBER(12)          NOT NULL,
  COMPANY_CODE              VARCHAR2(10),
  RECEIPT_SUBR_ID           VARCHAR2(9),
  RECEIPT_GRP_ID            VARCHAR2(9),
  RECEIPT_SUBLOC_ID         VARCHAR2(8),
  RECEIPT_DIV_ID            VARCHAR2(4),
  RECEIPT_DISP_SUBR_GRP_ID  VARCHAR2(23),
  RECEIPT_DISP_NAME         VARCHAR2(100),
  CUSTOMER_TYPE             VARCHAR2(10),
  RECEIPT_DEPOSIT_DATE      DATE                NOT NULL,
  RECEIPT_NUMBER            VARCHAR2(20)        NOT NULL,
  RECEIPT_AMOUNT            NUMBER(15,2)        NOT NULL,
  TRX_SUBR_ID               VARCHAR2(9),
  TRX_GRP_ID                VARCHAR2(9)         NOT NULL,
  TRX_SUBLOC_ID             VARCHAR2(8)         NOT NULL,
  TRX_DIV_ID                VARCHAR2(4)         NOT NULL,
  TRX_DISP_SUBR_GRP_ID      VARCHAR2(23),
  TRX_NUMBER                VARCHAR2(15)        NOT NULL,
  TRX_BILLING_YEAR_MONTH    NUMBER(6)           NOT NULL,
  AMOUNT_APPLIED            NUMBER(15,2)        NOT NULL
)
ON COMMIT PRESERVE ROWS;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM MODIFY RECEIPT_SUBR_ID VARCHAR2(30);
ALTER TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM MODIFY TRX_SUBR_ID VARCHAR2(30);
ALTER TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM MODIFY TRX_DISP_SUBR_GRP_ID VARCHAR2(30);
ALTER TABLE DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM MODIFY RECEIPT_DISP_SUBR_GRP_ID VARCHAR2(30);

GRANT SELECT, INSERT, UPDATE ON DCSREPORTS.TEMP_RPT_AR_ADVANCE_PREMIUM TO DCS_USERS_ALL;
