/* VERSION: 2.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
DROP TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS;
--CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS
--CREATE TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS
CREATE GLOBAL TEMPORARY TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS
(
  PARENT_ID         NUMBER(4),
  GRP_ID            VARCHAR2(9),
  PRD_CDE           NUMBER,
  SUBR_ID           VARCHAR2(9),
  CLAIMS_01         NUMBER(11,2),
  CLAIMS_02         NUMBER(11,2),
  CLAIMS_03         NUMBER(11,2),
  CLAIMS_04         NUMBER(11,2),
  CLAIMS_05         NUMBER(11,2),
  CLAIMS_06         NUMBER(11,2),
  CLAIMS_07         NUMBER(11,2),
  CLAIMS_08         NUMBER(11,2),
  CLAIMS_09         NUMBER(11,2),
  CLAIMS_10         NUMBER(11,2),
  CLAIMS_11         NUMBER(11,2),
  CLAIMS_12         NUMBER(11,2)
) ON COMMIT PRESERVE ROWS;
--);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS TO DCS_USERS_ALL; 

-- Add/modify columns 
alter table DCSREPORTS.TEMP_RPT_UW_PMPM_CLAIMS add GROUP_NAME varchar2(100);
-- Add comments to the columns 
comment on column TEMP_RPT_UW_PMPM_CLAIMS.GROUP_NAME
  is 'NAME OF THE GROUP OR ASSOCIATION BEING REPORTED';
