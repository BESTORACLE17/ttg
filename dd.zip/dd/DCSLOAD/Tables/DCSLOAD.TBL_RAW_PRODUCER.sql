DROP TABLE DCSLOAD.TBL_RAW_PRODUCER CASCADE CONSTRAINTS;

CREATE TABLE /* 2.1.2 */ TBL_RAW_PRODUCER
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2 
|| Revision Type  : Bug-Fix
|| Service Request: HD29760 - Transamerica agent load process is not listing
||                  all the appointed states (Allen Moore)
|| Revision By    : Jeff Reynolds
|| Revision Date  : 11/28/2007
|| Revision Desc  : Added indexes to facilitate appointment licnse_state 
||                  combinations and to improve performance.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
(AGENT_SSN               VARCHAR2(100)
,AGENT_NO                VARCHAR2(100)
,AGENCY_NAME			 VARCHAR2(100)
,AGENT_LNAME             VARCHAR2(100)
,AGENT_FNAME             VARCHAR2(100)
,AGENT_MNAME             VARCHAR2(100)
,STATE                   VARCHAR2(100)
,LICENSE_NO              VARCHAR2(100)
,LICNSE_STATE            VARCHAR2(100)
,LICNSE_RESID            VARCHAR2(100)
,LICNSE_STATUS           VARCHAR2(100)
,LOI                     VARCHAR2(100)
,LICNSE_TYPE             VARCHAR2(100)
,LICNSE_ISSDT            VARCHAR2(100)
,LICNSE_RNDT             VARCHAR2(100)
,PT_CARRIER              VARCHAR2(100)
,APT_EFFDT               VARCHAR2(100)
,APT_STATUS              VARCHAR2(100)
,ADDR_LINE1              VARCHAR2(100)
,ADDR_LINE2              VARCHAR2(100)
,CITY                    VARCHAR2(100)
,ZIP                     VARCHAR2(100)
,EMAIL                   VARCHAR2(100)
,CORP_IND                VARCHAR2(100)
,AGENTNUM_STATUS         VARCHAR2(100)
,OVERALL_STATUS          VARCHAR2(100)
,COMPANY_CODE_A          VARCHAR2(100)
,TAXID_TYPE              VARCHAR2(100)
,LIC_TERM_DATE           VARCHAR2(100)
,APPT_TERM_DATE          VARCHAR2(100)
,EMAIL2                  VARCHAR2(100)
,BUS_PHONE               VARCHAR2(100)
,HOME_PHONE              VARCHAR2(100)
,FAX_PHONE               VARCHAR2(100)
,CELL_PHONE              VARCHAR2(100)
,MOD_DTE                 DATE
,MOD_OP                  VARCHAR2(30)
,RECORD_ID               NUMBER
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCACHE
NOPARALLEL;


GRANT INSERT, UPDATE, DELETE, SELECT ON TBL_RAW_PRODUCER TO dcs2000 WITH GRANT OPTION;

DROP INDEX DCSLOAD.DCSLOAD_RAW_PRODUCER;

CREATE INDEX DCSLOAD.DCSLOAD_RAW_PRODUCER
    ON DCSLOAD.TBL_RAW_PRODUCER (
       TRIM(AGENT_SSN)
     , TRIM(AGENT_NO)
     , TRIM(AGENCY_NAME)
     , TRIM(AGENT_LNAME)
     , TRIM(AGENT_FNAME)
     , TRIM(AGENT_MNAME)
     , TRIM(TAXID_TYPE)
     , TRIM(STATE)
     , LICNSE_STATE)
TABLESPACE RAW_DATA;

DROP INDEX DCSLOAD.DCSLOAD_RAW_PRODUCER2;

CREATE INDEX DCSLOAD.DCSLOAD_RAW_PRODUCER2
    ON DCSLOAD.TBL_RAW_PRODUCER (
       AGENT_SSN , AGENT_NO)
TABLESPACE RAW_DATA;
