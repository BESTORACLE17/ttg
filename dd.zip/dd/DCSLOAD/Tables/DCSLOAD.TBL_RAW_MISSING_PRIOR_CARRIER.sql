/* VERSION: 3.1.1 */ 
--
-- TBL_RAW_MISSING_PRIOR_CARRIER  (Table) 
--
CREATE TABLE DCSLOAD.TBL_RAW_MISSING_PRIOR_CARRIER
(
  SSN      VARCHAR2(9 BYTE),
  SUBR_ID  VARCHAR2(9 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

