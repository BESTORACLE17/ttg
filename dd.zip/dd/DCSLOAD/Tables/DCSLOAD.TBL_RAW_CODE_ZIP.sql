/* VERSION: 3.1.1 */ 
--
-- TBL_RAW_CODE_ZIP  (Table) 
--
CREATE TABLE DCSLOAD.TBL_RAW_CODE_ZIP
(
  CODE              NUMBER(5)                   NOT NULL,
  REGION_TYPE_CODE  NUMBER(2)                   NOT NULL,
  REGION_CODE       NUMBER(2),
  CITY              VARCHAR2(30 BYTE)           NOT NULL,
  STATE             VARCHAR2(2 BYTE)            NOT NULL,
  COUNTY_CODE       NUMBER(4),
  MAINT_CODE        NUMBER(4),
  MOD_DTE           DATE,
  MOD_OP            VARCHAR2(12 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          3120K
            NEXT             1M
            MINEXTENTS       3
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- TEMP1_IX  (Index) 
--
CREATE INDEX DCSLOAD.TEMP1_IX ON DCSLOAD.TBL_RAW_CODE_ZIP
(CODE)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

