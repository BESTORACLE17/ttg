CREATE OR REPLACE procedure /* VERSION: 2.1.1 */          EEP.prc_ee_KAISCOPER2
(
   p_ee_file_name_path in varchar2
)
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.1
|| SR/WO #        : TRAC6714 
|| Revision By    : Raj Chetlapalli
|| Revision Date  : 02/13/2011
|| Revision Desc  : Assign Default Effective Date for the Terminated records.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
is

   ln_errorcode       NUMBER;
   lv_errortext       VARCHAR2(4000);
   ln_ee_file_id      eep.TBL_EE_INCOMING_FILES.ee_file_id%TYPE;
   e_stop_processing  EXCEPTION;

begin

   begin
      select ee_file_id
        into ln_ee_file_id
        from eep.tbl_ee_incoming_files a
       where upper(a.ee_file_name) = upper(eep.Fnc_Parse_File_Name(p_ee_file_name_path)) ;
   exception
      when others
      then
         raise e_stop_processing ;
   end ;

   -- First Udpate all the termined records with zero effective date

    update eep.tbl_ee_eligibility_data_all
    set cover_eff_dte = to_number(to_char(TO_DATE(TO_CHAR(cover_trm_dte), 'YYYYMMDD') - 1, 'YYYYMMDD')) ,
    derived_cover_eff_dte = to_number(to_char(TO_DATE(TO_CHAR(cover_trm_dte), 'YYYYMMDD') - 1, 'YYYYMMDD'))
    where ee_file_id = ln_ee_file_id
    and cover_eff_dte = 0;


   commit;

exception
   when others
   then
      rollback;

      DBMS_OUTPUT.PUT_LINE
      (
           'File['   || to_char(ln_ee_file_id) || ']'
        || ' Error[' || lv_errortext           || ']'
      ) ;

      pkg_ee_library.prc_update_process_status
      (
          ln_ee_file_id
        , eep.fnc_get_lookup_id('EE_PROCESS_STATUS', 'TERMINATED' )
        , lv_errortext
      ) ;

end prc_ee_KAISCOPER2;
/