. /home/oracle8/.vadevenv

logfilename=`echo $1 | cut -d / -f 3`

sqlload / control=../ctl/wmactaudit.ctl log=$logfilename.log data=$1

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_DDPV_LAYOUT TBL_EE_RAW_WMACTAUDIT
