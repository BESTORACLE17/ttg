set serverout on
whenever sqlerror exit 1
begin
   update eep.tbl_ee_raw_sicomm
      set wait_period_from_date = null 
    where wait_period_from_date is not null;

   commit;
end;
/
exit
