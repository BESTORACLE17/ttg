set serveroutput on
whenever sqlerror exit failure
exec eep.PRC_EE_CHP834_CONVERSION('D');
exit