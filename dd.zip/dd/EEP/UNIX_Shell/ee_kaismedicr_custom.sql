set serverout on
exec EEP.PRC_EE_KAISMEDICR('&1');
exit
