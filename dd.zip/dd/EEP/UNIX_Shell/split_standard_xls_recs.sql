set serverout on
exec eep.PRC_SPLIT_STANDARD_XLS_RECS();
exit
