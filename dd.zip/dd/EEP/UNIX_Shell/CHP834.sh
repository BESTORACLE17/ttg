. /home/oracle/.cofixenv

umask 011 

logfilename=`echo $1 | cut -d / -f 3`
  
sqlplus / @truncate_table.sql EEP.TBL_EE_RAW_CHP834

sqlldr / control=../ctl/CHP834.ctl log=$UTL_DIR/ee/$logfilename.log data=$1

echo "Running CHP834 Conversion Routine..."

#sqlplus / @prc_ee_run_chp834_conv.sql


sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_DDPV_LAYOUT TBL_EE_RAW_CHP834




