set serverout on
exec EEP.PRC_EE_BAH834('&1');
exit