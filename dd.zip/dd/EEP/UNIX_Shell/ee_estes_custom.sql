set serverout on
exec EEP.PRC_EE_ESTES('&1');
exit