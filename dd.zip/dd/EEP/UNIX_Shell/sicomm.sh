#!/bin/bash

. /home/oracle/.cvrelenv

logfilename=`echo $1 | cut -d / -f 3`

umask 011
logfilename=`echo $logfilename | tr [a-z] [A-Z]`
  
sqlplus / @truncate_table.sql EEP.TBL_EE_RAW_SICOMM
sqlplus / @truncate_table.sql EEP.TBL_RAW_DEPENDENT_SEQ_SICOMM
  
if  [[ $rc -ne 0 ]]
then
exit 1
else
  echo ""
  echo "Table truncated succesfully"
fi
  
sqlldr / control=../ctl/sicomm.ctl log=$UTL_DIR/ee/$logfilename.log data=$1
 
if [[ $? != 0 ]]
then
cat $UTL_DIR/ee/$logfilename.log
echo "***********************************************************"
     echo "There were errors during the load process."
     echo "Please check the log file for details."
     echo "***********************************************************"
     echo "Press ENTER to continue..."
     read ANS
     exit 1
fi

sqlplus / @sicomm_custom.sql

if  [[ $rc -ne 0 ]]
then
exit 1
else
  echo ""
  echo "Wait Period Date blanked out succesfully"
fi

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_DDPV_LAYOUT TBL_EE_RAW_SICOMM

sqlplus / @load_historical_table.sql
