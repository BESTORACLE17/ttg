. /home/oracle/.devrelenv

umask 011
logfilename=`echo $1 | cut -d / -f 3`
cat $1 | grep -v ^Z > /tmp/genworth.tmp
sqlload / control=../ctl/genworth.ctl log=$UTL_DIR/ee/$logfilename.log data=/tmp/genworth.tmp

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_GENWORTH TBL_EE_RAW_GENWORTH
