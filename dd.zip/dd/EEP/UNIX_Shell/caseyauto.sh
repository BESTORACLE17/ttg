. /home/oracle/.vafixenv

logfilename=`echo $1 | cut -d / -f 3`

# added for HD19638
umask 011
logfilename=`echo $logfilename | tr [a-z] [A-Z]`
# end of add for HD19368

sqlload / control=../ctl/caseyauto.ctl log=$UTL_DIR/ee/$logfilename.log data=$1

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_DDPV_LAYOUT TBL_EE_RAW_CASEYAUTO
