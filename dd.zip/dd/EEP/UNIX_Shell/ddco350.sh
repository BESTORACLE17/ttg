. /home/oracle8/.devrelenv

logfilename=`echo $1 | cut -d / -f 3`

  
sqlplus / @truncate_table.sql EEP.TBL_EE_RAW_DDCO350
  
if  [[ $? != 0 ]] then
exit 1
else
  echo ""
  echo "Table truncated succesfully"
fi
  
sqlload / control=../ctl/ddco350.ctl log=$UTL_DIR/ee/$logfilename.log data=$1
 
if [[ $? != 0 ]]
then
cat $UTL_DIR/ee/$logfilename.log
echo "***********************************************************"
     echo "There were errors during the load process."
     echo "Please check the log file for details."
     echo "***********************************************************"
     echo "Press ENTER to continue..."
     read ANS
     exit 1
fi
   

sqlplus / @move_raw_to_eligibility.sql $1 PKG_EE_DDCO.PRC_EE_LOAD_DDCO350 TBL_EE_RAW_DDCO350
