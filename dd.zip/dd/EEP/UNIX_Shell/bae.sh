. /home/oracle/.vaprodenv

umask 011
logfilename=`echo $1 | cut -d / -f 3`
cat $1 | grep -v ^Z > /tmp/bae.tmp
sqlload / control=../ctl/bae.ctl log=$UTL_DIR/ee/$logfilename.log data=/tmp/bae.tmp

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_BAE TBL_EE_RAW_BAE
