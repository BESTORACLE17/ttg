-- This script is used for VA only.Please refer previous script for CO and AR
set serverout on
whenever sqlerror exit failure
DECLARE
  P_ERRORCODE NUMBER;
  P_ERRORTEXT VARCHAR2(2000);

BEGIN
  P_ERRORCODE := 0;
  P_ERRORTEXT := NULL;

 EEP.PRC_EE_MOVE_RAW_TO_ELIGIBILITY('&1', '&2', '&3');
 EEP.PKG_EE_RUN_PROCESS.PRC_RUN_NEXT_PROCESS(P_ERRORCODE,P_ERRORTEXT, '&1');
END;
/
exit;
