set echo off heading off feedback off
select eep.FNC_EE_GET_FILE_FORMAT('&1') from dual;
exit