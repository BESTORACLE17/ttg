. /home/oracle/.devfixenv

umask 011

logfilename=`echo $1 | cut -d / -f 3`
logfilename=`echo $logfilename | tr [a-z] [A-Z]`

sqlldr / control=../ctl/estes.ctl log=$UTL_DIR/ee/$logfilename.log data=$1

if [[ $? != 0 ]]
then
cat $UTL_DIR/ee/$logfilename.log
echo "***********************************************************"
     echo "There were errors during the load process."
     echo "Please check the log file for details."
     echo "***********************************************************"
     echo "Press ENTER to continue..."
     read ANS
     exit 1
fi

sqlplus / @move_raw_to_eligibility.sql $1 PRC_EE_LOAD_DDPV_LAYOUT TBL_EE_RAW_ESTES

if [[ $? != 0 ]]
then
echo "***********************************************************"
     echo "There were errors during the move to eligibility for ESTES."
     echo "Please check the log file for details."
     echo "***********************************************************"
     echo "Press ENTER to continue..."
     read ANS
     exit 1
fi

sqlplus / @ee_estes_custom.sql $1

