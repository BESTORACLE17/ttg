/* VERSION: 3.1.1 */ 
--
-- TBL_EE_LOOKUP_TYPES  (Table) 
--
CREATE TABLE EEP.TBL_EE_LOOKUP_TYPES
(
  LOOKUP_TYPE_ID          NUMBER(15)            NOT NULL,
  LOOKUP_TYPE             VARCHAR2(30 BYTE)     NOT NULL,
  DESCRIPTION             VARCHAR2(80 BYTE)     NOT NULL,
  USER_MAINTAINABLE_FLAG  VARCHAR2(1 BYTE)      NOT NULL,
  START_DATE              DATE                  NOT NULL,
  END_DATE                DATE,
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATION_DATE           DATE,
  LAST_UPDATED_BY         VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE        DATE,
  STATUS                  VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_EE_LOOKUP_TYPES  (Index) 
--
CREATE UNIQUE INDEX EEP.PK_EE_LOOKUP_TYPES ON EEP.TBL_EE_LOOKUP_TYPES
(LOOKUP_TYPE_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_LOOKUP_TYPES TO EEP_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_EE_LOOKUP_TYPES 
-- 
ALTER TABLE EEP.TBL_EE_LOOKUP_TYPES ADD (
  CHECK ( USER_MAINTAINABLE_FLAG IN ( 'Y', 'N')));

ALTER TABLE EEP.TBL_EE_LOOKUP_TYPES ADD (
  CHECK ( STATUS IN ('A', 'I', 'D')));

ALTER TABLE EEP.TBL_EE_LOOKUP_TYPES ADD (
  CONSTRAINT PK_EE_LOOKUP_TYPES PRIMARY KEY (LOOKUP_TYPE_ID)
    USING INDEX 
    TABLESPACE EEP_INDEX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          16K
                NEXT             16K
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


