/*
-- EEP.TBL_EE_RAW_PERACHG
*/
DROP TABLE EEP.TBL_EE_RAW_PERACHG CASCADE CONSTRAINTS;

CREATE TABLE /* 2.1.1*/ EEP.TBL_EE_RAW_PERACHG
    (
       RECORD_ID             VARCHAR2(1 BYTE),
       SUBR_SSN              VARCHAR2(9 BYTE),
       DEPD_SSN              VARCHAR2(9 BYTE),
       RELSHIP_CDE           VARCHAR2(2 BYTE),
       SEX_CDE               VARCHAR2(1 BYTE),
       LNME                  VARCHAR2(20 BYTE),
       FNME                  VARCHAR2(15 BYTE),
       ADDR1                 VARCHAR2(30 BYTE),
       ADDR2                 VARCHAR2(30 BYTE),
       CITY                  VARCHAR2(27 BYTE),
       STATE                 VARCHAR2(2 BYTE),
       ZIP                   VARCHAR2(10 BYTE),
       PHONE                 VARCHAR2(10 BYTE),
       DOB                   VARCHAR2(8 BYTE),
       COVER_EFF_DTE         VARCHAR2(8 BYTE),
       COVER_TRM_DTE         VARCHAR2(8 BYTE),
       MNME                  VARCHAR2(1 BYTE),   
       GRP_ID                VARCHAR2(9 BYTE),
       RTE_CDE               VARCHAR2(1 BYTE),
       AGENCY_NO             VARCHAR2(3 BYTE),
       MOD_DTE               DATE                    DEFAULT SYSDATE,
       MOD_OP                VARCHAR2(30 BYTE)       DEFAULT USER
)
TABLESPACE RAW_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_RAW_PERACHG TO DCS2000 WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_RAW_PERACHG TO DCSREPORTS;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_RAW_PERACHG TO EEP_USERS_ALL;
