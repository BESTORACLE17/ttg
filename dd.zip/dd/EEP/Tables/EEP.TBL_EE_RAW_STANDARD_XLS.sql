--
-- TBL_EE_RAW_STANDARD_XLS  (Table)
--
-- Version 2.1.7
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision History
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.1
-- Change Control#: N/A
-- Revision By    : Jeff Reynolds
-- Revision Date  : 02/18/2008
-- Revision Desc  : Original version extracted from SR04363.02.VA version,
--                  released on 3/11/2006.
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.2
-- Change Control#: N/A
-- Revision By    : Jeff Reynolds
-- Revision Date  : 02/18/2008
-- Revision Desc  : Version extracted from VAPROD as of 2/18/2008.
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.3
-- Change Control#: SR07178.02.KY
-- Revision By    : Jeff Reynolds
-- Revision Date  : 02/18/2008
-- Revision Desc  : Added producer_id, producer_eff_dte, and producer_trm_dte.
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.4
-- Change Control#: SR08128.01.VA
-- Revision By    : Jeff Reynolds
-- Revision Date  : 06/03/2008
-- Revision Desc  : Added npi
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.5
-- Change Control#: SR08059.01.AR
-- Revision By    : Jeff Reynolds
-- Revision Date  : 06/05/2008
-- Revision Desc  : Added payment_method_code, bank_account_type_code,
--                  bank_routing_number, bank_account_number,
--                  credit_card_type_code, credit_card_number,
--                  credit_card_expiration
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.6
-- Change Control#: SR08092.26.CO - Apply Late Entrant to Subscriber, Spouse,
--                  or Dependents
-- Revision By    : Deborah Yates
-- Revision Date  : 09/04/2008
-- Revision Desc  : Added late_entrant flag
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
-- Revision Number: 2.1.7
-- Change Control#: SR08128.01.VA - EE 4.0 Layout
-- Revision By    : Raj Chetlapalli
-- Revision Date  : 04/16/2009
-- Revision Desc  : Added COB_CARRIER_ID
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
--
CREATE TABLE EEP.TBL_EE_RAW_STANDARD_XLS
(
  SUBR_ID                   VARCHAR2(30),
  GRP_ID                    VARCHAR2(9),
  SUBLOC_ID                 VARCHAR2(8),
  DIV_ID                    VARCHAR2(8),
  PRD_CDE                   VARCHAR2(4),
  PLN_CDE                   VARCHAR2(4),
  RTE_CDE                   VARCHAR2(4),
  COVER_EFF_DTE             VARCHAR2(8),
  COVER_TRM_DTE             VARCHAR2(8),
  HIRE_DTE                  VARCHAR2(8),
  GRP_TRM_DTE               VARCHAR2(8),
  PRIOR_CARRIER_EFF_DTE     VARCHAR2(8),
  COMPENSATION_CDE          VARCHAR2(2),
  UNION_CDE                 VARCHAR2(2),
  WORK_STS_CDE              VARCHAR2(2),
  COBRA_ELIG_CDE            VARCHAR2(2),
  COBRA_EFF_DTE             VARCHAR2(8),
  QUALI_EVENT_CDE           VARCHAR2(2),
  TRM_REASON_CDE            VARCHAR2(2),
  PRIORITY_CDE              VARCHAR2(2),
  SSN                       VARCHAR2(12),
  RELSHIP_CDE               VARCHAR2(2),
  LNME                      VARCHAR2(30),
  FNME                      VARCHAR2(30),
  MNME                      VARCHAR2(30),
  DOB                       VARCHAR2(8),
  HANDICAP_CDE              VARCHAR2(2),
  HANDICAP_EFF_DTE          VARCHAR2(8),
  SEX_CDE                   VARCHAR2(2),
  MARITAL_STS               VARCHAR2(2),
  STUDENT_CDE               VARCHAR2(2),
  ADDR1                     VARCHAR2(30),
  ADDR2                     VARCHAR2(30),
  ADDR3                     VARCHAR2(30),
  CITY                      VARCHAR2(30),
  STATE                     VARCHAR2(2),
  ZIP                       VARCHAR2(5),
  ZIP4                      VARCHAR2(4),
  COUNTRY_CDE               VARCHAR2(4),
  PHONE                     VARCHAR2(30),
  PRV_ID                    VARCHAR2(32),
  LOC                       VARCHAR2(4),
  TAX_ID                    VARCHAR2(9),
  SPOUSE_DENTAL_PLAN        VARCHAR2(1),
  DEP_OTHER_DENTAL_PLAN     VARCHAR2(1),
  COB_CARRIER_NME           VARCHAR2(60),
  PRV_NME                   VARCHAR2(30),
  CREATED_BY                VARCHAR2(30)        DEFAULT USER,
  CREATION_DATE             DATE                DEFAULT SYSDATE,
  MISC1                     VARCHAR2(50),
  MISC2                     VARCHAR2(50),
  MISC3                     VARCHAR2(50),
  MISC4                     VARCHAR2(50),
  MISC5                     VARCHAR2(50),
  RELIABILITY_FLAG          VARCHAR2(1),
  RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8),
  PRIOR_SUBR_ID             VARCHAR2(30),
  MISC_INFO                 VARCHAR2(10),
  WAIT_PERIOD_FROM_DATE     VARCHAR2(8),
  WAIT_PERIOD_TO_DATE       VARCHAR2(8)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


--
-- IDX_EE_RAW_STANDARD_XLS  (Index) 
--
--  Dependencies: 
--   TBL_EE_RAW_STANDARD_XLS (Table)
--
CREATE INDEX EEP.IDX_EE_RAW_STANDARD_XLS ON EEP.TBL_EE_RAW_STANDARD_XLS
(NVL("GRP_ID",'0'), NVL("SUBLOC_ID",'0'), NVL("DIV_ID",'0'))
TABLESPACE EEP_INDEX;


GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_RAW_STANDARD_XLS TO EEP_USERS_ALL;

ALTER TABLE EEP.TBL_EE_RAW_STANDARD_XLS ADD
(
  PRODUCER_ID               VARCHAR2(15),       /* 2.1.3 */
  PRODUCER_EFF_DTE          VARCHAR2(8),        /* 2.1.3 */
  PRODUCER_TRM_DTE          VARCHAR2(8)         /* 2.1.3 */
)
;
-- Version 2.1.4
ALTER TABLE EEP.TBL_EE_RAW_STANDARD_XLS ADD
(
  NPI                       VARCHAR2(10)        /* 2.1.4 */
)
;
-- Version 2.1.5
ALTER TABLE EEP.TBL_EE_RAW_STANDARD_XLS ADD
(
  PAYMENT_METHOD_CODE       VARCHAR2(2),        /* 2.1.5 */
  BANK_ACCOUNT_TYPE_CODE    VARCHAR2(2),        /* 2.1.5 */
  BANK_ROUTING_NUMBER       VARCHAR2(30),       /* 2.1.5 */
  BANK_ACCOUNT_NUMBER       VARCHAR2(30),       /* 2.1.5 */
  CREDIT_CARD_TYPE_CODE     VARCHAR2(2),        /* 2.1.5 */
  CREDIT_CARD_NUMBER        VARCHAR2(4),        /* 2.1.5 */
  CREDIT_CARD_EXPIRATION    VARCHAR2(6)         /* 2.1.5 */
)
;

-- 2.1.6
ALTER TABLE EEP.TBL_EE_RAW_STANDARD_XLS ADD (
    LATE_ENTRANT            VARCHAR2(1)
);

-- 2.1.7
ALTER TABLE EEP.TBL_EE_RAW_STANDARD_XLS ADD
(
  COB_CARRIER_ID                       VARCHAR2(30)        /* 2.1.7 */
);
