/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
||  Version #      : 2.1 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Bug Fix 
|| Version #      : 2.2 
|| Service Request: TRAC#6686 
|| Revision By    : Niyati Shroff
|| Revision Date  : 02/10/2011
|| Revision Desc  : Modified from on commit delete rows to preserve rows
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
DROP TABLE EEP.TBL_EE_SUBR_TRM_DTE_TEMP CASCADE CONSTRAINTS;

CREATE GLOBAL TEMPORARY TABLE EEP.TBL_EE_SUBR_TRM_DTE_TEMP
(
  EE_RECORD_ID             NUMBER(15),
  SUBMITTED_COVER_TRM_DTE  NUMBER(8),
  COVER_TRM_DTE            NUMBER(8),
  SUBR_ID                  VARCHAR2(30),
  INDV_ID                  NUMBER(2),
  GRP_SUBMITTED_SUBR_ID    VARCHAR2(30),
  RELSHIP_CDE              NUMBER(2),
  LNME                     VARCHAR2(30),
  MNME                     VARCHAR2(30),	-- 2.1
  FNME                     VARCHAR2(30),	
  DOB                      NUMBER(8),
  DERIVED_COVER_EFF_DTE    NUMBER(8),
  GRP_ID                   VARCHAR2(9),
  SUBLOC_ID                VARCHAR2(8),
  DIV_ID                   VARCHAR2(4),
  PRD_CDE                  VARCHAR2(4),
  PLN_CDE                  VARCHAR2(4),
  RTE_CDE                  VARCHAR2(4),
  TRM_DTE_DERIVED_FLAG     NUMBER(1)            DEFAULT 0,
  MAX_DTE_RECORD_FLAG      NUMBER(1)            DEFAULT 0,
  SUBMITTED_RECORD_NUMBER  NUMBER,
  TRM_REASON_CODE          NUMBER,
  PARENT_ID                NUMBER(4)            NOT NULL
)
ON COMMIT PRESERVE ROWS				-- 2.2
NOCACHE;