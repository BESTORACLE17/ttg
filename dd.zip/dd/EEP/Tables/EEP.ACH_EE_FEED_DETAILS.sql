/* VERSION: 3.1.1 */ 
--
-- ACH_EE_FEED_DETAILS  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_DETAILS
(
  SOURCE_ID                   NUMBER(15),
  TRANSMISSION_METHOD_LOOKUP  NUMBER(15),
  EE_FILE_FORMAT_LOOKUP       NUMBER(15),
  ENCRYPTION_TYPE_LOOKUP      NUMBER(15),
  ENCRYPTION_KEY              VARCHAR2(50 BYTE),
  SUBMITS_TERM_DATE           VARCHAR2(1 BYTE),
  EE_FILE_TYPE_LOOKUP         NUMBER(15),
  START_DATE                  DATE,
  END_DATE                    DATE,
  CREATED_BY                  VARCHAR2(30 BYTE),
  CREATION_DATE               DATE,
  LAST_UPDATED_BY             VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE            DATE,
  STATUS                      VARCHAR2(1 BYTE),
  REPORT_FORMAT_LOOKUP        NUMBER(15)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

