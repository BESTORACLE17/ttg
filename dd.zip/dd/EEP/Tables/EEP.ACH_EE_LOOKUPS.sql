/* VERSION: 3.1.1 */ 
--
-- ACH_EE_LOOKUPS  (Table) 
--
CREATE TABLE EEP.ACH_EE_LOOKUPS
(
  LOOKUP_CODE_ID          NUMBER(15),
  LOOKUP_TYPE_ID          NUMBER(15),
  LOOKUP_CODE             VARCHAR2(30 BYTE),
  MEANING                 VARCHAR2(80 BYTE),
  DESCRIPTION             VARCHAR2(80 BYTE),
  USER_MAINTAINABLE_FLAG  VARCHAR2(1 BYTE),
  START_DATE              DATE,
  END_DATE                DATE,
  ATTRIBUTE1              VARCHAR2(30 BYTE),
  ATTRIBUTE2              VARCHAR2(30 BYTE),
  ATTRIBUTE3              VARCHAR2(30 BYTE),
  ATTRIBUTE4              VARCHAR2(30 BYTE),
  ATTRIBUTE5              VARCHAR2(30 BYTE),
  CREATED_BY              VARCHAR2(30 BYTE),
  CREATION_DATE           DATE,
  LAST_UPDATED_BY         VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE        DATE,
  STATUS                  VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

