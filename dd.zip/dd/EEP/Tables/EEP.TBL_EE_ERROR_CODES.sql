/* VERSION: 3.1.1 */ 
--
-- TBL_EE_ERROR_CODES  (Table) 
--
CREATE TABLE EEP.TBL_EE_ERROR_CODES
(
  ERROR_ID                      NUMBER(15)      NOT NULL,
  ERROR_CODE                    VARCHAR2(30 BYTE) NOT NULL,
  ERROR_TYPE                    VARCHAR2(30 BYTE) NOT NULL,
  SEVERITY_LEVEL                NUMBER(2)       NOT NULL,
  DESCRIPTION                   VARCHAR2(200 BYTE),
  COMMENTS                      VARCHAR2(2000 BYTE),
  INTERNAL_ONLY_FLAG            VARCHAR2(1 BYTE),
  SORT_ORDER                    NUMBER(2),
  CREATED_BY                    VARCHAR2(30 BYTE),
  CREATION_DATE                 DATE,
  LAST_UPDATED_BY               VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE              DATE,
  STATUS                        VARCHAR2(1 BYTE),
  ERROR_REP_PRINT_CONTROL_FLAG  VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          520K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_EE_ERROR_CODES  (Index) 
--
CREATE UNIQUE INDEX EEP.PK_EE_ERROR_CODES ON EEP.TBL_EE_ERROR_CODES
(ERROR_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_EE_ERROR_CODES_U1  (Index) 
--
CREATE UNIQUE INDEX EEP.TBL_EE_ERROR_CODES_U1 ON EEP.TBL_EE_ERROR_CODES
(ERROR_CODE)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_ERROR_CODES TO EEP_USERS_ALL;

