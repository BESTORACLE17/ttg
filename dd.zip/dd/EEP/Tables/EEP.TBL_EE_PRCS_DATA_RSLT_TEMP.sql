--
-- VERSION 2.1.1 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: TRAC#3304 
|| Revision By    : Manoj Sathe 
|| Revision Date  : 11/03/2009 
|| Revision Desc  : Initial Creation used Enrollment process.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

DROP TABLE EEP.TBL_EE_PRCS_DATA_RSLT_TEMP CASCADE CONSTRAINTS;

CREATE GLOBAL TEMPORARY TABLE /*2.1.1*/EEP.TBL_EE_PRCS_DATA_RSLT_TEMP
(
  SUBR_ID  VARCHAR2(30 BYTE)
)
ON COMMIT DELETE ROWS
NOCACHE;

GRANT INSERT, SELECT, UPDATE ON EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP TO EEP_USERS_ALL;