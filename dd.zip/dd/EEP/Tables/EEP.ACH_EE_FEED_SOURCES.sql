/* VERSION: 3.1.2 */ 
--
-- ACH_EE_FEED_SOURCES  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_SOURCES
(
  SOURCE_ID                  NUMBER(15),
  SOURCE_NAME                VARCHAR2(70 BYTE),
  SHORT_NAME                 VARCHAR2(10 BYTE),
  SOURCE_TYPE_LOOKUP         NUMBER(15),
  ADDRESS1                   VARCHAR2(60 BYTE),
  ADDRESS2                   VARCHAR2(60 BYTE),
  ADDRESS3                   VARCHAR2(60 BYTE),
  CITY                       VARCHAR2(60 BYTE),
  STATE_PROVINCE             VARCHAR2(60 BYTE),
  POSTAL_CODE                VARCHAR2(60 BYTE),
  COUNTRY                    VARCHAR2(60 BYTE),
  DISCREPANCY_TOLERANCE_PCT  NUMBER(4,2),
  START_DATE                 DATE,
  END_DATE                   DATE,
  CREATED_BY                 VARCHAR2(30 BYTE),
  CREATION_DATE              DATE,
  LAST_UPDATED_BY            VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE           DATE,
  STATUS                     VARCHAR2(1 BYTE),
  SENDER_ID                  VARCHAR2(9 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


-- WO#15456
ALTER TABLE EEP.TBL_EE_FEED_SOURCES ADD COMPANNY_ID NUMBER(4); 


    