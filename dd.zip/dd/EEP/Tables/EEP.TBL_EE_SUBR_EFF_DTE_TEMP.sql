--
-- VERSION 2.1.2 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.1 
|| Service Request: S/R #03218-01 EE Files going on hold 
|| Revision By    : Russell J Hertzberg 
|| Revision Date  : 01/31/2005 
|| Revision Desc  : Initial Creation used in the Compare Process
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: WO#15919 
|| Revision By    : Russell J Hertzberg 
|| Revision Date  : 05/20/2005 
|| Revision Desc  : Altered the table to allow nulls 
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE GLOBAL TEMPORARY TABLE EEP.TEMP_EE_SUBR_EFF_DTE
(
  SUBR_ID               VARCHAR2(9),
  COVER_EFF_DTE         VARCHAR2(8)
)
ON COMMIT PRESERVE ROWS;


GRANT SELECT, INSERT, UPDATE ON EEP.TEMP_EE_SUBR_EFF_DTE TO EEP_USERS_ALL;