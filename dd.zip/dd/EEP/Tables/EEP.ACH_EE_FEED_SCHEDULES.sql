/* VERSION: 3.1.1 */ 
--
-- ACH_EE_FEED_SCHEDULES  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_SCHEDULES
(
  SCHEDULE_ID                 NUMBER(15),
  FREQUENCY_ID                NUMBER(15),
  SCHEDULE_DATE               DATE,
  EE_FILE_ID                  NUMBER(15),
  SOURCE_ID                   NUMBER(15),
  SCHEDULE_STATUS_LOOKUP      NUMBER(15),
  SPECIAL_SCHEDULE_FLAG       VARCHAR2(1 BYTE),
  EXPECTED_RECEIPT_DATE       DATE,
  NOTIFY_EE_FEED_SOURCE_FLAG  VARCHAR2(1 BYTE),
  REMARKS                     VARCHAR2(4000 BYTE),
  LAST_NOTIFICATION_DATE      DATE,
  CREATED_BY                  VARCHAR2(30 BYTE),
  CREATION_DATE               DATE,
  LAST_UPDATED_BY             VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE            DATE,
  STATUS                      VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

