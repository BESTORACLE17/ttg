--
-- TBL_EE_RAW_CHP1 (Table) 
--
CREATE TABLE TBL_EE_RAW_CHP1
(
  REPORT_TYPE         VARCHAR2(1 BYTE),
  MEMBERSHIP_NUMBER   VARCHAR2(9 BYTE),
  SUBR_ID            VARCHAR2(9 BYTE),
  LNME                VARCHAR2(25 BYTE),
  FNME                VARCHAR2(15 BYTE),
  MNME                VARCHAR2(15 BYTE),
  DOB                 VARCHAR2(8 BYTE),
  SEX_CDE             VARCHAR2(1 BYTE),
  SSN                 VARCHAR2(9 BYTE),
  RACE                VARCHAR2(1 BYTE),
  ADDR1               VARCHAR2(35 BYTE),
  ADDR2               VARCHAR2(30 BYTE),
  CITY                VARCHAR2(25 BYTE),
  STATE               VARCHAR2(2 BYTE),
  ZIP                 VARCHAR2(9 BYTE),
  COUNTY              VARCHAR2(2 BYTE),
  PHONE               VARCHAR2(10 BYTE),  
  CHP_PROGRAM_RATING  VARCHAR2(2 BYTE),
  EFFECTIVE_DTE       VARCHAR2(8 BYTE),
  TERMINATION_DTE     VARCHAR2(8 BYTE),  
  PROGRAM_AID_CODE    VARCHAR2(2 BYTE),
  MOD_OP              VARCHAR2(30 BYTE)         DEFAULT USER,
  MOD_DTE             DATE                      DEFAULT SYSDATE,
  GRP_ID              VARCHAR2(7 BYTE),
  SUBLOC_ID           VARCHAR2(9 BYTE),
  DIV_ID              VARCHAR2(4 BYTE),
  RTE_CDE             VARCHAR2(1 BYTE),
  SPOKEN_LANGUAGE     VARCHAR2(3 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;


--
-- IDX_EE_RAW_CHP1  (Index) 
--
CREATE INDEX IDX_EE_RAW_CHP1 ON TBL_EE_RAW_CHP1
(NVL("GRP_ID",'0'), NVL("SUBLOC_ID",'0'))
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             40K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


