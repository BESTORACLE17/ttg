/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  :
|| Service Request: SR#05203.01.VA
|| Revision By    : Dinesh Makked
|| Revision Date  : 08/02/2005
|| Revision Desc  : Changed the width of Group ID to 9 character.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.3
|| Revision Type  :
|| Service Request: SR#08224.01.VA
|| Revision By    : Raj Chetlapalli
|| Revision Date  : 08/15/2008
|| Revision Desc  : Add the new Handicap Code field
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

-- TBL_EE_RAW_DYNCORP  (Table) 
--
CREATE TABLE EEP.TBL_EE_RAW_DYNCORP
(
  ELIG_SSN         VARCHAR2(9 BYTE),
  ELIG_GROUP       VARCHAR2(4 BYTE),
  ELIG_SUBLOC      VARCHAR2(8 BYTE),
  ELIG_RATE_CODE   VARCHAR2(1 BYTE),
  ELIG_EFF_DTE     VARCHAR2(8 BYTE),
  ELIG_TRM_DTE     VARCHAR2(8 BYTE),
  ELIG_REL_CODE    VARCHAR2(1 BYTE),
  ELIG_FIRST_NAME  VARCHAR2(10 BYTE),
  ELIG_LAST_NAME   VARCHAR2(15 BYTE),
  ELIG_DOB         VARCHAR2(8 BYTE),
  ELIG_SEX         VARCHAR2(1 BYTE),
  ELIG_ADDRESS1    VARCHAR2(30 BYTE),
  ELIG_ADDRESS2    VARCHAR2(30 BYTE),
  ELIG_CITY        VARCHAR2(14 BYTE),
  ELIG_STATE       VARCHAR2(2 BYTE),
  ELIG_ZIP         VARCHAR2(5 BYTE),
  ELIG_ZIP4        VARCHAR2(4 BYTE),
  CREATED_BY       VARCHAR2(30 BYTE)            DEFAULT USER,
  CREATION_DATE    DATE                         DEFAULT SYSDATE,
  ELIG_DIV         VARCHAR2(4 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             3888K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_RAW_DYNCORP TO EEP_USERS_ALL;

--SR#05203.01.VA
ALTER TABLE EEP.TBL_EE_RAW_DYNCORP
   MODIFY ELIG_GROUP VARCHAR2(9);

ALTER TABLE EEP.TBL_EE_RAW_DYNCORP ADD (
  ELIG_HANDICAP_CDE                     VARCHAR2(1)  
);
