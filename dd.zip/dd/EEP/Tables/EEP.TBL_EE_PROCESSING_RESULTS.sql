/* VERSION: 3.1.10

  Revision History

  SR/WO:       SR 05085.25.AR
  Date:        10/1/2005
  By:          Mark Stock
  Revision:    Added WAIT_PERIOD_FROM_DATE & WAIT_PERIOD_TO_DATE
               and column comments
  New Version: 3.1.2 

  SR/WO:       SR 05208.01.ALL
  Date:        10/27/2006
  By:          Sudeep Prabhakaran

  SR/WO:       SR 08128.01.VA
  Date:        05/29/2008
  By:          Jeff Reynolds
  Revision:    Added new columns A_NPI and B_NPI.
  New Version: 3.1.6 
  Revision:    Modified Subr_id to Varchar2(30)
  New Version: 3.1.3 

  SR/WO:       SR 06122.02.KY
  Date:        07/25/2007
  By:          Jeff Reynolds
  Revision:    Added a_student_cde and b_student_cde
  New Version: 3.1.4 

  SR/WO:       SR 07178.02.KY
  Date:        02/18/2008
  By:          Jeff Reynolds
  Revision:    Added a and b records for producer_id, producer_eff_dte,
               and producer_trm_dte
  New Version: 3.1.5 

  SR/WO:       SR 08128.01.VA
  Date:        05/29/2008
  By:          Jeff Reynolds
  Revision:    Added new columns A_NPI and B_NPI.
  New Version: 3.1.6 

  SR/WO:       SR 08059.01.AR - Electronic Eligibility File Layout (Version 4.0)
  Date:        06/11/2008
  By:          Jeff Reynolds
  Revision:    Added new columns for payment method processing
  New Version: 3.1.7

  SR/WO:       SR 08092.27.CO - Retro Add/Term Date Validation
  Date:        09/04/2008
  By:          Deborah Yates
  Revision:    Added new columns
  New Version: 3.1.8

  SR/WO:       SR 08092.26.CO - Apply Late Entrant
  Date:        09/18/2008
  By:          Deborah Yates
  Revision:    Added late_entrant
  New Version: 3.1.9

  SR/WO:       SR 08128.01.VA - EE 4.0 Layout
  Date:        04/16/2009
  By:          Raj Chetlapalli
  Revision:    Added new columns A_COB_CARRIER_ID and B_COB_CARRIER_ID.
  New Version: 3.1.10

*/
--
-- TBL_EE_PROCESSING_RESULTS  (Table) 
--
CREATE TABLE EEP.TBL_EE_PROCESSING_RESULTS
(
  PROCESS_ID                  NUMBER(15)        NOT NULL,
  RECORD_ID                   NUMBER(15)        NOT NULL,
  SUBR_ID                     VARCHAR2(9),
  INDV_ID                     VARCHAR2(3),
  A_GRP_ID                    VARCHAR2(9),
  A_SUBLOC_ID                 VARCHAR2(8),
  A_DIV_ID                    VARCHAR2(8),
  A_PRD_CDE                   VARCHAR2(8),
  A_PLN_CDE                   VARCHAR2(8),
  A_RTE_CDE                   VARCHAR2(8),
  A_COVER_EFF_DTE             VARCHAR2(8),
  A_COVER_TRM_DTE             VARCHAR2(8),
  A_RELSHIP_CDE               VARCHAR2(8),
  A_LNME                      VARCHAR2(30),
  A_FNME                      VARCHAR2(30),
  A_MNME                      VARCHAR2(30),
  A_DOB                       VARCHAR2(8),
  A_ADDR1                     VARCHAR2(30),
  A_ADDR2                     VARCHAR2(30),
  A_ADDR3                     VARCHAR2(30),
  A_CITY                      VARCHAR2(30),
  A_STATE                     VARCHAR2(30),
  A_ZIP                       VARCHAR2(8),
  A_ZIP4                      VARCHAR2(8),
  A_COUNTRY_CDE               VARCHAR2(8),
  A_PRV_ID                    VARCHAR2(11),
  A_LOC                       VARCHAR2(4),
  A_TAX_ID                    VARCHAR2(9),
  A_DEP_ONLY_COVERAGE_FLAG    VARCHAR2(1),
  B_EXISTS_FLAG               VARCHAR2(1),
  B_GRP_ID                    VARCHAR2(9),
  B_SUBLOC_ID                 VARCHAR2(8),
  B_DIV_ID                    VARCHAR2(8),
  B_PRD_CDE                   VARCHAR2(8),
  B_PLN_CDE                   VARCHAR2(8),
  B_RTE_CDE                   VARCHAR2(8),
  B_COVER_EFF_DTE             VARCHAR2(8),
  B_COVER_TRM_DTE             VARCHAR2(8),
  B_RELSHIP_CDE               VARCHAR2(8),
  B_LNME                      VARCHAR2(30),
  B_FNME                      VARCHAR2(30),
  B_MNME                      VARCHAR2(30),
  B_DOB                       VARCHAR2(8),
  B_ADDR1                     VARCHAR2(30),
  B_ADDR2                     VARCHAR2(30),
  B_ADDR3                     VARCHAR2(30),
  B_CITY                      VARCHAR2(30),
  B_STATE                     VARCHAR2(30),
  B_ZIP                       VARCHAR2(8),
  B_ZIP4                      VARCHAR2(8),
  B_COUNTRY_CDE               VARCHAR2(8),
  B_PRV_ID                    VARCHAR2(11),
  B_LOC                       VARCHAR2(4),
  B_TAX_ID                    VARCHAR2(9),
  SUBR_HAS_DUMMY_ID_FLAG      VARCHAR2(1),
  ERROR_ID                    NUMBER(15)        NOT NULL,
  ERROR_SEVERITY_LEVEL        NUMBER(2)         NOT NULL,
  ERROR_DESC                  VARCHAR2(2000),
  CREATED_BY                  VARCHAR2(30),
  CREATION_DATE               DATE,
  MOD_DTE                     DATE,
  A_RELIABILITY_FLAG          VARCHAR2(1),
  A_RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8),
  B_RELIABILITY_FLAG          VARCHAR2(1),
  B_RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8),
  A_MISC_INFO                 VARCHAR2(10),
  B_MISC_INFO                 VARCHAR2(10),
  A_WAIT_PERIOD_FROM_DATE     VARCHAR2(8),
  A_WAIT_PERIOD_TO_DATE       VARCHAR2(8),
  B_WAIT_PERIOD_FROM_DATE     VARCHAR2(8),
  B_WAIT_PERIOD_TO_DATE       VARCHAR2(8)
)
TABLESPACE EEP_DATA
PCTUSED    90
PCTFREE    5
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          8K
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL
/

COMMENT ON COLUMN EEP.TBL_EE_PROCESSING_RESULTS.A_WAIT_PERIOD_FROM_DATE IS 'Optional Individual Wait Period Effective/Start Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/

COMMENT ON COLUMN EEP.TBL_EE_PROCESSING_RESULTS.A_WAIT_PERIOD_TO_DATE IS 'Optional Individual Wait Period Termination/End Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/

--
-- TBL_EE_PROCESSING_RESULTS_N1  (Index) 
--
CREATE INDEX EEP.TBL_EE_PROCESSING_RESULTS_N1 ON EEP.TBL_EE_PROCESSING_RESULTS
(PROCESS_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             520K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_PROCESSING_RESULTS TO EEP_USERS_ALL;

-- Modified for SR#05208.01.ALL
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS MODIFY SUBR_ID VARCHAR2(30);

-- added for sr07121.01.all
ALTER TABLE	EEP.TBL_EE_PROCESSING_RESULTS	MODIFY (A_PRV_ID    VARCHAR2(32) ); 

-- Added for SR06122.02.KY
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
   a_student_cde          VARCHAR2(2),
   b_student_cde          VARCHAR2(2)) ;

ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
  A_PRODUCER_ID               VARCHAR2(15),           /* 3.1.5 */
  A_PRODUCER_EFF_DTE          VARCHAR2(8),            /* 3.1.5 */
  A_PRODUCER_TRM_DTE          VARCHAR2(8),            /* 3.1.5 */
  B_PRODUCER_ID               VARCHAR2(15),           /* 3.1.5 */
  B_PRODUCER_EFF_DTE          VARCHAR2(8),            /* 3.1.5 */
  B_PRODUCER_TRM_DTE          VARCHAR2(8)             /* 3.1.5 */
);

-- Version 3.1.6 (Added for SR08128.01.VA)
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
   A_NPI                    VARCHAR2(10),               /* 3.1.6 */
   B_NPI                    VARCHAR2(10)                /* 3.1.6 */
);

-- Version 3.1.7
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD
(
  A_PAYMENT_METHOD_CODE       VARCHAR2(2),        /* 3.1.7 */
  A_BANK_ACCOUNT_TYPE_CODE    VARCHAR2(2),        /* 3.1.7 */
  A_BANK_ROUTING_NUMBER       VARCHAR2(30),       /* 3.1.7 */
  A_BANK_ACCOUNT_NUMBER       VARCHAR2(30),       /* 3.1.7 */
  A_CREDIT_CARD_TYPE_CODE     VARCHAR2(2),        /* 3.1.7 */
  A_CREDIT_CARD_NUMBER        VARCHAR2(4),        /* 3.1.7 */
  A_CREDIT_CARD_EXPIRATION    VARCHAR2(6),        /* 3.1.7 */
  B_PAYMENT_METHOD_CODE       VARCHAR2(2),        /* 3.1.7 */
  B_BANK_ACCOUNT_TYPE_CODE    VARCHAR2(2),        /* 3.1.7 */
  B_BANK_ROUTING_NUMBER       VARCHAR2(30),       /* 3.1.7 */
  B_BANK_ACCOUNT_NUMBER       VARCHAR2(30),       /* 3.1.7 */
  B_CREDIT_CARD_TYPE_CODE     VARCHAR2(2),        /* 3.1.7 */
  B_CREDIT_CARD_NUMBER        VARCHAR2(4),        /* 3.1.7 */
  B_CREDIT_CARD_EXPIRATION    VARCHAR2(6)         /* 3.1.7 */
)
;

-- 3.1.8
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
    A_SUBMITTED_COVER_TRM_DTE   NUMBER(8),
    B_SUBMITTED_COVER_TRM_DTE   NUMBER(8)
);

-- 3.1.9
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
    LATE_ENTRANT                VARCHAR2(1)
);

-- 3.1.10
ALTER TABLE EEP.TBL_EE_PROCESSING_RESULTS ADD (
   A_COB_CARRIER_ID                    VARCHAR2(30),               /* 3.1.10 */
   B_COB_CARRIER_ID                    VARCHAR2(30));

