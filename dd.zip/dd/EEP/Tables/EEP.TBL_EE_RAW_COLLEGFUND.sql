/* VERSION: 3.1.1 */
CREATE TABLE EEP.TBL_EE_RAW_COLLEGFUND
(
  SUBR_ID                   VARCHAR2(9),
  GRP_ID                    VARCHAR2(9),
  SUBLOC_ID                 VARCHAR2(8),
  DIV_ID                    VARCHAR2(8),
  PRD_CDE                   VARCHAR2(4),
  PLN_CDE                   VARCHAR2(4),
  RTE_CDE                   VARCHAR2(4),
  COVER_EFF_DTE             VARCHAR2(8),
  COVER_TRM_DTE             VARCHAR2(8),
  HIRE_DTE                  VARCHAR2(8),
  GRP_TRM_DTE               VARCHAR2(8),
  PRIOR_CARRIER_EFF_DTE     VARCHAR2(8),
  COMPENSATION_CDE          VARCHAR2(2),
  UNION_CDE                 VARCHAR2(2),
  WORK_STS_CDE              VARCHAR2(2),
  COBRA_ELIG_CDE            VARCHAR2(2),
  COBRA_EFF_DTE             VARCHAR2(8),
  QUALI_EVENT_CDE           VARCHAR2(2),
  TRM_REASON_CDE            VARCHAR2(2),
  PRIORITY_CDE              VARCHAR2(2),
  SSN                       VARCHAR2(12),
  RELSHIP_CDE               VARCHAR2(2),
  LNME                      VARCHAR2(30),
  FNME                      VARCHAR2(30),
  MNME                      VARCHAR2(30),
  DOB                       VARCHAR2(8),
  HANDICAP_CDE              VARCHAR2(2),
  HANDICAP_EFF_DTE          VARCHAR2(8),
  SEX_CDE                   VARCHAR2(2),
  MARITAL_STS               VARCHAR2(2),
  STUDENT_CDE               VARCHAR2(2),
  ADDR1                     VARCHAR2(30),
  ADDR2                     VARCHAR2(30),
  ADDR3                     VARCHAR2(30),
  CITY                      VARCHAR2(30),
  STATE                     VARCHAR2(2),
  ZIP                       VARCHAR2(5),
  ZIP4                      VARCHAR2(4),
  COUNTRY_CDE               VARCHAR2(4),
  PHONE                     VARCHAR2(30),
  PRV_ID                    VARCHAR2(11),
  LOC                       VARCHAR2(4),
  TAX_ID                    VARCHAR2(9),
  SPOUSE_DENTAL_PLAN        VARCHAR2(1),
  DEP_OTHER_DENTAL_PLAN     VARCHAR2(1),
  COB_CARRIER_NME           VARCHAR2(60),
  PRV_NME                   VARCHAR2(30),
  CREATED_BY                VARCHAR2(30)        DEFAULT USER,
  CREATION_DATE             DATE                DEFAULT SYSDATE,
  MISC1                     VARCHAR2(50),
  MISC2                     VARCHAR2(50),
  MISC3                     VARCHAR2(50),
  MISC4                     VARCHAR2(50),
  MISC5                     VARCHAR2(50),
  RELIABILITY_FLAG          VARCHAR2(1),
  RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8),
  PRIOR_SUBR_ID             VARCHAR2(9),
  MISC_INFO                 VARCHAR2(10)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_RAW_COLLEGFUND TO EEP_USERS_ALL;
-- sr07121.01.all
ALTER TABLE	EEP.TBL_EE_RAW_COLLEGFUND	MODIFY (PRV_ID VARCHAR2(32) ); 