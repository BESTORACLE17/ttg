/* VERSION: 3.1.1 */ 
--
-- TBL_EE_RAW_OVERNITE  (Table) 
--
CREATE TABLE EEP.TBL_EE_RAW_OVERNITE
(
  LOAD_SEQ   NUMBER,
  ELIG_SSN   VARCHAR2(9 BYTE),
  DATA_LINE  VARCHAR2(1000 BYTE),
  MOD_DTE    DATE                               DEFAULT SYSDATE,
  MOD_OP     VARCHAR2(30 BYTE)                  DEFAULT USER,
  MISC_INFO  VARCHAR2(10 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             8752K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- IDX_EE_RAW_OVERNITE_N1  (Index) 
--
CREATE INDEX EEP.IDX_EE_RAW_OVERNITE_N1 ON EEP.TBL_EE_RAW_OVERNITE
(ELIG_SSN)
NOLOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_RAW_OVERNITE TO EEP_USERS_ALL;

