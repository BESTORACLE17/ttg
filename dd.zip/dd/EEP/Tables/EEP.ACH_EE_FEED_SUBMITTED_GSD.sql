/* VERSION: 3.1.1 */ 
--
-- ACH_EE_FEED_SUBMITTED_GSD  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_SUBMITTED_GSD
(
  SOURCE_ID         NUMBER(15),
  GRP_ID            VARCHAR2(9 BYTE),
  SUBLOC_ID         VARCHAR2(8 BYTE),
  DIV_ID            VARCHAR2(4 BYTE),
  START_DATE        DATE,
  END_DATE          DATE,
  CREATED_BY        VARCHAR2(30 BYTE),
  CREATION_DATE     DATE,
  LAST_UPDATED_BY   VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE  DATE,
  STATUS            VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

