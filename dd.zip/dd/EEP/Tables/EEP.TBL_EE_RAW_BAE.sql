CREATE TABLE EEP.TBL_EE_RAW_BAE /* VERSION 2.1.4 */ (
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  : Enhancement
|| Service Request: SR07235.01.VA
|| Revision By    : Jeff Reynolds
|| Revision Date  : 12/10/2007
|| Revision Desc  : Added columns for prv_id and location_number
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.3
|| Revision Type  : Enhancement
|| Service Request: SR07235.01.VA
|| Revision By    : Jeff Reynolds
|| Revision Date  : 12/18/2007
|| Revision Desc  : Added columns for reporting_field_2 and
||                  reporting_field_2_eff_dte
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.4
|| Revision Type  : Enhancement
|| Service Request: SR07235.01.VA
|| Revision By    : Jeff Reynolds
|| Revision Date  : 01/07/2008
|| Revision Desc  : Added column "Name Suffix".  This data gets appended
||                  to the last name by the load process.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
   load_seq                         NUMBER,
   record_type                      VARCHAR2(1),
   subr_id                          VARCHAR2(30),
   ssn                              VARCHAR2(9),
   dependent_number                 VARCHAR2(2),
   dependent_ssn                    VARCHAR2(9),
   prior_ssn                        VARCHAR2(9),
   relationship_code                VARCHAR2(2),
   first_name                       VARCHAR2(15),
   middle_initial                   VARCHAR2(1),
   last_name                        VARCHAR2(30),
   birth_date                       VARCHAR2(8),
   hire_date                        VARCHAR2(8),
   gender_code                      VARCHAR2(1),
   marital_code                     VARCHAR2(1),
   mailing_address_line_1           VARCHAR2(30),
   mailing_address_line_2           VARCHAR2(30),
   mailing_address_line_3           VARCHAR2(30),
   mailing_city                     VARCHAR2(16),
   mailing_state_code               VARCHAR2(2),
   mailing_zip                      VARCHAR2(10),
   country_code                     VARCHAR2(3),
   telephone_number                 VARCHAR2(10),
   participant_type                 VARCHAR2(2),
   reporting_field_1                VARCHAR2(15),
   reporting_field_1_eff_dte        VARCHAR2(8),
   reporting_field_3                VARCHAR2(15),
   reporting_field_3_eff_dte        VARCHAR2(8),
   disabled_flag                    VARCHAR2(1),
   overage_elig_flag                VARCHAR2(1),
   cob_indicator                    VARCHAR2(1),
   coverage_tier                    VARCHAR2(2),
   coverage_type                    VARCHAR2(2),
   coverage_begin_date              VARCHAR2(8),
   coverage_end_date                VARCHAR2(8),
   coverage_effective_date          VARCHAR2(8),
   cobra_qualifying_code            VARCHAR2(2),
   cobra_qualifying_eff_date        VARCHAR2(8),
   created_by                       VARCHAR2(30),
   created_date                     DATE
) TABLESPACE EEP_DATA
/
CREATE INDEX IDX_EE_RAW_BAE_LOAD_SEQ
    ON EEP.TBL_EE_RAW_BAE (load_seq)
TABLESPACE EEP_INDEX
/
GRANT SELECT, INSERT, UPDATE ON EEP.TBL_EE_RAW_BAE to EEP_USERS_ALL
/
-- Version 2.1.2 (SR07235.01.VA)
ALTER TABLE EEP.TBL_EE_RAW_BAE ADD (
   prv_id                           VARCHAR2(32),
   location_number                  NUMBER(4)
)
/
-- Version 2.1.3 (SR07235.01.VA)
ALTER TABLE EEP.TBL_EE_RAW_BAE ADD (
   reporting_field_2                VARCHAR2(15),
   reporting_field_2_eff_dte        VARCHAR2(8)
)
/
-- Version 2.1.4 (SR07235.01.VA)
ALTER TABLE EEP.TBL_EE_RAW_BAE ADD (
   name_suffix                      VARCHAR2(10)
)
/
