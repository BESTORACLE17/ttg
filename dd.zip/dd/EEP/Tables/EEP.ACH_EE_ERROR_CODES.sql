/* VERSION: 3.1.1 */ 
--
-- ACH_EE_ERROR_CODES  (Table) 
--
CREATE TABLE EEP.ACH_EE_ERROR_CODES
(
  ERROR_ID                      NUMBER(15),
  ERROR_CODE                    VARCHAR2(30 BYTE),
  ERROR_TYPE                    VARCHAR2(30 BYTE),
  SEVERITY_LEVEL                NUMBER(2),
  DESCRIPTION                   VARCHAR2(200 BYTE),
  COMMENTS                      VARCHAR2(2000 BYTE),
  INTERNAL_ONLY_FLAG            VARCHAR2(1 BYTE),
  SORT_ORDER                    NUMBER(2),
  CREATED_BY                    VARCHAR2(30 BYTE),
  CREATION_DATE                 DATE,
  LAST_UPDATED_BY               VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE              DATE,
  STATUS                        VARCHAR2(1 BYTE),
  ERROR_REP_PRINT_CONTROL_FLAG  VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          520K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT SELECT ON  EEP.ACH_EE_ERROR_CODES TO EEP_USERS_ALL;

