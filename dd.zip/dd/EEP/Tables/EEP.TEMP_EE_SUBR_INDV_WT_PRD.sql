/* VERSION: 3.1.1 */
--  TRAC#4027
-- TEMP_EE_SUBR_INDV_WT_PRD  (Table) 
-- 

DROP TABLE eep.temp_ee_subr_indv_wt_prd CASCADE CONSTRAINTS;

CREATE GLOBAL TEMPORARY TABLE eep.temp_ee_subr_indv_wt_prd
(
  subr_id          VARCHAR2(30 BYTE)            NOT NULL,
  indv_id          NUMBER(2)                    NOT NULL,
  apply_waive_cde  NUMBER(4)                    NOT NULL,
  ben_class_cde    NUMBER(4)                    NOT NULL,
  eff_dte          NUMBER(8)                    NOT NULL,
  trm_dte          NUMBER(8),
  parent_id        NUMBER(4)       NOT NULL
)
ON COMMIT PRESERVE ROWS
NOCACHE;

CREATE OR REPLACE TRIGGER eep."TRG_EE_SUBR_INDV_WT_TEMP_PID"
   BEFORE UPDATE OR INSERT
   ON "EEP"."TEMP_EE_SUBR_INDV_WT_PRD"
   FOR EACH ROW
--============================================================================
-- Desc  : This Trigger is Created to insert parent_id from sys_context
--============================================================================
DECLARE
   l_parent_id   NUMBER := SYS_CONTEXT ('CNT_PARENT_ID', 'PARENT_ID');
BEGIN
   :NEW.parent_id := l_parent_id;
END;
/
GRANT INSERT, SELECT, UPDATE ON eep.temp_ee_subr_indv_wt_prd TO eep_users_all;