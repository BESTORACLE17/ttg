/* VERSION: 3.1.14

  Revision History

  SR/WO:      SR 05085.25.AR
  Date:       10/1/2005
  By:         Mark Stock
  Revision:   Added WAIT_PERIOD_FROM_DATE and WAIT_PERIOD_TO_DATE
              Also added GRANTS to VSS script

  SR/WO:       SR 06255.01.VA
  Date:        10/17/2006
  By:          Sudeep P
  Revision:    Added SUBMITTED_RECORD_NUMBER
  New Version: 3.1.3

  SR/WO:       SR 05208.01.ALL
  Date:        10/27/2006
  By:          Sudeep P
  Revision:    Modified Subr_id to Varchar2(30)
  New Version: 3.1.4

  SR/WO:       SR 05208.01.ALL
  Date:        01/26/2006
  By:          Sudeep P
  Revision:    Added new indexes in table. 
  New Version: 3.1.5

  SR/WO:       SR 06284.03.VA
  Date:        03/20/2007
  By:          Jeff Reynolds
  Revision:    Added new columns trm_dte_is_lt_split_dte_flag, ben_grp_id,
               ben_subloc_id, and ben_div_id.
  New Version: 3.1.6

  SR/WO:       SR 07178.02.KY
  Date:        02/05/2008
  By:          Jeff Reynolds
  Revision:    Added new columns PRODUCER_ID, PRODUCER_EFF_DTE, and
               PRODUCER_TRM_DTE.
  New Version: 3.1.7

  SR/WO:       SR 08128.01.VA
  Date:        05/29/2008
  By:          Jeff Reynolds
  Revision:    Added new column NPI
  New Version: 3.1.8

-- Revision Number: 3.1.9
-- Change Control#: SR08059.01.AR
-- Revision By    : Jeff Reynolds
-- Revision Date  : 06/05/2008
-- Revision Desc  : Added payment_method_code, bank_account_type_code,
--                  bank_routing_number, bank_account_number,
--                  credit_card_type_code, credit_card_number,
--                  credit_card_expiration

-- Revision Number: 3.1.10
-- Change Control#: SR08092.27.CO - Retro Add / Term Date Validation
-- Revision By    : Deborah Yates
-- Revision Date  : 09/04/2008
-- Revision Desc  : Added the submitted_cover_trm_dte

-- Revision Number: 3.1.11
-- Change Control#: SR08092.26.CO - Apply Late Entrant
-- Revision By    : Deborah Yates
-- Revision Date  : 09/18/2008
-- Revision Desc  : Added the late_entrant_flag

-- Revision Number: 3.1.12
-- Change Control#: HD35233 - WAL-MART EE LOADS TAKING TOO LONG TO COMPLETE
-- Revision By    : Jeff Reynolds
-- Revision Date  : 02/27/2009
-- Revision Desc  : Added index (non-unique) on grp_submitted_subr_id, ee_file_id
--
-- Revision Number: 3.1.13
-- Change Control#: SR 08128.01.VA
-- Revision By    : Raj Chetlapalli
-- Revision Date  : 04/16/2009
-- Revision Desc  : Added field COB_CARRIER_ID
--
-- Revision Number: 3.1.14
-- Change Control#: SR 10083.05.VA
-- Revision By    : Raj Chetlapalli
-- Revision Date  : 04/08/2011
-- Revision Desc  : Added 5010 Extended Fields
*/

--
-- TBL_EE_ELIGIBILITY_DATA_ALL  (Table) 
--
CREATE TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL
(
  EE_FILE_ID                    NUMBER(15)          NOT NULL,
  EE_RECORD_ID                  NUMBER(15)          NOT NULL,
  EE_RECORD_STATUS              NUMBER(15),
  SUBR_ID                       VARCHAR2(9),
  INDV_ID                       VARCHAR2(2),
  GRP_ID                        VARCHAR2(9),
  SUBLOC_ID                     VARCHAR2(8),
  DIV_ID                        VARCHAR2(4),
  PRD_CDE                       VARCHAR2(4),
  PLN_CDE                       VARCHAR2(4),
  RTE_CDE                       VARCHAR2(4),
  DEP_ONLY_COVERAGE_FLAG        VARCHAR2(1),
  COVER_EFF_DTE                 VARCHAR2(8),
  COVER_TRM_DTE                 VARCHAR2(8),
  PRIOR_CARRIER_EFF_DTE         VARCHAR2(8),
  HIRE_DTE                      VARCHAR2(8),
  WORK_STS_CDE                  VARCHAR2(2),
  COBRA_ELIG_CDE                VARCHAR2(2),
  COBRA_EFF_DTE                 VARCHAR2(8),
  QUALI_EVENT_CDE               VARCHAR2(2),
  TRM_REASON_CDE                VARCHAR2(2),
  TRM_COMMENT                   VARCHAR2(200),
  SSN                           VARCHAR2(12),
  RELSHIP_CDE                   VARCHAR2(2),
  LNME                          VARCHAR2(30),
  FNME                          VARCHAR2(30),
  MNME                          VARCHAR2(30),
  DOB                           VARCHAR2(8),
  HANDICAP_CDE                  VARCHAR2(2),
  HANDICAP_EFF_DTE              VARCHAR2(8),
  SEX_CDE                       VARCHAR2(2),
  MARITAL_STS                   VARCHAR2(2),
  STUDENT_CDE                   VARCHAR2(2),
  ADDR1                         VARCHAR2(30),
  ADDR2                         VARCHAR2(30),
  ADDR3                         VARCHAR2(30),
  CITY                          VARCHAR2(30),
  STATE                         VARCHAR2(2),
  ZIP                           VARCHAR2(5),
  ZIP4                          VARCHAR2(4),
  COUNTRY_CDE                   VARCHAR2(4),
  PHONE                         VARCHAR2(30),
  PRV_ID                        VARCHAR2(11),
  LOC                           VARCHAR2(4),
  TAX_ID                        VARCHAR2(9),
  SPOUSE_DENTAL_PLAN            VARCHAR2(1),
  DEP_OTHER_DENTAL_PLAN         VARCHAR2(1),
  COB_CARRIER_NME               VARCHAR2(60),
  PRV_NME                       VARCHAR2(30),
  CREATED_BY                    VARCHAR2(30),
  CREATION_DATE                 DATE,
  LAST_UPDATED_BY               VARCHAR2(30),
  LAST_UPDATE_DATE              DATE,
  DERIVED_COVER_EFF_DTE         VARCHAR2(8),
  RELIABILITY_FLAG              VARCHAR2(1),
  RELIABILITY_FLAG_EFF_DTE      VARCHAR2(8),
  PRIOR_SUBR_ID                 VARCHAR2(9),
  MISC_INFO                     VARCHAR2(10),
  WAIT_PERIOD_FROM_DATE         VARCHAR2(8),
  WAIT_PERIOD_TO_DATE           VARCHAR2(8)
)
TABLESPACE EEP_DATA
PCTUSED    90
PCTFREE    5
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             20M
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL
/

COMMENT ON COLUMN EEP.TBL_EE_ELIGIBILITY_DATA_ALL.WAIT_PERIOD_FROM_DATE IS 'Optional Individual Wait Period Effective/Start Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/

COMMENT ON COLUMN EEP.TBL_EE_ELIGIBILITY_DATA_ALL.WAIT_PERIOD_TO_DATE IS 'Optional Individual Wait Period Termination/End Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/


--
-- N1_EE_ELIGIBILITY_DATA_ALL  (Index) 
--
CREATE INDEX EEP.N1_EE_ELIGIBILITY_DATA_ALL ON EEP.TBL_EE_ELIGIBILITY_DATA_ALL
(EE_FILE_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


--
-- U1_EE_ELIGIBILITY_DATA_ALL  (Index) 
--
CREATE UNIQUE INDEX EEP.U1_EE_ELIGIBILITY_DATA_ALL ON EEP.TBL_EE_ELIGIBILITY_DATA_ALL
(EE_RECORD_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


-- 
-- Foreign Key Constraints for Table TBL_EE_ELIGIBILITY_DATA_ALL 
-- 
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
  CONSTRAINT FK_EE_ELIG_DATA_FILE_ID FOREIGN KEY (EE_FILE_ID) 
    REFERENCES EEP.TBL_EE_INCOMING_FILES (EE_FILE_ID))
/

ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
  CONSTRAINT FK_EE_RECORD_STATUS FOREIGN KEY (EE_RECORD_STATUS) 
    REFERENCES EEP.TBL_EE_LOOKUPS (LOOKUP_CODE_ID))
/


GRANT SELECT ON  EEP.TBL_EE_ELIGIBILITY_DATA_ALL TO DCS2000 WITH GRANT OPTION
/

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_ELIGIBILITY_DATA_ALL TO EEP_USERS_ALL
/

-- Added for SR#06255.01.VA
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD SUBMITTED_RECORD_NUMBER NUMBER;

-- Modified for SR#05208.01.ALL
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL MODIFY SUBR_ID VARCHAR2(30);
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD GRP_SUBMITTED_SUBR_ID VARCHAR2(30);
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD GRP_SUBMITTED_SUBR_ID_TYPE NUMBER(4);

-- Added for WO#25193
CREATE INDEX N2_EE_ELIGIBILITY_DATA_ALL ON EEP.TBL_EE_ELIGIBILITY_DATA_ALL
(EE_FILE_ID, SUBR_ID )
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          20M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added for WO#25193
CREATE INDEX N3_EE_ELIGIBILITY_DATA_ALL ON TBL_EE_ELIGIBILITY_DATA_ALL
(EE_FILE_ID, PRIOR_SUBR_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          20M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 2.1.7
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL
   ADD (
          TRM_DTE_IS_LT_SPLIT_DTE_FLAG  VARCHAR2(1),
          BEN_GRP_ID                    VARCHAR2(9),
          BEN_SUBLOC_ID                 VARCHAR2(8),
          BEN_DIV_ID                    VARCHAR2(4)
   );

-- Version 3.1.7
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
  PRODUCER_ID                   VARCHAR2(15), /* 3.1.7 */
  PRODUCER_EFF_DTE              VARCHAR2(8),  /* 3.1.7 */
  PRODUCER_TRM_DTE              VARCHAR2(8)   /* 3.1.7 */
);

-- Version 3.1.8
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
  NPI                           VARCHAR2(10)  /* 3.1.8 */
);
-- Version 3.1.9
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD
(
  PAYMENT_METHOD_CODE       VARCHAR2(2),        /* 3.1.9 */
  BANK_ACCOUNT_TYPE_CODE    VARCHAR2(2),        /* 3.1.9 */
  BANK_ROUTING_NUMBER       VARCHAR2(30),       /* 3.1.9 */
  BANK_ACCOUNT_NUMBER       VARCHAR2(30),       /* 3.1.9 */
  CREDIT_CARD_TYPE_CODE     VARCHAR2(2),        /* 3.1.9 */
  CREDIT_CARD_NUMBER        VARCHAR2(4),        /* 3.1.9 */
  CREDIT_CARD_EXPIRATION    VARCHAR2(6)         /* 3.1.9 */
)
;

-- 3.1.10
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
    SUBMITTED_COVER_TRM_DTE NUMBER(8)
);

-- 3.1.11
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
    LATE_ENTRANT_FLAG       VARCHAR2(1)
);

-- Added for HD35233   /* 3.1.12 */
CREATE INDEX N4_EE_ELIGIBILITY_DATA_ALL ON TBL_EE_ELIGIBILITY_DATA_ALL
(GRP_SUBMITTED_SUBR_ID, EE_FILE_ID)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          40M
            NEXT             40M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


-- 3.1.13
ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD (
  COB_CARRIER_ID                     VARCHAR2(30)  /* 3.1.13 */
);

ALTER TABLE EEP.TBL_EE_ELIGIBILITY_DATA_ALL ADD
(
  SUBR_ID_EXTENDED       VARCHAR2(50),
  LNME_EXTENDED          VARCHAR2(60),
  FNME_EXTENDED          VARCHAR2(35),
  ADDR1_EXTENDED         VARCHAR2(55),
  ADDR2_EXTENDED         VARCHAR2(55), 
  PRV_NME_EXTENDED       VARCHAR2(60), 
  EMAIL_ADDR_EXTENDED    VARCHAR2(256)  
);