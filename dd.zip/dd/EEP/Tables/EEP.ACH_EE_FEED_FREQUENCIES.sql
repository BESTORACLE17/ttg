/* VERSION: 3.1.1 */ 
--
-- ACH_EE_FEED_FREQUENCIES  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_FREQUENCIES
(
  FREQUENCY_ID           NUMBER(15),
  SOURCE_ID              NUMBER(15),
  FREQUENCY_TYPE_LOOKUP  NUMBER(15),
  FREQUENCY_UNITS        NUMBER,
  WHICH_DAY              VARCHAR2(30 BYTE),
  WHICH_DAY_FREQ_LOOKUP  NUMBER(15),
  GRACE_PERIOD_DAYS      NUMBER(3),
  START_DATE             DATE,
  END_DATE               DATE,
  CREATED_BY             VARCHAR2(30 BYTE),
  CREATION_DATE          DATE,
  LAST_UPDATED_BY        VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE       DATE,
  STATUS                 VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

