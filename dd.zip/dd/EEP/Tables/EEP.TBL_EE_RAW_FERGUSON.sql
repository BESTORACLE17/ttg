/* VERSION: 3.1.2 */ 
--
-- TBL_EE_RAW_FERGUSON  (Table) 
--
-- Create table
create table eep.TBL_EE_RAW_FERGUSON
(
  subr_id                  VARCHAR2(14),
  grp_id                   VARCHAR2(9),
  subloc_id                VARCHAR2(8),
  div_id                   VARCHAR2(4),
  rte_cde                  VARCHAR2(4),
  cover_eff_dte            VARCHAR2(8),
  cover_trm_dte            VARCHAR2(8),
  hire_dte                 VARCHAR2(8),
  cobra_elig_cde           VARCHAR2(2),
  cobra_eff_dte            VARCHAR2(8),
  quali_event_cde          VARCHAR2(2),
  trm_reason_cde           VARCHAR2(2),
  ssn                      VARCHAR2(9),
  relship_cde              VARCHAR2(2),
  lnme                     VARCHAR2(30),
  fnme                     VARCHAR2(30),
  mnme                     VARCHAR2(30),
  dob                      VARCHAR2(8),
  handicap_cde             VARCHAR2(2),
  handicap_eff_dte         VARCHAR2(8),
  sex_cde                  VARCHAR2(2),
  marital_sts              VARCHAR2(2),
  addr1                    VARCHAR2(30),
  addr2                    VARCHAR2(30),
  addr3                    VARCHAR2(30),
  city                     VARCHAR2(30),
  state                    VARCHAR2(2),
  zip                      VARCHAR2(5),
  zip4                     VARCHAR2(4),
  country_cde              VARCHAR2(4),
  student_cde              VARCHAR2(2),
  prv_id                   VARCHAR2(11),
  loc                      VARCHAR2(4),
  prv_nme                  VARCHAR2(30),
  npi                      VARCHAR2(10),
  cob_carrier_nme          VARCHAR2(60),
  cob_carrier_id           VARCHAR2(15),
  email_addr               VARCHAR2(60),
  created_by               VARCHAR2(30) default USER,
  creation_date            DATE default SYSDATE,
  misc1                    VARCHAR2(50),
  misc2                    VARCHAR2(50),
  misc3                    VARCHAR2(50),
  misc4                    VARCHAR2(50),
  misc5                    VARCHAR2(50),
  reliability_flag         VARCHAR2(1),
  reliability_flag_eff_dte VARCHAR2(8),
  prior_subr_id            VARCHAR2(30),
  misc_info                VARCHAR2(10),
  work_sts_cde             VARCHAR2(2),
  product_line_code        NUMBER(4) default 1
)
tablespace EEP_DATA
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 120K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate indexes 
create index eep.IDX_EE_RAW_FERGUSON on eep.TBL_EE_RAW_FERGUSON (NVL(GRP_ID,'0'), NVL(SUBLOC_ID,'0'), NVL(DIV_ID,'0'))
  tablespace EEP_INDEX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 120K
    minextents 1
    maxextents unlimited
  );

  -- Grant/Revoke object privileges 
grant select on eep.TBL_EE_RAW_FERGUSON to EEP_USERS_ALL;
