/* VERSION: 3.1.2 */ 
--
-- TBL_EE_FEED_SOURCES  (Table) 
--
CREATE TABLE EEP.TBL_EE_FEED_SOURCES
(
  SOURCE_ID                  NUMBER(15)         NOT NULL,
  SOURCE_NAME                VARCHAR2(70 BYTE)  NOT NULL,
  SHORT_NAME                 VARCHAR2(10 BYTE)  NOT NULL,
  SOURCE_TYPE_LOOKUP         NUMBER(15)         NOT NULL,
  ADDRESS1                   VARCHAR2(60 BYTE),
  ADDRESS2                   VARCHAR2(60 BYTE),
  ADDRESS3                   VARCHAR2(60 BYTE),
  CITY                       VARCHAR2(60 BYTE),
  STATE_PROVINCE             VARCHAR2(60 BYTE),
  POSTAL_CODE                VARCHAR2(60 BYTE),
  COUNTRY                    VARCHAR2(60 BYTE),
  DISCREPANCY_TOLERANCE_PCT  NUMBER(4,2),
  START_DATE                 DATE,
  END_DATE                   DATE,
  CREATED_BY                 VARCHAR2(30 BYTE),
  CREATION_DATE              DATE,
  LAST_UPDATED_BY            VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE           DATE,
  STATUS                     VARCHAR2(1 BYTE),
  SENDER_ID                  VARCHAR2(9 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_FEED_SOURCES TO EEP_USERS_ALL;

GRANT SELECT ON  EEP.TBL_EE_FEED_SOURCES TO DCS2000 WITH GRANT OPTION;

GRANT SELECT ON  EEP.TBL_EE_FEED_SOURCES TO DCS_USERS_ALL;

--
-- PK_EE_FEED_SOURCES  (Index) 
--
CREATE UNIQUE INDEX EEP.PK_EE_FEED_SOURCES ON EEP.TBL_EE_FEED_SOURCES
(SOURCE_ID)
LOGGING
TABLESPACE EEP_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_EE_FEED_SOURCES_U1  (Index) 
--
CREATE UNIQUE INDEX EEP.TBL_EE_FEED_SOURCES_U1 ON EEP.TBL_EE_FEED_SOURCES
(SHORT_NAME)
LOGGING
TABLESPACE EEP_INDEX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_EE_FEED_SOURCES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_EE_FEED_SOURCES FOR EEP.TBL_EE_FEED_SOURCES;

-- 
-- Non Foreign Key Constraints for Table TBL_EE_FEED_SOURCES 
-- 
ALTER TABLE EEP.TBL_EE_FEED_SOURCES ADD (
  CHECK ( STATUS IN ('A', 'I', 'D')));

ALTER TABLE EEP.TBL_EE_FEED_SOURCES ADD (
  CONSTRAINT PK_EE_FEED_SOURCES PRIMARY KEY (SOURCE_ID)
    USING INDEX 
    TABLESPACE EEP_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          24K
                NEXT             16K
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_EE_FEED_SOURCES 
-- 
ALTER TABLE EEP.TBL_EE_FEED_SOURCES ADD (
  CONSTRAINT FK_SOURCE_TYPE FOREIGN KEY (SOURCE_TYPE_LOOKUP) 
    REFERENCES EEP.TBL_EE_LOOKUPS (LOOKUP_CODE_ID));


-- WO#15456
ALTER TABLE EEP.TBL_EE_FEED_SOURCES ADD COMPANNY_ID NUMBER(4); 


    