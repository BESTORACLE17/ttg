CREATE TABLE eep.tbl_ee_raw_ADLCOORFID
       (
         rec_type              VARCHAR2(1 BYTE),
         subr_id               VARCHAR2(9 BYTE),
         grp_id                VARCHAR2(9 BYTE),
         subloc_id             VARCHAR2(8 BYTE),
         div_id                VARCHAR2(4 BYTE),
         act_ind               VARCHAR2(1 BYTE),
         ssn                   VARCHAR2(9 BYTE),
         fnme                  VARCHAR2(20 BYTE),
         mnme                  VARCHAR2(20 BYTE),
         lnme                  VARCHAR2(30 BYTE),
         sex_cde               VARCHAR2(1 BYTE),
         dob                   VARCHAR2(8 BYTE),
         relship_cde           VARCHAR2(1 BYTE),
         dependent_status_cde  VARCHAR2(1 BYTE),
         addr1                 VARCHAR2(50 BYTE),
         addr2                 VARCHAR2(50 BYTE),
         addr3                 VARCHAR2(50 BYTE),
         city                  VARCHAR2(20 BYTE),
         state                 VARCHAR2(20 BYTE),
         zip                   VARCHAR2(20 BYTE),
         country_cde           VARCHAR2(30 BYTE),
         cover_eff_dte         VARCHAR2(8 BYTE),
         cover_trm_dte         VARCHAR2(8 BYTE),
         pln_type              VARCHAR2(3 BYTE),
         pln_cde               VARCHAR2(3 BYTE),
         opt                   VARCHAR2(2 BYTE),
         company_cde           VARCHAR2(3 BYTE),
         pay_group             VARCHAR2(10 BYTE),
         loc_cde               VARCHAR2(15 BYTE),
         work_sts_cde          VARCHAR2(1 BYTE),
         original_subr_ssn     VARCHAR2(9 BYTE),
         mod_dte               DATE                    DEFAULT SYSDATE,
         mod_op                VARCHAR2(30 BYTE)       DEFAULT USER
       )
TABLESPACE raw_data;

GRANT INSERT, SELECT, UPDATE ON eep.tbl_ee_raw_coors TO eep_users_all;