/* VERSION: 3.1.1 */ 
--
-- ACH_EE_FEED_AUTO_TERM_DETAILS  (Table) 
--
CREATE TABLE EEP.ACH_EE_FEED_AUTO_TERM_DETAILS
(
  SOURCE_ID                    NUMBER(15),
  COMPARE_TYPE_LOOKUP          NUMBER(15),
  AUTO_TERM_FLAG               VARCHAR2(1 BYTE),
  WHICH_AUTO_TERM_DATE_LOOKUP  NUMBER(15),
  START_DATE                   DATE,
  END_DATE                     DATE,
  CREATED_BY                   VARCHAR2(30 BYTE),
  CREATION_DATE                DATE,
  LAST_UPDATED_BY              VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE             DATE,
  STATUS                       VARCHAR2(1 BYTE)
)
TABLESPACE EEP_DATA
PCTUSED    40
PCTFREE    0
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT SELECT ON  EEP.ACH_EE_FEED_AUTO_TERM_DETAILS TO EEP_USERS_ALL;

