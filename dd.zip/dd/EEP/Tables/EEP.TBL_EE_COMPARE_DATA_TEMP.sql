--
-- VERSION 2.1.10
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2
|| Service Request: S/R #03218-01 EE Files going on hold 
|| Revision By    : Russell J Hertzberg 
|| Revision Date  : 01/31/2005 
|| Revision Desc  : Added derived_cover_eff_dte column
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3
|| Service Request: S/R #05085.25.AR
|| Revision By    : Mark Stock
|| Revision Date  : 10/11/2005 
|| Revision Desc  : Added WAIT_PERIOD_FROM_DATE and WAIT_PERIOD_TO_DATE
                    (note longer length -- see column comments)
                    Also added sheme name to 2.1.2 revision
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4
|| Service Request: S/R #05208.01.ALL
|| Revision By    : Sudeep Prabhakaran
|| Revision Date  : 10/27/2006
|| Revision Desc  : 1. Modified Subr_id Column to Varchar2(30)
||						  2. Added two new columns. 
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.5
|| Service Request: 25193 - COV daily file has been in compare for 30 minutes.
|| Revision By    : Sudeep Prabhakaran
|| Revision Date  : 01/31/2007
|| Revision Desc  : Added Index to improve the performance. 
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.6
|| Service Request: SR06284.03.VA - Split Records Process Won't Utilizie Submitted Term Dates
|| Revision By    : Jeff Reynolds
|| Revision Date  : 03/20/2007
|| Revision Desc  : Added new columns trm_dte_is_lt_split_dte_flag, ben_grp_id,
||                  ben_subloc_id, and ben_div_id.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.7
|| Service Request: SR08092.27.CO - Retro Add/Term Date Validation
|| Revision By    : Deborah Yates
|| Revision Date  : 09/04/2008
|| Revision Desc  : Added new columns 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.8
|| Service Request: HD 34313
|| Revision By    : Satyasai/Ram Garimella
|| Revision Date  : 10/31/2008
|| Revision Desc  : Added Index
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement
|| Version #      : 2.1.9
|| Service Request: HD35233 - WalMart EE loads taking too long to complete
|| Revision By    : Jeff Reynolds
|| Revision Date  : 02/10/2009
|| Revision Desc  : Revised TBL_EE_COMPARE_DATA_TEMP_N1 to remove grp_id
||                  from the index.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Modification
|| Version #      : 2.1.10
|| Service Request: Added the missing field PRIOR_SUBR_ID in SVN Source
|| Revision By    : Raj Chetlapalli
|| Revision Date  : 04/16/2009
|| Revision Desc  : Added the missing field PRIOR_SUBR_ID in SVN Source
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_EE_COMPARE_DATA_TEMP  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE EEP.TBL_EE_COMPARE_DATA_TEMP
(
  DATA_GROUP_FLAG               VARCHAR2(30 BYTE)    NOT NULL,
  EE_FILE_ID                    NUMBER(15)           NOT NULL,
  EE_RECORD_ID                  NUMBER(15),
  SUBR_ID                       VARCHAR2(9 BYTE),
  INDV_ID                       VARCHAR2(2 BYTE),
  GRP_ID                        VARCHAR2(9 BYTE),
  SUBLOC_ID                     VARCHAR2(8 BYTE),
  DIV_ID                        VARCHAR2(4 BYTE),
  PRD_CDE                       VARCHAR2(4 BYTE),
  PLN_CDE                       VARCHAR2(4 BYTE),
  RTE_CDE                       VARCHAR2(4 BYTE),
  COVER_EFF_DTE                 VARCHAR2(8 BYTE),
  COVER_TRM_DTE                 VARCHAR2(8 BYTE),
  RELSHIP_CDE                   VARCHAR2(2 BYTE),
  LNME                          VARCHAR2(30 BYTE),
  FNME                          VARCHAR2(30 BYTE),
  MNME                          VARCHAR2(30 BYTE),
  DOB                           VARCHAR2(8 BYTE),
  ADDR1                         VARCHAR2(30 BYTE),
  ADDR2                         VARCHAR2(30 BYTE),
  ADDR3                         VARCHAR2(30 BYTE),
  CITY                          VARCHAR2(30 BYTE),
  STATE                         VARCHAR2(2 BYTE),
  ZIP                           VARCHAR2(5 BYTE),
  ZIP4                          VARCHAR2(4 BYTE),
  COUNTRY_CDE                   VARCHAR2(4 BYTE),
  MATCHING_REC_FOUND_FLAG       VARCHAR2(1 BYTE),
  CREATED_BY                    VARCHAR2(30 BYTE),
  CREATION_DATE                 DATE,
  LAST_UPDATED_BY               VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE              DATE
)
ON COMMIT PRESERVE ROWS;

--
-- TBL_EE_COMPARE_DATA_TEMP_N1  (Index) 
--
CREATE INDEX EEP.TBL_EE_COMPARE_DATA_TEMP_N1 ON EEP.TBL_EE_COMPARE_DATA_TEMP
(DATA_GROUP_FLAG, SUBR_ID, RELSHIP_CDE);                              -- 2.1.9

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_COMPARE_DATA_TEMP TO EEP_USERS_ALL;

-- 
-- S/R #03218-01 EE Files going on hold
-- 
ALTER TABLE eep.TBL_EE_COMPARE_DATA_TEMP ADD derived_cover_eff_dte VARCHAR2(8);

--
-- S/R #05085.25.AR
--
-- longer data length for potentially multiple YYYYMMDD values; can hold up to approx 40 values
--
ALTER TABLE eep.TBL_EE_COMPARE_DATA_TEMP ADD (
  WAIT_PERIOD_FROM_DATE VARCHAR2(400)
, WAIT_PERIOD_TO_DATE VARCHAR2(400)
)
/

COMMENT ON COLUMN eep.TBL_EE_COMPARE_DATA_TEMP.wait_period_from_date
IS 'Holds either a single YYYYMMDD date value for FILE_TO_FILE comparisons, or holds one or more YYYYMMDD date values, plus indicator flags, for FILE_TO_DCS comparisons (see PKG_EE_COMPARE_PROCESS). Can hold up to approx 40 values.'
/

COMMENT ON COLUMN eep.TBL_EE_COMPARE_DATA_TEMP.wait_period_to_date
IS 'Holds either a single YYYYMMDD date value for FILE_TO_FILE comparisons, or holds one or more YYYYMMDD date values for FILE_TO_DCS comparisons (see PKG_EE_COMPARE_PROCESS). Can hold up to approx 40 values.'
/

-- Modified for SR#05208.01.ALL
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP MODIFY SUBR_ID VARCHAR2(30);
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP ADD DCS_ASSIGNED_ID VARCHAR2(30);
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP ADD GRP_SUBMITTED_ID_TYPE NUMBER(4);

-- HD25193
CREATE INDEX TBL_EE_COMPARE_DATA_TEMP_N2 ON TBL_EE_COMPARE_DATA_TEMP (subr_id, relship_cde);

-- HD 34313  *** 2.1.8 ***
CREATE INDEX EEP.EE_COMPARE_DATA_TEMP_IX99 ON EEP.TBL_EE_COMPARE_DATA_TEMP (EE_RECORD_ID);

-- SR06284.03.VA   /* 2.1.6 */
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP ADD (
  TRM_DTE_IS_LT_SPLIT_DTE_FLAG  VARCHAR2(1),
  BEN_GRP_ID                    VARCHAR2(9),
  BEN_SUBLOC_ID                 VARCHAR2(8),
  BEN_DIV_ID                    VARCHAR2(4)
);

-- 2.1.7
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP ADD (
    SUBMITTED_COVER_TRM_DTE     NUMBER(8)
);

-- 2.1.10
ALTER TABLE EEP.TBL_EE_COMPARE_DATA_TEMP ADD (
    PRIOR_SUBR_ID                VARCHAR2(30)
);
