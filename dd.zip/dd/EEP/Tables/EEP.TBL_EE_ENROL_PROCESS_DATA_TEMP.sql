/*
  VERSION: 3.1.13

  Revision History

  SR/WO:       SR 05085.25.AR
  Date:        10/1/2005
  By:          Mark Stock
  Revision:    Added WAIT_PERIOD_FROM_DATE & WAIT_PERIOD_TO_DATE
               and column comments
  New Version: 3.1.2 

  Revision History

  SR/WO:       SR 06255.01.VA
  Date:        10/17/2006
  By:          Sudeep P
  Revision:    Added SUBMITTED_RECORD_NUMBER
  New Version: 3.1.3
---------------------------------------------------------
  Version      3.1.4                                                         
  SR/WO:       SR 05208.01.ALL
  Date:        10/25/06
  By:          Dinesh Makked
  Revision:    
  
---------------------------------------------------------
  Version      3.1.5                                                         
  SR/WO:       25193
  Date:        03/05/2007
  By:          Sudeep Prabhakaran
  Revision:    Added Index
  
---------------------------------------------------------
  Version      3.1.6                                                         
  SR/WO:       SR06284.03.VA
  Date:        03/23/2007
  By:          Jeff Reynolds
  Revision:    Added column DROPPED_SPLIT_RECORD_FLAG
  
---------------------------------------------------------
  Version      3.1.7
  SR/WO:       SR07178.02.KY
  Date:        02/19/2008
  By:          Jeff Reynolds
  Revision:    Added columns PRODUCER_ID, PRODUCER_EFF_DTE, and
               PRODUCER_TRM_DTE.

  SR/WO:       SR 08128.01.VA
  Date:        05/29/2008
  By:          Jeff Reynolds
  Revision:    Added new column NPI
  New Version: 3.1.8
  
-- Revision Number: 3.1.9
-- Change Control#: SR08059.01.AR
-- Revision By    : Jeff Reynolds
-- Revision Date  : 06/05/2008
-- Revision Desc  : Added payment_method_code, bank_account_type_code,
--                  bank_routing_number, bank_account_number,
--                  credit_card_type_code, credit_card_number,
--                  credit_card_expiration

-- Revision Number: 3.1.10
-- Change Control#: SR08092.27.CO - Retro Add/Term Date Validation
-- Revision By    : Deborah Yates
-- Revision Date  : 09/04/2008
-- Revision Desc  : Added some new columns

-- Revision Number: 3.1.11
-- Change Control#: SR08092.26.CO - Apply Late Entrant
-- Revision By    : Deborah Yates
-- Revision Date  : 09/18/2008
-- Revision Desc  : Added late_entrant_flag

-- Revision Number: 3.1.12
-- Change Control#: SR 08128.01.VA
-- Revision By    : Raj Chetlapalli
-- Revision Date  : 04/16/2009
-- Revision Desc  : Added new column COB Carrier ID

-- Revision Number: 3.1.13
-- Change Control#: SR 10083.05.VA
-- Revision By    : Raj Chetlapalli
-- Revision Date  : 04/08/2011
-- Revision Desc  : Added 5010 Extended Fields

---------------------------------------------------------

*/
 
--
-- TBL_EE_ENROL_PROCESS_DATA_TEMP  (Table) 
--
CREATE GLOBAL TEMPORARY TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP
(
  EE_RECORD_ID              NUMBER(15),
  EE_RECORD_STATUS          NUMBER(15),
  SUBR_ID                   VARCHAR2(9 BYTE),
  INDV_ID                   VARCHAR2(2 BYTE),
  GRP_ID                    VARCHAR2(9 BYTE),
  SUBLOC_ID                 VARCHAR2(8 BYTE),
  DIV_ID                    VARCHAR2(4 BYTE),
  PRD_CDE                   VARCHAR2(4 BYTE),
  PLN_CDE                   VARCHAR2(4 BYTE),
  RTE_CDE                   VARCHAR2(4 BYTE),
  DEP_ONLY_COVERAGE_FLAG    VARCHAR2(1 BYTE),
  COVER_EFF_DTE             VARCHAR2(8 BYTE),
  DERIVED_COVER_EFF_DTE     VARCHAR2(8 BYTE),
  COVER_TRM_DTE             VARCHAR2(8 BYTE),
  PRIOR_CARRIER_EFF_DTE     VARCHAR2(8 BYTE),
  HIRE_DTE                  VARCHAR2(8 BYTE),
  WORK_STS_CDE              VARCHAR2(2 BYTE),
  COBRA_ELIG_CDE            VARCHAR2(2 BYTE),
  COBRA_EFF_DTE             VARCHAR2(8 BYTE),
  QUALI_EVENT_CDE           VARCHAR2(2 BYTE),
  TRM_REASON_CDE            VARCHAR2(2 BYTE),
  TRM_COMMENT               VARCHAR2(200 BYTE),
  SSN                       VARCHAR2(12 BYTE),
  RELSHIP_CDE               VARCHAR2(2 BYTE),
  LNME                      VARCHAR2(30 BYTE),
  FNME                      VARCHAR2(30 BYTE),
  MNME                      VARCHAR2(30 BYTE),
  DOB                       VARCHAR2(8 BYTE),
  HANDICAP_CDE              VARCHAR2(2 BYTE),
  HANDICAP_EFF_DTE          VARCHAR2(8 BYTE),
  SEX_CDE                   VARCHAR2(2 BYTE),
  MARITAL_STS               VARCHAR2(2 BYTE),
  STUDENT_CDE               VARCHAR2(2 BYTE),
  ADDR1                     VARCHAR2(30 BYTE),
  ADDR2                     VARCHAR2(30 BYTE),
  ADDR3                     VARCHAR2(30 BYTE),
  CITY                      VARCHAR2(30 BYTE),
  STATE                     VARCHAR2(2 BYTE),
  ZIP                       VARCHAR2(5 BYTE),
  ZIP4                      VARCHAR2(4 BYTE),
  COUNTRY_CDE               VARCHAR2(4 BYTE),
  PHONE                     VARCHAR2(30 BYTE),
  PRV_ID                    VARCHAR2(11 BYTE),
  LOC                       VARCHAR2(4 BYTE),
  TAX_ID                    VARCHAR2(9 BYTE),
  SPOUSE_DENTAL_PLAN        VARCHAR2(1 BYTE),
  DEP_OTHER_DENTAL_PLAN     VARCHAR2(1 BYTE),
  COB_CARRIER_NME           VARCHAR2(60 BYTE),
  PRV_NME                   VARCHAR2(30 BYTE),
  CREATED_BY                VARCHAR2(30 BYTE),
  CREATION_DATE             DATE,
  LAST_UPDATED_BY           VARCHAR2(30 BYTE),
  LAST_UPDATE_DATE          DATE,
  RELIABILITY_FLAG          VARCHAR2(1 BYTE),
  RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8 BYTE),
  PRIOR_SUBR_ID             VARCHAR2(9 BYTE),
  MISC_INFO                 VARCHAR2(10 BYTE),
  COVER_EFF_DTE_ACTION_IND  NUMBER(1),
  COVER_TRM_DTE_ACTION_IND  NUMBER(1),
  WAIT_PERIOD_FROM_DATE     VARCHAR2(8),
  WAIT_PERIOD_TO_DATE       VARCHAR2(8)
)
ON COMMIT PRESERVE ROWS;

--
-- IDX1_EE_ENROL_PROCESS_DATA_TMP  (Index) 
--
CREATE INDEX EEP.IDX1_EE_ENROL_PROCESS_DATA_TMP ON EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP
(SUBR_ID);

--
-- IDX2_EE_ENROL_PROCESS_DATA_TMP  (Index) 
--
CREATE INDEX EEP.IDX2_EE_ENROL_PROCESS_DATA_TMP ON EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP
(EE_RECORD_ID);

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP TO EEP_USERS_ALL;

COMMENT ON COLUMN EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP.WAIT_PERIOD_FROM_DATE IS 'Optional Individual Wait Period Effective/Start Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/

COMMENT ON COLUMN EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP.WAIT_PERIOD_TO_DATE IS 'Optional Individual Wait Period Termination/End Date. Applied to all Benefit Classes configured for the feed source via the INDV_WAIT_PERIOD_BENEFIT_CLASS processing exception. Added for SR-05085.25.AR'
/

-- Added for SR#06255.01.VA
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD SUBMITTED_RECORD_NUMBER NUMBER;

-- SR#05208.01.ALL
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD GRP_SUBMITTED_SUBR_ID VARCHAR2(30);
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD GRP_SUBMITTED_SUBR_ID_TYPE NUMBER(4);
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP MODIFY SUBR_ID VARCHAR2(30); 
 
-- Added for WO#25193. 
CREATE INDEX IDX3_EE_ENROL_PROCESS_DATA_TMP ON TBL_EE_ENROL_PROCESS_DATA_TEMP
(GRP_SUBMITTED_SUBR_ID);

-- Added for SR06284.03.VA
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
   DROPPED_SPLIT_RECORD_FLAG     VARCHAR2(1)
);

-- Version 3.1.7
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
  PRODUCER_ID                   VARCHAR2(15), /* 3.1.7 */
  PRODUCER_EFF_DTE              VARCHAR2(8),  /* 3.1.7 */
  PRODUCER_TRM_DTE              VARCHAR2(8)   /* 3.1.7 */
);

-- Version 3.1.8
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
  NPI                           VARCHAR2(10)  /* 3.1.8 */
);
-- Version 3.1.9
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD
(
  PAYMENT_METHOD_CODE       VARCHAR2(2),        /* 3.1.9 */
  BANK_ACCOUNT_TYPE_CODE    VARCHAR2(2),        /* 3.1.9 */
  BANK_ROUTING_NUMBER       VARCHAR2(30),       /* 3.1.9 */
  BANK_ACCOUNT_NUMBER       VARCHAR2(30),       /* 3.1.9 */
  CREDIT_CARD_TYPE_CODE     VARCHAR2(2),        /* 3.1.9 */
  CREDIT_CARD_NUMBER        VARCHAR2(4),        /* 3.1.9 */
  CREDIT_CARD_EXPIRATION    VARCHAR2(6)         /* 3.1.9 */
);

-- 3.1.10
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
    SUBMITTED_COVER_TRM_DTE NUMBER(8),
    TRM_REASON_CODE         NUMBER(1)
);

-- 3.1.11
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
    LATE_ENTRANT_FLAG       VARCHAR2(1)
);

-- 3.1.12
ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD (
  COB_CARRIER_ID                           VARCHAR2(30)  /* 3.1.12 */
);

ALTER TABLE EEP.TBL_EE_ENROL_PROCESS_DATA_TEMP ADD
(
  SUBR_ID_EXTENDED       VARCHAR2(50),
  LNME_EXTENDED          VARCHAR2(60),
  FNME_EXTENDED          VARCHAR2(35),
  ADDR1_EXTENDED         VARCHAR2(55),
  ADDR2_EXTENDED         VARCHAR2(55), 
  PRV_NME_EXTENDED       VARCHAR2(60), 
  EMAIL_ADDR_EXTENDED    VARCHAR2(256)  
);
