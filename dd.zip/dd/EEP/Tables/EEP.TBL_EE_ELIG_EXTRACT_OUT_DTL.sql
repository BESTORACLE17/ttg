DROP TABLE EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL CASCADE CONSTRAINTS;

CREATE TABLE EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL
(
  SUBR_ID                        VARCHAR2(30 BYTE),
  GRP_ID                         VARCHAR2(9 BYTE),
  SUBLOC_ID                      VARCHAR2(8 BYTE),
  DIV_ID                         VARCHAR2(8 BYTE),
  PRD_CDE                        VARCHAR2(4 BYTE),
  PLN_CDE                        VARCHAR2(4 BYTE),
  RTE_CDE                        VARCHAR2(4 BYTE),
  COVER_EFF_DTE                  VARCHAR2(8 BYTE),
  COVER_TRM_DTE                  VARCHAR2(8 BYTE),
  HIRE_DTE                       VARCHAR2(8 BYTE),
  GRP_TRM_DTE                    VARCHAR2(8 BYTE),
  PRIOR_CARRIER_EFF_DTE          VARCHAR2(8 BYTE),
  COMPENSATION_CDE               VARCHAR2(2 BYTE),
  UNION_CDE                      VARCHAR2(2 BYTE),
  WORK_STS_CDE                   VARCHAR2(2 BYTE),
  COBRA_ELIG_CDE                 VARCHAR2(2 BYTE),
  COBRA_EFF_DTE                  VARCHAR2(8 BYTE),
  QUALI_EVENT_CDE                VARCHAR2(2 BYTE),
  TRM_REASON_CDE                 VARCHAR2(2 BYTE),
  PRIORITY_CDE                   VARCHAR2(2 BYTE),
  SSN                            VARCHAR2(12 BYTE),
  RELSHIP_CDE                    VARCHAR2(2 BYTE),
  LNME                           VARCHAR2(30 BYTE),
  FNME                           VARCHAR2(30 BYTE),
  MNME                           VARCHAR2(30 BYTE),
  DOB                            VARCHAR2(8 BYTE),
  HANDICAP_CDE                   VARCHAR2(2 BYTE),
  HANDICAP_EFF_DTE               VARCHAR2(8 BYTE),
  SEX_CDE                        VARCHAR2(2 BYTE),
  MARITAL_STS                    VARCHAR2(2 BYTE),
  STUDENT_CDE                    VARCHAR2(2 BYTE),
  ADDR1                          VARCHAR2(30 BYTE),
  ADDR2                          VARCHAR2(30 BYTE),
  ADDR3                          VARCHAR2(30 BYTE),
  CITY                           VARCHAR2(30 BYTE),
  STATE                          VARCHAR2(2 BYTE),
  ZIP                            VARCHAR2(5 BYTE),
  ZIP4                           VARCHAR2(4 BYTE),
  COUNTRY_CDE                    VARCHAR2(4 BYTE),
  PHONE                          VARCHAR2(30 BYTE),
  PRV_ID                         VARCHAR2(32 BYTE),
  LOC                            VARCHAR2(4 BYTE),
  TAX_ID                         VARCHAR2(9 BYTE),
  SPOUSE_DENTAL_PLAN             VARCHAR2(1 BYTE),
  DEP_OTHER_DENTAL_PLAN          VARCHAR2(1 BYTE),
  COB_CARRIER_NME                VARCHAR2(60 BYTE),
  PRV_NME                        VARCHAR2(30 BYTE),
  CREATED_BY                     VARCHAR2(30 BYTE) DEFAULT USER,
  CREATION_DATE                  DATE           DEFAULT SYSDATE,
  MISC1                          VARCHAR2(50 BYTE),
  MISC2                          VARCHAR2(50 BYTE),
  MISC3                          VARCHAR2(50 BYTE),
  MISC4                          VARCHAR2(50 BYTE),
  MISC5                          VARCHAR2(50 BYTE),
  RELIABILITY_FLAG               VARCHAR2(1 BYTE),
  RELIABILITY_FLAG_EFF_DTE       VARCHAR2(8 BYTE),
  PRIOR_SUBR_ID                  VARCHAR2(30 BYTE),
  MISC_INFO                      VARCHAR2(10 BYTE),
  WAIT_PERIOD_FROM_DATE          VARCHAR2(8 BYTE),
  WAIT_PERIOD_TO_DATE            VARCHAR2(8 BYTE),
  SUBMITTED_RECORD_NUMBER        NUMBER,
  PRODUCER_ID                    VARCHAR2(15 BYTE),
  PRODUCER_EFF_DTE               VARCHAR2(8 BYTE),
  PRODUCER_TRM_DTE               VARCHAR2(8 BYTE),
  PAYMENT_METHOD_CODE            VARCHAR2(2 BYTE),
  BANK_ACCOUNT_TYPE_CODE         VARCHAR2(2 BYTE),
  BANK_ROUTING_NUMBER            VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER            VARCHAR2(30 BYTE),
  CREDIT_CARD_TYPE_CODE          VARCHAR2(2 BYTE),
  CREDIT_CARD_NUMBER             VARCHAR2(30 BYTE),
  CREDIT_CARD_EXPIRATION         VARCHAR2(6 BYTE),
  LATE_ENTRANT_FLAG              VARCHAR2(1 BYTE),
  NPI                            VARCHAR2(10 BYTE),
  COB_CARRIER_ID                 VARCHAR2(30 BYTE),
  EMAIL_ADDR                     VARCHAR2(60 BYTE),
  FAX                            VARCHAR2(30 BYTE),
  APPLY_WAIVE_FLAG               VARCHAR2(1 BYTE),
  EMAIL_OPT_OUT_FLAG             VARCHAR2(1 BYTE),
  VALID_EMAIL_FLAG               VARCHAR2(1 BYTE),
  PRIOR_CARRIER_NME              VARCHAR2(100 BYTE),
  PRIOR_CARRIER_ID               VARCHAR2(30 BYTE),
  PARENT_ID                      NUMBER(4)      NOT NULL,
  PRODUCT_LINE_CODE              NUMBER(4),
  BANK_ACCOUNT_TYPE_CODE_CLAIMS  VARCHAR2(2 BYTE),
  BANK_ROUTING_NUMBER_CLAIMS     VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER_CLAIMS     VARCHAR2(30 BYTE),
  SUBR_ID_EXTENDED               VARCHAR2(50 BYTE),
  LNME_EXTENDED                  VARCHAR2(60 BYTE),
  FNME_EXTENDED                  VARCHAR2(35 BYTE),
  ADDR1_EXTENDED                 VARCHAR2(55 BYTE),
  ADDR2_EXTENDED                 VARCHAR2(55 BYTE),
  PRV_NME_EXTENDED               VARCHAR2(60 BYTE),
  EMAIL_ADDR_EXTENDED            VARCHAR2(256 BYTE),
  DCS_ASSIGNED_ID                VARCHAR2(30 BYTE),
  BALANCE_DUE_AMT                NUMBER,
  MASTER_GRP_ID                  VARCHAR2(30 BYTE),
  MASTER_SUBLOC_ID               VARCHAR2(30 BYTE),
  MASTER_DIV_ID                  VARCHAR2(30 BYTE),
  ORIGINAL_COVER_EFF_DTE         VARCHAR2(8 BYTE),
  MAINT_RSN_CDE                  VARCHAR2(2 BYTE),
  MAINT_TYP_CDE                  VARCHAR2(3 BYTE),
  EXHG_SUBR_ID                   VARCHAR2(60 BYTE),
  EXHG_DPND_ID                   VARCHAR2(60 BYTE),
  EXHG_PYMT_REF                  VARCHAR2(60 BYTE),
  EXHG_PHONE2                    VARCHAR2(30 BYTE),
  EXHG_TXT_FLAG                  VARCHAR2(2 BYTE),
  EXHG_TXT_ADDR                  VARCHAR2(256 BYTE),
  EXHG_QHP_ID                    VARCHAR2(60 BYTE),
  EXHG_GRP_ID                    VARCHAR2(60 BYTE),
  EXHG_POLY_ID                   VARCHAR2(60 BYTE),
  EXHG_MAINT_RSN                 VARCHAR2(10 BYTE),
  EXHG_MAINT_RSN_DTE             VARCHAR2(20 BYTE),
  EXHG_RTNG_ARA                  VARCHAR2(30 BYTE),
  EXHG_RTNG_ARA_DTE              VARCHAR2(20 BYTE),
  EXHG_APTC_AMT                  NUMBER(10,2),
  EXHG_APTC_AMT_DTE              VARCHAR2(20 BYTE),
  EXHG_CSR_AMT                   NUMBER(10,2),
  EXHG_CSR_AMT_DTE               VARCHAR2(20 BYTE),
  EXHG_PRE_AMT1                  NUMBER(10,2),
  EXHG_PRE_AMT1_DTE              VARCHAR2(20 BYTE),
  EXHG_PRE_AMT_TOT               NUMBER(10,2),
  EXHG_PRE_AMT_TOT_DTE           VARCHAR2(20 BYTE),
  EXHG_TOT_RES_AMT               NUMBER(10,2),
  EXHG_TOT_RES_AMT_DTE           VARCHAR2(20 BYTE),
  EXHG_TOT_RES_EMP_AMT           NUMBER(10,2),
  EXHG_TOT_RES_AMP_AMT_DTE       VARCHAR2(20 BYTE),
  EXHG_CMS_SBE                   VARCHAR2(30 BYTE),
  EXHG_CMS_SBE_DTE               VARCHAR2(20 BYTE),
  EXHG_ENROLL_DATE               VARCHAR2(8 BYTE),
  EXHG_TOBACCO_USE_FLAG          VARCHAR2(1 BYTE),
  EXHG_BROKER_NAME               VARCHAR2(60 BYTE),
  EXHG_BROKER_TIN                VARCHAR2(10 BYTE),
  EXHG_BROKER_LICENSE            VARCHAR2(20 BYTE),
  RELSHIP_CDE_EDI               VARCHAR2(2 BYTE),
  BENEFIT_CDE               VARCHAR2(2 BYTE),
  EMP_STS_CDE               VARCHAR2(2 BYTE),
  PMNT_REF_NUM              VARCHAR2(60 BYTE),
  PER_QUAL_01                VARCHAR2(2 BYTE),
  PER_NUMB_01                VARCHAR2(60 BYTE),
  PER_QUAL_02                VARCHAR2(2 BYTE),
  PER_NUMB_02                VARCHAR2(256 BYTE),
  PER_QUAL_03                VARCHAR2(2 BYTE),
  PER_NUMB_03                VARCHAR2(256 BYTE),
  SUBR_COUNTY                VARCHAR2(10 BYTE),
  SUBR_MARITAL                VARCHAR2(1 BYTE),
  SUBR_RACE                  VARCHAR2(1 BYTE),
  LANG_IND1                    VARCHAR2(1 BYTE),
  LANGUAGE1                    VARCHAR2(80 BYTE),
  LANG_IND2                    VARCHAR2(1 BYTE),
  LANGUAGE2                    VARCHAR2(80 BYTE),    
  MEM_ALT_ADDR1            VARCHAR2(55 BYTE),
  MEM_ALT_ADDR2            VARCHAR2(55 BYTE),
  MEM_ALT_ADDR3            VARCHAR2(55 BYTE),
  MEM_ALT_CITY1            VARCHAR2(30 BYTE),
  MEM_ALT_STAT1            VARCHAR2(2 BYTE),
  MEM_ALT_ZIP1             VARCHAR2(15 BYTE),
  MEM_ALT_ZIP4             VARCHAR2(4 BYTE),
  MEM_ALT_CTRY1            VARCHAR2(4 BYTE),
  MEM_ALT_CNTY1            VARCHAR2(5 BYTE),
  MEM_RSP_ADDR1            VARCHAR2(55 BYTE),
  MEM_RSP_ADDR2            VARCHAR2(55 BYTE),
  MEM_RSP_ADDR3            VARCHAR2(55 BYTE),
  MEM_RSP_CITY1            VARCHAR2(30 BYTE),
  MEM_RSP_STAT1            VARCHAR2(2 BYTE),
  MEM_RSP_ZIP1             VARCHAR2(15 BYTE),
  MEM_RSP_ZIP4             VARCHAR2(4 BYTE),
  MEM_RSP_CTRY1            VARCHAR2(4 BYTE),
  MEM_RSP_CNTY1            VARCHAR2(5 BYTE),
  LATE_ENROLL_FLG           VARCHAR2(1 BYTE),
  PROV_LAST_NME               VARCHAR2(60 BYTE),
  PROV_FIRST_NME           VARCHAR2(60 BYTE),
  BROKER_NAME              VARCHAR2(60 BYTE),
  BROKER_TIN               VARCHAR2(10 BYTE),
  BROKER_ACT               VARCHAR2(35 BYTE),    
  ENROLL_DATE              VARCHAR2(8 BYTE),
  TOBBACO_USE              VARCHAR2(1 BYTE),
  EXHG_PLAN_ID             VARCHAR2(16 BYTE)  
)
TABLESPACE EEP_DATA
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


CREATE OR REPLACE TRIGGER EEP."TRG_EE_ELIG_EXTRCT_OUT_DTL_PID" 
BEFORE UPDATE
    OR INSERT
    ON "EEP"."TBL_EE_ELIG_EXTRACT_OUT_DTL"
FOR EACH ROW
/* =============================================================================
|| Version      : 2.1.0
|| HD/SR Number : SR09065.02.VA
|| Modified By  : Stephen Ince
|| Modified On  : 02/10/20110
|| Description  : Creation.
|| =============================================================================
*/
DECLARE
    l_parent_id      NUMBER := sys_context('CNT_PARENT_ID','PARENT_ID');
BEGIN
   :new.parent_id    := l_parent_id;
END;
/


GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO DCS2000 WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO DCSREPORTS;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO DCS_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO EEP_USERS_ALL;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO REPORTUSER1;

GRANT DELETE, INSERT, SELECT, UPDATE ON EEP.TBL_EE_ELIG_EXTRACT_OUT_DTL TO SECURITY;
