CREATE TABLE EEP.TBL_EE_RAW_GENWORTH (
   load_seq                         NUMBER,
   record_type                      VARCHAR2(1),
   subr_id                          VARCHAR2(30),
   ssn                              VARCHAR2(9),
   dependent_number                 VARCHAR2(2),
   dependent_ssn                    VARCHAR2(9),
   prior_ssn                        VARCHAR2(9),
   relationship_code                VARCHAR2(2),
   first_name                       VARCHAR2(15),
   middle_initial                   VARCHAR2(1),
   last_name                        VARCHAR2(30),
   birth_date                       VARCHAR2(8),
   hire_date                        VARCHAR2(8),
   gender_code                      VARCHAR2(1),
   marital_code                     VARCHAR2(1),
   mailing_address_line_1           VARCHAR2(30),
   mailing_address_line_2           VARCHAR2(30),
   mailing_address_line_3           VARCHAR2(30),
   mailing_city                     VARCHAR2(16),
   mailing_state_code               VARCHAR2(2),
   mailing_zip                      VARCHAR2(10),
   country_code                     VARCHAR2(3),
   telephone_number                 VARCHAR2(10),
   participant_type                 VARCHAR2(2),
   reporting_field_2                VARCHAR2(15),
   reporting_field_5                VARCHAR2(15),
   disabled_flag                    VARCHAR2(1),
   overage_elig_flag                VARCHAR2(1),
   cob_indicator                    VARCHAR2(1),
   option_code                      VARCHAR2(6),
   coverage_tier                    VARCHAR2(2),
   coverage_type                    VARCHAR2(2),
   coverage_begin_date              VARCHAR2(8),
   coverage_end_date                VARCHAR2(8),
   coverage_effective_date          VARCHAR2(8),
   cobra_qualifying_code            VARCHAR2(2),
   cobra_qualifying_eff_date        VARCHAR2(8),
   created_by                       VARCHAR2(30),
   created_date                     DATE
) TABLESPACE EEP_DATA
/
CREATE INDEX IDX_EE_RAW_GENWORTH_LOAD_SEQ
    ON EEP.TBL_EE_RAW_GENWORTH (load_seq)
TABLESPACE EEP_INDEX
/
GRANT SELECT, INSERT, UPDATE ON EEP.TBL_EE_RAW_GENWORTH TO EEP_USERS_ALL
/
