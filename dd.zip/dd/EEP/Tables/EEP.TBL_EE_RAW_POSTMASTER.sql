/* VERSION: 3.1.1 */ 
--
-- TBL_EE_RAW_POSTMASTER  (Table) 
--
CREATE TABLE EEP.TBL_EE_RAW_POSTMASTER
(
  SUBR_ID                   VARCHAR2(9 BYTE),
  GRP_ID                    VARCHAR2(9 BYTE),
  SUBLOC_ID                 VARCHAR2(8 BYTE),
  DIV_ID                    VARCHAR2(8 BYTE),
  PRD_CDE                   VARCHAR2(4 BYTE),
  PLN_CDE                   VARCHAR2(4 BYTE),
  RTE_CDE                   VARCHAR2(4 BYTE),
  COVER_EFF_DTE             VARCHAR2(8 BYTE),
  COVER_TRM_DTE             VARCHAR2(8 BYTE),
  HIRE_DTE                  VARCHAR2(8 BYTE),
  GRP_TRM_DTE               VARCHAR2(8 BYTE),
  PRIOR_CARRIER_EFF_DTE     VARCHAR2(8 BYTE),
  COMPENSATION_CDE          VARCHAR2(2 BYTE),
  UNION_CDE                 VARCHAR2(2 BYTE),
  WORK_STS_CDE              VARCHAR2(2 BYTE),
  COBRA_ELIG_CDE            VARCHAR2(2 BYTE),
  COBRA_EFF_DTE             VARCHAR2(8 BYTE),
  QUALI_EVENT_CDE           VARCHAR2(2 BYTE),
  TRM_REASON_CDE            VARCHAR2(2 BYTE),
  PRIORITY_CDE              VARCHAR2(2 BYTE),
  SSN                       VARCHAR2(12 BYTE),
  RELSHIP_CDE               VARCHAR2(2 BYTE),
  LNME                      VARCHAR2(30 BYTE),
  FNME                      VARCHAR2(30 BYTE),
  MNME                      VARCHAR2(30 BYTE),
  DOB                       VARCHAR2(8 BYTE),
  HANDICAP_CDE              VARCHAR2(2 BYTE),
  HANDICAP_EFF_DTE          VARCHAR2(8 BYTE),
  SEX_CDE                   VARCHAR2(2 BYTE),
  MARITAL_STS               VARCHAR2(2 BYTE),
  STUDENT_CDE               VARCHAR2(2 BYTE),
  ADDR1                     VARCHAR2(30 BYTE),
  ADDR2                     VARCHAR2(30 BYTE),
  ADDR3                     VARCHAR2(30 BYTE),
  CITY                      VARCHAR2(30 BYTE),
  STATE                     VARCHAR2(2 BYTE),
  ZIP                       VARCHAR2(5 BYTE),
  ZIP4                      VARCHAR2(4 BYTE),
  COUNTRY_CDE               VARCHAR2(4 BYTE),
  PHONE                     VARCHAR2(30 BYTE),
  PRV_ID                    VARCHAR2(11 BYTE),
  LOC                       VARCHAR2(4 BYTE),
  TAX_ID                    VARCHAR2(9 BYTE),
  SPOUSE_DENTAL_PLAN        VARCHAR2(1 BYTE),
  DEP_OTHER_DENTAL_PLAN     VARCHAR2(1 BYTE),
  COB_CARRIER_NME           VARCHAR2(60 BYTE),
  PRV_NME                   VARCHAR2(30 BYTE),
  CREATED_BY                VARCHAR2(30 BYTE)   DEFAULT USER,
  CREATION_DATE             DATE                DEFAULT SYSDATE,
  MISC1                     VARCHAR2(50 BYTE),
  MISC2                     VARCHAR2(50 BYTE),
  MISC3                     VARCHAR2(50 BYTE),
  MISC4                     VARCHAR2(50 BYTE),
  MISC5                     VARCHAR2(50 BYTE),
  RELIABILITY_FLAG          VARCHAR2(1 BYTE),
  RELIABILITY_FLAG_EFF_DTE  VARCHAR2(8 BYTE),
  PRIOR_SUBR_ID             VARCHAR2(9 BYTE),
  MISC_INFO                 VARCHAR2(10 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  EEP.TBL_EE_RAW_POSTMASTER TO EEP_USERS_ALL;

-- sr07121.01.all
ALTER TABLE	EEP.TBL_EE_RAW_POSTMASTER	MODIFY (PRV_ID  VARCHAR2(32) ); 