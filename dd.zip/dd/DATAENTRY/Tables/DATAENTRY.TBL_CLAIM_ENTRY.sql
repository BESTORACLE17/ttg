/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR# 07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 07/02/2008.
|| Revision Desc  : Added Ortho payments column for data entry
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_CLAIM_ENTRY  (Table) 
--
CREATE TABLE DATAENTRY.TBL_CLAIM_ENTRY
(
  JULIAN_DATE        NUMBER(5)                  NOT NULL,
  BATCH_NUMBER       NUMBER(4)                  NOT NULL,
  CLAIM_NUMBER       NUMBER(5)                  NOT NULL,
  PATIENT_FNAME      VARCHAR2(10 BYTE),
  SEX                VARCHAR2(1 BYTE),
  BIRTH_DATE         DATE,
  SUBSCRIBER_FNAME   VARCHAR2(10 BYTE),
  SUBSCRIBER_LNAME   VARCHAR2(15 BYTE),
  SUBSCRIBER_ID      VARCHAR2(9 BYTE),
  RELATIONSHIP_CODE  NUMBER(2),
  ADDRESS            VARCHAR2(25 BYTE),
  CITY               VARCHAR2(17 BYTE),
  STATE              VARCHAR2(2 BYTE),
  ZIP                VARCHAR2(5 BYTE),
  OTHER_COVERAGES    NUMBER(1),
  ACCIDENT           NUMBER(1),
  XRAY               NUMBER(1),
  DOCTOR_SIGNATURE   NUMBER(1),
  AOB                VARCHAR2(1 BYTE),
  RESUBMIT           NUMBER(1),
  PROVIDER_STATE     VARCHAR2(2 BYTE),
  PROVIDER_TIN       VARCHAR2(9 BYTE),
  PROVIDER_LOC_CODE  VARCHAR2(4 BYTE),
  PROVIDER_NUMBER    VARCHAR2(9 BYTE),
  PROVIDER_NAME      VARCHAR2(5 BYTE),
  PROVIDER_TYPE      NUMBER(2)                  DEFAULT 0,
  MAINT_CODE         NUMBER(2)                  DEFAULT 0,
  MOD_DTE            DATE,
  MOD_OP             VARCHAR2(12 BYTE),
  PROVIDER_ADDR1     VARCHAR2(30 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_TBL_CLAIM_ENTRY  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_TBL_CLAIM_ENTRY ON DATAENTRY.TBL_CLAIM_ENTRY
(JULIAN_DATE, CLAIM_NUMBER)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_CLAIM_ENTRY  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_CLAIM_ENTRY FOR DATAENTRY.TBL_CLAIM_ENTRY;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_CLAIM_ENTRY TO DCS_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_CLAIM_ENTRY TO DCS2000 WITH GRANT OPTION;

-- 
-- Non Foreign Key Constraints for Table TBL_CLAIM_ENTRY 
-- 
ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY ADD (
  CONSTRAINT CHK_CLAIMS_SEX CHECK (SEX IN ('M', 'F', 'U') ));

ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY ADD (
  CONSTRAINT PK_TBL_CLAIM_ENTRY PRIMARY KEY (JULIAN_DATE, CLAIM_NUMBER)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_CLAIM_ENTRY 
-- 
ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY ADD (
  CONSTRAINT FK_CLAIM_ENTRY_TO_CLAIM_CTL FOREIGN KEY (JULIAN_DATE, CLAIM_NUMBER) 
    REFERENCES DATAENTRY.TBL_CLAIM_CONTROL_PANEL (JULIAN_DATE,CLAIM_NUMBER));

-- Added with SR# 05208.01.ALL
ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY MODIFY SUBSCRIBER_ID VARCHAR2(30);

-- Added with SR 06214.01.ALL - NPI
alter table DATAENTRY.TBL_CLAIM_ENTRY ADD
 RENDERING_PROVIDER_NPI   number(10);

alter table DATAENTRY.TBL_CLAIM_ENTRY ADD
 BILLING_PROVIDER_NPI     number(10);

-- Added with SR 07121.01.ALL - 12 Digit License Number
ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY MODIFY (PROVIDER_NUMBER VARCHAR2(30) );

-- Version 3.1.3 (SR07250.01.VA)
ALTER TABLE DATAENTRY.TBL_CLAIM_ENTRY ADD (
   ortho_payments           NUMBER(3)
);
-- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DATAENTRY.TBL_CLAIM_ENTRY modify 
  (PROVIDER_ADDR1    VARCHAR2(64 )
  );