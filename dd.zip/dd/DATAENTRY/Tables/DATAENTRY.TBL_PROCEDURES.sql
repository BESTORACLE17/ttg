/* VERSION: 3.1.1 */ 
--
-- TBL_PROCEDURES  (Table) 
--
CREATE TABLE DATAENTRY.TBL_PROCEDURES
(
  JULIAN_DATE     NUMBER(5)                     NOT NULL,
  BATCH_NUMBER    NUMBER(4)                     NOT NULL,
  CLAIM_NUMBER    NUMBER(5)                     NOT NULL,
  ITEM_NUMBER     NUMBER(4)                     NOT NULL,
  TOOTH           VARCHAR2(2 BYTE),
  SURFACE         VARCHAR2(5 BYTE),
  TREATMENT_DATE  DATE,
  PROCEDURE_CODE  VARCHAR2(5 BYTE),
  SUBMIT          NUMBER(8,2),
  DLM             VARCHAR2(1 BYTE),
  PCD             VARCHAR2(4 BYTE),
  MAINT_CODE      NUMBER(2)                     DEFAULT 0,
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_TBL_PROCEDURS  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_TBL_PROCEDURS ON DATAENTRY.TBL_PROCEDURES
(JULIAN_DATE, CLAIM_NUMBER, ITEM_NUMBER)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_PROCEDURES  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_PROCEDURES FOR DATAENTRY.TBL_PROCEDURES;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_PROCEDURES TO DCS_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_PROCEDURES 
-- 
ALTER TABLE DATAENTRY.TBL_PROCEDURES ADD (
  CONSTRAINT PK_TBL_PROCEDURS PRIMARY KEY (JULIAN_DATE, CLAIM_NUMBER, ITEM_NUMBER)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_PROCEDURES 
-- 
ALTER TABLE DATAENTRY.TBL_PROCEDURES ADD (
  CONSTRAINT FK_PROCEDURES_TO_CLAIM_ENTRY FOREIGN KEY (JULIAN_DATE, CLAIM_NUMBER) 
    REFERENCES DATAENTRY.TBL_CLAIM_ENTRY (JULIAN_DATE,CLAIM_NUMBER));


