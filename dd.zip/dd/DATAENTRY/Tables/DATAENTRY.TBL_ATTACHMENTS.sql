/* VERSION: 3.1.1 */ 
--
-- TBL_ATTACHMENTS  (Table) 
--
CREATE TABLE DATAENTRY.TBL_ATTACHMENTS
(
  JULIAN_DATE             NUMBER(5)             NOT NULL,
  BATCH_NUMBER            NUMBER(4)             NOT NULL,
  CLAIM_NUMBER            NUMBER(5)             NOT NULL,
  ATTACH_TO_CLAIM_NUMBER  NUMBER(5)             DEFAULT 0,
  FORM_NUMBER             VARCHAR2(4 BYTE),
  XREF_NUMBER             VARCHAR2(13 BYTE),
  XRAY                    NUMBER(1),
  MAINT_CODE              NUMBER(2)             DEFAULT 0,
  MOD_DTE                 DATE,
  MOD_OP                  VARCHAR2(12 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_ATTACHMENTS TO DCS_USERS_ALL;

--
-- PK_ATTACHMENTS  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_ATTACHMENTS ON DATAENTRY.TBL_ATTACHMENTS
(JULIAN_DATE, CLAIM_NUMBER)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_ATTACHMENTS  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_ATTACHMENTS FOR DATAENTRY.TBL_ATTACHMENTS;

-- 
-- Non Foreign Key Constraints for Table TBL_ATTACHMENTS 
-- 
ALTER TABLE DATAENTRY.TBL_ATTACHMENTS ADD (
  CONSTRAINT PK_ATTACHMENTS PRIMARY KEY (JULIAN_DATE, CLAIM_NUMBER)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_ATTACHMENTS 
-- 
ALTER TABLE DATAENTRY.TBL_ATTACHMENTS ADD (
  CONSTRAINT FK_ATTACHMENTS_TO_CLAIM_CTL FOREIGN KEY (JULIAN_DATE, CLAIM_NUMBER) 
    REFERENCES DATAENTRY.TBL_CLAIM_CONTROL_PANEL (JULIAN_DATE,CLAIM_NUMBER));


