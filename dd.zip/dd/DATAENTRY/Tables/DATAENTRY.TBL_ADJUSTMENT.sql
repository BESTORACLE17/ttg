/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR# VA.08242.01 - Faxed Claim Viewer
|| Revision By    : Eric Greene
|| Revision Date  : 10/30/2009
|| Revision Desc  : Added claim letter
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+*/
--
-- TBL_ADJUSTMENT  (Table) 
--
CREATE TABLE DATAENTRY.TBL_ADJUSTMENT
(
  JULIAN_DATE            NUMBER(5)              NOT NULL,
  BATCH_NUMBER           NUMBER(4)              NOT NULL,
  CLAIM_NUMBER           NUMBER(5)              NOT NULL,
  ORIGINAL_CLAIM_NUMBER  VARCHAR2(13 BYTE),
  SUBSCRIBER_ID          VARCHAR2(9 BYTE),
  SUFFIX                 VARCHAR2(2 BYTE),
  ADJUSTMENT_TYPE        NUMBER(2),
  MAINT_CODE             NUMBER(2)              DEFAULT 0,
  MOD_DTE                DATE,
  MOD_OP                 VARCHAR2(12 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_ADJUSTMENT TO DCS_USERS_ALL;

--
-- PK_ADJUSTMENT  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_ADJUSTMENT ON DATAENTRY.TBL_ADJUSTMENT
(JULIAN_DATE, CLAIM_NUMBER, CLAIM_LETTER)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_ADJUSTMENT  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_ADJUSTMENT FOR DATAENTRY.TBL_ADJUSTMENT;

-- 
-- Non Foreign Key Constraints for Table TBL_ADJUSTMENT 
-- 
ALTER TABLE DATAENTRY.TBL_ADJUSTMENT ADD (
  CONSTRAINT PK_ADJUSTMENT PRIMARY KEY (JULIAN_DATE, CLAIM_NUMBER, CLAIM_LETTER)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_ADJUSTMENT 
-- 
ALTER TABLE DATAENTRY.TBL_ADJUSTMENT ADD (
  CONSTRAINT FK_ADJUSTMENT_TO_CLAIM_CTL FOREIGN KEY (JULIAN_DATE, CLAIM_NUMBER, CLAIM_LETTER) 
    REFERENCES DATAENTRY.TBL_CLAIM_CONTROL_PANEL (JULIAN_DATE,CLAIM_NUMBER, CLAIM_LETTER));

-- Added with SR# 05208.01.ALL
ALTER TABLE DATAENTRY.TBL_ADJUSTMENT MODIFY SUBSCRIBER_ID VARCHAR2(30);
