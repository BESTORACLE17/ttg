/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  : Enhancement
|| Change Control#:  
|| Service Request: SR#05068.01.VA
|| Revision By    : Dinesh Makked
|| Revision Date  : 04/28/2005
|| Revision Desc  : Addded column PARENT_ID.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
||
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.3
|| Revision Type  : Enhancement
|| Change Control#:  
|| Service Request: SR#05085.09.AR
|| Revision By    : Matt WEst
|| Revision Date  : 07/25/2005
|| Revision Desc  : Addded column DOCUMENT_MEDIUM_CODE.
|| Production Date:
|| Production By  :
|| Dependencies   : TBL_CODE_DOCUMENT_MEDIUM
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

CREATE TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL
(
  JULIAN_DATE      NUMBER(5)                    NOT NULL,
  BATCH_NUMBER     NUMBER(4)                    NOT NULL,
  RANGE_FROM       NUMBER(5),
  RANGE_TO         NUMBER(5),
  CLAIM_TYPE_CODE  NUMBER(2),
  MAINT_CODE       NUMBER                       DEFAULT 0,
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_TBL_BATCH_CONTROL_PANEL  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_TBL_BATCH_CONTROL_PANEL ON DATAENTRY.TBL_BATCH_CONTROL_PANEL
(JULIAN_DATE, BATCH_NUMBER)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_BATCH_CONTROL_PANEL  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_BATCH_CONTROL_PANEL FOR DATAENTRY.TBL_BATCH_CONTROL_PANEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_BATCH_CONTROL_PANEL TO DCS_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_BATCH_CONTROL_PANEL 
-- 
ALTER TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL ADD (
  CONSTRAINT PK_TBL_BATCH_CONTROL_PANEL PRIMARY KEY (JULIAN_DATE, BATCH_NUMBER)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));



--
-- SR#05068.01.VA
-- 
ALTER TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL
   ADD PARENT_ID NUMBER(4);
                
ALTER TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL ADD 
  CONSTRAINT FK1_BATCH_CONTROL_PANEL FOREIGN KEY ( PARENT_ID )
    REFERENCES DCS2000.TBL_PARENT_COMPANY (PARENT_ID );                
    

--
-- SR#05085.09.AR
-- 
ALTER TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL
   ADD DOCUMENT_MEDIUM_CODE NUMBER(2);
                
ALTER TABLE DATAENTRY.TBL_BATCH_CONTROL_PANEL ADD 
  CONSTRAINT FK2_BATCH_CONTROL_PANEL FOREIGN KEY ( DOCUMENT_MEDIUM_CODE )
    REFERENCES DCS2000.TBL_CODE_DOCUMENT_MEDIUM (CODE );                

-- Update the NULL Document_Medium_Code fields to 1 (paper)    
UPDATE TBL_BATCH_CONTROL_PANEL
SET DOCUMENT_MEDIUM_CODE = 1
WHERE DOCUMENT_MEDIUM_CODE IS NULL;
