/* VERSION: 2.1.2 */ 
--
-- TBL_CODE_DE_CLAIM_TYPE  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05068.01.VA Add Company ID in W9 Record 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/08/2005 
|| Revision Desc  : Dropped ALLOW_NPF_LOOKUP column 
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/ 
CREATE TABLE DATAENTRY.TBL_CODE_DE_CLAIM_TYPE
(
  CODE              NUMBER(2)                   NOT NULL,
  DESCRIPTION       VARCHAR2(50 BYTE),
  ATTACHMENT        NUMBER(1)                   DEFAULT 0,
  XRAY              NUMBER(1)                   DEFAULT 0,
  LAUNCH_FORM       NUMBER(2)                   DEFAULT 0,
  MAINT_CODE        NUMBER(2)                   DEFAULT 0,
  MOD_DTE           DATE,
  MOD_OP            VARCHAR2(12 BYTE),
  ALLOW_NPF_LOOKUP  NUMBER(1)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_TBL_CODE_DE_CLAIM_TYPE  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_TBL_CODE_DE_CLAIM_TYPE ON DATAENTRY.TBL_CODE_DE_CLAIM_TYPE
(CODE)
LOGGING
TABLESPACE RAW_DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_CODE_DE_CLAIM_TYPE  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_CODE_DE_CLAIM_TYPE FOR DATAENTRY.TBL_CODE_DE_CLAIM_TYPE;

GRANT SELECT ON  DATAENTRY.TBL_CODE_DE_CLAIM_TYPE TO DCS_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_DE_CLAIM_TYPE 
-- 
ALTER TABLE DATAENTRY.TBL_CODE_DE_CLAIM_TYPE ADD (
  CONSTRAINT PK_TBL_CODE_DE_CLAIM_TYPE PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE RAW_DATA
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));

-- 
-- S/R #05068.01.VA Add Company ID in W9 Record 
-- 
ALTER TABLE DATAENTRY.TBL_CODE_DE_CLAIM_TYPE DROP COLUMN ALLOW_NPF_LOOKUP;
