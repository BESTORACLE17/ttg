/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TEMP_CLAIM_ENTRY  (Table) 
--
CREATE TABLE DATAENTRY.TEMP_CLAIM_ENTRY
(
  JULIAN_DATE        NUMBER(5)                  NOT NULL,
  BATCH_NUMBER       NUMBER(4)                  NOT NULL,
  CLAIM_NUMBER       NUMBER(5)                  NOT NULL,
  PATIENT_FNAME      VARCHAR2(10 BYTE),
  SEX                VARCHAR2(1 BYTE),
  BIRTH_DATE         DATE,
  SUBSCRIBER_FNAME   VARCHAR2(10 BYTE),
  SUBSCRIBER_LNAME   VARCHAR2(15 BYTE),
  SUBSCRIBER_ID      VARCHAR2(9 BYTE),
  RELATIONSHIP_CODE  NUMBER(2),
  ADDRESS            VARCHAR2(25 BYTE),
  CITY               VARCHAR2(17 BYTE),
  STATE              VARCHAR2(2 BYTE),
  ZIP                VARCHAR2(5 BYTE),
  OTHER_COVERAGES    NUMBER(1),
  ACCIDENT           NUMBER(1),
  XRAY               NUMBER(1),
  DOCTOR_SIGNATURE   NUMBER(1),
  AOB                NUMBER(1),
  RESUBMIT           NUMBER(1),
  PROVIDER_STATE     VARCHAR2(2 BYTE),
  PROVIDER_TIN       VARCHAR2(9 BYTE),
  PROVIDER_LOC_CODE  VARCHAR2(4 BYTE),
  PROVIDER_NUMBER    VARCHAR2(9 BYTE),
  PROVIDER_NAME      VARCHAR2(5 BYTE),
  PROVIDER_TYPE      NUMBER(2),
  MAINT_CODE         NUMBER(2),
  MOD_DTE            DATE,
  MOD_OP             VARCHAR2(12 BYTE),
  PROVIDER_ADDR1     VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DATAENTRY.TEMP_CLAIM_ENTRY MODIFY SUBSCRIBER_ID VARCHAR2(30);
