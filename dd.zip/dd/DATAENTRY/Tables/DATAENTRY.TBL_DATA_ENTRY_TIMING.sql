/* VERSION: 3.1.1 */ 
--
-- TBL_DATA_ENTRY_TIMING  (Table) 
--
CREATE TABLE DATAENTRY.TBL_DATA_ENTRY_TIMING
(
  USER_ID          VARCHAR2(12 BYTE)            NOT NULL,
  JULIAN_DATE      NUMBER(5)                    NOT NULL,
  BATCH_NUMBER     NUMBER(4)                    NOT NULL,
  CLAIMS_ENTERED   NUMBER(5),
  WORKED_DATE      DATE,
  BEG_TIME         DATE                         NOT NULL,
  END_TIME         DATE,
  MAINT_CODE       NUMBER(2),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  CLAIM_TYPE_CODE  NUMBER(2)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_DATA_ENTRY_TIMING  (Index) 
--
CREATE UNIQUE INDEX DATAENTRY.PK_DATA_ENTRY_TIMING ON DATAENTRY.TBL_DATA_ENTRY_TIMING
(USER_ID, JULIAN_DATE, BATCH_NUMBER, BEG_TIME)
LOGGING
TABLESPACE SYSTEM
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             3784K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      50
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- TBL_DATA_ENTRY_TIMING  (Synonym) 
--
CREATE SYNONYM DCS2000.TBL_DATA_ENTRY_TIMING FOR DATAENTRY.TBL_DATA_ENTRY_TIMING;

GRANT INSERT, SELECT, UPDATE ON  DATAENTRY.TBL_DATA_ENTRY_TIMING TO DCS_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_DATA_ENTRY_TIMING 
-- 
ALTER TABLE DATAENTRY.TBL_DATA_ENTRY_TIMING ADD (
  CONSTRAINT PK_DATA_ENTRY_TIMING PRIMARY KEY (USER_ID, JULIAN_DATE, BATCH_NUMBER, BEG_TIME)
    USING INDEX 
    TABLESPACE SYSTEM
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          16K
                NEXT             3784K
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      50
                FREELISTS        1
                FREELIST GROUPS  1
               ));


