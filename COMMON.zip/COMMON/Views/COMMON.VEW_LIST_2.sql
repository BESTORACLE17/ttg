CREATE OR REPLACE VIEW /*VERSION: 2.1.1*/ COMMON.Vew_List_2 AS
SELECT TRIM(SUBSTR(list_str, instr(list_str,'~',1,LEVEL) + 1,
                             instr(list_str,'~',1,LEVEL+1)
                             - instr(list_str,'~',1,LEVEL) - 1)) AS token
  FROM ( SELECT REPLACE(list_str,sys_context('LIST_CTX','list_2_delim'),'~') AS list_str
           FROM ( SELECT sys_context('LIST_CTX','list_2_delim')
                       ||sys_context('LIST_CTX','list_2_str')
                       ||sys_context('LIST_CTX','list_2_delim') AS list_str
                    FROM dual
                 )
        )
 CONNECT BY LEVEL <= length(sys_context('LIST_CTX','list_2_str')) - 
                     length(REPLACE(sys_context('LIST_CTX','list_2_str'),sys_context('LIST_CTX','list_2_delim'),'')) + 1
/