CREATE TABLE COMMON.ACH_CODE_SEVERITY_LEVELS
(
  SEVERITY_LEVEL_PK        NUMBER(10)            ,
  SEVERITY_LEVEL           NUMBER(4)             ,
  SEVERITY_LEVEL_TEXT      VARCHAR2(4000 BYTE)   ,
  CREATED_ON               DATE                  ,
  CREATED_BY               VARCHAR2(30 BYTE)     ,
  UPDATED_ON               DATE                  ,
  UPDATED_BY               VARCHAR2(30 BYTE)     ,
  ACTION                   VARCHAR2(1 BYTE)      ,
  DELETED_ON               DATE,
  DELETED_BY               VARCHAR2(30 BYTE),
  MAINT_CODE               NUMBER(2)             
)
TABLESPACE COMMON_DATA
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;
