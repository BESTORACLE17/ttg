--NATIONAL_PROVIDER 

CREATE CLUSTER DCS2000.NATIONAL_PROVIDER
(
  STATE                           VARCHAR2(2 BYTE),
  BUS_ID                          VARCHAR2(9 BYTE),
  NPF_OFF_NO                      NUMBER(3)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    5
INITRANS   2
MAXTRANS   255
SIZE       2000
STORAGE    (
            INITIAL          400M
            NEXT             50M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
INDEX
NOROWDEPENDENCIES
NOCACHE
NOPARALLEL;


CREATE INDEX DCS2000.NATIONAL_PROVIDER_IX ON CLUSTER DCS2000.NATIONAL_PROVIDER
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          80M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


