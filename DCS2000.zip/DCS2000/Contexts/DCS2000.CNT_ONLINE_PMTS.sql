
create or replace context CNT_ONLINE_PMTS using DCS2000.PKG_ONLINE_PAYMENTS accessed globally;