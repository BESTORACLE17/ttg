CREATE SEQUENCE seq_code_id_card_errors NOCACHE
/
