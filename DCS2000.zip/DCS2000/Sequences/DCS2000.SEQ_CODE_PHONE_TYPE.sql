CREATE SEQUENCE dcs2000.seq_code_phone_type;
/