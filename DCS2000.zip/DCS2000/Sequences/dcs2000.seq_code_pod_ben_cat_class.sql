CREATE SEQUENCE seq_code_pod_ben_cat_class NOCACHE
/

