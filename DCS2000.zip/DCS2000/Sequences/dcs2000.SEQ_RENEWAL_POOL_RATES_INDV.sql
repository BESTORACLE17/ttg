-- Sequence DDL 
create sequence dcs2000.SEQ_RENEWAL_POOL_RATES_INDV
start with 1 increment by 1 nocache nocycle;

