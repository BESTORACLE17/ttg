CREATE SEQUENCE seq_code_pod_benefit_category NOCACHE
/
