CREATE SEQUENCE seq_code_pod_policy_limit NOCACHE
/
