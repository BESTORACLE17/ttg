create or replace procedure /* VERSION: 2.1.2 */ DCS2000.prc_credentialing_list (p_error_code IN OUT NUMBER,
							                        p_error_text IN OUT VARCHAR2,
												    p_begin_date IN OUT NUMBER,
							                        p_end_date IN OUT NUMBER)

as
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  : Enhancement
|| Service Request: 10153.07.ALL Multi-Org - Util Directory
|| Revision By    : Prasad Jampana
|| Revision Date  : 07/23/2010
|| Revision Desc  : Modified the data type/size of UTL File directory variable 
||                  to match the table column specification.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/   

    cursor cMain is
        select d.lnme
             , d.fnme
             , d.mnme
			 , d.prv_id
             , d.st_lic
             , c.prd_cde
             , e.spc_cde
             , c.eff_dte
          from (select b.prd_cde
                     , b.prv_id
                     , min(b.eff_dte) eff_dte
                  from (select *
                          from dcs2000.tbl_prv_par  a
                         where a.maint_code = 0
                           and a.prd_cde in (1, 2, 3)
                           and to_number(to_char(sysdate, 'yyyymmdd')) between a.eff_dte and decode(NVL(a.trm_dte, 0), 0, 99999999, a.trm_dte)
                           and prv_id like 'VA%')  b
              group by b.prd_cde, b.prv_id)  c
              , dcs2000.tbl_prv  d
              , (select distinct f.prv_id
			                   , f.spc_cde 
				   from dcs2000.tbl_prv_specialty f
                  where f.maint_code = 0
                    and board_cde != 0
                    and board_certified_dte <= to_number(to_char(sysdate, 'yyyymmdd'))) e
         where c.prv_id = d.prv_id
           and c.prv_id =  e.prv_id (+)
--		   and c.eff_dte between p_begin_date and p_end_date
      order by c.prd_cde, d.lnme, d.fnme, d.mnme;

    cursor cBase1 (prvID VARCHAR2) is
	    select code
             , info_eff_dte
             , info_trm_dte
          from dcs2000.tbl_code_info_type a
             , dcs2000.tbl_prv_info_chk b
         where code in (0,1,3,15)
           and code = b.info_type (+)
           and b.prv_id (+) = prvID
		   and b.maint_code (+) = 0;

    cursor cBase2 (prvID VARCHAR2) is
	    select code
             , info_eff_dte
             , info_trm_dte
          from dcs2000.tbl_code_info_type a
             , dcs2000.tbl_prv_info_chk b
         where code in (0,1,3,5,6,15)
           and code = b.info_type (+)
           and b.prv_id (+) = prvID
		   and b.maint_code (+) = 0;

    cursor cDEALocations (prvID VARCHAR2, prdCde NUMBER) is
	    select distinct c.prv_id
	         , c.tax_id
	         , c.loc
	         , c.fac_state
	      from dcs2000.tbl_prv_par   c
	     where c.maint_code = 0
	       and c.prv_id = prvID
	       and c.prd_cde = prdCde
	       and to_number(to_char(sysdate, 'yyyymmdd')) between c.eff_dte and decode(NVL(c.trm_dte, 0), 0, 99999999, c.trm_dte)
	       and c.prv_id like 'VA%';
		   
    cursor cDEALicense (prvID VARCHAR2 , taxID VARCHAR2, loc NUMBER, facState VARCHAR2) is
	    select info_type
             , info_eff_dte
             , info_trm_dte
          from dcs2000.tbl_prv_info_chk  b
         where b.info_type = 4
           and b.prv_id = prvID
           and b.tax_id = taxID
           and b.loc  = loc
           and b.fac_state  = facState
           and b.maint_code  = 0;
	
	cursor cDeltaCareOralSurgeon (prvID VARCHAR2) is
		select info_type
             , info_eff_dte
             , info_trm_dte
          from dcs2000.tbl_prv_info_chk  b
         where b.info_type  = 14
           and b.prv_id = prvID
		   and b.maint_code  = 0;

   vDEALicense  cDEALicense%rowtype;
   procState    NUMBER := 0;
   
   i                    NUMBER(9);   -- Row counter
   l_FileHandle         UTL_FILE.FILE_TYPE; -- File Handle
   l_UtlFileDir         DCS2000.TBL_SYSTEM_DEFINITION_PATH.UTL_DIR_PATH%TYPE;		  -- Utl File Directory, this directory name comes FROM oracle tables
   l_UtlFileName        VARCHAR2(30) := 'credentialinglist.txt'; -- Assign the File name here
   l_strLine            VARCHAR2(2000);
   l_LogFileHandle      UTL_FILE.FILE_TYPE; -- File Handle
   l_LogFileName        VARCHAR2(35) := 'credentialinglist' || TO_CHAR(SYSDATE, 'yymmddhhmi') || '.LOG'; -- Assign the File name here
   l_strLogLine         VARCHAR2(2000);
   currentProduct		NUMBER(1);
   deaInfoType    NUMBER(4);
   deaInfoEffDte  NUMBER(8);
   deaInfoTrmDte  NUMBER(8);

begin
   p_error_code := 0;

   /*
      Open log and write start time.
   */
   l_UtlFileDir := Pkg_Dcs_Utl_File.FNC_UTL_FILE_DIR; -- Assign the Utl File Directory name
   Pkg_Dcs_Utl_File.PRC_UTL_FILE_OPEN ( l_LogFileHandle, l_UtlFileDir, l_LogFileName, 'W'); -- Open the Utl File in Write mode

   l_strLogLine := 'Started: ' || TO_CHAR(SYSDATE, 'mm/dd/yyyy hh24:mi:ss');
   UTL_FILE.PUT_LINE (l_LogFileHandle, l_strLogline);
   UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file

   /*
      Open datafile, and set to write mode.
   */
   Pkg_Dcs_Utl_File.PRC_UTL_FILE_OPEN ( l_FileHandle, l_UtlFileDir, l_UtlFileName, 'W'); -- Open the Utl File in Write mode

   /*
      Column Headers
   */
   l_strLine := 'Last Name' || CHR(9) || 'First Name' || CHR(9) || 'Middle Name' || CHR(9) || 'License #' || CHR(9) || 'Product' || CHR(9) || 'Specialty' || CHR(9) || 'Par Eff Dte' || CHR(9) || 'Info Type' || CHR(9) || 'Info Eff Dte' || CHR(9) || 'Info Trm Dte' || CHR(9) || 'Tax ID' || CHR(9) || 'Loc' || CHR(9) || 'Fac State';
   UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
   UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file

   /*
      Generate the List adding info check information from the bases, dea, and oral surgeon cursors
   */
   i := 0;
   FOR vMain IN cMain LOOP
      i := i + 1;
	  -- Get current product
	  currentProduct := vMain.prd_cde;
	  
	  -- if premier, base 1
	  if currentProduct = 1 then
	      procState := 1;
          for vBase1 in cBase1(vMain.prv_id) loop
	          l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || vBase1.code || CHR(9) || vBase1.info_eff_dte || CHR(9) || vBase1.info_trm_dte || CHR(9)  || CHR(9)  || CHR(9);
              UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
              UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file
		  end loop;
	  -- if deltacare, base 2
	  elsif currentProduct = 2 then
	      procState := 2;
	      for vBase2 in cBase2(vMain.prv_id) loop
	          l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || vBase2.code || CHR(9) || vBase2.info_eff_dte || CHR(9) || vBase2.info_trm_dte || CHR(9)  || CHR(9)  || CHR(9);
              UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
              UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file
		  end loop;
	  	 
		  -- Check the DEA License
	      for vDEALocations in cDEALocations(vMain.prv_id, vMain.prd_cde) loop
/*	          mPrvID := vMain.prv_id;
			  if (cDEALicense%ISOPEN) then
			  	 close cDEALicense;
			  end if;
			  open cDEALicense(vDEALocations.prv_id, vDEALocations.tax_id, vDEALocations.loc, vDEALocations.fac_state);
	          fetch cDEALicense into vDEALicense;  */
--NEED TO CODE for the no data found exception
			  begin
    	      procState := 3;
			  select info_type
                   , info_eff_dte
                   , info_trm_dte
				into deaInfoType
                   , deaInfoEffDte
                   , deaInfoTrmDte
                from dcs2000.tbl_prv_info_chk  b
               where b.info_type = 4
                 and b.prv_id = vDEALocations.prv_id
                 and b.tax_id = vDEALocations.tax_id
                 and b.loc  = vDEALocations.loc
                 and b.fac_state  = vDEALocations.fac_state
                 and b.maint_code  = 0;
				 
	          l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || deaInfoEffDte || CHR(9) || deaInfoTrmDte || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
--	            l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || vDEALicense.info_eff_dte || CHR(9) || vDEALicense.info_trm_dte || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
              UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
              UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file

			  exception
			      when NO_DATA_FOUND then
	                  l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || ' ' || CHR(9) || ' ' || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
                      UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
                      UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file

--			  if cDEALicense%FOUND then  */
			  end;
		  end loop;
		 
          if (cDEALicense%ISOPEN) then
		  	 close cDEALicense;
		  end if;
		  -- if oral surgeon, check for clinical priviledges
		  if vMain.spc_cde = 10 then
    	      procState := 4;
	          for vDeltaCareOralSurgeon in cDeltaCareOralSurgeon(vMain.prv_id) loop
	              l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '14' || CHR(9) || vDeltaCareOralSurgeon.info_eff_dte || CHR(9) || vDeltaCareOralSurgeon.info_trm_dte || CHR(9)  || CHR(9)  || CHR(9);
                  UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
                  UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file
		      end loop;
		  end if;
	  
	  -- if dpo, base 2
	  elsif currentProduct = 3 then
	      procState := 5;
	      for vBase2 in cBase2(vMain.prv_id) loop
	          l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || vBase2.code || CHR(9) || vBase2.info_eff_dte || CHR(9) || vBase2.info_trm_dte || CHR(9)  || CHR(9)  || CHR(9);
              UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
              UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file
		  end loop;
	  
		 -- Check the DEA License
	      for vDEALocations in cDEALocations(vMain.prv_id, vMain.prd_cde) loop
-- 	          for vDEALicense in cDEALicense(vDEALocations.prv_id, vDEALocations.tax_id, vDEALocations.loc, vDEALocations.fac_state) loop
-- 	              l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || vDEALicense.info_eff_dte || CHR(9) || vDEALicense.info_trm_dte || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
--                   UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
--                   UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file
-- 		      end loop;
			  begin
    	      procState := 6;
			  select info_type
                   , info_eff_dte
                   , info_trm_dte
				into deaInfoType
                   , deaInfoEffDte
                   , deaInfoTrmDte
                from dcs2000.tbl_prv_info_chk  b
               where b.info_type = 4
                 and b.prv_id = vDEALocations.prv_id
                 and b.tax_id = vDEALocations.tax_id
                 and b.loc  = vDEALocations.loc
                 and b.fac_state  = vDEALocations.fac_state
                 and b.maint_code  = 0;
				 
	          l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || deaInfoEffDte || CHR(9) || deaInfoTrmDte || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
--	            l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || vDEALicense.info_eff_dte || CHR(9) || vDEALicense.info_trm_dte || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
              UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
              UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file

			  exception
			      when NO_DATA_FOUND then
	                  l_strLine := vMain.lnme || CHR(9) || vMain.fnme || CHR(9) || vMain.mnme || CHR(9) || vMain.st_lic || CHR(9) || vMain.prd_cde || CHR(9) || Num_2_Str(NVL(vMain.spc_cde, 0), 2) || CHR(9) || vMain.eff_dte || CHR(9) || '4' || CHR(9) || ' ' || CHR(9) || ' ' || CHR(9) || vDEALocations.tax_id || CHR(9) || vDEALocations.loc || CHR(9) || vDEALocations.fac_state;
                      UTL_FILE.PUT_LINE (l_FileHandle, l_strline);
                      UTL_FILE.FFLUSH (l_FileHandle);  -- This FUNCTION IS to throw the output immediately to the file

--			  if cDEALicense%FOUND then  */
			  end;

		  end loop;

      end if;

   END LOOP;

   /*
      Close list file
   */
   UTL_FILE.FCLOSE (l_FileHandle); -- Close the file open FOR writing at the END of the PROCEDURE


   /*
      Write finishing time, finishing status, and close log file
   */
   l_strLogLine := 'Stopped: ' || TO_CHAR(SYSDATE, 'mm/dd/yyyy hh24:mi:ss');
   UTL_FILE.PUT_LINE (l_LogFileHandle, l_strLogline);
   UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file
   l_strLogLine := 'Total Rows processed: ' || TO_CHAR(i);
   UTL_FILE.PUT_LINE (l_LogFileHandle, l_strLogline);
   UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file

   UTL_FILE.PUT_LINE (l_LogFileHandle, 'This procedure completed WITH NO errors.');
   UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file
   UTL_FILE.FCLOSE (l_LogFileHandle); -- Close the file open FOR writing at the END of the PROCEDURE
   
EXCEPTION
   WHEN OTHERS THEN
      p_error_code := SQLCODE;
      p_error_text := SQLERRM;
      l_strLogLine := 'App State - ' || TO_CHAR(procState) || ':: Row ' || TO_CHAR(i) || ' has caused ' || SUBSTR(SQLERRM, 1, 100) || '.';
      UTL_FILE.PUT_LINE (l_LogFileHandle, l_strLogline);
      UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file
	  
	  /*
      Close list file
      */
      UTL_FILE.FCLOSE (l_FileHandle); -- Close the file open FOR writing at the END of the PROCEDURE
      UTL_FILE.PUT_LINE (l_LogFileHandle, 'This procedure completed WITH errors.');
      UTL_FILE.FFLUSH (l_LogFileHandle);  -- This FUNCTION IS to throw the output immediately to the file
      UTL_FILE.FCLOSE (l_LogFileHandle); -- Close the file open FOR writing at the END of the PROCEDURE

end prc_credentialing_list;
/
