CREATE OR REPLACE PROCEDURE /* VERSION: 2.2.0 */ dcs2000.prc_populate_provider_ids (
   p_error_code               IN OUT   NUMBER,
   p_error_text               IN OUT   VARCHAR2,
   p_parent_id                IN       dcs2000.tbl_company.parent_id%TYPE,
   p_document_medium_code     IN       dcs2000.tbl_wip_header.document_medium_code%TYPE,
   p_prv_id                   IN OUT   dcs2000.tbl_wip_header.prv_id%TYPE,
   p_tax_id                   IN OUT   dcs2000.tbl_wip_header.prv_tax_id%TYPE,
   p_fac_state                IN OUT   dcs2000.tbl_wip_header.fac_state%TYPE,
   p_rendering_provider_npi   IN OUT   dcs2000.tbl_wip_header.rendering_provider_npi%TYPE,
   p_billing_provider_npi     IN OUT   dcs2000.tbl_wip_header.billing_provider_npi%TYPE,
   p_npi_populate_code        IN OUT   dcs2000.tbl_wip_header.npi_populate_code%TYPE,
   p_override_mode            IN       VARCHAR2 DEFAULT 'N'                                                  /* 2.1.5 */
)
AS
/*
|| @"G:\Shared Files\IS-Dev\Service Requests\06214.01.ALL - NPI Processing and Compliance\SQL\Phase II\dcs2000.prc_populate_provider_ids.prc"
||------------------------------------------------------------------------
|| Component Description
||------------------------------------------------------------------------
||------------------------------------------------------------------------
|| Revision History
||------------------------------------------------------------------------
|| Version        : 2.1.1
|| Revision Type  : Created
|| Change Control#:
|| Service Request: 06214.01.ALL - NPI Processing and Compliance.
|| Revision By    : Ram Garimella and Jed Sousa
|| Revision Date  : 03/20/2007.
|| Revision Desc  : Created new procedure to provide all the possible variables
||                  required to incorporate new logic for the above mentioned SR,
||                  for populating Rendering NPI, Billing NPI, Tax Id, Provider Id
||                  and Fac State.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  : BugFix
|| Change Control#:
|| Service Request: 27565
|| Revision By    : Suresh Vadapalli
|| Revision Date  : 08/23/2007
|| Revision Desc  : Added state code in inp_get_prv_id.

|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.3
|| Revision Type  : Enhancement
|| Change Control#:
|| Service Request: SR 06081.01.VA
|| Revision By    : Manoj Chandrakant Sathe
|| Revision Date  : 11/20/2007, 04/10/2008 (SV)
|| Revision Desc  : Added to pass Parent Id, in   -
||                   - inp_get_rendering_provider_npi in FNC_GET_PROVIDER_NPI
||                   - inp_get_billing_provider_npi defalut Parent id is changed to p_paremt_id parameter from default
||                   - inp_get_prv_id in FNC_GET_LIC_INFO_FROM_NPI
||                   - inp_get_tax_id passed p_paremt_id in place of default
                     --Replaced hard-coded parent ID w/ a function call. - SV
||
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.4
|| Revision Type  : Enhancement
|| Change Control#:
|| Service Request: SR 08016.01.AR
|| Revision By    : Manoj Sathe
|| Revision Date  : 07/29/2008
|| Revision Desc  : Added check to look for Provider Id if a default
||                  provider Id (--00000000000)is passed in place of NULL.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.5
|| Revision Type  : Enhancement
|| Change Control#:
|| Service Request: SR06003.02.VA
|| Revision By    : Jeff Reynolds
|| Revision Date  : 12/21/2007 (merged 11/18/2008)
|| Revision Desc  : Allow routine to operate in a new mode where the rendering
||                  and billing provider NPIs are returned regardless of the
||                  document medium code and it's associated npi_populate_code.
||                  This is to support the 835 dual use NPI requirement.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.6
|| Revision Type  : Bugfix
|| Change Control#:
|| Service Request: SR09001.23.CO
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 03/10/2009
|| Revision Desc  :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.7
|| Revision Type  : Bugfix
|| Service Request: TRAC#6491
|| Revision By    : Manoj Sathe
|| Revision Date  : 01/13/2011
|| Revision Desc  : Changed the function inp_get_prv_id to get the Prov Id
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.8
|| Revision Type  : Enhancement
|| SR/WO          : SR 11105.02.ALL
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 08/11/2011
|| Revision Desc  : Retrieve fac_state from only those networks that the parent has access to
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.9
|| Revision Type  : Enhancement
|| SR/WO          : SR 11105.02.ALL
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 08/17/2011
|| Revision Desc  : use parent id context if p_parent_id is passed as null
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.2.0
|| Revision Type  : Enhancement
|| SR/WO          : PMO-533
|| Revision By    : Bruce Johnson
|| Revision Date  : 01/08/2017
|| Revision Desc  : Force license/TIN lookup to both LPF and NPF
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

*/
   lv_error_text               VARCHAR2 (4000);
   lv_npi_auto_populate        dcs2000.tbl_code_document_medium.npi_auto_populate%TYPE;
   lv_prv_id                   dcs2000.tbl_wip_header.prv_id%TYPE;
   lv_tax_id                   dcs2000.tbl_wip_header.prv_tax_id%TYPE;
   lv_fac_state                dcs2000.tbl_wip_header.fac_state%TYPE;
   ln_rendering_provider_npi   dcs2000.tbl_wip_header.rendering_provider_npi%TYPE;
   ln_billing_provider_npi     dcs2000.tbl_wip_header.billing_provider_npi%TYPE;
   ln_brand_code               dcs2000.tbl_parent_company.brand_code%TYPE;
   c_none             CONSTANT dcs2000.tbl_system_parameters_dtl.current_value%TYPE      := 'NONE';
   c_min              CONSTANT dcs2000.tbl_system_parameters_dtl.current_value%TYPE      := 'MIN';
   c_max              CONSTANT dcs2000.tbl_system_parameters_dtl.current_value%TYPE      := 'MAX';
   c_default_parent_id         dcs2000.tbl_parent_company.parent_id%TYPE
                                                                  := COMMON.PKG_PARENT_ID_UTILS.FNC_PARENT_ID;
   -- 04/10/2008 SV
   c_y_flag           CONSTANT VARCHAR2 (1)                                              := 'Y';
   c_n_flag           CONSTANT VARCHAR2 (1)                                              := 'N';
   c_lpf              CONSTANT NUMBER (1)                                                := 1;
   c_npf              CONSTANT NUMBER (1)                                                := 2;
   c_default_prv_id   CONSTANT VARCHAR2 (12)                                             := '000000000000';     --2.1.4
   lv_prv_file                 NUMBER (1);
   lv_master_plan_state        dcs2000.tbl_system_parameters_dtl.current_value%TYPE;
   lv_npi_auto_populate_type   dcs2000.tbl_system_parameters_dtl.current_value%TYPE;

   PROCEDURE inp_get_fac_state
   IS
   BEGIN
      IF (p_prv_id IS NOT NULL)
      THEN
         lv_fac_state               := SUBSTR (p_prv_id, 1, 2);
      ELSIF (p_tax_id IS NOT NULL)
      THEN
         BEGIN
            SELECT DISTINCT fac_state
                       INTO lv_fac_state
                       FROM provider.tbl_facility fac, provider.tbl_facility_location fac_loc
                      WHERE fac.facility_pk = fac_loc.facility_pk
                        AND fac.tax_id = p_tax_id
                        AND fac_loc.network_id IN (SELECT network_id
                                                     FROM dcs2000.tbl_parent_network
                                                    WHERE parent_id = SYS_CONTEXT ('CNT_PARENT_ID', 'PARENT_ID'));
         EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
               lv_fac_state               := NULL;
            WHEN TOO_MANY_ROWS
            THEN
               lv_fac_state               := NULL;
         END;
      ELSIF (p_billing_provider_npi IS NOT NULL)
      THEN
         -- function returns null if multiple rows or no data found
         BEGIN
            SELECT *
              INTO lv_fac_state
              FROM TABLE (provider.pkg_npi_utils.fnc_get_distinct_states (NVL(p_parent_id,c_default_parent_id),
                                                                          p_billing_provider_npi,
                                                                          c_y_flag,
                                                                          c_npf
                                                                         )
                         );
         EXCEPTION
            WHEN TOO_MANY_ROWS
            THEN
               lv_fac_state               := NULL;
         END;
      ELSIF (p_rendering_provider_npi IS NOT NULL)
      THEN
         -- function returns null if multiple rows or no data found
         BEGIN
            SELECT *
              INTO lv_fac_state
              FROM TABLE (provider.pkg_npi_utils.fnc_get_distinct_states (NVL(p_parent_id,c_default_parent_id),
                                                                          p_rendering_provider_npi,
                                                                          c_y_flag,
                                                                          c_npf
                                                                         )
                         );
         EXCEPTION
            WHEN TOO_MANY_ROWS
            THEN
               lv_fac_state               := NULL;
         END;
      END IF;

      p_fac_state                := lv_fac_state;
   EXCEPTION
      WHEN OTHERS
      THEN
         p_fac_state                := NULL;
   END inp_get_fac_state;

   PROCEDURE inp_get_rendering_provider_npi
   IS
   BEGIN
      IF p_rendering_provider_npi IS NULL
      THEN
         SELECT npi
           INTO ln_rendering_provider_npi
           FROM TABLE (provider.pkg_npi_utils.fnc_get_provider_npi (SUBSTR (p_prv_id, 3),
                                                                    p_fac_state,
                                                                    c_y_flag,
                                                                    lv_prv_file,
                                                                    NVL(p_parent_id,c_default_parent_id)
                                                                   )
                      );                                                                                 --Version 2.1.3
      END IF;                                                                 -- EndIf p_rendering_provider_npi IS NULL.
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ln_rendering_provider_npi  := NULL;
      WHEN OTHERS
      THEN
         ln_rendering_provider_npi  := NULL;
   END inp_get_rendering_provider_npi;

   PROCEDURE inp_get_billing_provider_npi
   IS
   BEGIN
      IF p_billing_provider_npi IS NULL
      THEN
         IF lv_npi_auto_populate_type = c_min
         THEN
            lv_error_text              := 'Getting Min Billing VPI with Tax id ' || TO_CHAR (p_tax_id);

            SELECT MIN (npi)
              INTO ln_billing_provider_npi
              FROM TABLE (provider.pkg_npi_utils.fnc_get_dist_npis_for_business (NVL(p_parent_id,c_default_parent_id),
                                                                                 TO_CHAR (p_tax_id),
                                                                                 c_y_flag,
                                                                                 lv_prv_file
                                                                                )
                         );                                                                              --Version 2.1.3
         ELSIF lv_npi_auto_populate_type = c_max
         THEN
            lv_error_text              := 'Getting Max Billing VPI with Tax id ' || TO_CHAR (p_tax_id);

            SELECT MAX (npi)
              INTO ln_billing_provider_npi
              FROM TABLE (provider.pkg_npi_utils.fnc_get_dist_npis_for_business (NVL(p_parent_id,c_default_parent_id),
                                                                                 TO_CHAR (p_tax_id),
                                                                                 c_y_flag,
                                                                                 lv_prv_file
                                                                                )
                         );                                                                              --Version 2.1.3
         END IF;                                                                     -- c_NPI_AUTO_POPULATE_TYPE = c_MAX
      END IF;                                                                   -- EndIf p_billing_provider_npi IS NULL.
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         ln_billing_provider_npi    := NULL;
   END inp_get_billing_provider_npi;

   PROCEDURE inp_get_prv_id (p_prv_file IN NUMBER)
   IS
   BEGIN
      -- Version 2.1.7, removed Parent id case clause as parent is always passed to get the NPF data.
      lv_error_text              :=
                        'Getting Value for Prv Id for Rendering having Parent Id with NPI ' || p_rendering_provider_npi;

      SELECT DISTINCT state_code || license_number
        INTO lv_prv_id
        FROM (TABLE (provider.pkg_npi_utils.fnc_get_lic_info_from_npi (p_rendering_provider_npi,
                                                                       c_y_flag,
                                                                       p_prv_file , --lv_prv_file,
                                                                       p_fac_state,
                                                                       NVL(p_parent_id,c_default_parent_id)
                                                                      )
                    )
             );
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         lv_prv_id                  := NULL;
      WHEN TOO_MANY_ROWS
      THEN
         lv_prv_id                  := NULL;
   END inp_get_prv_id;

   PROCEDURE inp_get_tax_id (p_prv_file IN NUMBER)
   IS
   BEGIN
      CASE
         WHEN c_default_parent_id = p_parent_id
         THEN
            lv_error_text              :=
                            'Getting Value for Tax Id for Billing having Parent Id with NPI ' || p_billing_provider_npi;
            lv_tax_id                  :=
               provider.pkg_npi_utils.fnc_get_tax_id_from_npi (p_billing_provider_npi,
                                                               p_parent_id,
                                                               c_y_flag,
                                                               p_prv_file
                                                              );                                         --Version 2.1.3
         ELSE
            lv_error_text              :=
                    'Getting Value for Tax Id for Billing and NOT having Parent Id with NPI ' || p_billing_provider_npi;
            lv_tax_id                  :=
               provider.pkg_npi_utils.fnc_get_tax_id_from_npi (p_billing_provider_npi,
                                                               NVL(p_parent_id,c_default_parent_id),
                                                               c_y_flag,
                                                               p_prv_file
                                                              );                                         --Version 2.1.3
      END CASE;
   EXCEPTION
      WHEN OTHERS
      THEN
         lv_tax_id                  := NULL;
   END inp_get_tax_id;

   PROCEDURE calc_npi_pop_cd
   IS
   BEGIN
      IF lv_npi_auto_populate_type = c_none
      THEN
         p_npi_populate_code        := 0;
      ELSIF     (p_rendering_provider_npi IS NULL AND ln_rendering_provider_npi IS NOT NULL)
            AND (p_billing_provider_npi IS NULL AND ln_billing_provider_npi IS NOT NULL)
      THEN
         p_npi_populate_code        := 3;
      ELSIF (p_billing_provider_npi IS NULL AND ln_billing_provider_npi IS NOT NULL)
      THEN
         p_npi_populate_code        := 2;
      ELSIF (p_rendering_provider_npi IS NULL AND ln_rendering_provider_npi IS NOT NULL)
      THEN
         p_npi_populate_code        := 1;
      ELSE
         p_npi_populate_code        := 0;
      END IF;
   END calc_npi_pop_cd;

   FUNCTION fnc_get_brand_code (p_parent_id IN NUMBER)
      RETURN dcs2000.tbl_parent_company.brand_code%TYPE
   IS
   BEGIN
      SELECT CASE (brand_code)
                WHEN 1
                   THEN 1
                ELSE 0
             END
        INTO ln_brand_code
        FROM tbl_parent_company
       WHERE parent_id = p_parent_id;

      RETURN ln_brand_code;
   END fnc_get_brand_code;

   FUNCTION fnc_get_npi_auto_pop
      RETURN dcs2000.tbl_code_document_medium.npi_auto_populate%TYPE
   IS
   BEGIN
      SELECT npi_auto_populate
        INTO lv_npi_auto_populate
        FROM tbl_code_document_medium
       WHERE code = p_document_medium_code;

      RETURN UPPER (lv_npi_auto_populate);
   EXCEPTION
      WHEN NO_DATA_FOUND
      THEN
         RETURN 'N';
   END fnc_get_npi_auto_pop;
BEGIN
   p_error_code               := 0;
   p_error_text               := 'Success';
   ln_rendering_provider_npi  := p_rendering_provider_npi;
   ln_billing_provider_npi    := p_billing_provider_npi;
   lv_npi_auto_populate_type  := UPPER (pkg_dcs_system_parameters.fnc_get_system_parameter ('NPI_AUTO_POPULATE_TYPE'));
   lv_npi_auto_populate       := fnc_get_npi_auto_pop;

   IF lv_npi_auto_populate_type = c_none
   THEN
      p_npi_populate_code        := 0;
   ELSIF (lv_npi_auto_populate_type <> c_none AND lv_npi_auto_populate = 'N' AND p_override_mode <> 'Y')
   THEN                                                                                                      /* 2.1.5 */
      p_npi_populate_code        := 0;
   ELSE
      IF (    p_fac_state IS NULL
          AND p_prv_id IS NULL
          AND p_tax_id IS NULL
          AND p_rendering_provider_npi IS NULL
          AND p_billing_provider_npi IS NULL
         )
      THEN
         p_npi_populate_code        := 0;
      ELSE
         lv_master_plan_state       := UPPER (pkg_dcs_system_parameters.fnc_get_system_parameter ('MASTER_PLAN_STATE'));

         IF (p_fac_state IS NULL)
         THEN
            inp_get_fac_state;                                                     -- changes the value of lv_fac_state
         ELSE
            lv_fac_state               := p_fac_state;
         END IF;

         IF (lv_fac_state IS NOT NULL)
         THEN
            IF (INSTR (lv_master_plan_state, lv_fac_state, 1) > 0 OR (fnc_get_brand_code (NVL(p_parent_id,c_default_parent_id)) <> 1))
            THEN
               lv_prv_file                := c_lpf;
            ELSE
               lv_prv_file                := c_npf;
            END IF;

            IF (p_rendering_provider_npi IS NULL AND p_prv_id IS NOT NULL)
            THEN
               inp_get_rendering_provider_npi;                        -- changes the value of ln_rendering_provider_npi
            END IF;

            IF (p_billing_provider_npi IS NULL AND p_tax_id IS NOT NULL)
            THEN
               inp_get_billing_provider_npi;                            -- changes the value of ln_billing_provider_npi
            END IF;
         END IF;

         calc_npi_pop_cd;
         p_rendering_provider_npi   := ln_rendering_provider_npi;
         p_billing_provider_npi     := ln_billing_provider_npi;
      END IF;
   END IF;

   IF (p_rendering_provider_npi IS NOT NULL AND (p_prv_id IS NULL OR p_prv_id = lv_fac_state || '000000000000')
      )                                            --2.1.4 substr(p_prv_id,3,14) = C_DEFAULT_PRV_ID ))           --2.1.4
   THEN
      inp_get_prv_id(p_prv_file => 1); 
      IF lv_prv_id IS NULL
      THEN   
        inp_get_prv_id(p_prv_file => 2); 
      END IF;
      p_prv_id                   := lv_prv_id;
   END IF;

   IF (p_billing_provider_npi IS NOT NULL AND p_tax_id IS NULL)
   THEN
      inp_get_tax_id(p_prv_file => 1); 
      IF lv_tax_id IS NULL
      THEN
        inp_get_tax_id(p_prv_file => 2);
      END IF; 
      p_tax_id                   := lv_tax_id;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      p_error_code               := -1;
      p_error_text               := SQLERRM;
END prc_populate_provider_ids;
/