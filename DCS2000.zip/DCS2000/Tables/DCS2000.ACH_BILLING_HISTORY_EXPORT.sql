/* VERSION: 3.1.1 */ 
--
-- ACH_BILLING_HISTORY_EXPORT  (Table) 
--
CREATE TABLE DCS2000.ACH_BILLING_HISTORY_EXPORT
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE),
  SUBLOC_ID                VARCHAR2(8 BYTE),
  DIV_ID                   VARCHAR2(4 BYTE),
  BILL_DATE                NUMBER(8),
  BILL_FROM_DATE           NUMBER(8),
  BILL_NO_OF_MONTHS        NUMBER(4),
  BILL_DUE_DATE            NUMBER(8),
  BILL_COUNT               NUMBER(7),
  BILL_AMT                 NUMBER(9,2),
  ASO_RISK_TYPE            NUMBER(2),
  PRODUCT_CODE             NUMBER(4),
  BILLING_CODE             NUMBER(12),
  REC_ACCOUNT_CODE         NUMBER(12),
  UNEARN_REV_ACCOUNT_CODE  NUMBER(12),
  REV_ACCOUNT_CODE         NUMBER(12),
  AR_TRANSFER_DATE         DATE,
  ARCHIVED_ON              DATE,
  ARCHIVED_BY              VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          512K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_BILLING_HISTORY_EXPORT TO DCS_USERS_ALL;

