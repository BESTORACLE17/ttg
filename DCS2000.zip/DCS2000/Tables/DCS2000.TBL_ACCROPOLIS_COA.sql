/* VERSION: 3.1.1 */ 
--
-- TBL_ACCROPOLIS_COA  (Table) 
--
CREATE TABLE DCS2000.TBL_ACCROPOLIS_COA
(
  ACC_NO           NUMBER(8),
  ACC_DESCRIPTION  VARCHAR2(100 BYTE)           NOT NULL,
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_ACCROPOLIS_COA  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_ACCROPOLIS_COA ON DCS2000.TBL_ACCROPOLIS_COA
(ACC_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          32K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ACCROPOLIS_COA TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ACCROPOLIS_COA TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_ACCROPOLIS_COA 
-- 
ALTER TABLE DCS2000.TBL_ACCROPOLIS_COA ADD (
  CONSTRAINT PK_ACCROPOLIS_COA PRIMARY KEY (ACC_NO)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          32K
                NEXT             16K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


