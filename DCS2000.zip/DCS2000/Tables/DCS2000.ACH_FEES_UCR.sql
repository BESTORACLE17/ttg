/* VERSION: 3.1.2 */ 
--
-- ACH_FEES_UCR  (Table) 
--
CREATE TABLE DCS2000.ACH_FEES_UCR
(
  PRD_CDE         NUMBER(4),
  PLN_CDE         NUMBER(4),
  REG_CDE         NUMBER(4),
  SPC_CDE         NUMBER(4),
  PERCENTILE_CDE  NUMBER(4),
  PRC_CDE         VARCHAR2(5 BYTE),
  EFF_DTE         NUMBER(8),
  TRM_DTE         NUMBER(8),
  FEE             NUMBER(7,2),
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          9368K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_FEES_UCR TO DCS_USERS_ALL;
/
Alter table dcs2000.ACH_FEES_UCR add( NETWORK_ID NUMBER(4)); -- 3.1.2 Satya 11105.02.ALL Multi network 
/
