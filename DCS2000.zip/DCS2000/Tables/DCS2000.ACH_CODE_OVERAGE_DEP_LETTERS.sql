/* VERSION: 3.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : NEW 
|| Version #      : 3.1.1
|| Service Request: SR# 07178.03.KY Overage Dep Processing
|| Revision By    : KETAN PATEL
|| Revision Date  : 02/27/2008.
|| Revision Desc  : CREATED TABLE
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_CODE_OVERAGE_DEP_LETTERS
(
     OVERAGE_DEP_LETTERS_PK  NUMBER(4)                  NOT NULL,
     ACTION                  VARCHAR2(1)                NOT NULL,
     CREATED_ON              DATE                       NOT NULL,
     CREATED_BY              VARCHAR2(30)               NOT NULL,
     UPDATED_ON              DATE                       NOT NULL,
     UPDATED_BY              VARCHAR2(30)               NOT NULL,
     MAINT_CODE              NUMBER(2)                  NOT NULL,
     CODE                    VARCHAR2(50)               NOT NULL,
     DESCRIPTION             VARCHAR2(100)              NOT NULL,
     EFF_DTE                 DATE                       NOT NULL,
     TRM_DTE                 DATE                               ,
     AUTO_TERM_FLAG          VARCHAR2(1)                        ,  
     LETTER_BODY             VARCHAR2(4000)             NOT NULL,
     OVERAGE_DEP_LTR_TYPES_PK  NUMBER                
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;