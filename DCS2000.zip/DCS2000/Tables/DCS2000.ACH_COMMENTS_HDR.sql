/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR# SR08001.01.VA
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/12/2008.
|| Revision Desc  : Corrected the typo in table name (TBL_ is used instead of ACH_ )
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_COMMENTS_HDR  (Table) 
--
CREATE TABLE DCS2000.ACH_COMMENTS_HDR
(
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  ADD_DTE              DATE,
  ADD_OP               VARCHAR2(12 BYTE),
  COMMENT_ID           NUMBER(12)               NOT NULL,
  SUBR_ID              VARCHAR2(9 BYTE),
  INDV_ID              NUMBER(2),
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  CLAIM_NO             VARCHAR2(14 BYTE),
  CHECK_NBR            VARCHAR2(10 BYTE),
  PRV_ID               VARCHAR2(11 BYTE),
  LOC                  NUMBER(4),
  TAX_ID               VARCHAR2(9 BYTE),
  FAC_STATE            VARCHAR2(2 BYTE),
  COMMENT_INQUIRY      NUMBER(2),
  COMMENT_INQUIRY_STS  NUMBER(2),
  COMPLETED_DTE        DATE,
  COMMENT_TYPE         NUMBER(4),
  COMMENT_ERROR_TYPE   NUMBER(4),
  SOURCE_OBJECT_ID     NUMBER(4),
  COMMENT_SECURITY     NUMBER(2),
  LAST_DETAIL_MOD_DTE  DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          107600K
            NEXT             3080K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_COMMENTS_HDR TO DCS_USERS_ALL;

--HD 13874  01/25/2005  - SHB found that ACH_COMMENTS_HDR had not been modified when TBL_COMMENTS_HDR was
-- Comment Inquiry field was expanded to 3 places from 2.
alter table DCS2000.ACH_COMMENTS_HDR modify COMMENT_INQUIRY NUMBER(3);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_COMMENTS_HDR MODIFY SUBR_ID VARCHAR2(30);

--SR06214.01.ALL  03/19/2007  - SHB found that ACH_COMMENTS_HDR had not been modified when TBL_COMMENTS_HDR was
-- PRODUCER_ID column had not been added
ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (PRODUCER_ID  NUMBER(15));

-- DCS_PROVIDER_ID column had not been added
ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (DCS_PROVIDER_ID NUMBER(12)); --3.1.3 

-- DCS_FACILITY_ID column had not been added
ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (DCS_FACILITY_ID NUMBER(12)); --3.1.3 

ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (ACTION_CODE VARCHAR2(1)); --3.1.3 
ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (ACTION_BY   VARCHAR2(30)); --3.1.3 
ALTER TABLE DCS2000.ACH_COMMENTS_HDR ADD (ACTION_ON   DATE);--3.1.3 

-- Added for SR 07121.01.ALL 12 Digit License Number
ALTER TABLE	DCS2000.ACH_COMMENTS_HDR	MODIFY (PRV_ID        VARCHAR2(32) ); 