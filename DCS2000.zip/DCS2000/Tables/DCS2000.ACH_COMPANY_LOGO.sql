create table DCS2000.ACH_COMPANY_LOGO
(
  CREATED_BY             VARCHAR2(30),
  CREATED_ON             DATE,
  UPDATED_BY             VARCHAR2(30),
  UPDATED_ON             DATE,
  MAINT_CODE             NUMBER(4),
  ACTION_CODE            VARCHAR2(1),
  ACTION_BY              VARCHAR2(30),
  ACTION_ON              DATE,
  COMPANY_LOGO_PK        NUMBER(12),
  COMPANY_ID             NUMBER(4) not null,
  IMAGE_TYPE             NUMBER(2) not null,
  IMAGE_ID               NUMBER(4),
  LOGO_INDENT_FLAG       VARCHAR2(1),
  SHOW_COMPANY_NAME_FLAG VARCHAR2(1)
);