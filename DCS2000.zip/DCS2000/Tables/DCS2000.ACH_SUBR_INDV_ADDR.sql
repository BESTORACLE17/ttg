/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV_ADDR  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_ADDR
(
  SUBR_ID           VARCHAR2(9 BYTE),
  INDV_ID           NUMBER(2),
  ADDR_CDE          NUMBER(2),
  CONTACT_SALU_CDE  NUMBER(2),
  ADDR1             VARCHAR2(30 BYTE),
  ADDR2             VARCHAR2(30 BYTE),
  ADDR3             VARCHAR2(30 BYTE),
  CITY              VARCHAR2(30 BYTE),
  STATE             VARCHAR2(2 BYTE),
  ZIP               NUMBER(5),
  ZIP4              NUMBER(4),
  COUNTRY_CDE       NUMBER(4),
  MAINT_CODE        NUMBER(4),
  MOD_DTE           DATE,
  MOD_OP            VARCHAR2(12 BYTE),
  INS_UPD_FLAG      VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          171336K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


-- Create/Recreate indexes 
create index DCS2000.ACH_SUBR_INDV_ADDR_IX on DCS2000.ACH_SUBR_INDV_ADDR (SUBR_ID, INDV_ID)
  tablespace PRODIX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
--
-- ACH_SUBR_INDV_ADDR_MOD_OP_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_SUBR_INDV_ADDR_MOD_OP_IX ON DCS2000.ACH_SUBR_INDV_ADDR
(MOD_OP)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          5M
            NEXT             2M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

grant delete on DCS2000.ACH_SUBR_INDV_ADDR to DCSADMIN;
GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_INDV_ADDR TO DCS_USERS_ALL;


--===================================
--SR 05085.07 Custodial Parent Info
--08/31/2005
--Suresh Vadapalli
--===================================

ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD CUSTODIAL_LNME VARCHAR2(30) ;
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD CUSTODIAL_FNME VARCHAR2(30) ;
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD OBRA CHAR(1) ;
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD CASE_NUMBER VARCHAR2(15) ;


-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_INDV_ADDR MODIFY SUBR_ID VARCHAR2(30);

-- 14359
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD ADDRESS_VERIFIED NUMBER(4) default -1 ;
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD PARENT_ID NUMBER(4) not null ;
ALTER TABLE dcs2000.ACH_SUBR_INDV_ADDR ADD PREFER_COMMUNICATION_CODE NUMBER(4) ;
-- Add comments to the columns 
comment on column DCS2000.ACH_SUBR_INDV_ADDR.PARENT_ID
  is 'SR10006.01.ALL - Multi-Org';
