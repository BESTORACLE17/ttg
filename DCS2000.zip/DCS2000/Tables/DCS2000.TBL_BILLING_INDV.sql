/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Eric Lichtman
|| Revision Date  : 10/24/2006.
|| Revision Desc  : Altered table added column print_subr_id
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_INDV  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_INDV
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  SUBR_ID                  VARCHAR2(9 BYTE)     NOT NULL,
  GRP_ID                   VARCHAR2(9 BYTE)     NOT NULL,
  SUBLOC_ID                VARCHAR2(8 BYTE)     NOT NULL,
  DIV_ID                   VARCHAR2(4 BYTE)     NOT NULL,
  BILLING_CODE             NUMBER(12)           NOT NULL,
  BILL_DATE                NUMBER(8)            NOT NULL,
  BILL_FROM_DATE           NUMBER(8)            NOT NULL,
  BILL_NO_OF_MONTHS        NUMBER(4)            NOT NULL,
  BILL_DUE_DATE            NUMBER(8)            NOT NULL,
  BILL_COUNT               NUMBER(7)            NOT NULL,
  BILL_AMT                 NUMBER(9,2)          NOT NULL,
  ASO_RISK_TYPE            NUMBER(2)            NOT NULL,
  PRODUCT_CODE             NUMBER(4)            NOT NULL,
  REC_ACCOUNT_CODE         NUMBER(12)           NOT NULL,
  UNEARN_REV_ACCOUNT_CODE  NUMBER(12)           NOT NULL,
  REV_ACCOUNT_CODE         NUMBER(12)           NOT NULL,
  AR_TRANSFER_DATE         DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_INDV TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_INDV TO PRODDBLINK;

GRANT SELECT, UPDATE ON  DCS2000.TBL_BILLING_INDV TO AR;

--
-- PK_BILLING_INDV  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_BILLING_INDV ON DCS2000.TBL_BILLING_INDV
(SUBR_ID, GRP_ID, SUBLOC_ID, DIV_ID, BILLING_CODE, 
BILL_DATE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_BILLING_INDV 
-- 
ALTER TABLE DCS2000.TBL_BILLING_INDV ADD (
  CONSTRAINT PK_BILLING_INDV PRIMARY KEY (SUBR_ID, GRP_ID, SUBLOC_ID, DIV_ID, BILLING_CODE, BILL_DATE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          256K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_BILLING_INDV 
-- 
ALTER TABLE DCS2000.TBL_BILLING_INDV ADD (
  CONSTRAINT FK1_BILLING_INDV FOREIGN KEY (GRP_ID, SUBLOC_ID, DIV_ID) 
    REFERENCES DCS2000.TBL_GSD (GRP_ID,SUBLOC_ID,DIV_ID));

ALTER TABLE DCS2000.TBL_BILLING_INDV ADD (
  CONSTRAINT FK2_BILLING_INDV FOREIGN KEY (SUBR_ID) 
    REFERENCES DCS2000.TBL_SUBR (SUBR_ID));

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV MODIFY SUBR_ID VARCHAR2(30);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV ADD PRINT_SUBR_ID VARCHAR2(30);
