/* VERSION: 3.1.1 */ 
--
-- TBL_COA_ACCOUNTS  (Table) 
--
CREATE TABLE DCS2000.TBL_COA_ACCOUNTS
(
  ACCOUNT_ID          NUMBER(12)                NOT NULL,
  MAINT_CODE          NUMBER(4),
  CREATED_BY          VARCHAR2(30 BYTE),
  CREATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  ACTIVE_FLAG         VARCHAR2(1 BYTE),
  SEGMENT1_VALUE_ID   NUMBER(12),
  SEGMENT2_VALUE_ID   NUMBER(12),
  SEGMENT3_VALUE_ID   NUMBER(12),
  SEGMENT4_VALUE_ID   NUMBER(12),
  SEGMENT5_VALUE_ID   NUMBER(12),
  SEGMENT6_VALUE_ID   NUMBER(12),
  SEGMENT7_VALUE_ID   NUMBER(12),
  SEGMENT8_VALUE_ID   NUMBER(12),
  SEGMENT9_VALUE_ID   NUMBER(12),
  SEGMENT10_VALUE_ID  NUMBER(12),
  START_DATE          DATE                      NOT NULL,
  END_DATE            DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_COA_ACCOUNTS  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(ACCOUNT_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N1_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N1_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT1_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N2_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N2_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT2_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N3_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N3_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT3_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N4_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N4_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT4_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N5_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N5_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT5_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N6_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N6_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT6_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N7_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N7_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT7_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N8_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N8_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT8_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N9_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N9_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT9_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- N10_COA_ACCOUNTS  (Index) 
--
CREATE INDEX DCS2000.N10_COA_ACCOUNTS ON DCS2000.TBL_COA_ACCOUNTS
(SEGMENT10_VALUE_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_COA_ACCOUNTS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_COA_ACCOUNTS TO PRODDBLINK;

GRANT REFERENCES, SELECT ON  DCS2000.TBL_COA_ACCOUNTS TO AR;

-- 
-- Non Foreign Key Constraints for Table TBL_COA_ACCOUNTS 
-- 
ALTER TABLE DCS2000.TBL_COA_ACCOUNTS ADD (
  CONSTRAINT PK_COA_ACCOUNTS PRIMARY KEY (ACCOUNT_ID)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


