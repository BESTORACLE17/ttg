-- Create table
create table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
(
  MAINT_CODE            NUMBER(4),
  MOD_DTE               DATE,
  MOD_OP                VARCHAR2(30),
  CODE                  NUMBER(4) not null,
  DESCRIPTION           VARCHAR2(100),
  COST_CONTAIN_GROUP    NUMBER(4),
  COST_CONTAIN_CODE     VARCHAR2(2),
  SORT_ORDER            NUMBER(4),
  SOURCE_DATA           VARCHAR2(2000),
  PRECISION             NUMBER,
  FLAG_SHOW_PERCENTAGE  VARCHAR2(1),
  FLAG_SHOW_AS_NEGATIVE VARCHAR2(1)
)
tablespace PROD
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
  add constraint PK_CODE_COST_CONTAIN_CONTROL primary key (CODE)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
  add constraint UK_CODE_COST_CONTAIN_CONTROL unique (DESCRIPTION)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
 alter table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
  add constraint UK_CODE_COST_CONTAIN_CONTROL2 unique (COST_CONTAIN_GROUP,SORT_ORDER)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
  add constraint FK_COST_CTL_TO_COST_CONTAIN foreign key (COST_CONTAIN_CODE)
  references tbl_code_cost_contain (CODE);
  
alter table DCS2000.TBL_CODE_COST_CONTAIN_CONTROL
  add constraint FK_COST_CTL_TO_COST_GROUP foreign key (COST_CONTAIN_GROUP)
  references TBL_CODE_COST_CONTAIN_GROUP (CODE);

-- Grant/Revoke object privileges 
grant select on DCS2000.TBL_CODE_COST_CONTAIN_CONTROL to DCSREPORTS;
grant select, insert, update, delete on DCS2000.TBL_CODE_COST_CONTAIN_CONTROL to DCS_USERS_ALL;
