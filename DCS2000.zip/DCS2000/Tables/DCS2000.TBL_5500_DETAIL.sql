/* 3.1.4 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR 06216.03.AR 
|| Revision By    : Jeff Reynolds
|| Revision Date  : 11/07/2007 
|| Revision Desc  : Expanded amount fields to NUMBER(15,2) and count fields
||                  to NUMBER(13).  Also removed DROP TABLE statement at
||                  beginning of script for installation safety on existing
||                  databases.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3 
|| Revision Type  : Enhancement
|| Service Request: SR08092.23.CO - Override Commissions
|| Revision By    : Deborah Yates
|| Revision Date  : 12/05/2008
|| Revision Desc  : Added the closing_cash_balance column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: SR08092.23.CO - Override Commissions
|| Revision By    : Deborah Yates
|| Revision Date  : 01/20/2009
|| Revision Desc  : Removed the closing_cash_balance column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/


CREATE TABLE DCS2000.TBL_5500_DETAIL ( 
  SEQUENCE_ID       NUMBER (6)    NOT NULL, 
  RECORD_TYPE       NUMBER (2)    NOT NULL, 
  COVERED_INDV_CNT  NUMBER (13),                 /* 3.1.2 */
  PREMIUMS_AMT      NUMBER (15,2),               /* 3.1.2 */
  CLAIMS_AMT        NUMBER (15,2),               /* 3.1.2 */
  RESERVE_OPEN      NUMBER (15,2),               /* 3.1.2 */
  RESERVE_CLOSE     NUMBER (15,2),               /* 3.1.2 */
  MAINT_CODE        NUMBER (4), 
  MOD_DTE           DATE, 
  MOD_OP            VARCHAR2 (12), 
  CONSTRAINT PK_5500_DETAIL
  PRIMARY KEY ( SEQUENCE_ID, RECORD_TYPE ) 
    USING INDEX 
     TABLESPACE PROD PCTFREE 10
     STORAGE ( INITIAL 1064960 NEXT 1048576 PCTINCREASE 0 ))
   TABLESPACE PROD
   PCTFREE 10
   PCTUSED 40
   INITRANS 1
   MAXTRANS 255
  STORAGE ( 
   INITIAL 1064960
   NEXT 1048576
   PCTINCREASE 0
   MINEXTENTS 1
   MAXEXTENTS 2147483645
   FREELISTS 1 FREELIST GROUPS 1 )
   NOCACHE; 

GRANT INSERT ON DCS2000.TBL_5500_DETAIL TO DCS_USERS_ALL;

GRANT SELECT ON DCS2000.TBL_5500_DETAIL TO DCS_USERS_ALL;

GRANT UPDATE ON DCS2000.TBL_5500_DETAIL TO DCS_USERS_ALL;

CREATE OR REPLACE TRIGGER "DCS2000".TRG_5500_DETAIL
 BEFORE INSERT OR UPDATE ON TBL_5500_DETAIL
 FOR EACH ROW
DECLARE
   p_ErrorCode      NUMBER ;
   p_ErrorText      VARCHAR2(500);
BEGIN
   :new.mod_dte    := SYSDATE ;
   :new.mod_op     := USER ;
   :new.maint_code := NVL(:new.maint_code, 0);
EXCEPTION
   WHEN OTHERS THEN
      p_ErrorCode  := SQLCODE ;
      p_ErrorText  := PKG_DCS_ERROR.FNC_GetDCSErrorMsg( p_ErrorCode );
      RAISE_APPLICATION_ERROR( p_ErrorCode, p_ErrorText ) ;
END TRG_5500_DETAIL ;
/

ALTER TABLE DCS2000.TBL_5500_DETAIL ADD  CONSTRAINT FK_5500_DETAIL_2_HEADER
 FOREIGN KEY (SEQUENCE_ID) 
  REFERENCES DCS2000.TBL_5500_HEADER (SEQUENCE_ID) ;

----------------------------------------------------
-- SR 04094.13.NE Form 5500 Reporting
-- Date:   06/18/2004
-- Desc:   Add column RPT_RATING
----------------------------------------------------
alter table DCS2000.TBL_5500_DETAIL add EMPLOYEE_CNT number(13);    /* 3.1.2 */

-- 3.1.3
--ALTER TABLE DCS2000.TBL_5500_DETAIL ADD CLOSING_CASH_BALANCE(15,2);  /* 3.1.4 */