-- Create table
create table DCS2000.TBL_CODE_COST_CONTAIN_GROUP
(
  MAINT_CODE         NUMBER(4),
  MOD_DTE            DATE,
  MOD_OP             VARCHAR2(30),
  CODE               NUMBER(4) not null,
  DESCRIPTION        VARCHAR2(100),
  HEADER_TEXT        VARCHAR2(255),
  FOOTER_TEXT        VARCHAR2(255),
  FLAG_SHOW_HEADER   VARCHAR2(1),
  FLAG_SHOW_FOOTER   VARCHAR2(1),
  FLAG_SHOW_SUBTOTAL VARCHAR2(1)
)
tablespace PROD
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DCS2000.TBL_CODE_COST_CONTAIN_GROUP
  add constraint PK_CODE_COST_CONTAIN_GROUP primary key (CODE)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table DCS2000.TBL_CODE_COST_CONTAIN_GROUP
  add constraint UK_CODE_COST_CONTAIN_GROUP unique (DESCRIPTION)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Grant/Revoke object privileges 
grant select on DCS2000.TBL_CODE_COST_CONTAIN_GROUP to DCSREPORTS;
grant select, insert, update, delete on DCS2000.TBL_CODE_COST_CONTAIN_GROUP to DCS_USERS_ALL;
