/* VERSION: 3.1.1 */ 
--
-- TBL_ADJUD_AQ  (Table) 
--
BEGIN
  DBMS_AQADM.DROP_QUEUE_TABLE
  (
    QUEUE_TABLE           =>        'DCS2000.TBL_ADJUD_AQ'
   ,FORCE                 =>        TRUE
  );
  DBMS_AQADM.CREATE_QUEUE_TABLE
  (
    QUEUE_TABLE           =>        'DCS2000.TBL_ADJUD_AQ'
   ,QUEUE_PAYLOAD_TYPE    =>        'DCS2000.OBJ_ADJUD_PROCESS_MSG'
   ,COMPATIBLE            =>        '8.0.3'
   ,STORAGE_CLAUSE        =>        '
                                     TABLESPACE PROD
                                     PCTUSED    40
                                     PCTFREE    10
                                     INITRANS   1
                                     MAXTRANS   255
                                     STORAGE    (
                                                 INITIAL          1M
                                                 NEXT             1M
                                                 MINEXTENTS       1
                                                 MAXEXTENTS       2147483645
                                                 PCTINCREASE      0
                                                 FREELISTS        1
                                                 FREELIST GROUPS  1
                                                 BUFFER_POOL      DEFAULT
                                                )'
   ,SORT_LIST             =>        'PRIORITY'
   ,MULTIPLE_CONSUMERS    =>         FALSE
   ,MESSAGE_GROUPING      =>         0
   ,COMMENT               =>         'adjudication processes'
   );
End;
/

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ADJUD_AQ TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ADJUD_AQ TO PRODDBLINK;
execute dbms_aqadm.create_queue('adjud_process_001','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_002','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_003','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_005','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_006','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_007','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_008','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_009','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_010','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_011','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_012','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_013','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_014','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_100','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_101','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_102','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_103','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_104','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_105','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_106','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_107','tbl_adjud_aq');
execute dbms_aqadm.create_queue('adjud_process_108','tbl_adjud_aq');
execute dbms_aqadm.start_queue('adjud_process_001',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_002',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_003',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_005',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_006',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_007',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_008',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_009',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_010',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_011',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_012',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_013',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_014',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_100',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_101',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_102',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_103',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_104',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_105',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_106',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_107',TRUE,TRUE);
execute dbms_aqadm.start_queue('adjud_process_108',TRUE,TRUE);

