--=======================================
--SR 03266.01 Ingenix Fees
--DateL 09/26/2005 
--Suresh Vadapalli
--=======================================
/* VERSION: 3.1.1 */ 

CREATE TABLE DCS2000.ACH_FEES_ZIP_DETAIL
(
  FEE_ZIP_KEY  NUMBER(8),                       
  ZIP_AREA     VARCHAR2(3),                     
  PRC_CDE      VARCHAR2(5),                     
  PRCNT_50     NUMBER(8,2),
  PRCNT_60     NUMBER(8,2),
  PRCNT_70     NUMBER(8,2),
  PRCNT_75     NUMBER(8,2),
  PRCNT_80     NUMBER(8,2),
  PRCNT_85     NUMBER(8,2),
  PRCNT_90     NUMBER(8,2),
  PRCNT_95     NUMBER(8,2),
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12),
  INS_UPD_FLAG VARCHAR2(1)
);

GRANT SELECT,INSERT,UPDATE,DELETE ON DCS2000.ACH_FEES_ZIP_DETAIL TO dcs_users_all;


