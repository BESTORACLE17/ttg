/* VERSION 2.0.0 */

-- SR 11105.02.ALL Multi Network
-- Satya Sai
-- 06/21/2011

CREATE TABLE DCS2000.ACH_CODE_PRODUCT_DIRECTORY
      (    CREATED_BY              VARCHAR2(30)        
         , CREATED_ON              DATE               
         , UPDATED_BY              VARCHAR2(30)       
         , UPDATED_ON              DATE               
         , MAINT_CODE              NUMBER(4)  
         , ACTION_CODE             VARCHAR2(1)
         , ACTION_BY               VARCHAR2(30)
         , ACTION_ON               DATE
         , PARENT_ID               NUMBER(4)          
         , PRODUCT_CODE            NUMBER(4) 
         , PLAN_CODE               NUMBER(4)           
         , DIRECTORY_CODE          NUMBER(4)          
         , GRP_ID                  VARCHAR2(9)
         , SUBLOC_ID               VARCHAR2(8)
         , DIV_ID                  VARCHAR2(4)
         , EFF_DATE                DATE                
         , TERM_DATE               DATE                
      );
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_CODE_PRODUCT_DIRECTORY TO COMMON;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_CODE_PRODUCT_DIRECTORY TO DCS_USERS_ALL;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_CODE_PRODUCT_DIRECTORY TO NPFCOMPARE;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_CODE_PRODUCT_DIRECTORY TO PROVIDER;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_CODE_PRODUCT_DIRECTORY TO SECURITY;
/