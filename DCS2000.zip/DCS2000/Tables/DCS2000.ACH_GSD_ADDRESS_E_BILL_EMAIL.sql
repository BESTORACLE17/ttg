/* VERSION: 3.1.3 */ 
--
-- ACH_GSD_ADDRESS_E_BILL_EMAIL  (Table) 
--
/*
| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.1 
|| Revision Type  : Enhancement
|| Service Request: SR 04033.03.VA - phase II 
|| Revision By    : Jeff Reynolds
|| Revision Date  : 01/16/2008 
|| Revision Desc  : Original version.
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR 07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/10/2008 
|| Revision Desc  : Added the following columns
||               1.pk
||               2.action_code
||               3.action_by
||               4.action_on
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_ADDRESS_E_BILL_EMAIL (
   gsd_address_e_bill_email_pk  NUMBER(15)     NOT NULL,
   maint_code                   NUMBER(4),
   created_on                   DATE,
   created_by                   VARCHAR2(30),
   updated_on                   DATE,
   updated_by                   VARCHAR2(30),
   grp_id                       VARCHAR2(9)    NOT NULL,
   subloc_id                    VARCHAR2(8)    NOT NULL,
   div_id                       VARCHAR2(4)    NOT NULL,
   addr_cde                     NUMBER(2)      NOT NULL,
   e_billing_email_address      VARCHAR2(500)  NOT NULL,
   lnme                         VARCHAR2(30),
   fnme                         VARCHAR2(30)
)
TABLESPACE PROD;

--Version 3.1.2
--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_ADDRESS_E_BILL_EMAIL ADD (pk NUMBER);

ALTER TABLE DCS2000.ACH_GSD_ADDRESS_E_BILL_EMAIL ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS_E_BILL_EMAIL ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS_E_BILL_EMAIL ADD (action_on DATE);
--End SR07109.04.VA
