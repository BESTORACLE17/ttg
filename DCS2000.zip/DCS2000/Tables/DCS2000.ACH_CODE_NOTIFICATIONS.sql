--=======================================
--SR 07109.04 VA GM QUALITY EDITS
--Date 06/30/2008 
--Pramod Gujjar
--=======================================
/* VERSION: 3.1.1 */ 
CREATE TABLE DCS2000.ACH_CODE_NOTIFICATIONS
( CREATED_BY                    VARCHAR2(30),
  CREATED_ON                    DATE,
  UPDATED_BY                    VARCHAR2(30),
  UPDATED_ON                    DATE,
  MAINT_CODE                    NUMBER (4),
  CODE_PK                       NUMBER(1)       NOT NULL,
  DESCRIPTION                   VARCHAR2(30)    NOT NULL,
  EMAIL_ID                      VARCHAR2(200)    NOT NULL
);
GRANT INSERT, SELECT, UPDATE, DELETE ON DCS2000.ACH_CODE_NOTIFICATIONS TO DCS_USERS_ALL;