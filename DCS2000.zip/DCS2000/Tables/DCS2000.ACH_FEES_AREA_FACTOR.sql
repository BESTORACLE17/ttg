/* VERSION: 2.1.1 */
--
-- TBL_FEES_AREA_FACTOR  (Table) 
--

CREATE TABLE DCS2000.ACH_FEES_AREA_FACTOR
(
   MAINT_CODE           NUMBER(4)
  ,MOD_DTE              DATE
  ,MOD_OP               VARCHAR2(12 BYTE)
  ,INS_UPD_FLAG         VARCHAR2(1) 
  ,REGION_CODE          NUMBER(4)
  ,AREA_FACTOR          NUMBER(4,3)
  ,STATE                    VARCHAR2(2 BYTE)
  ,STATE_FACTOR         NUMBER(4,3)
)
TABLESPACE PROD;
