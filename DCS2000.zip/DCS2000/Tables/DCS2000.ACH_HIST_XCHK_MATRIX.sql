/* VERSION: 3.1.2 */ 
--
-- ACH_HIST_XCHK_MATRIX  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2
|| Revision Type  : Enhancement
|| Service Request: SR07106.01.AR Ability to history cross check according to
||                : a pariticular surface
|| Revision By    : Sanjay Mudaliar.
|| Revision Date  : 07/07/2008 
|| Revision Desc  : Surface columns added to ACH_HIST_XCHK_MATRIX
||                  dropped primary key
||                  GSD and XCHK GSD added to the unique key
||                  added new column with corresponding sequence for primary key
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_HIST_XCHK_MATRIX
(
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  COMPANY_ID       NUMBER(4),
  XCHK_COMPANY_ID  NUMBER(4),
  INS_UPD_FLAG     CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_HIST_XCHK_MATRIX TO DCS_USERS_ALL;

--Start 3.1.2

ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (GRP_ID VARCHAR2(9) );
   
ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (SUBLOC_ID VARCHAR2(8) );
  
ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (DIV_ID VARCHAR2(4) );
   
ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (XCHK_GRP_ID VARCHAR2(9) );
   
ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (XCHK_SUBLOC_ID VARCHAR2(8) );
   
ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (XCHK_DIV_ID VARCHAR2(4) );

ALTER TABLE DCS2000.ACH_HIST_XCHK_MATRIX ADD (PK_HIST_XCHK_MATRIX NUMBER(15) );

--End 3.1.2