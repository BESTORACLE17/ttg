/* VERSION: 3.1.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : NEW
|| Version #      : 3.1.1
|| Service Request: SR# 07178.02.KY Individual Product Processing Enhancements
|| Revision By    : KETAN PATEL
|| Revision Date  : 01/08/2008.
|| Revision Desc  : CREATED TABLE
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_PRODUCER (Table) 
--


CREATE TABLE DCS2000.ACH_SUBR_PRODUCER 
(  subr_producer_pk  NUMBER(15)     NOT NULL,    
   maint_code        NUMBER         NOT NULL,
   created_on        DATE           NOT NULL,
   created_by        VARCHAR2(30)   NOT NULL,
   updated_on        DATE           NOT NULL,
   updated_by        VARCHAR2(30)   NOT NULL,
   subr_id           VARCHAR2(30)   NOT NULL,
   indv_id           NUMBER(2)      NOT NULL,
   producer_id       NUMBER(15)     NOT NULL,
   eff_dte           DATE           NOT NULL, 
   trm_dte           DATE )
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           ) 
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;


GRANT SELECT ON  DCS2000.ACH_SUBR_PRODUCER TO DCSREPORTS WITH GRANT OPTION;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_PRODUCER TO DCS_USERS_ALL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_PRODUCER TO EEP;

GRANT SELECT ON  DCS2000.ACH_SUBR_PRODUCER TO OPENCON;

GRANT SELECT ON  DCS2000.ACH_SUBR_PRODUCER TO PRODDBLINK;

