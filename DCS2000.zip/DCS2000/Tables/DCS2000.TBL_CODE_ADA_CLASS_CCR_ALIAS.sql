-- Create table
create table DCS2000.TBL_CODE_ADA_CLASS_CCR_ALIAS
(
  CODE        NUMBER(4) not null,
  DESCRIPTION VARCHAR2(100),
  SORT_ORDER  NUMBER(4),
  MAINT_CODE  NUMBER(4),
  MOD_DTE     DATE,
  MOD_OP      VARCHAR2(30)
)
tablespace PROD
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DCS2000.TBL_CODE_ADA_CLASS_CCR_ALIAS
  add constraint PK_CODE_ADA_CLASS_CCR_ALIAS primary key (CODE)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
alter table DCS2000.TBL_CODE_ADA_CLASS_CCR_ALIAS
  add constraint UK_CODE_ADA_CLASS_CCR_ALIAS unique (DESCRIPTION)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1M
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Grant/Revoke object privileges 
grant select on DCS2000.TBL_CODE_ADA_CLASS_CCR_ALIAS to DCSREPORTS with grant option;
grant select, insert, update, delete on DCS2000.TBL_CODE_ADA_CLASS_CCR_ALIAS to DCS_USERS_ALL;
