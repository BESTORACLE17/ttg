--********************
-- ACH_GA_PRODUCT_PLAN_HEADER
-- SR - 07109.01.VA
-- version 2.1.1
--********************
CREATE TABLE DCS2000.ACH_GA_PRODUCT_PLAN_HEADER
(
   CREATED_BY                 VARCHAR2(12 BYTE),
   CREATED_ON                 DATE,   
   UPDATED_BY                 VARCHAR2(12 BYTE),
   UPDATED_ON                 DATE,
   MAINT_CODE                 NUMBER(4),
   ACTION_CODE                VARCHAR2(1 BYTE),
   ACTION_BY                  VARCHAR2(30 BYTE),
   ACTION_ON                  DATE,          
   PRODUCT_PLAN_HEADER_PK     NUMBER(9),          
   PRODUCT_PLAN_ID            NUMBER(12),       
   PRODUCT_PLAN_NAME          VARCHAR2(100 BYTE),  
   EFF_DATE                   DATE,                
   TERM_DATE                  DATE,
   TERM_REASON_CODE           NUMBER(4),
   COMMENTS                   VARCHAR2(200 BYTE),
   NOTES                      VARCHAR2(200 BYTE)
);
 