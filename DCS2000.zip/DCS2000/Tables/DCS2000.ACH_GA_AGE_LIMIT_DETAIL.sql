--********************
-- ACH_GA_AGE_LIMIT_DETAIL
-- SR - 07109.01.VA
--********************
CREATE TABLE DCS2000.ACH_GA_AGE_LIMIT_DETAIL
(
  CREATED_BY               VARCHAR2(12 BYTE),
  CREATED_ON               DATE,   
  UPDATED_BY               VARCHAR2(12 BYTE),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  USER_DEFINED_FIELD1      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD2      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD3      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD4      VARCHAR2(100 BYTE),
  ACTION_CODE              VARCHAR2(1 BYTE),
  ACTION_BY                VARCHAR2(30 BYTE),
  ACTION_ON                DATE,   
  AGE_LIMIT_DETAIL_PK      NUMBER(9),
  AGE_LIMIT_HEADER_PK      NUMBER(9),
  AGE_LIMIT_TYPE_CODE      NUMBER(2),
  RELATIONSHIP_CODE        NUMBER(4),
  EFF_DATE                 DATE, 
  TERM_DATE                DATE,                 
  TERM_REASON_CODE         NUMBER(4),
  COMMENTS                 VARCHAR2(200 BYTE),
  NOTES                    VARCHAR2(200 BYTE),  
  AGE_LIMIT                NUMBER(3),
  AGE_LIMIT_COVER_CODE     NUMBER(2),
  DISPLAY_ON_WEB           NUMBER(1)
);
