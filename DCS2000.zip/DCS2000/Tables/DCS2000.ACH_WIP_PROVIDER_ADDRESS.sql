CREATE TABLE DCS2000.ACH_WIP_PROVIDER_ADDRESS
(
  CREATED_BY               VARCHAR2(30)    NOT NULL,
  CREATED_ON               DATE                 NOT NULL,
  UPDATED_BY               VARCHAR2(30 )    NOT NULL,
  UPDATED_ON               DATE                 NOT NULL,
  MAINT_CODE               NUMBER(4)            NOT NULL,
  WIP_PROVIDER_ADDRESS_PK  NUMBER(12)           NOT NULL,
  CLAIM_NO                 VARCHAR2(14 ),
  ADDRESS_LINE1            VARCHAR2(64 ),
  ADDRESS_LINE2            VARCHAR2(64 ),
  ADDRESS_LINE3            VARCHAR2(64 ),
  CITY                     VARCHAR2(60 ),
  STATE                    VARCHAR2(2 ),
  ZIP                      VARCHAR2(5 ),
  ZIP4                     VARCHAR2(4 ),
  PHONE                    VARCHAR2(30 ),
  FAX                      VARCHAR2(30 ),
  EMAIL_ADDRESS            VARCHAR2(30 ),
  FIRST_NAME               VARCHAR2(50 ),
  LAST_NAME                VARCHAR2(50 ),
  ACTION_CODE              VARCHAR2(1 ),
  ACTION_BY                VARCHAR2(30 ),
  ACTION_ON                DATE,
  USE_FOR_MAILING          NUMBER(4),
  PARENT_ID                NUMBER(4)
)
TABLESPACE PROD
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


GRANT SELECT ON DCS2000.ACH_WIP_PROVIDER_ADDRESS TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_WIP_PROVIDER_ADDRESS TO DCS_USERS_ALL;
