/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR05085.13.VA - Access Bills through DCSWEB
|| Revision By    : Jeff Reynolds
|| Revision Date  : 08/21/2007.
|| Revision Desc  : Added columns E_BILLING_EMAIL_1 and E_BILLING_EMAIL_2.
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


*/
--
-- ACH_SUBR_INDV_PAYMENT_METHOD  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_PAYMENT_METHOD
(
  SUBR_ID                     VARCHAR2(9 BYTE)  NOT NULL,
  INDV_ID                     NUMBER(2)         NOT NULL,
  PAYMENT_METHOD_CODE         NUMBER(4)         NOT NULL,
  EFF_DTE                     NUMBER(8)         NOT NULL,
  TRM_DTE                     NUMBER(8),
  BANK_ROUTING_NUMBER         VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER         VARCHAR2(30 BYTE),
  CREDIT_CARD_NUMBER          VARCHAR2(30 BYTE),
  CREDIT_CARD_TYPE_CODE       NUMBER(4),
  CREDIT_CARD_EXPIRE_YEAR     VARCHAR2(4 BYTE),
  CREDIT_CARD_EXPIRE_MONTH    VARCHAR2(2 BYTE),
  MAINT_CODE                  NUMBER(4),
  MOD_DTE                     DATE,
  MOD_OP                      VARCHAR2(30 BYTE),
  BANK_ACH_DETAIL_ID          NUMBER(4),
  BANK_ACCOUNT_TYPE_CODE      NUMBER(4),
  PAYMENT_METHOD_ACTIVE_FLAG  VARCHAR2(1 BYTE),
  E_BILLING_EMAIL_1           VARCHAR2(500 BYTE),           -- Version 3.1.3
  E_BILLING_EMAIL_2           VARCHAR2(500 BYTE)            -- Version 3.1.3
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

ALTER TABLE DCS2000.ACH_SUBR_INDV_PAYMENT_METHOD MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_INDV_PAYMENT_METHOD TO DCS_USERS_ALL;

