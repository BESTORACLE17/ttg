CREATE TABLE DCS2000.ACH_CODE_PRICING_SET_PRODUCT
(
  CREATED_BY            VARCHAR2(12 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(12 BYTE),
  UPDATED_ON            DATE,
  MAINT_CODE            NUMBER(4),
  ACTION_CODE           VARCHAR2(1 BYTE),
  ACTION_BY             VARCHAR2(30 BYTE),
  ACTION_ON             DATE,
  PRICING_SET_CODE      NUMBER(4),
  PRODUCT_CODE          NUMBER(4)  
)
TABLESPACE PROD;

COMMENT ON TABLE DCS2000.ACH_CODE_PRICING_SET_PRODUCT               IS 'Table that describes the describes the mapping between a Product Code and Pricing Set Code.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.CREATED_BY   IS 'User ID of the user who created the row.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.CREATED_ON   IS 'Date on which the row was created.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.UPDATED_BY   IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.UPDATED_ON   IS 'Date on which the row was last updated.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.ACTION_CODE  IS 'Action (Insert/Update/Delete) that was taken on the production record that caused old maintenance record to be archived. I = Insert, U = Update, and D = Delete.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.ACTION_BY    IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.ACTION_ON    IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.PRICING_SET_CODE     IS 'System generated PK for the Pricing Set Code table ';

COMMENT ON COLUMN DCS2000.ACH_CODE_PRICING_SET_PRODUCT.PRODUCT_CODE         IS 'System generated PK for the Product Code table.';
