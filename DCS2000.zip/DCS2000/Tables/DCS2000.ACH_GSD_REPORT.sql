/* VERSION: 3.1.6 */ 
--
-- ACH_GSD_REPORT  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR 04033.03.VA Phase II - ASO Billing Enhancements
|| Revision By    : Jeff Reynolds
|| Revision Date  : 01/21/2008 
|| Revision Desc  : Added CODE_RPT_GROUPING_PK 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3 
|| Revision Type  : Enhancement
|| Service Request: SR07178.03.KY Overage Dep Processing  
|| Revision By    : Ketan Patel.
|| Revision Date  : 03/02/2008 
|| Revision Desc  : Added following columns EFF_DTE,TRM_DTE,REPORT_DEST_CODE,AUTO_TERM_OVERAGE_DEP_FLAG
                     DEP_VER_LETTER_PK,CONTINUING_STU_VER_LETTER_PK,FINAL_DEP_VER_LETTER_PK     
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4 
|| Revision Type  : Enhancement
|| Service Request: SR07178.03.KY Overage Dep Processing  
|| Revision By    : Ketan Patel.
|| Revision Date  : 03/26/2008 
|| Revision Desc  : Added following column AUTO_RATE_CHANGE_FLAG   
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.5 
|| Revision Type  : Enhancement
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar.
|| Revision Date  : 06/10/2008 
|| Revision Desc  : Added the following columns
||                1.pk
||                2.created_by 
||                3.created_on 
||                4.updated_by 
||                5.updated_on 
||                6.action_code
||                7.action_by
||                8.action_on
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.6 
|| Revision Type  : Enhancement
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar.
|| Revision Date  : 06/13/2008 
|| Revision Desc  : Renamed column pk to GSD_REPORT_PK
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

*/
CREATE TABLE DCS2000.ACH_GSD_REPORT
(
  GRP_ID        VARCHAR2(9 BYTE),
  SUBLOC_ID     VARCHAR2(8 BYTE),
  DIV_ID        VARCHAR2(4 BYTE),
  RPT_CDE       NUMBER(2),
  RPT_FREQ_CDE  NUMBER(2),
  RPT_FREQ      NUMBER(4),
  RPT_RUN_DTE   NUMBER(8),
  MAINT_CODE    NUMBER(4),
  MOD_DTE       DATE,
  MOD_OP        VARCHAR2(12 BYTE),
  COMMENTS      VARCHAR2(1000 BYTE),
  INS_UPD_FLAG  CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_REPORT TO DCS_USERS_ALL;

-- Version 3.1.2
ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (
  CODE_RPT_GROUPING_PK   NUMBER(10)
);

-- 3.1.3

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD(   EFF_DTE                          NUMBER(8),
                                          TRM_DTE                          NUMBER(8),
                                          REPORT_DEST_CODE                 NUMBER(4),
                                          AUTO_TERM_OVERAGE_DEP_FLAG       VARCHAR2(1) CHECK(AUTO_TERM_OVERAGE_DEP_FLAG IN ('Y','N')),
                                          DEP_VER_LETTER_PK                NUMBER(4),
                                          CONTINUING_STU_VER_LETTER_PK     NUMBER(4),
                                          FINAL_DEP_VER_LETTER_PK          NUMBER(4)
                                      ) ;

-- 3.1.4                                      
ALTER TABLE DCS2000.ACH_GSD_REPORT ADD AUTO_RATE_CHANGE_FLAG VARCHAR2(1) ;


--Start 3.1.5
ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (gsd_report_pk NUMBER); --3.1.6

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_REPORT ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_REPORT ON DCS2000.ACH_GSD_REPORT(GRP_ID,SUBLOC_ID,DIV_ID,RPT_CDE) TABLESPACE PRODIX;
--End 3.1.5