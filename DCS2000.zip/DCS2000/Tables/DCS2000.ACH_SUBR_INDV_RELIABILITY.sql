/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV_RELIABILITY  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_RELIABILITY
(
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  SUBR_ID              VARCHAR2(9 BYTE),
  INDV_ID              NUMBER(2),
  EFF_DTE              NUMBER(8),
  TRM_DTE              NUMBER(8),
  AUTO_GENERATED_FLAG  VARCHAR2(1 BYTE),
  INS_UPD_FLAG         VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_INDV_RELIABILITY MODIFY SUBR_ID VARCHAR2(30);

GRANT SELECT ON  DCS2000.ACH_SUBR_INDV_RELIABILITY TO DCS_USERS_ALL;

