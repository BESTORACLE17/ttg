/* VERSION: 3.1.1 */ 
--
-- ACH_DOC_IMAGE_DETAILS  (Table) 
--
CREATE TABLE DCS2000.ACH_DOC_IMAGE_DETAILS
(
  MAINT_CODE              NUMBER(4),
  MOD_DTE                 DATE,
  MOD_OP                  VARCHAR2(12 BYTE),
  DOC_HEADER_ID           NUMBER(15),
  DOC_DETAIL_ID           NUMBER(15),
  EFF_DTE                 NUMBER(8),
  TRM_DTE                 NUMBER(8),
  CONTACT_NAME            VARCHAR2(60 BYTE),
  ADDR1                   VARCHAR2(30 BYTE),
  ADDR2                   VARCHAR2(30 BYTE),
  ADDR3                   VARCHAR2(30 BYTE),
  CITY                    VARCHAR2(30 BYTE),
  STATE                   VARCHAR2(2 BYTE),
  ZIP                     VARCHAR2(9 BYTE),
  ADDRESS_TYPE_CODE       NUMBER(4),
  PHONE                   VARCHAR2(30 BYTE),
  FAX                     VARCHAR2(30 BYTE),
  EMAIL_ADDRESS           VARCHAR2(60 BYTE),
  BROKER_ID               VARCHAR2(9 BYTE),
  AGENCY_ID               VARCHAR2(9 BYTE),
  DESIGNEE_ID             VARCHAR2(9 BYTE),
  DESIGNEE_INDV_ID        NUMBER(2),
  INFO_TYPE_ALLOWED_CODE  NUMBER(4),
  INFO_XFER_TYPE_CODE     NUMBER(4),
  TERM_EVENT_CODE         NUMBER(4),
  REMUNERATION_FLAG       VARCHAR2(1 BYTE),
  COMMENTS                VARCHAR2(2000 BYTE),
  BUSINESS_NAME           VARCHAR2(60 BYTE),
  CONTACT_TITLE           VARCHAR2(30 BYTE),
  CONTACT_DEPT            VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_DOC_IMAGE_DETAILS TO DCS_USERS_ALL;

alter table dcs2000.ach_doc_image add PRODUCER_ID        NUMBER(15);
-- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DCS2000.ACH_DOC_IMAGE_DETAILS modify 
  (ADDR1    VARCHAR2(64 ),
   ADDR2    VARCHAR2(64 ),
   ADDR3    VARCHAR2(64 )
  );