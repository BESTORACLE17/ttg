/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_BILLING_RULES  (Table) 
--
CREATE TABLE DCS2000.TBL_CODE_BILLING_RULES
(
  MAINT_CODE    NUMBER(4),
  MOD_DTE       DATE,
  MOD_OP        VARCHAR2(12 BYTE),
  CODE          NUMBER(2)                       NOT NULL,
  DAY           NUMBER(2)                       NOT NULL,
  RULE          NUMBER(4)                       NOT NULL,
  DESCRIPTION   VARCHAR2(30 BYTE),
  INITIAL_ONLY  NUMBER(2)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CODE_BILL_RULES  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CODE_BILL_RULES ON DCS2000.TBL_CODE_BILLING_RULES
(CODE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_BILLING_RULES TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CODE_BILLING_RULES TO PRODDBLINK;

GRANT SELECT ON  DCS2000.TBL_CODE_BILLING_RULES TO OPENCON;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_BILLING_RULES 
-- 
ALTER TABLE DCS2000.TBL_CODE_BILLING_RULES ADD (
  CONSTRAINT PK_CODE_BILL_RULES PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          16K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


