/* VERSION: 3.1.3*/ 
--
-- ACH_GSD_CARRY_OVER_BENEFITS  (Table) 
--
-- SR07109.04.VA
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_CARRY_OVER_BENEFITS
(
  GRP_ID                VARCHAR2(9),
  SUBLOC_ID             VARCHAR2(8),
  DIV_ID                VARCHAR2(4),
  PRD_CDE               NUMBER(4),
  PLN_CDE               NUMBER(4),
  EFF_DTE               NUMBER(8),
  TRM_DTE               NUMBER(8),
  CARRY_OVER_ALLOWED    NUMBER(4),
  MAXIMUM_AMT           NUMBER(8,2),
  CLAIMS_THRESHOLD_AMT  NUMBER(8,2),
  ACCOUNT_MAXIMUM_AMT   NUMBER(8,2),
  EFF_PERIOD_MM         NUMBER(4),
  CARRY_OVER_IMMEDIATE  NUMBER(4),
  MAINT_CODE            NUMBER(4),
  MOD_DTE               DATE,
  MOD_OP                VARCHAR2(12),
  GSD_CARRY_OVER_BENEFITS_PK    NUMBER,
  CREATED_BY            VARCHAR2(30),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30),
  UPDATED_ON            DATE,
  ACTION_CODE           VARCHAR2(1),
  ACTION_BY             VARCHAR2(30),
  ACTION_ON             DATE
);
GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_CARRY_OVER_BENEFITS TO DCS_USERS_ALL;
CREATE INDEX DCS2000.IX_ACH_GSD_CARRY_OVER_BENEFITS ON DCS2000.ACH_GSD_CARRY_OVER_BENEFITS(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,EFF_DTE);
/
ALTER TABLE DCS2000.ACH_GSD_CARRY_OVER_BENEFITS ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.3
/