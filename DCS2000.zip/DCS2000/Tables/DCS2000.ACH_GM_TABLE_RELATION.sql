/* VERSION: 2.1.1 */
CREATE TABLE DCS2000.ACH_GM_TABLE_RELATION
(
  CREATED_BY            VARCHAR2(30 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30 BYTE),
  UPDATED_ON            DATE,
  MAINT_CODE            NUMBER(4),
  ACTION_CODE           VARCHAR2(1 BYTE),
  ACTION_BY             VARCHAR2(30 BYTE),
  ACTION_ON             DATE,
  TABLE_RELATION_PK     NUMBER(12),
  PARENT_TABLE_PK       NUMBER(12),
  CHILD_TABLE_PK        NUMBER(12),
  OWNER                 VARCHAR2(30 BYTE),
  PACKAGE_NAME          VARCHAR2(30 BYTE),
  PROCEDURE_NAME        VARCHAR2(30 BYTE),
  PROCEDURE_CALL_TYPE   NUMBER,
  EXECUTION_ORDER       NUMBER(4)
)
TABLESPACE PROD ;

COMMENT ON TABLE DCS2000.ACH_GM_TABLE_RELATION IS 'Table that defines relationships among application tables in DCS module.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.CREATED_BY IS 'User ID of the user who created the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.CREATED_ON IS 'Date on which the row was created.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.UPDATED_BY IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.UPDATED_ON IS 'Date on which the row was last updated.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.ACTION_CODE  IS 'Action (Insert/Update/Delete) that was taken on the production record that caused old maintenance record to be archived. I = Insert, U = Update, and D = Delete.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.ACTION_BY    IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.ACTION_ON    IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.TABLE_RELATION_PK IS 'System generated PK of the table.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.PARENT_TABLE_PK IS 'System generated PK of the Parent table.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_RELATION.CHILD_TABLE_PK IS 'System generated PK of the Child table.';
