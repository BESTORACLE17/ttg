--
-- TBL_CODE_ADJUD_AUTO_CLOSE  (Table) 
--
CREATE TABLE DCS2000.TBL_CODE_ADJUD_AUTO_CLOSE
(
  CODE         NUMBER(4)                        NOT NULL,
  DESCRIPTION  VARCHAR2(100)                    NOT NULL,
  MAINT_CODE   NUMBER(4)                        NOT NULL,
  MOD_DTE      DATE                             NOT NULL,
  MOD_OP       VARCHAR2(12)                     NOT NULL
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL
/

comment on table DCS2000.TBL_CODE_ADJUD_AUTO_CLOSE is
'Used to identify errors that must be reviewed even if all lines denied.'
;



--
-- PK_CODE_ADJUD_AUTO_CLOSE  (Index) 
--

ALTER TABLE DCS2000.TBL_CODE_ADJUD_AUTO_CLOSE ADD (
  CONSTRAINT PK_CODE_ADJUD_AUTO_CLOSE PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ))
/

CREATE OR REPLACE TRIGGER DCS2000.TRG_CODE_ADJUD_AUTO_CLOSE
 BEFORE INSERT OR UPDATE on TBL_CODE_ADJUD_AUTO_CLOSE
 FOR EACH ROW
DECLARE
   p_ErrorCode      NUMBER ;
   p_ErrorText      VARCHAR2(500);
BEGIN
   :new.mod_dte    := SYSDATE ;
   :new.mod_op     := USER ;
   :new.maint_code := NVL(:new.maint_code, 0);
EXCEPTION
   WHEN OTHERS THEN
      p_ErrorCode  := SQLCODE ;
      p_ErrorText  := PKG_DCS_ERROR.FNC_GetDCSErrorMsg( p_ErrorCode );
      RAISE_APPLICATION_ERROR( p_ErrorCode, p_ErrorText ) ;
END TRG_CODE_ADJUD_AUTO_CLOSE;
/
SHOW ERRORS;

