/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_COB_BANK  (Table) 
--
CREATE TABLE DCS2000.TBL_COB_BANK
(
  PERIOD_YYYYMM  NUMBER(6)                      NOT NULL,
  SUBR_ID        VARCHAR2(9 BYTE)               NOT NULL,
  INDV_ID        NUMBER(4)                      NOT NULL,
  GRP_ID         VARCHAR2(11 BYTE)              NOT NULL,
  BGN_BANK       NUMBER(8,2),
  USE_BANK       NUMBER(8,2),
  CLAIM_NO       VARCHAR2(14 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_TBL_COB_BANK  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_TBL_COB_BANK ON DCS2000.TBL_COB_BANK
(PERIOD_YYYYMM, SUBR_ID, INDV_ID, GRP_ID)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_COB_BANK TO DCS_USERS_ALL;

-- 
-- Non Foreign Key Constraints for Table TBL_COB_BANK 
-- 
ALTER TABLE DCS2000.TBL_COB_BANK ADD (
  CONSTRAINT PK_TBL_COB_BANK PRIMARY KEY (PERIOD_YYYYMM, SUBR_ID, INDV_ID, GRP_ID)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_COB_BANK MODIFY SUBR_ID VARCHAR2(30);

