/* VERSION: 2.1.2 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR#05001.02.NE NEDD Production Support 
|| Revision By    : Russell Hertzberg
|| Revision Date  : 02/25/2005 
|| Revision Desc  : Modified the BANK_CHECK_AMT to be VARCHAR2(12) - it was VARCHAR2(10) 
|| Production Date:
|| Production By  :
|| Dependencies   :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_CHECK_CLEARED_FILE  (Table) 
--
CREATE TABLE DCS2000.TBL_CHECK_CLEARED_FILE
(
  RUN_DATE             DATE                NOT NULL,
  CHECK_NUMBER         VARCHAR2(10)        NOT NULL,
  BANK_CHECK_AMT       VARCHAR2(12),
  BANK_CLEARED_DTE     VARCHAR2(8),
  BANK_ACCOUNT_NUMBER  VARCHAR2(40),
  CHECK_ISSUE_DATE     VARCHAR2(8),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CHECK_CLEARED_FILE  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CHECK_CLEARED_FILE ON DCS2000.TBL_CHECK_CLEARED_FILE
(CHECK_NUMBER, RUN_DATE)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- CHECK_CLEARED_FILE_CHECK_FIX  (Index) 
--
CREATE INDEX DCS2000.CHECK_CLEARED_FILE_CHECK_FIX ON DCS2000.TBL_CHECK_CLEARED_FILE
(LTRIM("CHECK_NUMBER",'0'))
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CHECK_CLEARED_FILE TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CHECK_CLEARED_FILE TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_CHECK_CLEARED_FILE 
-- 
ALTER TABLE DCS2000.TBL_CHECK_CLEARED_FILE ADD (
  CONSTRAINT PK_CHECK_CLEARED_FILE PRIMARY KEY (CHECK_NUMBER, RUN_DATE)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1040K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


