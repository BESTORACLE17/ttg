/* VERSION: 3.1.3 */
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: SR# 10089.02.VA - Enrollment Source
|| Revision By    : Scott E. Hunley
|| Revision Date  : 05/04/2010
|| Revision Desc  : Added ENROLLMENT_SRC_CODE column to mirror tbl_subr_indv
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV
(
  SUBR_ID           VARCHAR2(9 BYTE),
  INDV_ID           NUMBER(2),
  INDV_EFF_DTE      NUMBER(8),
  TRM_DTE           NUMBER(8),
  TRM_REASON_CDE    NUMBER(2),
  SSN               NUMBER(12),
  RELSHP_CDE        NUMBER(2),
  LNME              VARCHAR2(30 BYTE),
  FNME              VARCHAR2(30 BYTE),
  MNME              VARCHAR2(30 BYTE),
  DOB               NUMBER(8),
  HANDICAP_CDE      NUMBER(2),
  HANDICAP_EFF_DTE  NUMBER(8),
  SEX_CDE           NUMBER(2),
  MARITAL_STS       NUMBER(2),
  MAINT_CODE        NUMBER(4),
  MOD_DTE           DATE,
  MOD_OP            VARCHAR2(12 BYTE),
  INS_UPD_FLAG      VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          85M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACH_SUBR_INDV_IDX  (Index) 
--
CREATE INDEX DCS2000.ACH_SUBR_INDV_IDX ON DCS2000.ACH_SUBR_INDV
(SUBR_ID, INDV_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_INDV MODIFY SUBR_ID VARCHAR2(30);
ALTER TABLE DCS2000.ACH_SUBR_INDV ADD GSD_PK NUMBER(15);
ALTER TABLE DCS2000.ACH_SUBR_INDV ADD DCS_INDIVIDUAL_IDENTIFIER VARCHAR2(30);
ALTER TABLE DCS2000.ACH_SUBR_INDV ADD DCS_ASSIGNED_ID VARCHAR2(30);
ALTER TABLE DCS2000.ACH_SUBR_INDV ADD ENROLLMENT_SRC_CODE NUMBER(4);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_INDV TO DCS_USERS_ALL;