/* Version 3.0.0 
 Satya sai
 SR 10340.01.VA
*/
CREATE TABLE DCS2000.ACH_TPA
         ( CREATED_BY           VARCHAR2(30),
           CREATED_ON           DATE,
           UPDATED_ON           DATE,
           UPDATED_BY           VARCHAR2(12),
           MAINT_CODE           NUMBER(4),
           ACTION_CODE          VARCHAR2(1),
           ACTION_BY            VARCHAR2(30),
           ACTION_ON            DATE,
           TPA_ID               NUMBER(4)         ,
           TPA_NAME             VARCHAR2(200)     ,
           TELEPHONE_LOCAL      VARCHAR2(30),
           TELEPHONE_TOLL_FREE  VARCHAR2(30),
           WEBSITE              VARCHAR2(1000),
           BRAND_CODE           NUMBER(4)         ,
           FAX_NUMBER           VARCHAR2(30)
         );
GRANT SELECT ON DCS2000.ACH_TPA TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_TPA TO DCS_USERS_ALL;