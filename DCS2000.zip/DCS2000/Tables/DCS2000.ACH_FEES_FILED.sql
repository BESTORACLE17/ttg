/* VERSION: 3.1.3 */ 
--
-- ACH_FEES_FILED  (Table) 
--
CREATE TABLE DCS2000.ACH_FEES_FILED
(
  PRV_ID          VARCHAR2(11 BYTE),
  LOC             NUMBER(4),
  TAX_ID          VARCHAR2(9 BYTE),
  FAC_STATE       VARCHAR2(2 BYTE),
  PRC_CDE         VARCHAR2(5 BYTE),
  EFF_DTE         NUMBER(8),
  TRM_DTE         NUMBER(8),
  FEE             NUMBER(7,2),
  PRODUCT_CODE    NUMBER(4),
  SPECIALTY_CODE  NUMBER(4),
  NEW_MAINT_CODE  NUMBER(4),
  OLD_MAINT_CODE  NUMBER(4),
  INS_UPD_FLAG    VARCHAR2(1 BYTE),
  NPF_PROC_DATE   DATE,
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          251080K
            NEXT             20M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACH_FEES_FILED_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_FEES_FILED_IX ON DCS2000.ACH_FEES_FILED
(PRV_ID, LOC, TAX_ID, PRC_CDE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          180M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_FEES_FILED TO DCS_USERS_ALL;
/
Alter table dcs2000.ACH_FEES_FILED add( NETWORK_ID NUMBER(4)); -- 3.1.3 Satya 11105.02.ALL Multi network 
/

