/* VERSION 1.1.1 */

/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version Number : 1.1.1
|| Revision Type  : Creation
|| Service Request: SR#08249.01.AR - Online Billing Adjustments
|| Revision By    : Deborah Yates
|| Revision Date  : 01/23/2009
|| Revision Desc  : Created to temporarily store online billing adjustments
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

CREATE TABLE DCS2000.TBL_BILLING_ONLINE_ADJUST_EXP
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE)     NOT NULL,
  SUBLOC_ID                VARCHAR2(8 BYTE)     NOT NULL,
  DIV_ID                   VARCHAR2(4 BYTE)     NOT NULL,
  BILL_DATE                NUMBER(8)            NOT NULL,
  BILL_FROM_DATE           NUMBER(8)            NOT NULL,
  BILL_NO_OF_MONTHS        NUMBER(4)            NOT NULL,
  BILL_DUE_DATE            NUMBER(8)            NOT NULL,
  BILL_COUNT               NUMBER(7)            NOT NULL,
  BILL_AMT                 NUMBER(9,2)          NOT NULL,
  ASO_RISK_TYPE            NUMBER(2)            NOT NULL,
  PRODUCT_CODE             NUMBER(4)            NOT NULL,
  BILLING_CODE             NUMBER(12)           NOT NULL,
  REC_ACCOUNT_CODE         NUMBER(12)           NOT NULL,
  UNEARN_REV_ACCOUNT_CODE  NUMBER(12)           NOT NULL,
  REV_ACCOUNT_CODE         NUMBER(12)           NOT NULL,
  AR_TRANSFER_DATE         DATE,
  BILLING_CYCLE            NUMBER(2),
  SUBR_COUNT               NUMBER(7)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
MONITORING;


GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.TBL_BILLING_ONLINE_ADJUST_EXP TO AR;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.TBL_BILLING_ONLINE_ADJUST_EXP TO DCS_USERS_ALL;
