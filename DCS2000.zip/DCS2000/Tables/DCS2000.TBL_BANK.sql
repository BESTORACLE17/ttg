/* VERSION: 3.1.1 */ 
--
-- TBL_BANK  (Table) 
--
CREATE TABLE DCS2000.TBL_BANK
(
  BANK_ID         NUMBER(4),
  BANK_NAME       VARCHAR2(100 BYTE)            NOT NULL,
  DISPLAY_NAME    VARCHAR2(30 BYTE)             NOT NULL,
  BRANCH_NAME     VARCHAR2(100 BYTE),
  ADDR1           VARCHAR2(30 BYTE),
  ADDR2           VARCHAR2(30 BYTE),
  ADDR3           VARCHAR2(30 BYTE),
  CITY            VARCHAR2(30 BYTE),
  STATE           VARCHAR2(2 BYTE),
  ZIP             NUMBER(5),
  ZIP4            NUMBER(4),
  COUNTRY_CDE     NUMBER(4),
  ACH_SETUP_FLAG  VARCHAR2(1 BYTE),
  EFF_DTE         NUMBER(8),
  TRM_DTE         NUMBER(8),
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BANK TO DCS_USERS_ALL;

--
-- PK_BANK  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_BANK ON DCS2000.TBL_BANK
(BANK_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_BANK 
-- 
ALTER TABLE DCS2000.TBL_BANK ADD (
  CONSTRAINT PK_BANK PRIMARY KEY (BANK_ID)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_BANK 
-- 
ALTER TABLE DCS2000.TBL_BANK ADD (
  CONSTRAINT FK_BANK_2_COUNTRY FOREIGN KEY (COUNTRY_CDE) 
    REFERENCES DCS2000.TBL_CODE_COUNTRY (COUNTRY));


