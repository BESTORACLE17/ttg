/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2
|| Revision Type  : Enhancement
|| Change Control#: 
|| Service Request: SR#04226.02.NC 
|| Revision By    : Dinesh Makked
|| Revision Date  : 02/02/2005
|| Revision Desc  : Added column IMMEDIATE_ORIGIN_NAME & IMMEDIATE_DESTINATION_NAME.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/


--
-- TBL_BANK_ACH_DETAIL  (Table) 
--
CREATE TABLE DCS2000.TBL_BANK_ACH_DETAIL
(
  BANK_ACH_DETAIL_ID       NUMBER(4),
  BANK_ID                  NUMBER(4)            NOT NULL,
  BILLING_CYCLE            NUMBER(4)            NOT NULL,
  BANK_ACH_DETAIL_NAME     VARCHAR2(100 BYTE)   NOT NULL,
  DISPLAY_NAME             VARCHAR2(30 BYTE)    NOT NULL,
  PRIORITY_CODE            VARCHAR2(30 BYTE)    NOT NULL,
  IMMEDIATE_DESTINATION    VARCHAR2(30 BYTE)    NOT NULL,
  IMMEDIATE_ORIGIN         VARCHAR2(30 BYTE)    NOT NULL,
  FILE_ID_MODIFIER         VARCHAR2(30 BYTE)    NOT NULL,
  RECORD_SIZE              VARCHAR2(30 BYTE)    NOT NULL,
  BLOCKING_FACTOR          VARCHAR2(30 BYTE)    NOT NULL,
  FORMAT_CODE              VARCHAR2(30 BYTE)    NOT NULL,
  SERVICE_CLASS_CODE       VARCHAR2(30 BYTE)    NOT NULL,
  STANDARD_ENTRY_CLASS     VARCHAR2(30 BYTE)    NOT NULL,
  ORIGINATOR_STATUS_CODE   VARCHAR2(30 BYTE)    NOT NULL,
  TRANSACTION_DESCRIPTION  VARCHAR2(30 BYTE)    NOT NULL,
  LOGDX_RECORD             VARCHAR2(4000 BYTE),
  EFF_DTE                  NUMBER(8),
  TRM_DTE                  NUMBER(8),
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  EMAIL_SUBJECT            VARCHAR2(50),
  EMAIL_BODY               VARCHAR2(2000),
  EMAIL_FROM               VARCHAR2(50),
  EMAIL_TO                 VARCHAR2(1000)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BANK_ACH_DETAIL TO DCS_USERS_ALL;

--
-- PK_BANK_ACH_DETAIL  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_BANK_ACH_DETAIL ON DCS2000.TBL_BANK_ACH_DETAIL
(BANK_ACH_DETAIL_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- BANK_ACH_DETAIL_IX  (Index) 
--
CREATE UNIQUE INDEX DCS2000.BANK_ACH_DETAIL_IX ON DCS2000.TBL_BANK_ACH_DETAIL
(BILLING_CYCLE, EFF_DTE)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_BANK_ACH_DETAIL 
-- 
ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL ADD (
  CONSTRAINT PK_BANK_ACH_DETAIL PRIMARY KEY (BANK_ACH_DETAIL_ID)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_BANK_ACH_DETAIL 
-- 
ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL ADD (
  CONSTRAINT FK_BANK_ACH_DETAIL_2_BANK FOREIGN KEY (BANK_ID) 
    REFERENCES DCS2000.TBL_BANK (BANK_ID));



--
-- SR#04226.02
--     
ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL ADD IMMEDIATE_ORIGIN_NAME VARCHAR2(23);

ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL ADD IMMEDIATE_DESTINATION_NAME VARCHAR2(23);

ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL MODIFY IMMEDIATE_ORIGIN_NAME NOT NULL;

ALTER TABLE DCS2000.TBL_BANK_ACH_DETAIL MODIFY IMMEDIATE_DESTINATION_NAME NOT NULL;
 