/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 2.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR#05068.01.VA
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 04/28/2005
|| Revision Desc  : Added BRAND_CODE column.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- VERSION 2.1.2  
--
-- ACH_PARENT_COMPANY  (Table) 
--
CREATE TABLE DCS2000.ACH_PARENT_COMPANY
(
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  PARENT_ID            NUMBER(4),
  PARENT_NAME          VARCHAR2(200 BYTE),
  INS_UPD_FLAG         VARCHAR2(1 BYTE),
  TELEPHONE_LOCAL      VARCHAR2(30 BYTE),
  TELEPHONE_TOLL_FREE  VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_PARENT_COMPANY TO DCS_USERS_ALL;

--
-- SR 03266.15.NE (Provider Reports)  SHB
-- 
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD WEBSITE VARCHAR2(1000);

--
-- SR 05068.01.VA Add Company ID in W9 Record 
-- 
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD BRAND_CODE NUMBER(4);

--
-- .NET Column Changes
--
ALTER TABLE DCS2000.ACH_PARENT_COMPANY RENAME COLUMN MOD_DTE TO UPDATED_ON;
ALTER TABLE DCS2000.ACH_PARENT_COMPANY RENAME COLUMN MOD_OP  TO UPDATED_BY;
ALTER TABLE DCS2000.ACH_PARENT_COMPANY RENAME COLUMN INS_UPD_FLAG TO ACTION_CODE;
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD CREATED_BY VARCHAR2(30);
COMMENT ON COLUMN ACH_PARENT_COMPANY.CREATED_BY IS 'Refer To Production Table';
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD CREATED_ON DATE;
COMMENT ON COLUMN ACH_PARENT_COMPANY.CREATED_ON IS 'Refer To Production Table';
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD ACTION_BY VARCHAR2(30);
COMMENT ON COLUMN ACH_PARENT_COMPANY.ACTION_BY IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';
ALTER TABLE DCS2000.ACH_PARENT_COMPANY ADD ACTION_ON DATE;
COMMENT ON COLUMN ACH_PARENT_COMPANY.ACTION_ON IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';
