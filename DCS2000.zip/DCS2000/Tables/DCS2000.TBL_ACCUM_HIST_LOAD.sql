/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_ACCUM_HIST_LOAD  (Table) 
--
CREATE TABLE DCS2000.TBL_ACCUM_HIST_LOAD
(
  MAINT_CODE            NUMBER(4),
  MOD_DTE               DATE,
  MOD_OP                VARCHAR2(12 BYTE),
  GRP_ID                VARCHAR2(9 BYTE),
  SUBLOC_ID             VARCHAR2(8 BYTE),
  DIV_ID                VARCHAR2(4 BYTE),
  PRD_CDE               NUMBER(4),
  PLN_CDE               NUMBER(4),
  COVER_PERIOD_ID       NUMBER(4),
  SUBR_ID               VARCHAR2(9 BYTE),
  SUBR_FNAME            VARCHAR2(30 BYTE),
  SUBR_LNAME            VARCHAR2(30 BYTE),
  PAT_FNAME             VARCHAR2(30 BYTE),
  PAT_LNAME             VARCHAR2(30 BYTE),
  PAT_DOB               NUMBER(8),
  PAT_REL_CDE           NUMBER(2),
  BEN_CLASS_CDE         NUMBER(4),
  TREATMENT_DTE         NUMBER(8),
  PRC_CDE               VARCHAR2(5 BYTE),
  TOOTH_ID              VARCHAR2(2 BYTE),
  SURFACES              VARCHAR2(7 BYTE),
  SUBMIT                NUMBER(8,2),
  NET                   NUMBER(8,2),
  DEDUCTIBLE            NUMBER(8,2),
  COB                   NUMBER(8,2),
  ERROR_NO              NUMBER(4),
  INDV_ID               NUMBER(2),
  COB_PRIME_CARRIER_ID  NUMBER(4),
  PRV_TAX_ID            VARCHAR2(9 BYTE),
  FAC_STATE             VARCHAR2(2 BYTE),
  CLAIM_NO              VARCHAR2(14 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

COMMENT ON TABLE DCS2000.TBL_ACCUM_HIST_LOAD IS 'This table contains entries that require claim history and accumulator information to be loaded.  Upon initial load, columns subloc_id, div_id, prd_cde, pln_cde, cover_period_id, ben_class_cde, and error_no will be set to zero.  The load process will populate these columns.';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.MAINT_CODE IS 'Indicates if the row is active.';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.MOD_DTE IS 'Date of last Update.';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.MOD_OP IS 'User identification of the last update.';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.GRP_ID IS 'Group Number';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SUBLOC_ID IS 'Sublocation Number';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.DIV_ID IS 'Division Number';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PRD_CDE IS 'Product Code';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PLN_CDE IS 'Plan Code';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.COVER_PERIOD_ID IS 'Coverage Period Number';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SUBR_ID IS 'Subscriber Identification';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SUBR_FNAME IS 'Subscriber First Name';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SUBR_LNAME IS 'Subscriber Last Name';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PAT_FNAME IS 'Patient First Name';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PAT_LNAME IS 'Patient Last Name';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PAT_DOB IS 'Patient DOB';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PAT_REL_CDE IS 'Patient Relationship Code';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.BEN_CLASS_CDE IS 'Benefit Class Code';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.TREATMENT_DTE IS 'Treatment Date Procedure was performed';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.PRC_CDE IS 'Procedure Code';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.TOOTH_ID IS 'Tooth Number';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SURFACES IS 'Surfaces for which the procedure was performed';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.SUBMIT IS 'Submit amount';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.NET IS 'Net Payment amount';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.DEDUCTIBLE IS 'Deductible amount';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.COB IS 'Co-odrination of Benefits amount';

COMMENT ON COLUMN DCS2000.TBL_ACCUM_HIST_LOAD.ERROR_NO IS 'Review Error Number';

--
-- ACCUM_HIST_LOAD_GRP_IX  (Index) 
--
CREATE INDEX DCS2000.ACCUM_HIST_LOAD_GRP_IX ON DCS2000.TBL_ACCUM_HIST_LOAD
(GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- ACCUM_HIST_LOAD_SUBR_IX  (Index) 
--
CREATE INDEX DCS2000.ACCUM_HIST_LOAD_SUBR_IX ON DCS2000.TBL_ACCUM_HIST_LOAD
(SUBR_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_ACCUM_HIST_LOAD MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ACCUM_HIST_LOAD TO DCS_USERS_ALL;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE ON  DCS2000.TBL_ACCUM_HIST_LOAD TO BRUCEJ;

GRANT SELECT ON  DCS2000.TBL_ACCUM_HIST_LOAD TO PRODDBLINK;

