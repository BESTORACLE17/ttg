--=================================
-- SR 07109.04.VA
-- 05/28/2008
-- Suresh Vadapalli
--=================================

CREATE TABLE DCS2000.ACH_ATRB_POOL_NO
   ( CREATED_BY   VARCHAR2(30)      
   , CREATED_ON   DATE              
   , UPDATED_BY   VARCHAR2(30)      
   , UPDATED_ON   DATE              
   , MAINT_CODE   NUMBER(4)         
   , ACTION_CODE  VARCHAR2(1)
   , ACTION_BY    VARCHAR2(30)
   , ACTION_ON    DATE
   , CODE         NUMBER(4)          
   , EFF_DATE     DATE              
   , TERM_DATE    DATE
   , LOSS_RATIO_CODE NUMBER(4)       
   );

GRANT SELECT, INSERT, UPDATE, DELETE ON DCS2000.ACH_ATRB_POOL_NO TO DCS_USERS_ALL;
