/* VERSION: 3.1.7 */ 
--
-- ACH_GSD_CLASS  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.7
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_CLASS
(
  GRP_ID                   VARCHAR2(9 BYTE),
  SUBLOC_ID                VARCHAR2(8 BYTE),
  DIV_ID                   VARCHAR2(4 BYTE),
  PRD_CDE                  NUMBER(4),
  PLN_CDE                  NUMBER(4),
  PAR_NPAR_PRV_INDI        NUMBER(1),
  BEN_CLASS_CDE            NUMBER(4),
  GSD_CLASS_EFF_DTE        NUMBER(8),
  GSD_CLASS_TRM_DTE        NUMBER(8),
  COPAY_PERCENT            NUMBER(5,4),
  CLAIM_WAIT_PERIOD        NUMBER(4),
  WAIVE_CLAIM_WAIT_PERIOD  NUMBER(1),
  DED_PROCESSING_SEQUENCE  NUMBER(2),
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  LATE_ENTRANTS_MONTHS     NUMBER(2),
  PRORATE_FLAG             VARCHAR2(1 BYTE),
  COPAY_TYPE               NUMBER(4),
  MAX_COPAY_PERCENT        NUMBER(5,4),
  COPAY_INCREMENT          NUMBER(5,4),
  COPAY_INCREMENT2         NUMBER(5,4),
  COPAY_INCREMENT3         NUMBER(5,4),
  COPAY_INCREMENT4         NUMBER(5,4),
  COPAY_INCREMENT5         NUMBER(5,4),
  INS_UPD_FLAG             CHAR(1 BYTE),
  FEES_ZIP_SET             NUMBER(4),
  FEES_ZIP_PAR_PCT         NUMBER(4),
  FEES_ZIP_NONPAR_PCT      NUMBER(4
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          7520K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_CLASS TO DCS_USERS_ALL;

--05085.19 
--SV 08/10/2005  
--Ver 3.1.2 

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD REL_CDE NUMBER(4);

--06146.01.VA
--BJ 10/24/2007  
--Ver 3.1.3 

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD WAIT_PERIOD_ELIG_ONLY NUMBER(4);


--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (gsd_class_pk NUMBER); --3.1.5

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_CLASS ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_CLASS ON DCS2000.ACH_GSD_CLASS(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,PAR_NPAR_PRV_INDI,BEN_CLASS_CDE,GSD_CLASS_EFF_DTE,REL_CDE) TABLESPACE PRODIX;
--End SR07109.04.VA

--SR07318.02.KY
ALTER TABLE dcs2000.ach_gsd_class
  ADD (product_tier_code    NUMBER(4));
  
ALTER TABLE dcs2000.ach_gsd_class ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.7