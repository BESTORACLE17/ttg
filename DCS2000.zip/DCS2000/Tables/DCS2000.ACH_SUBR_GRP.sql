/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_GRP  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_GRP
(
  SUBR_ID                VARCHAR2(9 BYTE),
  GRP_ID                 VARCHAR2(9 BYTE),
  SUBLOC_ID              VARCHAR2(8 BYTE),
  DIV_ID                 VARCHAR2(4 BYTE),
  HIRE_DTE               NUMBER(8),
  GRP_TRM_DTE            NUMBER(8),
  ORIG_HIRE_DTE          NUMBER(8),
  ELIG_WAIT_PER_OVR_CDE  NUMBER(2),
  COMPENSATION_CDE       NUMBER(2),
  UNION_CDE              NUMBER(2),
  WORK_STS_CDE           NUMBER(2),
  COBRA_ELIG_CDE         NUMBER(2),
  COBRA_EFF_DTE          NUMBER(8),
  MAINT_CODE             NUMBER(4),
  MOD_DTE                DATE,
  MOD_OP                 VARCHAR2(12 BYTE),
  INS_UPD_FLAG           VARCHAR2(1 BYTE),
  PRIOR_CARRIER_EFF_DTE  NUMBER(8),
  BROKER_ID              VARCHAR2(9 BYTE),
  PRODUCER_ID            NUMBER(15)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          73816K
            NEXT             3M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACH_SUBR_GRP_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_SUBR_GRP_IX ON DCS2000.ACH_SUBR_GRP
(GRP_ID, MOD_DTE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_GRP MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_GRP TO DCS_USERS_ALL;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE ON  DCS2000.ACH_SUBR_GRP TO DMAKKED;

