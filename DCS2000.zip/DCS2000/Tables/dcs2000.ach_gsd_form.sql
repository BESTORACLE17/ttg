/* VERSION: 3.1.4 */ 

--============================================================================
-- Revision Type  : Enhancement
-- Service Request: SR 10067.02.ALL Multi product
-- Version        : 3.1.4
-- Revision By    : Satya Sai
-- Revision Date  : 10/25/2010
-- Revision Desc  : Adding Product Line Code column
--============================================================================
create table DCS2000.ach_GSD_FORM
(
  GRP_ID                    VARCHAR2(9),
  SUBLOC_ID                 VARCHAR2(8),
  DIV_ID                    VARCHAR2(4),
  FRM_TYPE_CDE              NUMBER(4),
  FRM_REQ_DTE               NUMBER(8),
  FRM_ISS_DTE               NUMBER(8),
  MAINT_CODE                NUMBER(4),
  MOD_DTE                   DATE,
  MOD_OP                    VARCHAR2(12),
  doc_type                  NUMBER(2),
  EFFECTIVE_DATE            NUMBER(8),
  MAILTO_CODE               NUMBER(2),
  NUMBER_OF_COPIES_TO_PRINT NUMBER(10),
  action_code               VARCHAR2(1) CHECK (UPPER(action_code) IN ('I', 'U', 'D')),
  action_by                 VARCHAR2(30),
  action_on                 DATE
)
tablespace PROD;

--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_FORM ADD (gsd_form_pk NUMBER);

ALTER TABLE DCS2000.ACH_GSD_FORM ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_FORM ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_FORM ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_FORM ADD (updated_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_FORM ON DCS2000.ACH_GSD_FORM(GRP_ID,SUBLOC_ID,DIV_ID,FRM_TYPE_CDE,FRM_REQ_DTE) TABLESPACE PRODIX;
--End SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_FORM ADD (PRODUCT_LINE_CODE NUMBER(4)); -- 3.1.4 