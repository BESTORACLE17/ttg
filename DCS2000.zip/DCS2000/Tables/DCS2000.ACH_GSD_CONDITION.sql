/* VERSION: 3.1.4 */ 
--
-- ACH_GSD_CONDITION  (Table) 
--
-- SR07109.04.VA
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Bug fix
|| Service Request: TRAC6133 
|| Revision By    : Clark Zivelonghi
|| Revision Date  : 12/03/2010 
|| Revision Desc  : removed PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_CONDITION
(
  GRP_ID        VARCHAR2(9),
  SUBLOC_ID     VARCHAR2(8),
  DIV_ID        VARCHAR2(4),
  PRD_CDE       NUMBER(4),
  PLN_CDE       NUMBER(4),
  CONDITION     NUMBER(4),
  EFF_DTE       NUMBER(8),
  TRM_DTE       NUMBER(8),
  MAINT_CODE    NUMBER(4),
  MOD_DTE       DATE,
  MOD_OP        VARCHAR2(12),
  GSD_CONDITION_PK       NUMBER,
  CREATED_BY    VARCHAR2(30),
  CREATED_ON    DATE,
  UPDATED_BY    VARCHAR2(30),
  UPDATED_ON    DATE,
  ACTION_CODE   VARCHAR2(1),
  ACTION_BY     VARCHAR2(30),
  ACTION_ON     DATE
);
GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_CONDITION TO DCS_USERS_ALL;
CREATE INDEX DCS2000.IX_ACH_GSD_CONDITION ON DCS2000.ACH_GSD_CONDITION(GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE, PLN_CDE, CONDITION, EFF_DTE);
--ALTER TABLE DCS2000.ACH_GSD_CONDITION ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.3