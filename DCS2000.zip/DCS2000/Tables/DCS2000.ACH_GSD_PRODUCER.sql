/* VERSION: 3.1.5 */ 
--
-- ACH_GSD_PRODUCER  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.2
|| Revision Type  : Enhancement
|| Change Control#: 
|| Service Request: SR 05269.02.KY
|| Revision By    : Suresh Vadapalli
|| Revision Date  : 04/11/2006
|| Revision Desc  :
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.3
|| Revision Type  : Enhancement
|| Change Control#: 
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/10/2008
|| Revision Desc  :
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.4
|| Revision Type  : Enhancement
|| Change Control#: 
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/13/2008
|| Revision Desc  : Renamed PK to GSD_PRODUCER_PK
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.5
|| Revision Type  : Enhancement
|| Change Control#: 
|| Service Request: 10067.02.ALL Multi Products
|| Revision By    : Satya Sai
|| Revision Date  : 09/03/2010
|| Revision Desc  : Adding product line code column
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_PRODUCER
(
  MAINT_CODE                   NUMBER(4)        NOT NULL,
  MOD_DTE                      DATE             NOT NULL,
  MOD_OP                       VARCHAR2(12 BYTE) NOT NULL,
  GRP_ID                       VARCHAR2(9 BYTE) NOT NULL,
  SUBLOC_ID                    VARCHAR2(8 BYTE) NOT NULL,
  DIV_ID                       VARCHAR2(4 BYTE) NOT NULL,
  PRODUCER_ID                  NUMBER(15)       NOT NULL,
  GRP_PRODUCER_EFF_DTE         NUMBER(8)        NOT NULL,
  GRP_PRODUCER_TRM_DTE         NUMBER(8)        NOT NULL,
  COMMISSION_TYPE_CODE         NUMBER(4)        NOT NULL,
  COMMISSION_SCHEDULE_CODE     NUMBER(4),
  COMMISSION_SLIDING_SCALE_ID  NUMBER(4),
  COMMISSION_FIXED_PERCENT     NUMBER(6,4),
  COMMISSION_FIXED_AMOUNT      NUMBER(7,2),
  NEGOTIATED_COMMISSION_FLAG   VARCHAR2(1 BYTE),
  PAY_TO_PRODUCER_ID           NUMBER(15),
  PAY_TO_LOCATION_ID           NUMBER(15)       NOT NULL,
  REMARKS                      VARCHAR2(4000 BYTE),
  INS_UPD_FLAG                 CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_PRODUCER TO DCS_USERS_ALL;


ALTER TABLE DCS2000.ACH_GSD_PRODUCER MODIFY COMMISSION_FIXED_AMOUNT NUMBER(9,4); -- SR 05269.02.KY

--Start 3.1.3
ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (gsd_producer_pk NUMBER); --3.1.4

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_PRODUCER ON DCS2000.ACH_GSD_PRODUCER(GRP_ID,SUBLOC_ID,DIV_ID,PRODUCER_ID,GRP_PRODUCER_EFF_DTE,COMMISSION_TYPE_CODE,PAY_TO_PRODUCER_ID,PAY_TO_LOCATION_ID) TABLESPACE PRODIX;
--End 3.1.3

ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (SEND_DELINQUENCY_LETTER_FLAG  VARCHAR2(1)); --SR07109.04.VA GM quality edits - Phase II
ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (ADJUSTMENT_MONTH              VARCHAR2(2)); --SR07109.04.VA GM quality edits - Phase II
ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (ADJUSTMENT_YEAR               VARCHAR2(4)); --SR07109.04.VA GM quality edits - Phase II
ALTER TABLE DCS2000.ACH_GSD_PRODUCER ADD (PRODUCT_LINE_CODE             NUMBER(4)); --3.1.5