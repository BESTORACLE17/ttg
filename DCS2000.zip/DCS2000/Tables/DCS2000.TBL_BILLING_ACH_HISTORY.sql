/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_ACH_HISTORY  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_ACH_HISTORY
(
  REQUEST_ID           NUMBER(6),
  SUBR_ID              VARCHAR2(9 BYTE),
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  TRANSACTION_CODE     CHAR(2 BYTE),
  ROUTING_NUMBER       VARCHAR2(9 BYTE),
  ACCOUNT_NUMBER       VARCHAR2(17 BYTE),
  AMOUNT               NUMBER(12,2),
  ACCOUNT_HOLDER_NAME  VARCHAR2(100 BYTE),
  TRACE_NUMBER         VARCHAR2(15 BYTE),
  BILL_MONTH_YEAR      NUMBER(6),
  COMPANY_ID           NUMBER(4),
  MAINT_CODE           NUMBER(4),
  MOD_OP               VARCHAR2(12 BYTE),
  MOD_DTE              DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- IDX_BILLING_ACH_HISTORY  (Index) 
--
CREATE INDEX DCS2000.IDX_BILLING_ACH_HISTORY ON DCS2000.TBL_BILLING_ACH_HISTORY
(REQUEST_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_ACH_HISTORY MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_ACH_HISTORY TO DCS_USERS_ALL;

