--********************
-- ACH_GA_AGE_LIMIT_HEADER
-- SR - 07109.01.VA
--********************
CREATE TABLE DCS2000.ACH_GA_AGE_LIMIT_HEADER
(
  CREATED_BY               VARCHAR2(12 BYTE),
  CREATED_ON               DATE,   
  UPDATED_BY               VARCHAR2(12 BYTE),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1 BYTE),
  ACTION_BY                VARCHAR2(30 BYTE),
  ACTION_ON                DATE,
  AGE_LIMIT_HEADER_PK      NUMBER(9),
  AGE_LIMIT_ID             NUMBER(12),
  AGE_LIMIT_NAME           VARCHAR2(100 BYTE),             
  EFF_DATE                 DATE, 
  TERM_DATE                DATE,                 
  TERM_REASON_CODE         NUMBER(4),
  COMMENTS                 VARCHAR2(200 BYTE),
  NOTES                    VARCHAR2(200 BYTE)  
);
