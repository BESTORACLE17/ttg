-- Create table
create table DCS2000.ACH_COMPANY_PRODUCTS
(
  CREATED_BY          VARCHAR2(30),
  CREATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30),   
  UPDATED_ON          DATE,
  MAINT_CODE          NUMBER(4),
  ACTION_CODE         VARCHAR2(1),
  ACTION_BY           VARCHAR2(30),
  ACTION_ON           DATE,
  COMPANY_ID          NUMBER(4) not null,
  PRD_CDE             NUMBER(4) not null,
  ACCT_COMPANY_ID     NUMBER(4),
  COMPANY_PRODUCTS_PK NUMBER(12) not null,
  EFF_DATE            DATE,
  TERM_DATE           DATE
);