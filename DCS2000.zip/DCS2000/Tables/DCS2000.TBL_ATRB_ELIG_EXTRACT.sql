/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.0
|| Revision Type  : Initial Development
|| Service Request: 10254.01.VA - Delta Care Monthly Extract -  PMI
|| Revision By    : Stephen Ince
|| Revision Date  : 12/10/2010 
|| Revision Desc  : Initial Development
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_ATRB_ELIG_EXTRACT  (Table) 
--

-- Create table
create table dcs2000.TBL_ATRB_ELIG_EXTRACT
(
  parent_id            NUMBER(4) not null,
  created_by           VARCHAR2(30) not null,
  created_on           DATE not null,
  updated_by           VARCHAR2(30) not null,
  updated_on           DATE not null,
  maint_code           NUMBER(2),
  elig_extract_atrb_pk NUMBER not null,
  elig_extract_pk      NUMBER,
  grp_id               VARCHAR2(9),
  subloc_id            VARCHAR2(8),
  div_id               VARCHAR2(4),
  eff_dte              NUMBER(8),
  trm_dte              NUMBER(8)
)
tablespace PROD
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table dcs2000.TBL_ATRB_ELIG_EXTRACT
  add constraint PK_ATRB_ELIG_EXTRACT primary key (ELIG_EXTRACT_ATRB_PK)
  using index 
  tablespace PROD
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 64K
    minextents 1
    maxextents unlimited
  );
alter table dcs2000.TBL_ATRB_ELIG_EXTRACT
  add constraint FK_ATRB_ELIG_EXTRACT_2_CODE foreign key (ELIG_EXTRACT_PK)
  references dcs2000.TBL_CODE_ELIG_EXTRACT (ELIG_EXTRACT_PK);
-- Grant/Revoke object privileges 
grant select on dcs2000.TBL_ATRB_ELIG_EXTRACT to DCSREPORTS with grant option;
grant select, insert, update, delete on dcs2000.TBL_ATRB_ELIG_EXTRACT to DCS_USERS_ALL;
grant select, insert, update on dcs2000.TBL_ATRB_ELIG_EXTRACT to SECURITY;