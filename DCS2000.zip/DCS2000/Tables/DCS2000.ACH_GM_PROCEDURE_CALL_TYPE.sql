/* VERSION: 2.1.1 */
CREATE TABLE DCS2000.ACH_GM_PROCEDURE_CALL_TYPE
(
  CREATED_BY           VARCHAR2(30 BYTE),
  CREATED_ON           DATE,
  UPDATED_BY           VARCHAR2(30 BYTE),
  UPDATED_ON           DATE,
  MAINT_CODE           NUMBER(4),
  ACTION_CODE          VARCHAR2(1 BYTE),
  ACTION_BY            VARCHAR2(30 BYTE),
  ACTION_ON            DATE,
  PROCEDURE_CALL_TYPE  NUMBER(2)                NOT NULL,
  DESRIPTION           VARCHAR2(200 BYTE)       NOT NULL,
  ARGUMENT_LIST        VARCHAR2(4000 BYTE)      NOT NULL
)
TABLESPACE PROD;

COMMENT ON TABLE DCS2000.ACH_GM_PROCEDURE_CALL_TYPE               IS 'Table trhat describes the associated arguments to be passed in a procedurre call.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.CREATED_BY   IS 'User ID of the user who created the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.CREATED_ON   IS 'Date on which the row was created.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.UPDATED_BY   IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.UPDATED_ON   IS 'Date on which the row was last updated.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.ACTION_CODE     IS 'Action (Insert/Update/Delete) that was taken on the production record that caused old maintenance record to be archived. I = Insert, U = Update, and D = Delete.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.ACTION_BY       IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.ACTION_ON       IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.PROCEDURE_CALL_TYPE        IS 'System generated PK.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.DESRIPTION                 IS 'Display name of the procedure call type.';

COMMENT ON COLUMN DCS2000.ACH_GM_PROCEDURE_CALL_TYPE.ARGUMENT_LIST              IS 'List of arguments to be passed in the associted procedure call.';
