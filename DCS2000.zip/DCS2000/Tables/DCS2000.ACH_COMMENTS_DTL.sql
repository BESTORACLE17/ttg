/* VERSION: 3.1.1 */ 
--
-- ACH_COMMENTS_DTL  (Table) 
--
CREATE TABLE DCS2000.ACH_COMMENTS_DTL
(
  MAINT_CODE            NUMBER(4),
  MOD_DTE               DATE,
  MOD_OP                VARCHAR2(12 BYTE),
  ADD_DTE               DATE,
  ADD_OP                VARCHAR2(12 BYTE),
  COMMENT_ID            NUMBER(12)              NOT NULL,
  COMMENT_LINE          NUMBER(4)               NOT NULL,
  COMMENT_TEXT          VARCHAR2(4000 BYTE)     NOT NULL,
  RECEIVED_DTE          DATE,
  CALL_BACK             NUMBER(1),
  CALL_BACK_DTE         DATE,
  COMMENT_SOURCE        NUMBER(2),
  COMMENT_INQUIRY_TYPE  NUMBER(2),
  SOURCE_OBJECT_ID      NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_COMMENTS_DTL TO DCS_USERS_ALL;

