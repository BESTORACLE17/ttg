/* VERSION: 3.1.5 */ 
 /*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.5
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 06/09/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_COVERAGE  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_COVERAGE
(
  GRP_ID                     VARCHAR2(9 BYTE),
  SUBLOC_ID                  VARCHAR2(8 BYTE),
  DIV_ID                     VARCHAR2(4 BYTE),
  COVER_PERIOD_ID            NUMBER(4),
  COVER_BEGIN_DTE            NUMBER(8),
  COVER_END_DTE              NUMBER(8),
  COMB_DED_WITHIN_GRP        NUMBER(1),
  COMB_MAX_WITHIN_GRP        NUMBER(1),
  COMB_WITH_GRP_ID           VARCHAR2(9 BYTE),
  COMB_WITH_SUBLOC_ID        VARCHAR2(8 BYTE),
  COMB_WITH_DIV_ID           VARCHAR2(4 BYTE),
  COMB_WITH_COVER_PERIOD_ID  NUMBER(4),
  COMB_DED_WITH_GRP          NUMBER(1),
  COMB_MAX_WITH_GRP          NUMBER(1),
  MAINT_CODE                 NUMBER(4),
  MOD_DTE                    DATE,
  MOD_OP                     VARCHAR2(12 BYTE),
  INS_UPD_FLAG               CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1944K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_COVERAGE TO DCS_USERS_ALL;


--SR 03349.03 SV 09/28/2005 

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD SUBR_ELIG_EFF NUMBER(1);


--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (gsd_coverage_pk NUMBER); --3.1.4

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_COVERAGE ON DCS2000.ACH_GSD_COVERAGE(GRP_ID,SUBLOC_ID,DIV_ID,COVER_PERIOD_ID) TABLESPACE PRODIX;
--End SR07109.04.VA

ALTER TABLE DCS2000.ACH_GSD_COVERAGE ADD (PRODUCT_LINE_CODE  NUMBER(4));-- 3.1.5