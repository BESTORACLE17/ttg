/* VERSION: 3.1.3 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/18/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR 07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/10/2008.
|| Revision Desc  : Added the following columns
||               1.pk
||               2.created_by 
||               3.created_on 
||               4.updated_by 
||               5.updated_on 
||               6.action_code
||               7.action_by
||               8.action_on
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD
(
  GRP_ID                  VARCHAR2(9 BYTE),
  SUBLOC_ID               VARCHAR2(8 BYTE),
  DIV_ID                  VARCHAR2(4 BYTE),
  EFF_DTE                 NUMBER(8),
  TRM_DTE                 NUMBER(8),
  GRP_NME                 VARCHAR2(100 BYTE),
  RELIABILITY             NUMBER(1),
  RELIABILITY_GRC_PERIOD  NUMBER(2),
  OCCUPATION_CDE          NUMBER(4),
  INDUSTRY_NO             NUMBER(4),
  BUS_TYPE                NUMBER(2),
  SIC_CODE                NUMBER(4),
  ST_WITHHOLD_OVERRIDE    NUMBER(1),
  AOB_OVERRIDE            NUMBER(1),
  MAINT_CODE              NUMBER(4),
  MOD_DTE                 DATE,
  MOD_OP                  VARCHAR2(12 BYTE),
  MEDICAL_COB_RVW         NUMBER(1),
  IS_SENSITIVE_GROUP      VARCHAR2(1 BYTE),
  NAICS_CODE              VARCHAR2(6 BYTE),
  GSD_EFF_DTE             NUMBER(8),
  NEI                     VARCHAR2(9 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1184K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD TO DCS_USERS_ALL;

--SR 05085.02 08/17/2005 SV 

ALTER TABLE DCS2000.ACH_GSD ADD ORTHO_CONT_MM NUMBER(4);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_GSD ADD GSD_PK NUMBER(15);
ALTER TABLE DCS2000.ACH_GSD ADD GRP_SUBMITTED_MBR_ID_TYP_CDE NUMBER(4);
ALTER TABLE DCS2000.ACH_GSD ADD GRP_CORRESP_MBR_ID_TYP_CDE NUMBER(4);
ALTER TABLE DCS2000.ACH_GSD ADD OTHER_CORRESP_MBR_ID_TYP_CDE NUMBER(4);
ALTER TABLE DCS2000.ACH_GSD ADD MASK_SUBRID_GRP_CORRESP_FLAG NUMBER(1);
ALTER TABLE DCS2000.ACH_GSD ADD MASK_SUBRID_OTHER_CORRESP_FLAG NUMBER(1);


--Version: 3.1.3
--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD ADD (pk NUMBER);

ALTER TABLE DCS2000.ACH_GSD ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD ON DCS2000.ACH_GSD(GRP_ID,SUBLOC_ID,DIV_ID) TABLESPACE PRODIX;
--End SR07109.04.VA
