/* VERSION: 3.1.2 */ 
--
-- ACH_PRODUCER_CONTACTS  (Table) 
--
CREATE TABLE DCS2000.ACH_PRODUCER_CONTACTS
(
  MAINT_CODE              NUMBER(4),
  MOD_DTE                 DATE,
  MOD_OP                  VARCHAR2(12 BYTE),
  PRODUCER_ID             NUMBER(15),
  LOCATION_ID             NUMBER(15),
  CONTACT_CDE             NUMBER(4),
  CONTACT_SALUTATION_CDE  NUMBER(4),
  LNME                    VARCHAR2(50 BYTE),
  MNME                    VARCHAR2(50 BYTE),
  FNME                    VARCHAR2(50 BYTE),
  SUFFIX                  VARCHAR2(30 BYTE),
  EMAIL_ADDRESS           VARCHAR2(100 BYTE),
  FAX_NO                  VARCHAR2(30 BYTE),
  PHONE_NO1               VARCHAR2(30 BYTE),
  PHONE_NO2               VARCHAR2(30 BYTE),
  INS_UPD_FLAG            CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_PRODUCER_CONTACTS TO DCS_USERS_ALL;

ALTER TABLE dcs2000.ach_producer_contacts ADD ( EMAIL_COMMISSION_STATEMENT NUMBER(1) CHECK ( EMAIL_COMMISSION_STATEMENT IN ( 0, 1 ) ) );