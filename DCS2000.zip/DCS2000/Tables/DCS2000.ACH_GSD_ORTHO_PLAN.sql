/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.1
|| Revision Type  : Enhancement
|| Service Request: SR07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 07/23/2008
|| Revision Desc  : Original version.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.2
|| Revision Type  : Enhancement
|| Service Request: SR07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 09/10/2008
|| Revision Desc  : Modified table to also carry an ortho down payment rule
||                  ID override, so that if the GSD should use a different rule
||                  than the system-defined default rule, it can be specified
||                  here.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.3
|| Revision Type  : Enhancement
|| Service Request: SR07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 09/26/2008
|| Revision Desc  : Added column for ortho proration_type per Bruce J e-mail.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_ORTHO_PLAN  (Table) 
--
  GSD_ORTHO_PLAN_PK            NUMBER                   ,
  GRP_ID                       VARCHAR2(9 BYTE)         ,
  SUBLOC_ID                    VARCHAR2(8 BYTE)         ,
  DIV_ID                       VARCHAR2(4 BYTE)         ,
  PRD_CDE                      NUMBER(4)                ,
  PLN_CDE                      NUMBER(4)                ,
  EFF_DTE                      NUMBER(8)                ,
  TRM_DTE                      NUMBER(8)                ,
  ORTHO_PAYMENT_TYPE_CODE      NUMBER(4)                ,
  ORTHO_PAYMENT_FREQUENCY_CODE NUMBER(4)                ,
  SINGLE_PAYMENT_PER_REC_IND   NUMBER(1)                ,
  DOWN_PAYMENT_MAXIMUM         NUMBER(8,2)              ,
  MINIMUM PAYMENT_AMOUNT       NUMBER(8,2)              ,
  MANUAL_SETUP_IND             NUMBER(1)                ,
  ORTHO_MAX_INCREASED_IND      NUMBER(1)                ,
  ORTHO_DP_RULE_ID_OVERRIDE    NUMBER(4)                ,
  PRORATION_TYPE               NUMBER(4)                ,
  MAINT_CODE                   NUMBER(4)                ,
  MOD_DTE                      DATE                     ,
  MOD_OP                       VARCHAR2(12 BYTE)        ,
  INS_UPD_FLAG                 CHAR(1)                  ,
  CREATED_BY                   VARCHAR2(30)             ,
  CREATED_ON                   DATE                     ,
  UPDATED_BY                   VARCHAR2(30)             ,
  UPDATED_ON                   DATE                     ,
  ACTION_CODE                  VARCHAR2(1)              ,
  ACTION_BY                    VARCHAR2(30)             ,
  ACTION_ON                    DATE                     
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    30
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          500K
            NEXT             2M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_ORTHO_PLAN TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.ACH_GSD_ORTHO_PLAN TO PRODDBLINK;

GRANT SELECT ON  DCS2000.ACH_GSD_ORTHO_PLAN TO OPENCON;

--
-- IX1_ACH_GSD_ORTHO_PLAN  (Index) 
--
CREATE INDEX DCS2000.IX1_ACH_GSD_ORTHO_PLAN ON DCS2000.ACH_GSD_ORTHO_PLAN
(GSD_ORTHO_PLAN_PK)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          250K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- IX2_ACH_GSD_ORTHO_PLAN  (Index) 
--
CREATE INDEX DCS2000.IX2_ACH_GSD_ORTHO_PLAN ON DCS2000.ACH_GSD_ORTHO_PLAN
(GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE, PLN_CDE, EFF_DTE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          250K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

ALTER TABLE DCS2000.ACH_GSD_ORTHO_PLAN ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.4