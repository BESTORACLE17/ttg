/* VERSION: 3.1.1 */ 
--
-- TBL_ACCUMULATOR  (Table) 
--
CREATE TABLE DCS2000.TBL_ACCUMULATOR
(
  SUBR_ID          NUMBER(12)                   NOT NULL,
  GRP_ID           VARCHAR2(9 BYTE)             NOT NULL,
  PLAN_NUMBER      NUMBER(4)                    NOT NULL,
  INDV_ID          NUMBER(2)                    NOT NULL,
  COVERAGE_PERIOD  NUMBER(4)                    NOT NULL,
  COVERAGE_TYPE    NUMBER(2)                    NOT NULL,
  DDP_PAYS         NUMBER(7,2),
  PATIENT_PAYS     NUMBER(7,2),
  DEDUCTIBLE       NUMBER(7,2),
  MAINT_CDE        NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          10M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ACCUMULATOR TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ACCUMULATOR TO PRODDBLINK;

