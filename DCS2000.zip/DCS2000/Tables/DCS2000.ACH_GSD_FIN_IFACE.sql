/* VERSION: 3.1.3 */ 
--
-- ACH_GSD_FIN_IFACE  (Table) 
--
/*
| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR 06216.03.AR 
|| Revision By    : Jeff Reynolds
|| Revision Date  : 11/06/2007 
|| Revision Desc  : Expanded amount fields to NUMBER(15,2) and count fields
||                  to NUMBER(13).
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3
|| Revision Type  : Enhancement
|| Service Request: SR 10067.02.VA Multi Products 
|| Revision By    :  Satya Sai
|| Revision Date  : 08/03/2010 
|| Revision Desc  : Adding Product line code column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_FIN_IFACE
(
  MAINT_CODE               NUMBER(4),
  MOD_DATE                 DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE),
  SUBLOC_ID                VARCHAR2(8 BYTE),
  DIV_ID                   VARCHAR2(4 BYTE),
  PAY_DTE                  NUMBER(8),
  POST_DTE                 NUMBER(6),
  TRANSACTION_CODE         NUMBER(2),
  GL_ACCOUNT_NUMBER        VARCHAR2(20 BYTE),
  CLAIMS_CT                NUMBER(13),          /* 3.1.2 */
  CLAIMS_AMT               NUMBER(15,2),        /* 3.1.2 */
  INVOICE_NO               VARCHAR2(20 BYTE),
  SUBR_CNT                 NUMBER(13),          /* 3.1.2 */
  INVOICE_AMT              NUMBER(15,2),        /* 3.1.2 */
  PREMIUM_AMT              NUMBER(15,2),        /* 3.1.2 */
  CAP_AMT                  NUMBER(15,2),        /* 3.1.2 */
  ADJUSTED_INVOICE_AMOUNT  NUMBER(15,2)         /* 3.1.2 */
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          23920K
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_FIN_IFACE TO DCS_USERS_ALL;


ALTER TABLE DCS2000.ACH_GSD_FIN_IFACE ADD( PRODUCT_LINE_CODE NUMBER(4)); -- 3.1.3

