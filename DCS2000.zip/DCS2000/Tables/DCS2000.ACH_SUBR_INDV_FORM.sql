/* VERSION: 3.1.4*/ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR#07178.03.KY Overage Dep Processing
|| Revision By    : Ketan Patel.
|| Revision Date  : 03/04/2008.
|| Revision Desc  : Added column OVERAGE_DEP_LETTERS_PK
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4 
|| Service Request: 10067.02.ALL Multi Products
|| Revision By    : Satya Sai
|| Revision Date  : 09/08/2010
|| Revision Desc  : Adding Product Line code column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV_FORM  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_FORM
(
  SUBR_ID        VARCHAR2(9 BYTE),
  INDV_ID        NUMBER(2),
  FRM_TYP_CDE    NUMBER(4),
  FRM_REQ_DTE    NUMBER(8),
  FRM_ISS_DTE    NUMBER(8),
  DOC_TYPE       NUMBER(2),
  GRP_ID         VARCHAR2(9 BYTE),
  SUBLOC_ID      VARCHAR2(8 BYTE),
  DIV_ID         VARCHAR2(4 BYTE),
  PRV_ID         VARCHAR2(11 BYTE),
  CLAIM_NO       VARCHAR2(14 BYTE),
  DOC_ID         VARCHAR2(14 BYTE),
  MAINT_CODE     NUMBER(4),
  MOD_DTE        DATE,
  MOD_OP         VARCHAR2(12 BYTE),
  RECEIVE_DATE   NUMBER(8),
  EFF_DTE        NUMBER(8),
  TRM_DTE        NUMBER(8),
  ADDR_CDE       NUMBER(2),
  LTR_TYP_CDE    NUMBER(4),
  DOC_HEADER_ID  NUMBER(15),
  DISCLOSE_DTE   NUMBER(8),
  COMMENTS       VARCHAR2(2000 BYTE),
  IS_GRP_ADDR    VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          45424K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_INDV_FORM MODIFY SUBR_ID VARCHAR2(30);
-- Added with SR# 05208.01.ALL

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_INDV_FORM TO DCS_USERS_ALL;

-- Added for SR07121.01.ALL
ALTER TABLE	DCS2000.ACH_SUBR_INDV_FORM	MODIFY (PRV_ID  VARCHAR2(32) );

--3.1.3
ALTER TABLE DCS2000.ACH_SUBR_INDV_FORM 
   ADD (OVERAGE_DEP_LETTERS_PK NUMBER(10));
   
   --3.1.4
ALTER TABLE DCS2000.ACH_SUBR_INDV_FORM 
   ADD (PRODUCT_LINE_CODE NUMBER(4));

