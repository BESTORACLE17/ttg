/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Eric Lichtman
|| Revision Date  : 10/24/2006.
|| Revision Desc  : Altered table added column print_subr_id
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: SR# 05085.13.VA
|| Revision By    : Dinesh Makked
|| Revision Date  : 10/22/07
|| Revision Desc  : Added E_BILLING_EMAIL & BILLING_DISTRIBUTION_CODE
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4
|| Service Request:  06156.02.VA INDV Association Business
|| Revision By    : Satya sai
|| Revision Date  :05/01/2013
|| Revision Desc  : Added BILLING_INDV_EXTRACT_PK
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_INDV_EXTRACT  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_INDV_EXTRACT
(
  BATCH_ID             NUMBER(8)                NOT NULL,
  GRP_ID               VARCHAR2(9 BYTE)         NOT NULL,
  SUBLOC_ID            VARCHAR2(8 BYTE)         NOT NULL,
  DIV_ID               VARCHAR2(4 BYTE)         NOT NULL,
  PRD_CDE              NUMBER(4)                NOT NULL,
  PLN_CDE              NUMBER(4)                NOT NULL,
  SUBR_ID              VARCHAR2(9 BYTE)         NOT NULL,
  INDV_ID              NUMBER(2)                NOT NULL,
  LNME                 VARCHAR2(30 BYTE),
  FNME                 VARCHAR2(30 BYTE),
  RTE_CDE              NUMBER(2),
  EFF_DTE              NUMBER(8),
  BILL_MONTH_YEAR      NUMBER(6),
  BILL_CDE             NUMBER(2),
  OLD_RTE_AMT          NUMBER(5,2),
  NEW_RTE_AMT          NUMBER(5,2),
  BILLED_AMT           NUMBER(7,2),
  RUN_NUMBER           NUMBER(3),
  PAYMENT_METHOD_CODE  NUMBER(4)                NOT NULL,
  COBRA_ELIG_CDE       NUMBER(2),
  COBRA_EFF_DTE        NUMBER(8),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          20272K
            NEXT             16K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_INDV_EXTRACT TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_INDV_EXTRACT TO PRODDBLINK;

--
-- BILLING_EXTRACT_INDV_GSD_IX  (Index) 
--
CREATE INDEX DCS2000.BILLING_EXTRACT_INDV_GSD_IX ON DCS2000.TBL_BILLING_INDV_EXTRACT
(GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          8080K
            NEXT             200K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Foreign Key Constraints for Table TBL_BILLING_INDV_EXTRACT 
-- 
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT ADD (
  CONSTRAINT FK_BILLING_INDV_2_GSD FOREIGN KEY (GRP_ID, SUBLOC_ID, DIV_ID) 
    REFERENCES DCS2000.TBL_GSD (GRP_ID,SUBLOC_ID,DIV_ID));

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT MODIFY SUBR_ID VARCHAR2(30);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT ADD PRINT_SUBR_ID VARCHAR2(30);

-- Added for SR#05085.13.VA
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT
 ADD (E_BILLING_EMAIL VARCHAR2(500 BYTE));

-- Added for SR#05085.13.VA
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT
 ADD (BILLING_DISTRIBUTION_CODE  NUMBER(2));
 
-- Added for SR#06156.02.VA
ALTER TABLE DCS2000.TBL_BILLING_INDV_EXTRACT
 ADD (BILLING_INDV_EXTRACT_PK  NUMBER(6));