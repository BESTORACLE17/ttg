--********************
-- TBL_ADD_NEW_GROUP_LOG
-- SR - 07109.01.VA
-- version 2.1.1
--********************
CREATE TABLE DCS2000.TBL_ADD_NEW_GROUP_LOG
(
CREATED_BY		               VARCHAR2(12)      NOT NULL,
CREATED_ON                    DATE              NOT NULL,   
ERROR_CODE                    NUMBER,
ERROR_TEXT                    VARCHAR2(500),
MESSAGE                       VARCHAR2(500),
GRP_ID                        VARCHAR2(9)       NOT NULL,
SUBLOC_ID                     VARCHAR2(9)       NOT NULL,
DIV_ID                        VARCHAR2(9)       NOT NULL,
BEN_GRP_ID                    VARCHAR2(9)       NOT NULL,
BEN_SUBLOC_ID                 VARCHAR2(8)       NOT NULL,
BEN_DIV_ID                    VARCHAR2(4)       NOT NULL,
PLAN_ID                       NUMBER(9)         NOT NULL,
EFF_DATE								DATE				   NOT NULL,
TERM_DATE							DATE,
TERM_REASON_CODE					NUMBER(2)
);