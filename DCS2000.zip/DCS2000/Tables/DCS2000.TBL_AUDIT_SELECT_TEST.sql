/* VERSION: 3.1.1 */ 
--
-- TBL_AUDIT_SELECT_TEST  (Table) 
--
CREATE TABLE DCS2000.TBL_AUDIT_SELECT_TEST
(
  CLAIM_NO    VARCHAR2(14 BYTE)                 NOT NULL,
  MAINT_CODE  NUMBER(4),
  MOD_DTE     DATE,
  MOD_OP      VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          120K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_AUDIT_SELECT_TEST  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_AUDIT_SELECT_TEST ON DCS2000.TBL_AUDIT_SELECT_TEST
(CLAIM_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          520K
            NEXT             504K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_AUDIT_SELECT_TEST TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_AUDIT_SELECT_TEST TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_AUDIT_SELECT_TEST 
-- 
ALTER TABLE DCS2000.TBL_AUDIT_SELECT_TEST ADD (
  CONSTRAINT PK_AUDIT_SELECT_TEST PRIMARY KEY (CLAIM_NO)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          520K
                NEXT             504K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


