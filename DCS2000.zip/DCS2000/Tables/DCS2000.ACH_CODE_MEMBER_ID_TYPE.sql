-- VERSION: 2.1.1  
--
-- ACH_CODE_MEMBER_ID_TYPE (Table) 
--
CREATE TABLE DCS2000.ACH_CODE_MEMBER_ID_TYPE
(
   MAINT_CODE	    NUMBER(4),
   MOD_OP           VARCHAR2(30),
   MOD_DTE          DATE,
   CODE	            NUMBER(4),
   DESCRIPTION	    VARCHAR2(30),
   INS_UPD_FLAG     VARCHAR2(1)
)
   TABLESPACE PROD
   PCTUSED    40
   PCTFREE    10
   INITRANS   1
   MAXTRANS   255
   STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
   LOGGING 
   NOCACHE
   NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_CODE_MEMBER_ID_TYPE TO DCS_USERS_ALL;

