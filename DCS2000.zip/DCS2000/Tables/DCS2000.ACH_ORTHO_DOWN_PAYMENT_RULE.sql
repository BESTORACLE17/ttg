/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.1
|| Revision Type  : Enhancement
|| Service Request: SR07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 08/21/2008
|| Revision Desc  : Original version.  Defines the rules to use for standard
||                  down payment calculations.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version        : 3.1.2
|| Revision Type  : Enhancement
|| Service Request: SR07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 09/10/2008
|| Revision Desc  : Modified unique key structure to add a rule ID, so that
||                  multiple sets of rules can be defined instead of just one.
|| Production Date:
|| Production By  :
|| Dependencies   :
|| Limitations    :
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

/* VERSION: 3.1.1 */ 
--
-- ACH_ORTHO_DOWN_PAYMENT_RULE  (Table) 
--
CREATE TABLE DCS2000.ACH_ORTHO_DOWN_PAYMENT_RULE
(
  ORTHO_DOWN_PAYMENT_RULE_PK   NUMBER           NOT NULL,
  ORTHO_DP_RULE_ID             NUMBER(4)        NOT NULL,
  COST_RANGE_MAX_AMT           NUMBER(8,2)      NOT NULL,
  EFF_DTE                      NUMBER(8)        NOT NULL,
  TRM_DTE                      NUMBER(8)        NOT NULL,
  BILLED_OR_NET_AMOUNT_FLAG    VARCHAR2(1)      NOT NULL,
  DOWN_PAYMENT_PCT             NUMBER(6,2)              ,
  APPLY_COPAY_PCT_IND_YN       VARCHAR2(1)              ,
  NET_PAYMENT_MAXIMUM_AMT      NUMBER(8,2)              ,
  MAINT_CODE                   NUMBER(4)        NOT NULL,
  MOD_DTE                      DATE                     ,
  MOD_OP                       VARCHAR2(12 BYTE)        ,
  INS_UPD_FLAG                 VARCHAR2(1)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    30
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          500K
            NEXT             2M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_ORTHO_DOWN_PAYMENT_RULE TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.ACH_ORTHO_DOWN_PAYMENT_RULE TO PRODDBLINK;

GRANT SELECT ON  DCS2000.ACH_ORTHO_DOWN_PAYMENT_RULE TO OPENCON;
