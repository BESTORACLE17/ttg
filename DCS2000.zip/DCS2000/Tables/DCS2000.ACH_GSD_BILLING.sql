/* VERSION: 2.1.9 */ 
--
-- ACH_GSD_BILLING  (Table) 
-- 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05085.06.AR - Display Leave of Absence Info 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 08/01/2005 
|| Revision Desc  : Added BENEFIT_SERVICES_PROFILE_ID column 
|| Production Date: 
|| Production By  : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.3 
|| Service Request: SR 07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/10/2008 
|| Revision Desc  : Added the following columns 
||               1.pk
||               2.created_by 
||               3.created_on 
||               4.updated_by 
||               5.updated_on 
||               6.action_code
||               7.action_by
||               8.action_on
|| Production Date: 
|| Production By  : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.4 
|| Service Request: SR 07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/13/2008 
|| Revision Desc  : Renamed pk to gsd_billing_pk
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.5 
|| Service Request: SR 08092.27.CO - Retro Termination Date Checks
|| Revision By    : Deborah Yates
|| Revision Date  : 07/21/2008 
|| Revision Desc  : added the ELIG_END_DAY column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.6 
|| Service Request: SR 08092.29.CO - Special Billing Coverage for Dependents
|| Revision By    : Ram Garimella
|| Revision Date  : 08/23/2008 
|| Revision Desc  : added the minimum_age column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.7
|| Service Request: SR08092.26.CO - Late Entrant
|| Revision By    : Deborah Yates
|| Revision Date  : 09/09/2009
|| Revision Desc  : added the late_entrant_override_flag column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.8
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.9
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 07/30/2010 
|| Revision Desc  : Added Combined_billing column 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_BILLING
(
  MAINT_CODE                   NUMBER(4)        NOT NULL,
  MOD_DTE                      DATE,
  MOD_OP                       VARCHAR2(12 BYTE),
  GRP_ID                       VARCHAR2(9 BYTE) NOT NULL,
  SUBLOC_ID                    VARCHAR2(8 BYTE) NOT NULL,
  DIV_ID                       VARCHAR2(4 BYTE) NOT NULL,
  PRD_CDE                      NUMBER(4)        NOT NULL,
  PLN_CDE                      NUMBER(4)        NOT NULL,
  EFF_DTE                      NUMBER(8)        NOT NULL,
  TRM_DTE                      NUMBER(8)        NOT NULL,
  BILLING_TYPE                 NUMBER(2)        NOT NULL,
  BILLING_RULE                 NUMBER(2),
  BILLING_CYCLE                NUMBER(2)        NOT NULL,
  BILLING_DISTRIBUTION_CODE    NUMBER(2),
  ELIG_WAIT_PERIOD_DAYS        NUMBER(4),
  ELIG_WAIT_PERIOD_MONTHS      NUMBER(2),
  ELIG_START_DAY               NUMBER(2),
  ELIG_START_RANGE             NUMBER(2),
  ELIG_EFF_DTE_REQUIRED        NUMBER(1),
  INIT_ENR_ELIG_WAIT_PER_OVER  NUMBER(1),
  RETRO_IND                    NUMBER(1)        NOT NULL,
  RETRO_UOM_CODE               NUMBER(4)        NOT NULL,
  RETRO_UNITS                  NUMBER(4)        NOT NULL,
  ALLOW_RETRO_WITH_CLAIMS      NUMBER(1),
  ASO_REPORTING_CODE           NUMBER(4),
  INDV_AUTO_RENEWAL_IND        NUMBER(1)        NOT NULL,
  COBRA_ADMIN_IND              NUMBER(1)        NOT NULL,
  DELINQUENCY_PROFILE_ID       NUMBER(12)       NOT NULL,
  INS_UPD_FLAG                 CHAR(1 BYTE),
  BILLING_FREQ                 NUMBER(2),
  BROKER_ID_REQUIRED           VARCHAR2(1 BYTE),
  PAYMENT_METHOD_CODE          NUMBER(4),
  ADDITIONAL_FEES              NUMBER(1),
  IMAGE_ID_REQUIRED            NUMBER(1),
  BANK_ACH_DETAIL_ID           NUMBER(4),
  BANK_ROUTING_NUMBER          VARCHAR2(30 BYTE),
  BANK_ACCOUNT_NUMBER          VARCHAR2(30 BYTE),
  BANK_ACCOUNT_TYPE_CODE       NUMBER(4),
  CREDIT_CARD_NUMBER           VARCHAR2(30 BYTE),
  CREDIT_CARD_TYPE_CODE        NUMBER(4),
  CREDIT_CARD_EXPIRE_YEAR      VARCHAR2(4 BYTE),
  CREDIT_CARD_EXPIRE_MONTH     VARCHAR2(2 BYTE),
  PAYMENT_METHOD_ACTIVE_FLAG   VARCHAR2(1 BYTE),
  TAX_TYPE_CODE                NUMBER(4),
  RATE_TYPE                    NUMBER(4),
  SECURITY_DEPOSIT             NUMBER(1),
  ENROLLMENT_FEE               NUMBER(1)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_BILLING TO DCS_USERS_ALL;

-- 
-- 05085.06.AR - Added the following column to the table 
-- 
ALTER TABLE DCS2000.ACH_GSD_BILLING ADD BENEFIT_SERVICES_PROFILE_ID NUMBER(4);

--Version 2.1.3 
--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (gsd_billing_pk NUMBER);  --2.1.4 

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_BILLING ON DCS2000.ACH_GSD_BILLING(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,EFF_DTE) TABLESPACE PRODIX;
--End SR07109.04.VA


-- 2.1.5
ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (ELIG_END_DAY NUMBER(2));

-- 2.1.6
ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (MINIMUM_AGE NUMBER(2));

-- 2.1.7
ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (LATE_ENTRANT_OVERRIDE_FLAG NUMBER(1));

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (PRODUCT_LINE_CODE  NUMBER(4)); --2.1.8

ALTER TABLE DCS2000.ACH_GSD_BILLING ADD (COMBINED_BILLING_FLAG  VARCHAR2(1)); --2.1.9