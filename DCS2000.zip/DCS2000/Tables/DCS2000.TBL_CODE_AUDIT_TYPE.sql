/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_AUDIT_TYPE  (Table) 
--
CREATE TABLE DCS2000.TBL_CODE_AUDIT_TYPE
(
  CODE         NUMBER(4)                        NOT NULL,
  DESCRIPTION  VARCHAR2(50 BYTE)                NOT NULL,
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CODE_AUDIT_TYPE  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CODE_AUDIT_TYPE ON DCS2000.TBL_CODE_AUDIT_TYPE
(CODE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_AUDIT_TYPE TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CODE_AUDIT_TYPE TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_AUDIT_TYPE 
-- 
ALTER TABLE DCS2000.TBL_CODE_AUDIT_TYPE ADD (
  CONSTRAINT PK_CODE_AUDIT_TYPE PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          16K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


