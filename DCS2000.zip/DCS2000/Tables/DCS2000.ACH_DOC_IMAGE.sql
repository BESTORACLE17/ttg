/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_DOC_IMAGE  (Table) 
--
CREATE TABLE DCS2000.ACH_DOC_IMAGE
(
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  DOC_HEADER_ID    NUMBER(9),
  GRP_ID           VARCHAR2(9 BYTE),
  SUBLOC_ID        VARCHAR2(8 BYTE),
  DIV_ID           VARCHAR2(4 BYTE),
  NEI              VARCHAR2(9 BYTE),
  AGENCY_ID        VARCHAR2(9 BYTE),
  BROKER_ID        VARCHAR2(9 BYTE),
  FORM_TYPE        NUMBER(4),
  REQUEST_DTE      NUMBER(8),
  RECEIVED_DTE     NUMBER(8),
  EFF_DTE          NUMBER(8),
  TRM_DTE          NUMBER(8),
  DOC_ID           VARCHAR2(100 BYTE),
  COMMENTS         VARCHAR2(2000 BYTE),
  TERM_EVENT_CODE  NUMBER(4),
  ISSUE_DTE        NUMBER(8),
  DISCLOSE_DTE     NUMBER(8),
  PRV_ID           VARCHAR2(11 BYTE),
  LOC              NUMBER(4),
  TAX_ID           VARCHAR2(9 BYTE),
  FAC_STATE        VARCHAR2(2 BYTE),
  SUBR_ID          VARCHAR2(9 BYTE),
  INDV_ID          NUMBER(2),
  SCAN_LOC         NUMBER(2),
  DOCUMENT_KEY     VARCHAR2(100 BYTE)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_DOC_IMAGE TO DCS_USERS_ALL;

alter table dcs2000.ach_doc_image add PRODUCER_ID        NUMBER(15);
alter table dcs2000.ach_doc_image add CHECK_NBR          VARCHAR2(10);
alter table dcs2000.ach_doc_image add CHECK_CLEARED_DATE NUMBER(8);

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_DOC_IMAGE MODIFY SUBR_ID VARCHAR2(30);

-- Added with SR# 06214.01.ALL
ALTER TABLE DCS2000.ACH_DOC_IMAGE ADD (NATIONAL_PROVIDER_ID NUMBER(10) );

-- Addfor for SR 07121.01.ALL 12 Dig lic number
ALTER TABLE	DCS2000.ACH_DOC_IMAGE	MODIFY (PRV_ID    VARCHAR2(32) ); 
