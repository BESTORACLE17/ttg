/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_CHECK_REGISTER  (Table) 
--
CREATE TABLE DCS2000.TBL_CHECK_REGISTER
(
  PAYMENT_DATE        VARCHAR2(10 BYTE),
  RUN_NUMBER          NUMBER(3),
  CHECK_NBR           VARCHAR2(10 BYTE),
  CHECK_AMT           NUMBER(8,2),
  PAYEE_NO            VARCHAR2(9 BYTE),
  AOB                 NUMBER(1),
  LOC                 NUMBER(4),
  FAC_STATE           VARCHAR2(2 BYTE),
  PAYEE_NAME          VARCHAR2(60 BYTE),
  L_TOTALWITHHOLDAMT  NUMBER(8,2),
  L_TOTALNET          NUMBER(8,2),
  L_BALANCE_AMT       NUMBER(8,2)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             512K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_CHECK_REGISTER MODIFY PAYEE_NO VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CHECK_REGISTER TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CHECK_REGISTER TO PRODDBLINK;

