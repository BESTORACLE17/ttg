--=======================================
--SR 07109.04 VA GM QUALITY EDITS
--Date 06/30/2008 
--Pramod Gujjar
--=======================================
/* VERSION: 3.1.1 */ 
CREATE TABLE DCS2000.ACH_GM_UPD_NOTIFICATIONS
( GRP_ID                       VARCHAR2(9),
  SUBLOC_ID                    VARCHAR2(8),
  DIV_ID                       VARCHAR2(4),
  FROM_VALUE                   VARCHAR2(4000),
  TO_VALUE                     VARCHAR2(4000),
  TABLE_COLUMN_PK              NUMBER,
  ACTION_CODE                  VARCHAR2(1),
  ACTION_BY                    VARCHAR2(30),
  ACTION_ON                    DATE,
  STATUS                       VARCHAR2(30)
); 
GRANT INSERT, SELECT, UPDATE, DELETE ON DCS2000.ACH_GM_UPD_NOTIFICATIONS TO DCS_USERS_ALL;