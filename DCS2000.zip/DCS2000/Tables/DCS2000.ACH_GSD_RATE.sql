/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_RATE  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_RATE
(
  GRP_ID        VARCHAR2(9 BYTE),
  SUBLOC_ID     VARCHAR2(8 BYTE),
  DIV_ID        VARCHAR2(4 BYTE),
  PRD_CDE       NUMBER(4),
  PLN_CDE       NUMBER(4),
  RATE_CDE      NUMBER(2),
  RATE_EFF_DTE  NUMBER(8),
  RATE_TRM_DTE  NUMBER(8),
  PREMIUM_AMT   NUMBER(7,2),
  MAINT_CODE    NUMBER(4),
  MOD_DTE       DATE,
  MOD_OP        VARCHAR2(12 BYTE),
  INS_UPD_FLAG  CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          7064K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACH_GSD_RATE_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_GSD_RATE_IX ON DCS2000.ACH_GSD_RATE
(GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE, PLN_CDE, 
RATE_CDE, RATE_EFF_DTE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          6208K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_RATE TO DCS_USERS_ALL;

--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_RATE ADD (gsd_rate_pk NUMBER); --3.1.3

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_RATE ADD (action_on DATE);
--End SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_RATE ADD (PRODUCT_LINE_CODE  NUMBER(4));--3.1.4 