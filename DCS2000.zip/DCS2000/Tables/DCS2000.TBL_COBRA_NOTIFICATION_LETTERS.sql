/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_COBRA_NOTIFICATION_LETTERS  (Table) 
--
CREATE TABLE DCS2000.TBL_COBRA_NOTIFICATION_LETTERS
(
  SUBR_ID        VARCHAR2(9 BYTE)               NOT NULL,
  GRP_ID         VARCHAR2(9 BYTE)               NOT NULL,
  SUBLOC_ID      VARCHAR2(8 BYTE)               NOT NULL,
  DIV_ID         VARCHAR2(4 BYTE)               NOT NULL,
  NME            VARCHAR2(50 BYTE),
  ADDRESS_LINE1  VARCHAR2(30 BYTE)              NOT NULL,
  ADDRESS_LINE2  VARCHAR2(30 BYTE),
  ADDRESS_LINE3  VARCHAR2(30 BYTE),
  CITY           VARCHAR2(30 BYTE)              NOT NULL,
  STATE          VARCHAR2(2 BYTE)               NOT NULL,
  ZIP            NUMBER(5)                      NOT NULL,
  ZIP4           NUMBER(4),
  CUR_TRM_DTE    VARCHAR2(18 BYTE),
  NEW_EFF_DTE    VARCHAR2(18 BYTE),
  NEW_TRM_DTE    VARCHAR2(18 BYTE),
  TERM_REASON    VARCHAR2(30 BYTE),
  PLAN_NAME      VARCHAR2(35 BYTE),
  PRODUCT        VARCHAR2(30 BYTE),
  MONTHS         NUMBER(2),
  RATE_DESC1     VARCHAR2(30 BYTE),
  PREMIUM_AMT1   NUMBER(7,2),
  RATE_DESC2     VARCHAR2(30 BYTE),
  PREMIUM_AMT2   NUMBER(7,2),
  RATE_DESC3     VARCHAR2(30 BYTE),
  PREMIUM_AMT3   NUMBER(7,2),
  RATE_DESC4     VARCHAR2(30 BYTE),
  PREMIUM_AMT4   NUMBER(7,2),
  RATE_DESC5     VARCHAR2(30 BYTE),
  PREMIUM_AMT5   NUMBER(7,2),
  MAINT_CODE     NUMBER(4),
  MOD_DTE        DATE,
  MOD_OP         VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          20272K
            NEXT             16K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- BILLING_COBRA_LETTERS_IX  (Index) 
--
CREATE INDEX DCS2000.BILLING_COBRA_LETTERS_IX ON DCS2000.TBL_COBRA_NOTIFICATION_LETTERS
(SUBR_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          8080K
            NEXT             200K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_COBRA_NOTIFICATION_LETTERS MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_COBRA_NOTIFICATION_LETTERS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_COBRA_NOTIFICATION_LETTERS TO PRODDBLINK;

