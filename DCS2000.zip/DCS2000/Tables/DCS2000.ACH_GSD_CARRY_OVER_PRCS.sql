/* VERSION: 3.1.2 */ 
--
-- ACH_GSD_CARRY_OVER_PRCS  (Table) 
--
-- SR07109.04.VA
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.3
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_CARRY_OVER_PRCS
(
  GRP_ID              VARCHAR2(9 BYTE),
  SUBLOC_ID           VARCHAR2(8 BYTE),
  DIV_ID              VARCHAR2(4 BYTE),
  PRD_CDE             NUMBER(4),
  PLN_CDE             NUMBER(4),
  SEQ_IND             NUMBER(4),
  EFF_DTE             NUMBER(8),
  TRM_DTE             NUMBER(8),
  OCCURANCE           NUMBER(4),
  PROCEDURES          VARCHAR2(512 BYTE),
  CARRY_OVER_EFF_DTE  VARCHAR2(512 BYTE),
  MAINT_CODE          NUMBER(4),
  MOD_DTE             DATE,
  MOD_OP              VARCHAR2(12 BYTE),
  GSD_CARRY_OVER_PRCS_PK                  NUMBER, --3.1.2
  CREATED_BY          VARCHAR2(30 BYTE),
  CREATED_ON          DATE,
  UPDATED_BY          VARCHAR2(30 BYTE),
  UPDATED_ON          DATE,
  ACTION_CODE         VARCHAR2(1 BYTE),
  ACTION_BY           VARCHAR2(30 BYTE),
  ACTION_ON           DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          7064K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_CARRY_OVER_PRCS TO DCS_USERS_ALL;

ALTER TABLE DCS2000.ACH_GSD_CARRY_OVER_PRCS ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.3