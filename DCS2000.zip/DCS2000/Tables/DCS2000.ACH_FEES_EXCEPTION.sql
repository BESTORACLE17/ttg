/* VERSION: 3.1.2 */ 
--
-- ACH_FEES_EXCEPTION  (Table) 
--
CREATE TABLE DCS2000.ACH_FEES_EXCEPTION
(
  PRV_ID                 VARCHAR2(11 BYTE),
  LOC                    NUMBER(4),
  TAX_ID                 VARCHAR2(9 BYTE),
  FAC_STATE              VARCHAR2(2 BYTE),
  PRD_CDE                NUMBER(4),
  PLN_CDE                NUMBER(4),
  GRP_ID                 VARCHAR2(9 BYTE),
  SUBLOC_ID              VARCHAR2(8 BYTE),
  DIV_ID                 VARCHAR2(4 BYTE),
  PRC_CDE                VARCHAR2(5 BYTE),
  EFF_DTE                NUMBER(8),
  TRM_DTE                NUMBER(8),
  EXCEPTION_CDE          NUMBER(4),
  EXCEPTION_PERCENT_CDE  NUMBER(4),
  EXCEPTION_PERCENT      NUMBER(6,3),
  EXCEPTION_AMT          NUMBER(8,3),
  MAINT_CODE             NUMBER(4),
  MOD_DTE                DATE,
  MOD_OP                 VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1000K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_FEES_EXCEPTION TO DCS_USERS_ALL;

-- Added for SR 07121.01.ALL 12 dig lic number
ALTER TABLE	DCS2000.ACH_FEES_EXCEPTION	MODIFY (PRV_ID VARCHAR2(32) );
/
Alter table dcs2000.ACH_FEES_EXCEPTION add( NETWORK_ID NUMBER(4)); -- 3.1.2 Satya 11105.02.ALL Multi network 
/
