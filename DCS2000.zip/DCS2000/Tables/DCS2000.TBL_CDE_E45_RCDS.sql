/* VERSION: 2.1.2 */ 
--
-- TBL_CDE_E45_RCDS  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05068.01.VA Add Company ID in W9 Record 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/08/2005 
|| Revision Desc  : Added PARENT_ID column.  
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/ 
CREATE TABLE DCS2000.TBL_CDE_E45_RCDS
(
  RECORD_TYPE     CHAR(2 BYTE),
  BATCH_DATE      VARCHAR2(8 BYTE),
  BATCH_TYPE      CHAR(2 BYTE),
  CLAIM_TYPE      CHAR(1 BYTE),
  BATCH_NO        CHAR(4 BYTE),
  REEL_NO         CHAR(1 BYTE),
  SUFFIX          CHAR(2 BYTE),
  JULIAN_DATE     VARCHAR2(7 BYTE),
  CLAIM_NO        VARCHAR2(5 BYTE),
  RCV_DATE        VARCHAR2(8 BYTE),
  GRP_ID          VARCHAR2(9 BYTE),
  PRV_ID          VARCHAR2(13 BYTE),
  PRV_LNAME       VARCHAR2(5 BYTE),
  ACCIDENT_CDE    CHAR(1 BYTE),
  PROCESS_STATUS  NUMBER(1),
  PRV_LOC         VARCHAR2(4 BYTE),
  PRV_TAX_ID      VARCHAR2(9 BYTE),
  FAC_STATE       VARCHAR2(2 BYTE),
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          816K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- IX_CDE_E45_RCDS  (Index) 
--
CREATE INDEX DCS2000.IX_CDE_E45_RCDS ON DCS2000.TBL_CDE_E45_RCDS
(JULIAN_DATE, CLAIM_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          600K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CDE_E45_RCDS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CDE_E45_RCDS TO PRODDBLINK;

GRANT INSERT, SELECT ON  DCS2000.TBL_CDE_E45_RCDS TO DATAENTRY;

--
-- S/R #05068.01.VA Add Company ID in W9 Record 
-- Version: 2.1.2 
-- 
ALTER TABLE DCS2000.TBL_CDE_E45_RCDS ADD (PARENT_ID    NUMBER(4));

-- Added as part of 06214.01.ALL - NPI -- Ram
ALTER TABLE DCS2000.TBL_CDE_E45_RCDS ADD  ( RENDERING_PROVIDER_NPI   NUMBER(10));
ALTER TABLE DCS2000.TBL_CDE_E45_RCDS ADD  ( BILLING_PROVIDER_NPI   NUMBER(10));

-- Added for SR07121.01.ALL
ALTER TABLE	DCS2000.TBL_CDE_E45_RCDS	MODIFY (PRV_ID VARCHAR2(32) ); 

--- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DCS2000.TBL_CDE_E45_RCDS modify 
  (ADDR1    VARCHAR2(64 ),
   ADDR2    VARCHAR2(64 )
  );