--********************
-- ACH_GA_CLASS_RULE_HEADER
-- SR - 07109.01.VA
-- version 2.1.1
--********************
CREATE TABLE DCS2000.ACH_GA_CLASS_RULE_HEADER
(
  CREATED_BY               VARCHAR2(12 BYTE),
  CREATED_ON               DATE,   
  UPDATED_BY               VARCHAR2(12 BYTE),
  UPDATED_ON               DATE,    
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1 BYTE),
  ACTION_BY                VARCHAR2(30 BYTE),
  ACTION_ON                DATE,
  CLASS_RULE_HEADER_PK     NUMBER(9),
  CLASS_RULE_ID            NUMBER(12),
  CLASS_RULE_NAME          VARCHAR2(100 BYTE), 
  EFF_DATE                 DATE, 
  TERM_DATE                DATE,                 
  TERM_REASON_CODE         NUMBER(4),
  COMMENTS                 VARCHAR2(200 BYTE),
  NOTES                    VARCHAR2(200 BYTE)
);
