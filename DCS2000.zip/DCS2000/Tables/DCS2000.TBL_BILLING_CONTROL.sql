/* VERSION: 3.1.2 */ 
--
-- TBL_BILLING_CONTROL  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR01313.01.VA - Retro Rate Change on Bills
|| Revision By    : Jeff Reynolds
|| Revision Date  : 02/27/2008.
|| Revision Desc  : Added allow_bill_run_flag
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.TBL_BILLING_CONTROL
(
  BILL_CYCLE     NUMBER(2),
  BILL_FROM_DTE  NUMBER(8),
  BILL_TO_DTE    NUMBER(8),
  BILL_DUE_DTE   NUMBER(8),
  RUN_NUMBER     NUMBER(3)                      NOT NULL,
  MAINT_CODE     NUMBER(4),
  MOD_DTE        DATE,
  MOD_OP         VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          56K
            NEXT             8K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_CONTROL TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_CONTROL TO PRODDBLINK;

GRANT SELECT ON  DCS2000.TBL_BILLING_CONTROL TO EEP;

-- 3.1.2
ALTER TABLE DCS2000.ACH_BILLING_CONTROL ADD (
   allow_bill_run_flag        VARCHAR2(1)
);
