CREATE TABLE DCS2000.ACH_ATRB_STATE_PRICING
(
  CREATED_BY                     VARCHAR2(30),
  CREATED_ON                     DATE,
  UPDATED_BY                     VARCHAR2(30),
  UPDATED_ON                     DATE,
  ACTION_CODE                    VARCHAR2(1),
  ACTION_BY                      VARCHAR2(30),
  ACTION_ON                      DATE,
  MAINT_CODE                     NUMBER(4)    NOT NULL,
  STATE                          VARCHAR2(2)  NOT NULL,
  STATE_EFF_DTE                  NUMBER(8),
  GRP_ID                         VARCHAR2(9),
  SUBLOC_ID                      VARCHAR2(8),
  DIV_ID                         VARCHAR2(4),
  EFF_DATE                       DATE,
  TERM_DATE                      DATE,
  CONSISTENT_REIMBURSEMENT_FLAG  NUMBER(1)
);
GRANT INSERT, SELECT, UPDATE, DELETE ON DCS2000.ACH_ATRB_STATE_PRICING TO DCS_USERS_ALL; 