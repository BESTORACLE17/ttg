/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: SR# 08092.27.CO - Retro Add / Term Date Validation
|| Revision By    : Deborah Yates
|| Revision Date  : 09/04/2008
|| Revision Desc  : Added the submitted_indv_trm_dte column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4
|| Service Request: SR 10067.02.VA Multi Products
|| Revision By    : Satya Sai
|| Revision Date  : 06/23/2010
|| Revision Desc  : New column Product line code added
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_COVER_INDV  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_COVER_INDV
(
  SUBR_ID             VARCHAR2(9 BYTE),
  INDV_ID             NUMBER(2),
  GRP_ID              VARCHAR2(9 BYTE),
  SUBLOC_ID           VARCHAR2(8 BYTE),
  DIV_ID              VARCHAR2(4 BYTE),
  PRD_CDE             NUMBER(4),
  PLN_CDE             NUMBER(4),
  RTE_CDE             NUMBER(4),
  COVER_EFF_DTE       NUMBER(8),
  SUBR_NO             VARCHAR2(9 BYTE),
  INDV_NO             NUMBER(2),
  INDV_EFF_DTE        NUMBER(8),
  INDV_TRM_DTE        NUMBER(8),
  TRM_REASON_CDE      NUMBER(2),
  TRM_COMMENT         VARCHAR2(200 BYTE),
  PRIORITY_CDE        NUMBER(2),
  MAINT_CODE          NUMBER(4),
  MOD_DTE             DATE,
  MOD_OP              VARCHAR2(12 BYTE),
  INS_UPD_FLAG        VARCHAR2(1 BYTE),
  BASE_INCENTIVE_LVL  NUMBER(2)
)
TABLESPACE ARCHIVE
PCTUSED    90
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          100M
            NEXT             10M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACH_SUBR_COVER_INDV_GRP_ID_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_SUBR_COVER_INDV_GRP_ID_IX ON DCS2000.ACH_SUBR_COVER_INDV
(GRP_ID, SUBLOC_ID, MOD_OP)
LOGGING
TABLESPACE ARCHIVE
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          5M
            NEXT             2M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  2
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- ACH_SUBR_COVER_INDV_IX  (Index) 
--
CREATE INDEX DCS2000.ACH_SUBR_COVER_INDV_IX ON DCS2000.ACH_SUBR_COVER_INDV
(SUBR_ID, INDV_NO, GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE ARCHIVE
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          30M
            NEXT             5M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_COVER_INDV MODIFY SUBR_ID VARCHAR2(30);
ALTER TABLE DCS2000.ACH_SUBR_COVER_INDV MODIFY SUBR_NO VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_COVER_INDV TO DCS_USERS_ALL;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE ON  DCS2000.ACH_SUBR_COVER_INDV TO DMAKKED;

ALTER TABLE DCS2000.ACH_SUBR_COVER_INDV ADD (
    SUBMITTED_INDV_COVER_TRM_DTE    NUMBER(8)
);
-- 3.1.4
ALTER TABLE DCS2000.ACH_SUBR_COVER_INDV ADD (
    PRODUCT_LINE_CODE  NUMBER(4)
);

