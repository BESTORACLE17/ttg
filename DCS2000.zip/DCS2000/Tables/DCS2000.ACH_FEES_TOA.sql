/* VERSION: 3.1.1 */ 
--
-- ACH_FEES_TOA  (Table) 
--
CREATE TABLE DCS2000.ACH_FEES_TOA
(
  TOA_ID      NUMBER(4),
  PRC_CDE     VARCHAR2(5 BYTE),
  EFF_DTE     NUMBER(8),
  TRM_DTE     NUMBER(8),
  FEE         NUMBER(7,2),
  REG_CDE     NUMBER(4),
  MAINT_CODE  NUMBER(4),
  MOD_DTE     DATE,
  MOD_OP      VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1120K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_FEES_TOA TO DCS_USERS_ALL;

