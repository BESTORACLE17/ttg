/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_EXTRACT_RPT  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_EXTRACT_RPT
(
  GRPSUBDIV          VARCHAR2(38 BYTE),
  GROUP_NAME         VARCHAR2(100 BYTE)         NOT NULL,
  SUBSCRIBER_ID      VARCHAR2(15 BYTE),
  LAST_NAME          VARCHAR2(30 BYTE),
  FIRST_NAME         VARCHAR2(30 BYTE),
  RATE_CODE          NUMBER(2),
  EFFECTIVE_DATE     VARCHAR2(10 BYTE),
  ADJUST_DATE        VARCHAR2(10 BYTE),
  BILLING_CODE       NUMBER,
  OLD_RATE_AMOUNT    NUMBER(5,2),
  NEW_RATE_AMOUNT    NUMBER(5,2),
  BILLED_AMOUNT      NUMBER(5,2),
  BILLING_FROM_DATE  VARCHAR2(10 BYTE),
  BILLING_END_DTE    VARCHAR2(10 BYTE),
  BILLING_DUE_DATE   VARCHAR2(10 BYTE),
  ADDRESS_LINE1      VARCHAR2(30 BYTE)          NOT NULL,
  ADDRESS_LINE2      VARCHAR2(30 BYTE),
  ADDRESS_LINE3      VARCHAR2(30 BYTE),
  CITY               VARCHAR2(30 BYTE)          NOT NULL,
  STATE              VARCHAR2(2 BYTE)           NOT NULL,
  ZIP                NUMBER(5)                  NOT NULL,
  ZIP4               NUMBER(4),
  BILL_AMT1          NUMBER(9,2),
  BILL_DTE1          VARCHAR2(10 BYTE),
  BILL_AMT2          NUMBER(9,2),
  BILL_DTE2          VARCHAR2(10 BYTE),
  BILL_AMT3          NUMBER(9,2),
  LNAME              VARCHAR2(30 BYTE),
  FNAME              VARCHAR2(30 BYTE),
  BILLING_DISTR      NUMBER(2),
  BILLING_RULE       NUMBER(2)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          35880K
            NEXT             520K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_EXTRACT_RPT MODIFY SUBSCRIBER_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_EXTRACT_RPT TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_EXTRACT_RPT TO PRODDBLINK;

