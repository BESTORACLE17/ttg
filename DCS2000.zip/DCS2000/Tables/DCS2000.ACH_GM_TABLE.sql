/* VERSION: 2.1.1 */
CREATE TABLE DCS2000.ACH_GM_TABLE
(
  CREATED_BY            VARCHAR2(30 BYTE),
  CREATED_ON            DATE,
  UPDATED_BY            VARCHAR2(30 BYTE),
  UPDATED_ON            DATE,
  MAINT_CODE            NUMBER(4),
  ACTION_CODE           VARCHAR2(1 BYTE),
  ACTION_BY             VARCHAR2(30 BYTE),
  ACTION_ON             DATE,
  TABLE_PK              NUMBER(12),
  NAME                  VARCHAR2(30 BYTE),
  DISPLAY_NAME          VARCHAR2(100 BYTE),
  GM_TABLE_GROUP_PK     NUMBER(4)
)
TABLESPACE PROD;

COMMENT ON TABLE DCS2000.ACH_GM_TABLE               IS 'Table that describes the tab names displayed on the front-end appliactions. This table is intended to be used by review reports.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.CREATED_BY   IS 'User ID of the user who created the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.CREATED_ON   IS 'Date on which the row was created.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.UPDATED_BY   IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.UPDATED_ON   IS 'Date on which the row was last updated.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.ACTION_CODE  IS 'Action (Insert/Update/Delete) that was taken on the production record that caused old maintenance record to be archived. I = Insert, U = Update, and D = Delete.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.ACTION_BY    IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.ACTION_ON    IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.TABLE_PK     IS 'System generated PK.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.NAME         IS 'Name of the database table.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE.DISPLAY_NAME IS 'Display name of the table in front end application.';

ALTER TABLE DCS2000.ACH_GM_TABLE ADD (OWNER      VARCHAR2(30));
ALTER TABLE DCS2000.ACH_GM_TABLE ADD (TAB_NAME   VARCHAR2(30));