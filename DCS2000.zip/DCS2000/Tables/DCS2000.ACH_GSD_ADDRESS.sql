/* VERSION: 3.1.7 */ 
--============================================================================
-- Revision Type  : Enhancement
-- Service Request: SR05085.13.VA
-- Version        : 3.1.2
-- Revision By    : Jeff Reynolds
-- Revision Date  : 08/21/2007
-- Revision Desc  : Added new columns E_BILLING_EMAIL_1 and E_BILLING_EMAIL_2
--============================================================================
-- Revision Type  : Enhancement
-- Service Request: HD30048
-- Version        : 3.1.3
-- Revision By    : Jeff Reynolds
-- Revision Date  : 12/27/2007
-- Revision Desc  : Added new column BILLING_DISTRIBUTION_CODE
--============================================================================
-- Revision Type  : Enhancement
-- Service Request: HD30048
-- Version        : 3.1.4
-- Revision By    : Jeff Reynolds
-- Revision Date  : 01/31/2008
-- Revision Desc  : Dropped column E_BILLING_EMAIL_2
--============================================================================
-- Revision Type  : Enhancement
-- Service Request: SR07109.04.VA
-- Version        : 3.1.5
-- Revision By    : Sanjay Mudaliar
-- Revision Date  : 06/10/2008
-- Revision Desc  : Added the following columns
--               1.pk
--               2.created_by 
--               3.created_on 
--               4.updated_by 
--               5.updated_on 
--               6.action_code
--               7.action_by
--               8.action_on
--============================================================================
-- Revision Type  : Enhancement
-- Service Request: SR07109.04.VA
-- Version        : 3.1.6
-- Revision By    : Sanjay Mudaliar
-- Revision Date  : 06/13/2008
-- Revision Desc  : Renamed column pk to gsd_address_pk
--============================================================================
/*
|| Version #      : 3.1.7
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_ADDRESS  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_ADDRESS
(
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  ADDR_CDE             NUMBER(2),
  CONTACT_SALUTATION   NUMBER(2),
  LNME                 VARCHAR2(30 BYTE),
  FNME                 VARCHAR2(30 BYTE),
  ADDR1                VARCHAR2(30 BYTE),
  ADDR2                VARCHAR2(30 BYTE),
  ADDR3                VARCHAR2(30 BYTE),
  CITY                 VARCHAR2(30 BYTE),
  STATE                VARCHAR2(2 BYTE),
  ZIP                  NUMBER(5),
  ZIP4                 NUMBER(4),
  COUNTRY_CDE          NUMBER(4),
  REGION_OVERRIDE_CDE  NUMBER(4),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  INS_UPD_FLAG         CHAR(1 BYTE),
  E_BILLING_EMAIL_1    VARCHAR2(500 BYTE),           /* 3.1.2 */
  -- E_BILLING_EMAIL_2    VARCHAR2(500 BYTE),           /* 3.1.2 */  /* 3.1.4 */
  BILLING_DISTRIBUTION_CODE  NUMBER(2)               /* 3.1.3 */
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          4384K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_ADDRESS TO DCS_USERS_ALL;

--Version 3.1.5
--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (gsd_address_pk NUMBER); --3.1.6

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_ADDRESS ON DCS2000.ACH_GSD_ADDRESS(GRP_ID,SUBLOC_ID,DIV_ID,ADDR_CDE) TABLESPACE PRODIX;
--End SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_ADDRESS ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.7