/* VERSION: 3.1.5 */ 
--
-- ACH_GSD_AGE_LMT  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.5
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_GSD_AGE_LMT
(
  GRP_ID             VARCHAR2(9 BYTE),
  SUBLOC_ID          VARCHAR2(8 BYTE),
  DIV_ID             VARCHAR2(4 BYTE),
  PRD_CDE            NUMBER(4),
  PLN_CDE            NUMBER(4),
  AGE_LMT_TYPE_CDE   NUMBER(2),
  AGE_EFF_DTE        NUMBER(8),
  AGE_TRM_DTE        NUMBER(8),
  AGE_LMT            NUMBER(3),
  AGE_LMT_COVER_CDE  NUMBER(2),
  MAINT_CODE         NUMBER(4),
  MOD_DTE            DATE,
  MOD_OP             VARCHAR2(12 BYTE),
  INS_UPD_FLAG       CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          2880K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_AGE_LMT TO DCS_USERS_ALL;


--05085.19 
--SV 08/10/2005  
--Ver 3.1.2 

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD REL_CDE NUMBER(4);


--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (gsd_age_lmt_pk NUMBER); --3.1.4

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_AGE_LMT ON DCS2000.ACH_GSD_AGE_LMT(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,AGE_LMT_TYPE_CDE,AGE_EFF_DTE,REL_CDE) TABLESPACE PRODIX;
--End SR07109.04.VA

ALTER TABLE DCS2000.ACH_GSD_AGE_LMT ADD (PRODUCT_LINE_CODE  NUMBER(4));