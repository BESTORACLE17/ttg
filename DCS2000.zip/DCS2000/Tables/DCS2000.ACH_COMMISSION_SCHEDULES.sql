/* VERSION: 3.1.1 */ 
--
-- ACH_COMMISSION_SCHEDULES  (Table) 
--
CREATE TABLE DCS2000.ACH_COMMISSION_SCHEDULES
(
  COMM_SCHEDULE_CDE  NUMBER(4),
  EFF_DTE            NUMBER(8),
  TERM_DTE           NUMBER(8),
  YEAR_FROM          NUMBER(3),
  YEAR_TO            NUMBER(3),
  RATE               NUMBER(9,4),
  MIN_ENROLL         NUMBER(9),
  MAX_ENROLL         NUMBER(9),
  MIN_COMM           NUMBER(9,3),
  MAX_COMM           NUMBER(9,3),
  MAINT_CODE         NUMBER(4),
  MOD_OP             VARCHAR2(12 BYTE),
  MOD_DTE            DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_COMMISSION_SCHEDULES TO DCS_USERS_ALL;

