/* VERSION: 3.1.2 */ 
--
-- ACH_CODE_COMM_TYPE  (Table) 
--
/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR#08092.23.CO
|| Revision By    : Deborah Yates
|| Revision Date  : 06/12/2008.
|| Revision Desc  : Added new column for override commissions
||		    Also added the other flag columns to the archive table.
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/ 
CREATE TABLE DCS2000.ACH_CODE_COMM_TYPE
(
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12 BYTE),
  CODE         NUMBER(4),
  DESCRIPTION  VARCHAR2(50 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_CODE_COMM_TYPE TO DCS_USERS_ALL;


-----------------------------------
-- 3.1.2
-----------------------------------
alter table DCS2000.ACH_CODE_COMM_TYPE add (
	SUPPORTS_ASO	VARCHAR2(1 BYTE),
	SUPPORTS_RISK	VARCHAR2(1 BYTE),
	OVERRIDE_FLAG	VARCHAR2(1 BYTE)
);
