/* VERSION: 3.1.1 */ 
--
-- ACH_BILLING_ASO_EXPORT  (Table) 
--
CREATE TABLE DCS2000.ACH_BILLING_ASO_EXPORT
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  GRP_ID                   VARCHAR2(9 BYTE)     NOT NULL,
  SUBLOC_ID                VARCHAR2(8 BYTE)     NOT NULL,
  DIV_ID                   VARCHAR2(4 BYTE)     NOT NULL,
  PRODUCT_CODE             NUMBER(4)            NOT NULL,
  BILL_DATE                NUMBER(8)            NOT NULL,
  BILL_FROM_DATE           NUMBER(8)            NOT NULL,
  BILL_NO_OF_MONTHS        NUMBER(4)            NOT NULL,
  BILL_DUE_DATE            NUMBER(8)            NOT NULL,
  BILL_COUNT               NUMBER(7)            NOT NULL,
  BILL_AMT                 NUMBER(9,2)          NOT NULL,
  ASO_RISK_TYPE            NUMBER(2)            NOT NULL,
  BILLING_CODE             NUMBER(12)           NOT NULL,
  REC_ACCOUNT_CODE         NUMBER(12),
  UNEARN_REV_ACCOUNT_CODE  NUMBER(12),
  REV_ACCOUNT_CODE         NUMBER(12),
  AR_TRANSFER_DATE         DATE,
  REPORTING_CODE           NUMBER(4),
  ARCHIVED_BY              VARCHAR2(30 BYTE),
  ARCHIVED_ON              DATE
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT SELECT ON  DCS2000.ACH_BILLING_ASO_EXPORT TO DCS_USERS_ALL;

