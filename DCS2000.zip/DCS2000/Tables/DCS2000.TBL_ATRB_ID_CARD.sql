/* VERSION: 3.0.0 */ 
--
-- TBL_ATRB_ID_CARD  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.0.0
|| Service Request: 10067.02.ALL Multi Products
|| Revision By    : Satya Sai
|| Revision Date  : 09/08/2010
|| Revision Desc  : Adding Product Line code column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

*/
CREATE TABLE DCS2000.TBL_ATRB_ID_CARD
(
  ID_CARD_CODE  NUMBER(2)                  NOT NULL,
  PRODUCT_CODE  NUMBER(4),
  MAINT_CODE    NUMBER(4),                  
  CREATED_BY    VARCHAR2(30)               NOT NULL,
  CREATED_ON    DATE                       NOT NULL,
  UPDATED_BY    VARCHAR2(30)               NOT NULL,
  UPDATED_ON    DATE                       NOT NULL,
  PARENT_ID     NUMBER(4)                  NOT NULL
)
TABLESPACE PROD
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL;

ALTER TABLE DCS2000.TBL_ATRB_ID_CARD ADD (
  CONSTRAINT FK_ATRB_ID_CARD_2_ID_CARD 
 FOREIGN KEY (ID_CARD_CODE) 
 REFERENCES DCS2000.TBL_CODE_ID_CARD (CODE));

GRANT SELECT ON DCS2000.TBL_ATRB_ID_CARD TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.TBL_ATRB_ID_CARD TO DCS_USERS_ALL;

GRANT SELECT ON DCS2000.TBL_ATRB_ID_CARD TO ECOMMERCE;

GRANT SELECT ON DCS2000.TBL_ATRB_ID_CARD TO E_COMMERCE_ROLE;

GRANT SELECT ON DCS2000.TBL_ATRB_ID_CARD TO OPENCON;

GRANT SELECT ON DCS2000.TBL_ATRB_ID_CARD TO PRODDBLINK;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.TBL_ATRB_ID_CARD TO SECURITY;
