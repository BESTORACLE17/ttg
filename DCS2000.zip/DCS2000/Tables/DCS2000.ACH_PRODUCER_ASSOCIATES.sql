/* VERSION: 3.1.1 */ 
--
-- ACH_PRODUCER_ASSOCIATES  (Table) 
--
CREATE TABLE DCS2000.ACH_PRODUCER_ASSOCIATES
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  PRODUCER_ID              NUMBER(15),
  ASSOC_PRODUCER_ID        NUMBER(15),
  EFF_DTE                  NUMBER(8),
  TRM_DTE                  NUMBER(8),
  PAY_ASSOC_PRODUCER_FLAG  NUMBER(1),
  INS_UPD_FLAG             CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_PRODUCER_ASSOCIATES TO DCS_USERS_ALL;

