/* VERSION: 3.1.5 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.5
|| Revision Type  : Enhancement
|| Service Request: 10343.01.CO 
|| Revision By    : SATYA SAI
|| Revision Date  : 02/28/2011 
|| Revision Desc  : Adding Variable_fee , full_fee  columns
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_UNDERWRITING  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_UNDERWRITING
(
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  PRD_CDE              NUMBER(4),
  PLN_CDE              NUMBER(4),
  EFF_DTE              NUMBER(8),
  TRM_DTE              NUMBER(8),
  RESERVE_AMT          NUMBER(9,2),
  RESERVE_PERCENT      NUMBER(6,3),
  PER_CLAIM_FEE        NUMBER(7,2),
  PER_SUBSCRIBER_FEE   NUMBER(7,2),
  PAID_CLAIMS_PERCENT  NUMBER(6,3),
  ADMIN_PERCENT        NUMBER(6,3),
  TAX_PERCENT          NUMBER(6,3),
  RISK_FACTOR_PERCENT  NUMBER(6,3),
  USA_PERCENT          NUMBER(6,3),
  GENERIC_PERCENT      NUMBER(6,3),
  STAB_FUND            NUMBER(1),
  STAB_PERCENT         NUMBER(5,2),
  STAB_EFF_DATE        NUMBER(8),
  ESCROW_DEP_AMT       NUMBER(9,2),
  PRE_PAYS             NUMBER(1),
  EMP_PERCENT          NUMBER(6,3),
  DEP_PERCENT          NUMBER(6,3),
  GUARANTEE_CODE       NUMBER(2),
  GUARANTEE_START_DTE  NUMBER(8),
  GUARANTEE_END_DTE    NUMBER(8),
  GUARANTEE_COMMENTS   VARCHAR2(2000 BYTE),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  INS_UPD_FLAG         CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_UNDERWRITING TO DCS_USERS_ALL;

--Start changes for SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (gsd_underwriting_pk NUMBER); --3.1.3

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_UNDERWRITING ON DCS2000.ACH_GSD_UNDERWRITING(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,EFF_DTE) TABLESPACE PRODIX;
--End changes for SR07109.04.VA
--Start SR06262.03.VA
CREATE INDEX DCS2000.IDX_GSD_UNDERWRITING_PK ON DCS2000.ACH_GSD_UNDERWRITING
(GSD_UNDERWRITING_PK)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;
--End SR06262.03.VA
ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (PRODUCT_LINE_CODE  NUMBER(4)); -- 3.1.4

ALTER TABLE DCS2000.ACH_GSD_UNDERWRITING ADD (FULL_FEE  NUMBER(7,2), VARIABLE_FEE NUMBER(7,2)); -- 3.1.5
 