/*Version 3.1.5*/


--=======================================================
-- SR 06146.01.VA Waiting Period Calculating Incorrectly 
-- 09/28/2007
-- Suresh Vadapalli
-- Version 3.1.3
-- Added column "comb_ben_class_cde"
--=======================================================
-- SR 07109.04.VA GM quality edits - Phase II
-- 06/10/2008
-- Sanjay Mudaliar
-- Version 3.1.4
-- Added the following columns
--     1.pk
--     2.created_by 
--     3.created_on 
--     4.updated_by 
--     5.updated_on 
--     6.action_code
--     7.action_by
--     8.action_on
--=======================================================
-- SR 07109.04.VA GM quality edits - Phase II
-- 06/13/2008
-- Sanjay Mudaliar
-- Version 3.1.5
-- Renamed column pk to gsd_combine_pk
--=======================================================

CREATE TABLE DCS2000.ACH_GSD_COMBINE
(
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  BEN_CLASS_CDE        NUMBER(4),
  SEQ_IND              NUMBER(4),
  EFF_DTE              NUMBER(8),
  TRM_DTE              NUMBER(8),
  COVERAGE_IND         NUMBER(1),
  LIFETIME_IND         NUMBER(1),
  ELIGIBILITY_IND      NUMBER(1),
  COMB_WITH_GRP_ID     VARCHAR2(9 BYTE),
  COMB_WITH_SUBLOC_ID  VARCHAR2(8 BYTE),
  COMB_WITH_DIV_ID     VARCHAR2(4 BYTE),
  COMB_DED_WITH_GRP    NUMBER(1),
  COMB_MAX_WITH_GRP    NUMBER(1),
  ALL_BEN_CLASS_FLAG   CHAR(1 BYTE),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  INS_UPD_FLAG         VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;


-- SR 03349.03 04/11/2006 SV Version 3.1.2

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD DED_APPLY_FWD_MM NUMBER(4)
ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD MAX_APPLY_FWD_MM NUMBER(4);

GRANT SELECT ON  DCS2000.ACH_GSD_COMBINE TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_COMBINE TO DCS_USERS_ALL;


-- Version 3.1.3 SR 06146.01.VA

ALTER TABLE DCS2000.ACH_GSD_COMBINE
 ADD (COMB_BEN_CLASS_CDE  NUMBER(4));

--Version 3.1.4
--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (gsd_combine_pk NUMBER); --3.1.5

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_COMBINE ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_COMBINE ON DCS2000.ACH_GSD_COMBINE(GRP_ID,SUBLOC_ID,DIV_ID,BEN_CLASS_CDE,SEQ_IND,EFF_DTE) TABLESPACE PRODIX;
--End SR07109.04.VA