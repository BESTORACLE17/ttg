/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_ADJUD_CLAIMS  (Table) 
--
CREATE TABLE DCS2000.TBL_ADJUD_CLAIMS
(
  CLAIM_NO     VARCHAR2(14 BYTE)                NOT NULL,
  SUBR_ID      VARCHAR2(9 BYTE),
  PROCESS_CNT  NUMBER(4),
  PROCESS_GRP  NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_ADJUD_CLAIMS  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_ADJUD_CLAIMS ON DCS2000.TBL_ADJUD_CLAIMS
(CLAIM_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2064K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- ADJUD_CLAIMS_SUBR_ID_IX  (Index) 
--
CREATE INDEX DCS2000.ADJUD_CLAIMS_SUBR_ID_IX ON DCS2000.TBL_ADJUD_CLAIMS
(SUBR_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ADJUD_CLAIMS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ADJUD_CLAIMS TO PRODDBLINK;

GRANT DELETE ON  DCS2000.TBL_ADJUD_CLAIMS TO OPS$DCSUNIX;

-- 
-- Non Foreign Key Constraints for Table TBL_ADJUD_CLAIMS 
-- 
ALTER TABLE DCS2000.TBL_ADJUD_CLAIMS ADD (
  CONSTRAINT PK_ADJUD_CLAIMS PRIMARY KEY (CLAIM_NO)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          2064K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_ADJUD_CLAIMS MODIFY SUBR_ID VARCHAR2(30);

-- Add with HD#27058
create index adjud_claims_subr_id_fix 
on dcs2000.tbl_adjud_claims (rtrim(subr_id))
tablespace prodix;
