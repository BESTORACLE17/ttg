/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_INDV_LETTERS  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_INDV_LETTERS
(
  SUBR_ID          VARCHAR2(9 BYTE)             NOT NULL,
  GRP_ID           VARCHAR2(9 BYTE)             NOT NULL,
  SUBLOC_ID        VARCHAR2(8 BYTE)             NOT NULL,
  DIV_ID           VARCHAR2(4 BYTE)             NOT NULL,
  NME              VARCHAR2(50 BYTE),
  ADDRESS_LINE1    VARCHAR2(30 BYTE)            NOT NULL,
  ADDRESS_LINE2    VARCHAR2(30 BYTE),
  ADDRESS_LINE3    VARCHAR2(30 BYTE),
  CITY             VARCHAR2(30 BYTE)            NOT NULL,
  STATE            VARCHAR2(2 BYTE)             NOT NULL,
  ZIP              NUMBER(5)                    NOT NULL,
  ZIP4             NUMBER(4),
  COVERAGE_PERIOD  VARCHAR2(43 BYTE),
  RENEW_DTE        VARCHAR2(18 BYTE),
  DEADLINE_DTE     VARCHAR2(18 BYTE),
  PAYMENT_TYPE     VARCHAR2(10 BYTE),
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  SAL              VARCHAR2(4 BYTE),
  ADULT_RATE       NUMBER(7,2),
  CHILD_RATE       NUMBER(7,2)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          20272K
            NEXT             16K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- BILLING_INDV_LETTERS_IX  (Index) 
--
CREATE INDEX DCS2000.BILLING_INDV_LETTERS_IX ON DCS2000.TBL_BILLING_INDV_LETTERS
(SUBR_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          8080K
            NEXT             200K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV_LETTERS MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_INDV_LETTERS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_INDV_LETTERS TO PRODDBLINK;

