--=================================
-- SR 10067.02.VA Multi Products
-- 07/15/2010
-- Satya sai
--=================================

CREATE TABLE DCS2000.ACH_DCSAUTO_DETAIL_PL
(
  DETAIL_ID          NUMBER(8)                  NOT NULL,
  PRODUCT_LINE_CODE  NUMBER(4)                  NOT NULL,
  MAINT_CODE         NUMBER(4)                  NOT NULL,
  CREATED_BY         VARCHAR2(30 )              NOT NULL,
  CREATED_ON         DATE                       NOT NULL,
  UPDATED_BY         VARCHAR2(30 )              NOT NULL,
  UPDATED_ON         DATE                       NOT NULL,
  ACTION_CODE        VARCHAR2(1 ),
  ACTION_BY          VARCHAR2(30 ),
  ACTION_ON          DATE,
  PARENT_ID          NUMBER(4)                  NOT NULL
);
/
GRANT SELECT ON DCS2000.ACH_DCSAUTO_DETAIL_PL TO DCSREPORTS WITH GRANT OPTION;
/
GRANT DELETE ON DCS2000.ACH_DCSAUTO_DETAIL_PL TO DCS_OPERATIONS;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_DCSAUTO_DETAIL_PL TO DCS_USERS_ALL;
/
GRANT SELECT ON DCS2000.ACH_DCSAUTO_DETAIL_PL TO PRODDBLINK;
/