/* VERSION: 1.0.1 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 1.0.0 
|| Service Request: SR# 12300.04.VA - Story 12
|| Revision By    : Adrian Lowry
|| Revision Date  : 08/28/2013
|| Revision Desc  : Initial Creation through DDL script only.
|| 
|| Version #      : 1.0.1
|| Service Request: SR# 12333.06.CO - Story 34
|| Revision By    : Michael Hylton
|| Revision Date  : 03/12/2014
|| Revision Desc  : Created this table script and put into the DCS2000/tables
||                  folder in SVN.
|| 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV_BILLING  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_BILLING
(
 SUBR_ID                VARCHAR2(30 BYTE),
 INDV_ID                NUMBER(2),
 AMOUNT_TYPE            NUMBER(2),
 AMOUNT                 NUMBER(15,2),
 EFF_DATE               DATE,
 TERM_DATE              DATE,
 MAINT_CODE             NUMBER(4),
 CREATED_ON             DATE,
 CREATED_BY             VARCHAR2(29 BYTE),
 UPDATED_ON             DATE,
 UPDATED_BY             VARCHAR2(30 BYTE),
 ACTION_CODE            VARCHAR2(1 BYTE),
 ACTION_BY              VARCHAR2(30 BYTE),
 ACTION_ON              DATE,
 PARENT_ID              NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

      
