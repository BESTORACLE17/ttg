/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
||
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Eric Lichtman
|| Revision Date  : 10/24/2006
|| Revision Desc  : Altered table added column print_subr_id
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR# 01313.01.ALL - Retro Rate Changes on Bills
|| Revision By    : Jeff Reynolds
|| Revision Date  : 03/07/2008
|| Revision Desc  : Added full_month_rate_amt
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4 
|| Service Request: HD 32821 
|| Revision By    : Manoj Sathe
|| Revision Date  : 07/11/2008
|| Revision Desc  : Added Index - DCS2000.BILLING_EXTRACT_GSD_2_IX 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*//
--
-- TBL_BILLING_EXTRACT  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_EXTRACT
(
  GRP_ID           VARCHAR2(9 BYTE)             NOT NULL,
  SUBLOC_ID        VARCHAR2(8 BYTE)             NOT NULL,
  DIV_ID           VARCHAR2(4 BYTE)             NOT NULL,
  PRD_CDE          NUMBER(4)                    NOT NULL,
  PLN_CDE          NUMBER(4)                    NOT NULL,
  SUBR_ID          VARCHAR2(9 BYTE)             NOT NULL,
  INDV_ID          NUMBER(2)                    NOT NULL,
  LNME             VARCHAR2(30 BYTE),
  FNME             VARCHAR2(30 BYTE),
  RTE_CDE          NUMBER(2),
  EFF_DTE          NUMBER(8),
  BILL_MONTH_YEAR  NUMBER(6),
  BILL_CDE         NUMBER(2),
  OLD_RTE_AMT      NUMBER(5,2),
  NEW_RTE_AMT      NUMBER(5,2),
  BILLED_AMT       NUMBER(5,2),
  RUN_NUMBER       NUMBER(3),
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          20272K
            NEXT             1M
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_EXTRACT TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_EXTRACT TO PRODDBLINK;

--
-- BILLING_EXTRACT_GSD_IX  (Index) 
--
CREATE INDEX DCS2000.BILLING_EXTRACT_GSD_IX ON DCS2000.TBL_BILLING_EXTRACT
(GRP_ID, SUBLOC_ID, DIV_ID, RUN_NUMBER)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added Index as part of HD32821
CREATE INDEX DCS2000.BILLING_EXTRACT_GSD_2_IX ON DCS2000.TBL_BILLING_EXTRACT
(GRP_ID, SUBLOC_ID, DIV_ID, BILL_MONTH_YEAR, RUN_NUMBER)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Foreign Key Constraints for Table TBL_BILLING_EXTRACT 
-- 
ALTER TABLE DCS2000.TBL_BILLING_EXTRACT ADD (
  CONSTRAINT FK_BILLING_EXTRACT_2_GSD FOREIGN KEY (GRP_ID, SUBLOC_ID, DIV_ID) 
    REFERENCES DCS2000.TBL_GSD (GRP_ID,SUBLOC_ID,DIV_ID));

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_EXTRACT MODIFY SUBR_ID VARCHAR2(30);

-- Added with SR# 05208.11.ALL
ALTER TABLE DCS2000.TBL_BILLING_EXTRACT ADD PRINT_SUBR_ID VARCHAR2(30);

-- Added with SR# 01313.01.ALL    (Version 3.1.3)
ALTER TABLE DCS2000.TBL_BILLING_EXTRACT ADD (
    FULL_MONTH_RATE_AMT NUMBER(5,2));

