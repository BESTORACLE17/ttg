/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_INDV_SELECT  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_INDV_SELECT
(
  MAINT_CDE            NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE),
  SUBR_ID              VARCHAR2(9 BYTE)         NOT NULL,
  GRP_ID               VARCHAR2(9 BYTE)         NOT NULL,
  SUBLOC_ID            VARCHAR2(8 BYTE)         NOT NULL,
  DIV_ID               VARCHAR2(4 BYTE)         NOT NULL,
  PRD_CDE              NUMBER(4)                NOT NULL,
  PLN_CDE              NUMBER(4)                NOT NULL,
  BILLING_FROM_DTE     NUMBER(8),
  BILLING_END_DTE      NUMBER(8),
  BILLING_DUE_DTE      NUMBER(8),
  BILLING_CDE          NUMBER(2),
  BILLING_STS_IND      NUMBER(1)                NOT NULL,
  BILLING_RULE         NUMBER(2),
  BILLING_DISTR        NUMBER(2),
  RUN_NUMBER           NUMBER(3),
  RELOAD_BALANCE_FLAG  VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          240K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- BILLING_INDV_GSD_IX  (Index) 
--
CREATE INDEX DCS2000.BILLING_INDV_GSD_IX ON DCS2000.TBL_BILLING_INDV_SELECT
(SUBR_ID, GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1200K
            NEXT             200K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_INDV_SELECT MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_INDV_SELECT TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_INDV_SELECT TO PRODDBLINK;

