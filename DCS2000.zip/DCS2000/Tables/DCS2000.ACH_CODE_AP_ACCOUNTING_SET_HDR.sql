/* VERSION: 3.1.1 */ 
--
-- ACH_CODE_AP_ACCOUNTING_SET_HDR  (Table) 
--
CREATE TABLE DCS2000.ACH_CODE_AP_ACCOUNTING_SET_HDR
(
  CODE          NUMBER(4)                       NOT NULL,
  NAME          VARCHAR2(30 BYTE)               NOT NULL,
  DESCRIPTION   VARCHAR2(4000 BYTE)             NOT NULL,
  EFF_DTE       NUMBER(8)                       NOT NULL,
  TRM_DTE       NUMBER(8)                       NOT NULL,
  MAINT_CODE    NUMBER(4),
  MOD_DTE       DATE,
  MOD_OP        VARCHAR2(12 BYTE),
  INS_UPD_FLAG  CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_CODE_AP_ACCOUNTING_SET_HDR TO DCS_USERS_ALL;

