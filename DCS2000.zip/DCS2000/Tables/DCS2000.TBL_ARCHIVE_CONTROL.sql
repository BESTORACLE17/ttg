/* VERSION: 3.1.1 */ 
--
-- TBL_ARCHIVE_CONTROL  (Table) 
--
CREATE TABLE DCS2000.TBL_ARCHIVE_CONTROL
(
  TBL_TABLE_NAME  VARCHAR2(30 BYTE)             NOT NULL,
  ACH_TABLE_NAME  VARCHAR2(30 BYTE)             NOT NULL,
  TBL_GROUP       VARCHAR2(30 BYTE)             NOT NULL,
  ARCHIVE_STATUS  VARCHAR2(1 BYTE)              NOT NULL,
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          80K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_ARCHIVE_CONTROL  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_ARCHIVE_CONTROL ON DCS2000.TBL_ARCHIVE_CONTROL
(TBL_TABLE_NAME)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          120K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ARCHIVE_CONTROL TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ARCHIVE_CONTROL TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_ARCHIVE_CONTROL 
-- 
ALTER TABLE DCS2000.TBL_ARCHIVE_CONTROL ADD (
  CONSTRAINT PK_ARCHIVE_CONTROL PRIMARY KEY (TBL_TABLE_NAME)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          120K
                NEXT             104K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


