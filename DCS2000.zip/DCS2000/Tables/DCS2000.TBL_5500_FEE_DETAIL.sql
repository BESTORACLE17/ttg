/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision History
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR 06216.03.AR 
|| Revision By    : Jeff Reynolds
|| Revision Date  : 11/07/2007 
|| Revision Desc  : Expanded amount fields to NUMBER(15,2) and count fields
||                  to NUMBER(13).
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_5500_FEE_DETAIL  (Table) 
--
CREATE TABLE DCS2000.TBL_5500_FEE_DETAIL
(
  SEQUENCE_ID  NUMBER(6)                        NOT NULL,
  RECORD_TYPE  NUMBER(4)                        NOT NULL,
  RATE_TYPE    NUMBER(4)                        NOT NULL,
  BEGIN_DTE    NUMBER(8)                        NOT NULL,
  END_DTE      NUMBER(8)                        NOT NULL,
  RATE         NUMBER(6,3),
  PREMIUMS     NUMBER(15,2),                               /* 3.1.2 */
  FEE_AMT      NUMBER(15,2),                               /* 3.1.2 */
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12 BYTE),
  PRD_CDE      NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_5500_FEE_DETAIL TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_5500_FEE_DETAIL TO PRODDBLINK;

--
-- PK_5500_FEE_DETAIL  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_5500_FEE_DETAIL ON DCS2000.TBL_5500_FEE_DETAIL
(SEQUENCE_ID, RECORD_TYPE, RATE_TYPE, BEGIN_DTE, PRD_CDE)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_5500_FEE_DETAIL 
-- 
ALTER TABLE DCS2000.TBL_5500_FEE_DETAIL ADD (
  CONSTRAINT PK_5500_FEE_DETAIL PRIMARY KEY (SEQUENCE_ID, RECORD_TYPE, RATE_TYPE, BEGIN_DTE, PRD_CDE)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             256K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_5500_FEE_DETAIL 
-- 
ALTER TABLE DCS2000.TBL_5500_FEE_DETAIL ADD (
  CONSTRAINT FK_5500_FEE_2_HEADER FOREIGN KEY (SEQUENCE_ID) 
    REFERENCES DCS2000.TBL_5500_HEADER (SEQUENCE_ID));


