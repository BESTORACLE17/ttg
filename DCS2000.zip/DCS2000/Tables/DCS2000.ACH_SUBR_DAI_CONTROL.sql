-- VERSION: 2.1.1  
--
-- DCS2000.ACH_SUBR_DAI_CONTROL  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_DAI_CONTROL
(
   MAINT_CODE					NUMBER(4),
   UPDATED_BY					VARCHAR2(30),
   UPDATED_ON					DATE,
   DCS_ASSIGNED_ID              VARCHAR2(30),
   INS_UPD_FLAG                 VARCHAR2(1)     
)
   TABLESPACE PROD
   PCTUSED    40
   PCTFREE    10
   INITRANS   1
   MAXTRANS   255
   STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
   LOGGING 
   NOCACHE
   NOPARALLEL;
   
GRANT INSERT, SELECT, UPDATE ON DCS2000.ACH_SUBR_DAI_CONTROL TO DCS_USERS_ALL;

