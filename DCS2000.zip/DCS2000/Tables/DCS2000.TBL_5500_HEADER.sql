-- Create table
create table DCS2000.TBL_5500_HEADER
(
  SEQUENCE_ID   NUMBER(6) not null,
  SEQUENCE_NAME VARCHAR2(100) not null,
  REPORT_DTE    DATE not null,
  GRP_ID        VARCHAR2(9) not null,
  COMPANY_CDE   NUMBER(4),
  GRP_NME       VARCHAR2(100),
  GRP_TYPE      NUMBER(4),
  PULL_TYPE     NUMBER(2),
  BEG_DTE       NUMBER(8),
  END_DTE       NUMBER(8),
  EFF_DTE       NUMBER(8),
  TRM_DTE       NUMBER(8),
  CURRENT_QUEUE NUMBER(2) not null,
  COMMENTS      VARCHAR2(1000),
  MAINT_CODE    NUMBER(4) not null,
  MOD_DTE       DATE not null,
  MOD_OP        VARCHAR2(12) not null,
  DISP_GRP_ID   VARCHAR2(30)
)
tablespace PROD
  pctfree 10
  pctused 40
  initrans 1
  maxtrans 255
  storage
  (
    initial 1040K
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Create/Recreate primary, unique and foreign key constraints 
alter table DCS2000.TBL_5500_HEADER
  add constraint PK_5500_HEADER primary key (SEQUENCE_ID)
  using index 
  tablespace PRODIX
  pctfree 10
  initrans 2
  maxtrans 255
  storage
  (
    initial 1040K
    next 1M
    minextents 1
    maxextents unlimited
    pctincrease 0
  );
-- Grant/Revoke object privileges 
grant select, insert, update on DCS2000.TBL_5500_HEADER to DCS_USERS_ALL;
grant select on DCS2000.TBL_5500_HEADER to PRODDBLINK;
