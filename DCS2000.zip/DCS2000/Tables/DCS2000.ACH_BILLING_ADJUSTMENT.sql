/* VERSION: 3.1.6 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3 
|| Service Request: SR# 01313.01.VA - Retro Rate Changes on Bills
|| Revision By    : Ketan Patel.
|| Revision Date  : 02/28/2008.
|| Revision Desc  : Added columns OLD_RTE_AMT,NEW_RTE_AMT
                    Created Index on subr_id column          
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4
|| Service Request: SR# 01313.01.VA - Retro Rate Changes on Bills
|| Revision By    : Ketan Patel.
|| Revision Date  : 02/28/2008.
|| Revision Desc  : Added schema name in create index
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.5
|| Service Request: SR# 01313.01.VA - Retro Rate Changes on Bills
|| Revision By    : Jeff Reynolds
|| Revision Date  : 03/06/2008.
|| Revision Desc  : Added auto_created_flag
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.6
|| Service Request: SR 10067.02.VA Multi Products
|| Revision By    : Satya Sai
|| Revision Date  : 06/23/2010
|| Revision Desc  : New column Product line code added
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

--
-- ACH_BILLING_ADJUSTMENT  (Table) 
--
CREATE TABLE DCS2000.ACH_BILLING_ADJUSTMENT
(
  SUBR_ID          VARCHAR2(9 BYTE),
  INDV_ID          NUMBER(2),
  GRP_ID           VARCHAR2(9 BYTE),
  SUBLOC_ID        VARCHAR2(8 BYTE),
  DIV_ID           VARCHAR2(4 BYTE),
  PRD_CDE          NUMBER(4),
  PLN_CDE          NUMBER(4),
  YEAR_TO_ADJUST   NUMBER(4),
  MONTH_TO_ADJUST  NUMBER(2),
  ADJUST_TYPE      NUMBER(2),
  OLD_RTE_CDE      NUMBER(2),
  NEW_RTE_CDE      NUMBER(2),
  RUN_DTE          DATE,
  APPROVED_DTE     DATE,
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          8320K
            NEXT             104K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_BILLING_ADJUSTMENT MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_BILLING_ADJUSTMENT TO DCS_USERS_ALL;


-- 3.1.3
ALTER TABLE DCS2000.ACH_BILLING_ADJUSTMENT  ADD (  OLD_RTE_AMT NUMBER,  
                                                   NEW_RTE_AMT NUMBER 
                                                );

-- 3.1.3
CREATE INDEX DCS2000.N1_ACH_BILLING_ADJUSTMENT ON DCS2000.ACH_BILLING_ADJUSTMENT
(SUBR_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 3.1.5
ALTER TABLE DCS2000.ACH_BILLING_ADJUSTMENT ADD (
   AUTO_CREATED_FLAG   VARCHAR2(1)
);

-- 3.1.6
ALTER TABLE DCS2000.ACH_BILLING_ADJUSTMENT ADD (
    PRODUCT_LINE_CODE  NUMBER(4)
);

