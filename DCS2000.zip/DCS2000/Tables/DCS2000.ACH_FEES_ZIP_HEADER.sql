--=======================================
--SR 03266.01 Ingenix Fees
--DateL 09/26/2005 
--Suresh Vadapalli
--=======================================
/* VERSION: 3.1.1 */ 

CREATE TABLE DCS2000.ACH_FEES_ZIP_HEADER
(
  FEE_ZIP_SET  NUMBER(4),
  FEE_ZIP_KEY  NUMBER(8),
  BEGIN_DTE    NUMBER(8),
  TERM_DTE     NUMBER(8),
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12),
  INS_UPD_FLAG VARCHAR2(1)
);


GRANT SELECT,INSERT,UPDATE,DELETE ON DCS2000.ACH_FEES_ZIP_HEADER TO DCS_USERS_ALL;




