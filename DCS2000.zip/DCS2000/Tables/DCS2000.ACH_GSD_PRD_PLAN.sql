/* VERSION: 3.1.10 */ 

--------------------------------------------------------------------------
-- Revision History
--------------------------------------------------------------------------
/*
  S/R           By	 Date	     Description
  ------------- ---- ----------- ----------------------------------------- 
  04138.01.NE   MCS  06/27/2005  Added PROCESS_POLICY_SET and PROCEDURE_SET
                                 and FKs
                                 released to production on 6/27
                                 new version 3.1.2
  05138.02      MCS  08/08/2005  Added CEDED_PLN_CDE
                                 new version 3.1.3
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4 
|| Revision Type  : Enhancement
|| Service Request: SR07178.03.KY Overage Dep Processing  
|| Revision By    : Ketan Patel.
|| Revision Date  : 03/02/2008 
|| Revision Desc  : Added column SEND_STUDENT_VER_LETTER_FLAG 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.5 
|| Revision Type  : Enhancement
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/10/2008 
|| Revision Desc  : Added the following columns
||               1.pk
|| 		 2.created_by 
|| 		 3.created_on 
|| 		 4.updated_by 
|| 		 5.updated_on 
|| 		 6.action_code
|| 		 7.action_by
|| 		 8.action_on
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.6 
|| Revision Type  : Enhancement
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Sanjay Mudaliar
|| Revision Date  : 06/13/2008 
|| Revision Desc  : Renamed pk to gsd_prd_plan_pk
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.7 
|| Revision Type  : Enhancement
|| Service Request: SR07109.04.VA GM quality edits - Phase II
|| Revision By    : Pramod Gujjar
|| Revision Date  : 06/25/2008 
|| Revision Desc  : added column default_region_code
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.8 
|| Revision Type  : Enhancement
|| Service Request: SR08092.28.CO Setup a System Parameter to Disallow COB 
||                : within the Same
|| Revision By    : Sanjay Mudaliar.
|| Revision Date  : 06/30/2008 
|| Revision Desc  : Added COB SAME GROUP column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/	  					 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.9
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.10
|| Revision Type  : Enhancement
|| Service Request: 11077.01.VA 
|| Revision By    : SATYA SAI
|| Revision Date  : 04/22/2011 
|| Revision Desc  : Added LOSS_RATIO_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

--
-- ACH_GSD_PRD_PLAN  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_PRD_PLAN
(
  GRP_ID                    VARCHAR2(9),
  SUBLOC_ID                 VARCHAR2(8),
  DIV_ID                    VARCHAR2(4),
  PRD_CDE                   NUMBER(4),
  PLN_CDE                   NUMBER(4),
  GSD_PP_BEGIN_DTE          NUMBER(8),
  GSD_PP_END_DTE            NUMBER(8),
  AUTO_ADD_DPND             NUMBER(1),
  DELTAUSA                  NUMBER(1),
  MULTI_ST_ACC_IND          NUMBER(1),
  DEDUCT_CALC               NUMBER(1),
  COB_COVER_TYPE_CDE        NUMBER(2),
  GL_PREM_ACCT_NO           VARCHAR2(20),
  GL_CLAIM_ACCT_NO          VARCHAR2(20),
  GL_ADMIN_ACCT_NO          VARCHAR2(20),
  PRICING_SET_NO            NUMBER(4),
  HIST_XCHK_SET_NO          NUMBER(8),
  PAR_PERCENT_CDE           NUMBER(4),
  NONPAR_PERCENT_CDE        NUMBER(4),
  NONFILED_PERCENT_CDE      NUMBER(4),
  PAR_TOA                   NUMBER(4),
  NONPAR_TOA                NUMBER(4),
  PAR_RTOA                  NUMBER(4),
  NONPAR_RTOA               NUMBER(4),
  DC_REIMBURSE_PERCENT      NUMBER(5,4),
  ID_CARD_CDE               NUMBER(2),
  ID_CARD_MAILTO_CDE        NUMBER(2),
  ID_CARD_INT_ISSUE_DTE     NUMBER(8),
  ID_CARD_EFF_DTE_IND       NUMBER(1),
  ID_CARD_COMP_NAME         NUMBER(2),
  EOC_BOOKLET_NO            CHAR(8),
  ID_CARD_PRINT_EOC         NUMBER(1),
  ACCIDENT_CDE              NUMBER(2),
  ASO_RISK_TYPE             NUMBER(2),
  GRP_CONTRIB_TYPE          NUMBER(2),
  GRP_CONTRIB_PERCENT       NUMBER(10,4),
  CONTROL_PLN_CDE           NUMBER(4),
  DDPV_LTIME_CARRYOVER      NUMBER(1),
  GRP_LTIME_CARRYOVER       NUMBER(1),
  DUAL_COVER_CDE            NUMBER(2),
  SUBR_CORRESP_CDE          NUMBER(2),
  GRP_REPORT_CATEGORY       NUMBER(4),
  MAINT_CODE                NUMBER(4),
  MOD_DTE                   DATE,
  MOD_OP                    VARCHAR2(12),
  ALTERNATE_BENEFIT_SET_NO  NUMBER(4),
  INS_UPD_FLAG              CHAR(1),
  COMPANY_ID                NUMBER(4),
  ALT_FEE_IND               NUMBER(1),
  LATE_SUBMIT_TYPE          NUMBER(4),
  LATE_SUBMIT_VALUE         NUMBER(4),
  PROCESS_POLICY_SET        NUMBER(4)           DEFAULT 1                     NOT NULL,
  PROCEDURE_SET             NUMBER(4)           DEFAULT 1                     NOT NULL,
  CEDED_PLN_CDE             NUMBER(4)

)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          11496K
            NEXT             2M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL
/


GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG ON  DCS2000.ACH_GSD_PRD_PLAN TO DCSADMIN WITH GRANT OPTION
/

GRANT SELECT ON  DCS2000.ACH_GSD_PRD_PLAN TO DCSREPORTS WITH GRANT OPTION
/

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_PRD_PLAN TO DCS_USERS_ALL
/

--3.1.4
ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (SEND_STUDENT_VER_LETTER_FLAG VARCHAR2(1) CHECK( SEND_STUDENT_VER_LETTER_FLAG IN ('Y','N')));

--Start 3.1.5
ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (gsd_prd_plan_pk NUMBER);  --3.1.6

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (created_by VARCHAR2(30));
 
ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_PRD_PLAN ON DCS2000.ACH_GSD_PRD_PLAN(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,GSD_PP_BEGIN_DTE) TABLESPACE PRODIX;
--End 3.1.5

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (DEFAULT_REGION_CODE   NUMBER(4));  --07109.04VA gm quality edits

--3.1.8
ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (COB_SAME_GROUP  NUMBER(1));

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (PRODUCT_LINE_CODE  NUMBER(4));--3.1.9

ALTER TABLE DCS2000.ACH_GSD_PRD_PLAN ADD (LOSS_RATIO_CODE  NUMBER(4));--3.1.10