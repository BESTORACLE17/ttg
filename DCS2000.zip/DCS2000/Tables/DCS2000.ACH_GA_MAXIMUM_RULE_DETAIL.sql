--********************
-- ACH_GA_MAXIMUM_RULE_DETAIL
-- SR - 07109.01.VA
-- version 2.1.1
--********************
----------------------------------------------------------------------------
-- Version        : 2.1.2
-- Revision Type  : Enhancement
-- Service Request: SR07318.02.KY - TOYOTA onsite clinic - Phase II
-- Revision By    : Sanjay Mudaliar
-- Revision Date  : 06/27/2008
-- Revision Desc  : Added column for product_tier_code
----------------------------------------------------------------------------
CREATE TABLE DCS2000.ACH_GA_MAXIMUM_RULE_DETAIL
(
  CREATED_BY               VARCHAR2(12 BYTE),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(12 BYTE),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1 BYTE),
  ACTION_BY                VARCHAR2(30 BYTE),
  ACTION_ON                DATE,
  USER_DEFINED_FIELD1      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD2      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD3      VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD4      VARCHAR2(100 BYTE),   
  MAXIMUM_RULE_DETAIL_PK   NUMBER(9),
  MAXIMUM_RULE_HEADER_PK   NUMBER(9),
  RULE_ID                  NUMBER(4),
  MAXIMUM_TYPE             NUMBER(2),
  PAR_NPAR_PRV_IND         NUMBER(1),
  BENEFIT_CLASS_CODE       NUMBER(4),
  RELATIONSHIP_CODE        NUMBER(4),
  EFF_DATE                 DATE, 
  TERM_DATE                DATE,                                        
  TERM_REASON_CODE         NUMBER(4),
  COMMENTS                 VARCHAR2(200 BYTE),
  NOTES                    VARCHAR2(200 BYTE),
  MAXIMUM_AMT              NUMBER(8,2),
  DISPLAY_ON_WEB           NUMBER(1)
);

ALTER TABLE dcs2000.ACH_GA_MAXIMUM_RULE_DETAIL
  ADD (product_tier_code    NUMBER(4)); --2.1.2