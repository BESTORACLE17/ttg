DROP TABLE dcs2000.ach_subr_indv_phone;
/
CREATE TABLE dcs2000.ach_subr_indv_phone
(
  subr_indv_phone_pk      NUMBER(10),
  created_on              DATE,
  created_by              VARCHAR2(30 BYTE),
  updated_on              DATE,
  updated_by              VARCHAR2(30 BYTE),
  maint_code              NUMBER(2),
  parent_id               NUMBER(4),
  subr_id                 VARCHAR2(30 BYTE),
  indv_id                 NUMBER(2),
  phone_type_pk           NUMBER(10),
  phone_number            VARCHAR2(60)
)
TABLESPACE prod
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1 m
            NEXT             1 m
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING
NOCOMPRESS
NOCACHE
NOPARALLEL
MONITORING;
/

BEGIN
   DBMS_RLS.create_policy_group( object_schema => 'DCS2000'
                                         ,object_name   => 'ACH_SUBR_INDV_PHONE'
                                         ,policy_group  => 'DCS_POLICY_GROUP' );
                                         
   DBMS_RLS.add_grouped_policy
        (object_schema        => 'DCS2000',
         object_name          => 'ACH_SUBR_INDV_PHONE',
         policy_group         => 'DCS_POLICY_GROUP',
         policy_name          => 'POL_PARENT_ID',
         function_schema      => 'COMMON',
         policy_function      => 'PKG_PARENT_ID_UTILS.FNC_SET_PARENT_ID_SECURITY',
         statement_types      => 'SELECT,UPDATE,INSERT,DELETE',
         update_check         => TRUE,
         ENABLE               => TRUE,
         static_policy        => FALSE,
         policy_type          => DBMS_RLS.shared_context_sensitive
        );
END;
/
GRANT SELECT ON dcs2000.ach_subr_indv_phone TO dcsreports WITH GRANT OPTION;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON dcs2000.ach_subr_indv_phone TO dcs_users_all;
/
GRANT DELETE, INSERT, SELECT, UPDATE ON dcs2000.ach_subr_indv_phone TO security;
/