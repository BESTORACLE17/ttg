/* Version 3.0.0 
 Satya sai
 SR 10340.01.VA
*/
CREATE TABLE DCS2000.ACH_TPA_ADDRESS
      ( CREATED_BY                 VARCHAR2(30 ),
        CREATED_ON                 DATE,
        UPDATED_ON                 DATE,
        UPDATED_BY                 VARCHAR2(12),
        MAINT_CODE                 NUMBER(4),
        ACTION_BY                  VARCHAR2(30),
        ACTION_ON                  DATE,
        ACTION_CODE                VARCHAR2(1),
        TPA_ADDRESS_PK             NUMBER(12),
        TPA_ID                     NUMBER(4),
        ADDR_CDE                   NUMBER(2),
        ADDR1                      VARCHAR2(30 ),
        ADDR2                      VARCHAR2(30 ),
        ADDR3                      VARCHAR2(30 ),
        CITY                       VARCHAR2(30 ),
        STATE                      VARCHAR2(30 ),
        ZIP                        NUMBER(5),
        ZIP4                       NUMBER(4)
      );
GRANT SELECT ON DCS2000.ACH_TPA_ADDRESS TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_TPA_ADDRESS TO DCS_USERS_ALL;
