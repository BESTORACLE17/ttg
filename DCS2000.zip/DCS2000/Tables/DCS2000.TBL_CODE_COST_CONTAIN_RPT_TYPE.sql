/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_COST_CONTAIN_RPT_TYPE  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.1 
|| Revision Type  : Enhancement
|| Service Request: SR 06307.01.VA - DDPA Professional Review Task Force Phase 1
|| Revision By    : Jeff Reynolds
|| Revision Date  : 01/31/2008 
|| Revision Desc  : Original version
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.TBL_CODE_COST_CONTAIN_RPT_TYPE 
(
  CREATED_BY                  VARCHAR2(30 BYTE)     NOT NULL,
  CREATED_ON                  DATE                  NOT NULL,
  UPDATED_BY                  VARCHAR2(30 BYTE)     NOT NULL,
  UPDATED_ON                  DATE                  NOT NULL,
  MAINT_CODE                  NUMBER(4)             NOT NULL,
  CODE                        NUMBER(4)             NOT NULL,
  DESCRIPTION                 VARCHAR2(500 BYTE)    NOT NULL,
  SHORT_DESCRIPTION           VARCHAR2(30 BYTE),
  SORT_ORDER                  NUMBER(4),
  STANDARD_PROCESS_ORDER      NUMBER(4),
  INDUSTRY_CODE               VARCHAR2(6 BYTE),
  INDUSTRY_DESCRIPTION        VARCHAR2(500 BYTE),
  USER_MODIFIABLE             VARCHAR2(1 BYTE),
  USER_ADDITION               VARCHAR2(1 BYTE),
  USER_CODE                   VARCHAR2(6 BYTE),
  USER_DESCRIPTION1           VARCHAR2(500 BYTE),
  USER_DESCRIPTION2           VARCHAR2(500 BYTE),
  USER_DESCRIPTION3           VARCHAR2(500 BYTE),
  COMMENTS                    VARCHAR2(4000 BYTE),
  PROMPT_FOR_PROF_REV_FLAG    VARCHAR2(1 BYTE)
)
TABLESPACE PROD
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;

COMMENT ON TABLE TBL_CODE_COST_CONTAIN_RPT_TYPE IS 'Contains list of cost containment report types.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.CREATED_BY IS 'User ID of the user who created the row.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.CREATED_ON IS 'Date on which the row was created.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.UPDATED_BY IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.UPDATED_ON IS 'Date on which the row was last updated.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.CODE IS 'System Code value for this module that has a business processing tied into when the USER_ADDITION flag is null.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.DESCRIPTION IS 'Detailed description of the system code value.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.SHORT_DESCRIPTION IS 'Short description of the system code value.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.SORT_ORDER IS 'Sort order in which codes need to be displayed in front end applications. Application will default to code with least sort order.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.STANDARD_PROCESS_ORDER IS 'The order in which DCS2000 processes try to find addresses/contact etc for processing.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.INDUSTRY_CODE IS 'Industry standard code values can be different from DCS code values. This field can be used to store corresponding industry code value for DCS code.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.INDUSTRY_DESCRIPTION IS 'Industry descriptions can be different from DCS code descriptions. This field can be used to store corresponding industry descriptions for DCS code descriptions.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_MODIFIABLE IS 'Indicates if the row can be modified by the user.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_ADDITION IS 'Indicates if this is a user defined code. No system logic is tied to these codes.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_CODE IS 'Customers can define alternating code value. Can be used in site specific applications to combine/ignore DCS codes';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_DESCRIPTION1 IS 'User defined description. Can be used in site specific implementations or for alternate descriptions.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_DESCRIPTION2 IS 'User defined description. Can be used in site specific implementations or for alternate descriptions.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.USER_DESCRIPTION3 IS 'User defined description. Can be used in site specific implementations or for alternate descriptions.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.COMMENTS IS 'Documentation column that holds business process rules. Users/Developers can enter business process documentation behind this system code.';

COMMENT ON COLUMN TBL_CODE_COST_CONTAIN_RPT_TYPE.PROMPT_FOR_PROF_REV_FLAG IS 'Values of Y or N.';

ALTER TABLE DCS2000.TBL_CODE_COST_CONTAIN_RPT_TYPE  ADD (
  CONSTRAINT PK_CODE_COST_CONTAIN_RPT_TYPE
 PRIMARY KEY
 (CODE)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
               ));


GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_COST_CONTAIN_RPT_TYPE TO DCSREPORTS;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_COST_CONTAIN_RPT_TYPE TO DCS_USERS_ALL;

