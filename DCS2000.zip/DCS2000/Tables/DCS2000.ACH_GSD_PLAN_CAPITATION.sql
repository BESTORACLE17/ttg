/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_PLAN_CAPITATION  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_PLAN_CAPITATION
(
  GRP_ID              VARCHAR2(9 BYTE)          NOT NULL,
  SUBLOC_ID           VARCHAR2(8 BYTE)          NOT NULL,
  DIV_ID              VARCHAR2(4 BYTE)          NOT NULL,
  PRD_CDE             NUMBER(4)                 NOT NULL,
  PLN_CDE             NUMBER(4)                 NOT NULL,
  EFF_DTE             NUMBER(8)                 NOT NULL,
  TRM_DTE             NUMBER(8)                 NOT NULL,
  CAP_RATE_TYPE       NUMBER(2)                 NOT NULL,
  RTE_CDE             NUMBER(2)                 NOT NULL,
  PERCENT_AMT_CDE     NUMBER(2)                 NOT NULL,
  CAPITATION_PERCENT  NUMBER(5,4),
  CAPITATION_AMT      NUMBER(7,2),
  MAINT_CODE          NUMBER(4),
  MOD_DTE             DATE,
  MOD_OP              VARCHAR2(12 BYTE),
  INS_UPD_FLAG        CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_PLAN_CAPITATION TO DCS_USERS_ALL;

--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (gsd_plan_capitation_pk NUMBER); --3.1.3

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_PLAN_CAPITATION ON DCS2000.ACH_GSD_PLAN_CAPITATION(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,EFF_DTE,CAP_RATE_TYPE,RTE_CDE) TABLESPACE PRODIX;
--End SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_PLAN_CAPITATION ADD (PRODUCT_LINE_CODE  NUMBER(4));--3.1.4 