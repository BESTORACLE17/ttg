/* VERSION: 3.1.4 */ 

/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.4
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_GSD_LETTER  (Table) 
--
CREATE TABLE DCS2000.ACH_GSD_LETTER
(
  GRP_ID           VARCHAR2(9 BYTE),
  SUBLOC_ID        VARCHAR2(8 BYTE),
  DIV_ID           VARCHAR2(4 BYTE),
  PRD_CDE          NUMBER(4),
  PLN_CDE          NUMBER(4),
  LETTER_CDE       NUMBER(2),
  DATE_TO_SEND     NUMBER(8),
  LETTER_FREQ_CDE  NUMBER(2),
  LETTER_FREQ      NUMBER(4),
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  INS_UPD_FLAG     CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_GSD_LETTER TO DCS_USERS_ALL;

--Start SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (gsd_letter_pk NUMBER); --3.1.3

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (created_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (created_on DATE);

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (updated_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (updated_on DATE);

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (action_code VARCHAR2(1));

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (action_by VARCHAR2(30));

ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (action_on DATE);

CREATE INDEX DCS2000.IX_ACH_GSD_LETTER ON DCS2000.ACH_GSD_LETTER(GRP_ID,SUBLOC_ID,DIV_ID,PRD_CDE,PLN_CDE,LETTER_CDE) TABLESPACE PRODIX;
--End SR07109.04.VA
ALTER TABLE DCS2000.ACH_GSD_LETTER ADD (PRODUCT_LINE_CODE  NUMBER(4));--3.1.4