-- VERSION: 2.1.1  
--
-- ACH_SUBR_DII_CONTROL (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_DII_CONTROL
(
   MAINT_CODE				    NUMBER(4),
   UPDATE_ON				    DATE, 
   UPDATE_BY				    VARCHAR2(30),
   DCS_INDIVIDUAL_IDENTIFIER	VARCHAR2(30),
   DAC_ID					    NUMBER(30),
   NII                          VARCHAR2(30),
   INS_UPD_FLAG			        VARCHAR2(1)
)
   TABLESPACE PROD
   PCTUSED    40
   PCTFREE    10
   INITRANS   1
   MAXTRANS   255
   STORAGE    (
            INITIAL          8320K
            NEXT             104K
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
   LOGGING 
   NOCACHE
   NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_DII_CONTROL TO DCS_USERS_ALL;


 
