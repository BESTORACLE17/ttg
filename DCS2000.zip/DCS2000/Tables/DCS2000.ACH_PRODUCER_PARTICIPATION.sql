/* VERSION: 3.1.1 */ 
--
-- ACH_PRODUCER_PARTICIPATION  (Table) 
--
CREATE TABLE DCS2000.ACH_PRODUCER_PARTICIPATION
(
  MAINT_CODE               NUMBER(4),
  MOD_DTE                  DATE,
  MOD_OP                   VARCHAR2(12 BYTE),
  PRODUCER_ID              NUMBER(15),
  COMPANY_ID               NUMBER(4),
  EFF_DTE                  NUMBER(8),
  TRM_DTE                  NUMBER(8),
  PARTICIPATION_TYPE_CODE  NUMBER(4),
  TERM_REASON_CODE         NUMBER(2),
  INS_UPD_FLAG             CHAR(1 BYTE),
  AP_VENDOR_CLASS_CODE     NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_PRODUCER_PARTICIPATION TO DCS_USERS_ALL;

