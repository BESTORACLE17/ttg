/* VERSION: 3.1.1 */ 
--
-- TBL_CDE_REPORT  (Table) 
--
CREATE TABLE DCS2000.TBL_CDE_REPORT
(
  BATCH_NO        CHAR(4 BYTE),
  JULIAN_DATE     VARCHAR2(7 BYTE),
  CLAIM_NO_LOW    VARCHAR2(14 BYTE),
  CLAIM_NO_HIGH   VARCHAR2(14 BYTE),
  CLAIM_NO_MISS   VARCHAR2(14 BYTE),
  PROCESS_STATUS  NUMBER(4),
  VERIFIED        NUMBER(4),
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          17496K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CDE_REPORT  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CDE_REPORT ON DCS2000.TBL_CDE_REPORT
(BATCH_NO, JULIAN_DATE, CLAIM_NO_LOW, CLAIM_NO_HIGH, CLAIM_NO_MISS)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CDE_REPORT TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CDE_REPORT TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_CDE_REPORT 
-- 
ALTER TABLE DCS2000.TBL_CDE_REPORT ADD (
  CONSTRAINT PK_CDE_REPORT PRIMARY KEY (BATCH_NO, JULIAN_DATE, CLAIM_NO_LOW, CLAIM_NO_HIGH, CLAIM_NO_MISS)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       505
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


