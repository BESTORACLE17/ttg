/* VERSION: 2.1.4 */ 

--********************
-- ACH_GA_PRODUCT_PLAN_DETAIL
-- SR - 07109.01.VA
-- version 2.1.1
--********************
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.2 
|| Revision Type  : Enhancement
|| Service Request: SR08092.28.CO Setup a System Parameter to Disallow COB 
||                : within the Same
|| Revision By    : Sanjay Mudaliar.
|| Revision Date  : 06/30/2008 
|| Revision Desc  : Added COB SAME GROUP column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.3
|| Revision Type  : Enhancement
|| Service Request: sr10067.02.VA MULTI PRODUCT 
|| Revision By    : SATYA SAI
|| Revision Date  : 05/26/2010 
|| Revision Desc  : Added PRODUCT_LINE_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 2.1.4
|| Revision Type  : Enhancement
|| Service Request: 11077.01.VA 
|| Revision By    : SATYA SAI
|| Revision Date  : 04/22/2011 
|| Revision Desc  : Added LOSS_RATIO_CODE column
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

CREATE TABLE DCS2000.ACH_GA_PRODUCT_PLAN_DETAIL
   (
   CREATED_BY                 VARCHAR2(12 BYTE),
   CREATED_ON                 DATE,   
   UPDATED_BY                 VARCHAR2(12 BYTE),
   UPDATED_ON                 DATE,   
   MAINT_CODE                 NUMBER(4),
   USER_DEFINED_FIELD1        VARCHAR2(100 BYTE),
   USER_DEFINED_FIELD2        VARCHAR2(100 BYTE),
   USER_DEFINED_FIELD3        VARCHAR2(100 BYTE),
   USER_DEFINED_FIELD4        VARCHAR2(100 BYTE),
   ACTION_CODE                VARCHAR2(1 BYTE),
   ACTION_BY                  VARCHAR2(30 BYTE),
   ACTION_ON                  DATE,   
   PRODUCT_PLAN_DETAIL_PK     NUMBER(9),
   PRODUCT_PLAN_HEADER_PK     NUMBER(9),  
   PRODUCT_CODE               NUMBER(4),
   PLAN_CODE                  NUMBER(4),
   EFF_DATE                   DATE,
   TERM_DATE                  DATE,
   TERM_REASON_CODE           NUMBER(4),
   COMMENTS                   VARCHAR2(200 BYTE),
   NOTES                      VARCHAR2(200 BYTE),
   AUTO_ADD_DPND              NUMBER(1),
   DELTAUSA                   NUMBER(1),
   MULTI_ST_ACC_IND           NUMBER(1),
   DEDUCT_CALC                NUMBER(1),
   COB_COVER_TYPE_CODE        NUMBER(2),
   PRICING_SET_NO             NUMBER(4),
   HIST_XCHK_SET_NO           NUMBER(8),
   PAR_PERCENT_CODE           NUMBER(4),
   NONPAR_PERCENT_CODE        NUMBER(4),
   NONFILED_PERCENT_CODE      NUMBER(4),
   PAR_TOA                    NUMBER(4),
   NONPAR_TOA                 NUMBER(4),
   PAR_RTOA                   NUMBER(4),
   NONPAR_RTOA                NUMBER(4),
   DC_REIMBURSE_PERCENT       NUMBER(5,2),
   ID_CARD_CODE               NUMBER(2),
   ID_CARD_MAILTO_CODE        NUMBER(2),
   ID_CARD_INT_ISSUE_DTE      DATE,
   ID_CARD_EFF_DTE_IND        NUMBER(1),
   ID_CARD_COMP_NAME          NUMBER(2),
   EOC_BOOKLET_NO             CHAR(8 BYTE),
   ID_CARD_PRINT_EOC          NUMBER(1),
   ACCIDENT_CODE              NUMBER(2),
   ASO_RISK_TYPE              NUMBER(2),
   GRP_CONTRIB_TYPE           NUMBER(2),
   GRP_CONTRIB_PERCENT        NUMBER(10,4),
   CONTROL_PLN_CODE           NUMBER(4),
   DDPV_LTIME_CARRYOVER       NUMBER(1),
   GRP_LTIME_CARRYOVER        NUMBER(1),
   DUAL_COVER_CODE            NUMBER(2),
   SUBR_CORRESP_CODE          NUMBER(2),
   GRP_REPORT_CATEGORY        NUMBER(4),
   ALTERNATE_BENEFIT_SET_NO   NUMBER(4),
   COMPANY_ID                 NUMBER(4),
   ALT_FEE_IND                NUMBER(1),
   LATE_SUBMIT_TYPE           NUMBER(4),
   LATE_SUBMIT_VALUE          NUMBER(4),
   PROCESS_POLICY_SET         NUMBER(4),
   PROCEDURE_SET              NUMBER(4),
   CEDED_PLN_CODE             NUMBER(4),
   DEFAULT_REGION_CODE        NUMBER(4),
   DISPLAY_ON_WEB		         NUMBER(1)
);

-- 2.1.2
ALTER TABLE DCS2000.ACH_GA_PRODUCT_PLAN_DETAIL ADD (COB_SAME_GROUP  NUMBER(1));
/-- 2.1.3
ALTER TABLE DCS2000.ACH_GA_PRODUCT_PLAN_DETAIL ADD (PRODUCT_LINE_CODE  NUMBER(4));
/
ALTER TABLE DCS2000.ACH_GA_PRODUCT_PLAN_DETAIL ADD (LOSS_RATIO_CODE  NUMBER(4));--2.1.4
/