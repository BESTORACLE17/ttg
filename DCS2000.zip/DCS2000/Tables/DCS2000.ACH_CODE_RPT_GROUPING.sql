/* VERSION: 3.1.1 */ 
--
-- ACH_CODE_RPT_GROUPING  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Version #      : 3.1.1 
|| Revision Type  : Enhancement
|| Service Request: SR 04033.03.VA Phase II - ASO Billing Enhancements
|| Revision By    : Jeff Reynolds
|| Revision Date  : 01/21/2008 
|| Revision Desc  : Original version
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_CODE_RPT_GROUPING
(
   CREATED_BY            VARCHAR2(30)           ,
   CREATED_ON            DATE                   ,
   UPDATED_BY            VARCHAR2(30)           ,
   UPDATED_ON            DATE                   ,
   DELETED_BY            VARCHAR2(30)           ,
   DELETED_ON            DATE                   ,
   MAINT_CODE            NUMBER(4)              ,
   CODE_RPT_GROUPING_PK  NUMBER(10)             ,
   DESCRIPTION           VARCHAR2(200)          
)
TABLESPACE PROD
/
GRANT DELETE, INSERT, SELECT, UPDATE  ON DCS2000.ACH_CODE_RPT_GROUPING TO DCS_USERS_ALL
/
GRANT SELECT ON DCS2000.ACH_CODE_RPT_GROUPING TO DCSREPORTS
/
