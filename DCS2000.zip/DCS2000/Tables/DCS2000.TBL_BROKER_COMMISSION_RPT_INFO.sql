/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BROKER_COMMISSION_RPT_INFO  (Table) 
--
CREATE TABLE DCS2000.TBL_BROKER_COMMISSION_RPT_INFO
(
  MAINT_CODE                   NUMBER(4),
  MOD_DTE                      DATE,
  MOD_OP                       VARCHAR2(12 BYTE),
  GROUP_ID                     VARCHAR2(9 BYTE),
  SUBLOC_ID                    VARCHAR2(8 BYTE),
  DIV_ID                       VARCHAR2(4 BYTE),
  BROKER_ID                    VARCHAR2(9 BYTE),
  AGENCY_ID                    VARCHAR2(9 BYTE),
  BROKER_TYPE                  NUMBER(4),
  ADDR_CDE                     NUMBER(2),
  FIN_GL_ACCT_NO               VARCHAR2(20 BYTE),
  FIN_PAY_DATE                 NUMBER(8),
  FIN_POST_DATE                NUMBER(8),
  FIN_CLAIMS_CNT               NUMBER(7),
  FIN_INVOICE_AMT              NUMBER(9,2),
  FIN_PREMIUM_AMT              NUMBER(9,2),
  BROKER_INTERNAL              NUMBER(1),
  COMM_TIN                     VARCHAR2(9 BYTE),
  COMM_TIN_TYPE                NUMBER(1),
  COMM_EFF_DATE                NUMBER(8),
  COMM_TERM_DATE               NUMBER(8),
  COMM_PAY_TO_ID               VARCHAR2(9 BYTE),
  COMM_SCHEDULE_CDE            NUMBER(4),
  COMM_PERCENT_AMT             NUMBER(9,5),
  COMM_PAYMENT_AMT             NUMBER(9,2),
  SCALE_PERCENT_AMT            NUMBER(6,4),
  ASO_EFF_DATE                 NUMBER(8),
  ASO_TERM_DATE                NUMBER(8),
  ASO_COMM_IND                 NUMBER(4),
  ASO_FLAT_AMT                 NUMBER(9,2),
  ASO_PERC_AMT                 NUMBER(9,5),
  ASO_ENROLLMENT               NUMBER(9),
  TOT_COMMISSION_AMT           NUMBER(9,2),
  TRANSACTION_CODE             NUMBER(2),
  LICENSE_NUMBER               VARCHAR2(30 BYTE),
  DOI_TAX_ID                   VARCHAR2(30 BYTE),
  SLIDING_SCALE_ID             NUMBER(4),
  CONTRACT_YTD_PREMIUM_AMT     NUMBER(15,2),
  CONTRACT_YTD_COMMISSION_AMT  NUMBER(15,2),
  COMM_TYPE_CDE                NUMBER(4),
  BILLING_TYPE                 NUMBER(2),
  PROCESSED                    VARCHAR2(6 BYTE),
  CONTRACT_BEGIN_DTE           NUMBER(8),
  CONTRACT_END_DTE             NUMBER(8),
  SUBR_ID                      VARCHAR2(9 BYTE),
  SUBR_FNAME                   VARCHAR2(30 BYTE),
  SUBR_LNAME                   VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1040K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- BRKR_COMM_SUBR_LNME_IX  (Index) 
--
CREATE INDEX DCS2000.BRKR_COMM_SUBR_LNME_IX ON DCS2000.TBL_BROKER_COMMISSION_RPT_INFO
(SUBR_LNAME)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BROKER_COMMISSION_RPT_INFO MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BROKER_COMMISSION_RPT_INFO TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BROKER_COMMISSION_RPT_INFO TO DCSREPORTS;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.TBL_BROKER_COMMISSION_RPT_INFO TO DCS_COMMISSION_USERS;

GRANT SELECT ON  DCS2000.TBL_BROKER_COMMISSION_RPT_INFO TO PRODDBLINK;

