CREATE TABLE DCS2000.TBL_ADJUD_ERROR_ROUTE
(
  CREATED_BY          VARCHAR2(30 BYTE) NOT NULL,
  CREATED_ON          DATE              NOT NULL,
  UPDATED_BY          VARCHAR2(30 BYTE) NOT NULL,
  UPDATED_ON          DATE              NOT NULL,
  MAINT_CODE          NUMBER(4)         NOT NULL,
  ERROR_NO            NUMBER(4)         NOT NULL,
  PROCESS_POLICY_SET  NUMBER(4)         NOT NULL,
  PRD_CDE             NUMBER(4),
  GRP_ID              VARCHAR2(9 BYTE),
  SUBLOC_ID           VARCHAR2(8 BYTE),
  DIV_ID              VARCHAR2(4 BYTE),
  ERROR_QUEUE         NUMBER(4)         NOT NULL,
  DELIMITER_CDE       NUMBER(4),
  PROCESS_POLICY      NUMBER(4),
  ALLOW_OVRD          NUMBER(1)         NOT NULL,
  AUTO_CLOSE_IND      NUMBER(4)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;


CREATE UNIQUE INDEX UK_ADJUD_ERROR_ROUTE ON TBL_ADJUD_ERROR_ROUTE
(ERROR_NO, PROCESS_POLICY_SET, PRD_CDE, GRP_ID, SUBLOC_ID, DIV_ID)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


ALTER TABLE DCS2000.TBL_ADJUD_ERROR_ROUTE ADD (
  CONSTRAINT UK_ADJUD_ERROR_ROUTE
 UNIQUE (ERROR_NO, PROCESS_POLICY_SET, PRD_CDE, GRP_ID, SUBLOC_ID, DIV_ID)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));
CREATE OR REPLACE TRIGGER TRG_ADJUD_ERROR_ROUTE
  BEFORE INSERT OR UPDATE OR DELETE ON TBL_ADJUD_ERROR_ROUTE FOR EACH ROW
BEGIN

   IF INSERTING THEN

      :NEW.maint_code := NVL( :NEW.maint_code, 0 );
      :NEW.created_on := SYSDATE;
      :NEW.created_by := USER;
      :NEW.updated_on := SYSDATE;
      :NEW.updated_by := USER;

   ELSIF UPDATING THEN

      :NEW.maint_code := NVL( :NEW.maint_code, 0 );
      :NEW.updated_on := SYSDATE;
      :NEW.updated_by := USER;

   END IF;
 
END;
/
SHOW ERRORS;