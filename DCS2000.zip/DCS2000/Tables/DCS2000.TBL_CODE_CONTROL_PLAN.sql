/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_CONTROL_PLAN  (Table) 
--
CREATE TABLE DCS2000.TBL_CODE_CONTROL_PLAN
(
  CODE               NUMBER(4)                  NOT NULL,
  CONTROL_PLAN_NAME  VARCHAR2(50 BYTE),
  ADDRESS_1          VARCHAR2(64 BYTE),
  ADDRESS_2          VARCHAR2(64 BYTE),
  CITY               VARCHAR2(30 BYTE),
  STATE              VARCHAR2(2 BYTE),
  ZIP                NUMBER(9),
  TITLE              VARCHAR2(20 BYTE),
  LNAME              VARCHAR2(30 BYTE),
  FNAME              VARCHAR2(30 BYTE),
  PHONE_NO           VARCHAR2(30 BYTE),
  COMMENTS           VARCHAR2(200 BYTE),
  MAINT_CODE         NUMBER(4),
  MOD_DTE            DATE,
  MOD_OP             VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_CONTROL_PLAN TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CODE_CONTROL_PLAN TO PRODDBLINK;

--
-- PK_CODE_CONTROL_PLAN  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CODE_CONTROL_PLAN ON DCS2000.TBL_CODE_CONTROL_PLAN
(CODE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          24K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_CONTROL_PLAN 
-- 
ALTER TABLE DCS2000.TBL_CODE_CONTROL_PLAN ADD (
  CONSTRAINT PK_CODE_CONTROL_PLAN PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          24K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


-- 
-- Foreign Key Constraints for Table TBL_CODE_CONTROL_PLAN 
-- 
ALTER TABLE DCS2000.TBL_CODE_CONTROL_PLAN ADD (
  CONSTRAINT FK_CONTROL_PLAN_2_STATE FOREIGN KEY (STATE) 
    REFERENCES DCS2000.TBL_CODE_STATE (STATE));


