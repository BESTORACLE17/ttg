/* VERSION: 2.1.1 */
CREATE TABLE DCS2000.ACH_GM_TABLE_GROUP
( 
  CREATED_BY               VARCHAR2(30),
  CREATED_ON               DATE,
  UPDATED_BY               VARCHAR2(30),
  UPDATED_ON               DATE,
  MAINT_CODE               NUMBER(4),
  ACTION_CODE              VARCHAR2(1 BYTE),
  ACTION_BY                VARCHAR2(30 BYTE),
  ACTION_ON                DATE,
  GM_TABLE_GROUP_PK        NUMBER(4),
  NAME                     VARCHAR2(200),
  COMMENTS                 VARCHAR2(4000)
)
TABLESPACE PROD ;

COMMENT ON TABLE DCS2000.ACH_GM_TABLE_GROUP IS 'Table that defines Group for a combination of table category.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.CREATED_BY IS 'User ID of the user who created the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.CREATED_ON IS 'Date on which the row was created.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.UPDATED_BY IS 'User ID of the user who last updated the row.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.UPDATED_ON IS 'Date on which the row was last updated.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.ACTION_CODE  IS 'Action (Insert/Update/Delete) that was taken on the production record that caused old maintenance record to be archived. I = Insert, U = Update, and D = Delete.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.ACTION_BY    IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.ACTION_ON    IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.GM_TABLE_GROUP_PK IS 'System generated PK.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.NAME IS 'Display name of the Group.';

COMMENT ON COLUMN DCS2000.ACH_GM_TABLE_GROUP.COMMENTS IS 'Additional information attached with the group .';
