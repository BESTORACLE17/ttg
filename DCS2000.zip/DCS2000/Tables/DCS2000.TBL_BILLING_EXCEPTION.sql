/* VERSION: 3.1.1 */ 
--
-- TBL_BILLING_EXCEPTION  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_EXCEPTION
(
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  GRP_ID           VARCHAR2(9 BYTE)             NOT NULL,
  SUBLOC_ID        VARCHAR2(8 BYTE)             NOT NULL,
  DIV_ID           VARCHAR2(4 BYTE)             NOT NULL,
  PRD_CDE          NUMBER(4)                    NOT NULL,
  INCLUDE_EXCLUDE  NUMBER(2)                    NOT NULL,
  GRP_NME          VARCHAR2(100 BYTE),
  BILLING_CYCLE    NUMBER(2)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          2080K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_BILLING_EXCEPTION  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_BILLING_EXCEPTION ON DCS2000.TBL_BILLING_EXCEPTION
(GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_EXCEPTION TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_EXCEPTION TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_BILLING_EXCEPTION 
-- 
ALTER TABLE DCS2000.TBL_BILLING_EXCEPTION ADD (
  CONSTRAINT PK_BILLING_EXCEPTION PRIMARY KEY (GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1040K
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


