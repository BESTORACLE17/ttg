/* +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Creation
|| Version #      : 3.1.0
|| Service Request: TRAC#5065
|| Revision By    : Manoj Sathe
|| Revision Date  : 09/15/2010
|| Revision Desc  : Added as temp table to resolve performance issue in Claim Audit
||                  Application
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
DROP TABLE DCS2000.TBL_CLAIM_AUDIT_TEMP CASCADE CONSTRAINTS;

CREATE TABLE DCS2000.TBL_CLAIM_AUDIT_TEMP
(
  CLAIM_NO       VARCHAR2(14 BYTE),
  GRP_ID         VARCHAR2(9 BYTE),
  SUBLOC_ID      VARCHAR2(8 BYTE),
  DIV_NO         VARCHAR2(4 BYTE),
  TREATMENT_DTE  NUMBER(8),
  RUN_NO         NUMBER(8),
  PARENT_ID      NUMBER(4)                     NOT NULL
)
TABLESPACE PROD;

COMMENT ON COLUMN DCS2000.TBL_CLAIM_AUDIT_TEMP.PARENT_ID IS 'SR10006.01.ALL - Multi-Org';

CREATE OR REPLACE TRIGGER DCS2000."TRG_TBL_CLAIM_AUDIT_TEMP_PID"
 BEFORE UPDATE OR INSERT ON "DCS2000"."TBL_CLAIM_AUDIT_TEMP" FOR EACH ROW
--============================================================================
-- Revision Type  : Creation
-- Service Request: SR10006.01.ALL
-- Revision Desc  : This Trigger is Created to insert parent_id from sys_context
--============================================================================
DECLARE
    l_parent_id      NUMBER := sys_context('CNT_PARENT_ID','PARENT_ID');
BEGIN
   :new.parent_id    := l_parent_id;
END;
/
GRANT INSERT, SELECT, UPDATE, DELETE ON DCS2000.TBL_CLAIM_AUDIT_TEMP TO DCS_USERS_ALL;