/* VERSION: 3.1.1 */ 
--
-- TBL_ASSOCIATION_ADDRESS  (Table) 
--
CREATE TABLE DCS2000.TBL_ASSOCIATION_ADDRESS
(
  ASSOCIATION_ID      NUMBER(4)                 NOT NULL,
  ADDR_CDE            NUMBER(2)                 NOT NULL,
  DEPT                VARCHAR2(20 BYTE),
  CONTACT_SALUTATION  VARCHAR2(30 BYTE),
  LNME                VARCHAR2(30 BYTE),
  FNME                VARCHAR2(30 BYTE),
  ADDR1               VARCHAR2(30 BYTE)         NOT NULL,
  ADDR2               VARCHAR2(30 BYTE),
  ADDR3               VARCHAR2(30 BYTE),
  CITY                VARCHAR2(30 BYTE),
  STATE               VARCHAR2(2 BYTE),
  ZIP                 NUMBER(5)                 NOT NULL,
  ZIP4                NUMBER(4),
  COUNTRY_CDE         NUMBER(4)                 NOT NULL,
  MAINT_CODE          NUMBER(4),
  MOD_DTE             DATE,
  MOD_OP              VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          80K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ASSOCIATION_ADDRESS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ASSOCIATION_ADDRESS TO PRODDBLINK;

