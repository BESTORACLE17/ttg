--=======================================
--SR 03266.01 Ingenix Fees
--DateL 09/26/2005 
--Suresh Vadapalli
--=======================================
/* VERSION: 3.1.1 */ 


CREATE TABLE DCS2000.ACH_FEES_ZIP_RANGE
(
  FEE_ZIP_KEY  NUMBER(8),
  STATE        VARCHAR2(2),
  ZIP_AREA     VARCHAR2(3),
  ZIP_BGN1     VARCHAR2(3),
  ZIP_END1     VARCHAR2(3),
  ZIP_BGN2     VARCHAR2(3),
  ZIP_END2     VARCHAR2(3),
  ZIP_BGN3     VARCHAR2(3),
  ZIP_END3     VARCHAR2(3),
  ZIP_BGN4     VARCHAR2(3),
  ZIP_END4     VARCHAR2(3),
  ZIP_BGN5     VARCHAR2(3),
  ZIP_END5     VARCHAR2(3),
  ZIP1         VARCHAR2(3),
  ZIP2         VARCHAR2(3),
  ZIP3         VARCHAR2(3),
  ZIP4         VARCHAR2(3),
  ZIP5         VARCHAR2(3),
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12),
  INS_UPD_FLAG VARCHAR2(1)
);


GRANT SELECT,INSERT,UPDATE,DELETE ON DCS2000.ACH_FEES_ZIP_RANGE TO DCS_USERS_ALL;