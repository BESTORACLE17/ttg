/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_SUBR_INDV_CONTACT  (Table) 
--
CREATE TABLE DCS2000.ACH_SUBR_INDV_CONTACT
(
  SUBR_ID      VARCHAR2(9 BYTE)                 NOT NULL,
  INDV_ID      NUMBER(2)                        NOT NULL,
  CONTACT_CDE  NUMBER(2)                        NOT NULL,
  LNME         VARCHAR2(30 BYTE)                NOT NULL,
  FNME         VARCHAR2(30 BYTE)                NOT NULL,
  EMAIL_ADDR   VARCHAR2(60 BYTE),
  FAX          VARCHAR2(30 BYTE),
  PHONE        VARCHAR2(30 BYTE),
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_SUBR_INDV_CONTACT MODIFY SUBR_ID VARCHAR2(30);

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_SUBR_INDV_CONTACT TO DCS_USERS_ALL;

