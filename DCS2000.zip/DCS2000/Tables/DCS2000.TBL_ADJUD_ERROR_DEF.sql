DROP TABLE DCS2000.TBL_ADJUD_ERROR_DEF;
CREATE TABLE DCS2000.TBL_ADJUD_ERROR_DEF
(
  CREATED_BY         VARCHAR2(30 BYTE) NOT NULL,
  CREATED_ON         DATE              NOT NULL,
  UPDATED_BY         VARCHAR2(30 BYTE) NOT NULL,
  UPDATED_ON         DATE              NOT NULL,
  MAINT_CODE         NUMBER(4)         NOT NULL,
  ERROR_NO           NUMBER(4)         NOT NULL,
  DESCRIPTION        VARCHAR2(100 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          120K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
NOPARALLEL
NOMONITORING;
CREATE UNIQUE INDEX PK_ADJUD_ERROR_DEF ON TBL_ADJUD_ERROR_DEF
(ERROR_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          120K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

ALTER TABLE DCS2000.TBL_ADJUD_ERROR_DEF ADD (
  CONSTRAINT PK_ADJUD_ERROR_DEF
 PRIMARY KEY
 (ERROR_NO)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          120K
                NEXT             16K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));
