--=======================================
--SR 07109.04 VA GM QUALITY EDITS
--Date 06/30/2008 
--Pramod Gujjar
--=======================================
/* VERSION: 3.1.1 */ 
CREATE TABLE DCS2000.ACH_GM_EMAIL_NOTIFICATIONS
( CREATED_BY                    VARCHAR2(30),
  CREATED_ON                    DATE,
  UPDATED_BY                    VARCHAR2(30),
  UPDATED_ON                    DATE,
  MAINT_CODE                    NUMBER (4),
  EMAIL_NOTIFICATION_PK         NUMBER,
  TABLE_COLUMN_PK               NUMBER,
  NOTIFICATION_CODE             NUMBER(1)
);
GRANT INSERT, SELECT, UPDATE, DELETE ON DCS2000.ACH_GM_EMAIL_NOTIFICATIONS TO DCS_USERS_ALL;