/* VERSION: 3.1.1 */ 
--
-- TBL_BILLING_ASO  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_ASO
(
  GRP_ID            VARCHAR2(9 BYTE)            NOT NULL,
  SUBLOC_ID         VARCHAR2(8 BYTE)            NOT NULL,
  DIV_ID            VARCHAR2(4 BYTE)            NOT NULL,
  PRD_CDE           NUMBER(4)                   NOT NULL,
  YEAR              NUMBER(4)                   NOT NULL,
  MM                NUMBER(2)                   NOT NULL,
  DAY               NUMBER(2)                   NOT NULL,
  SOURCE            NUMBER(4)                   NOT NULL,
  GROUP_NME         VARCHAR2(100 BYTE),
  FEE_TYPE          NUMBER(4)                   NOT NULL,
  FEE_AMT           NUMBER(7,3),
  CLAIMS_CNT        NUMBER(8),
  CLAIMS_AMT        NUMBER(11,2),
  SUBR_CNT          NUMBER(8),
  ASC_AMT           NUMBER(11,2),
  DESCRIPTION       VARCHAR2(50 BYTE)           NOT NULL,
  MAINT_CODE        NUMBER(4),
  MOD_DTE           DATE,
  MOD_OP            VARCHAR2(12 BYTE),
  REPORTING_CODE    NUMBER(4),
  SUB_CNT           NUMBER(8),
  SUB_SP_CNT        NUMBER(8),
  SUB_CH_CNT        NUMBER(8),
  SUB_CHILDREN_CNT  NUMBER(8),
  SUB_FAMILY_CNT    NUMBER(8)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

COMMENT ON COLUMN DCS2000.TBL_BILLING_ASO.SOURCE IS '1 = PAYMENT, 2 = BILLING, 3 = ADJUSTMENT';

--
-- PK_TBL_BILLING_ASO  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_TBL_BILLING_ASO ON DCS2000.TBL_BILLING_ASO
(GRP_ID, SUBLOC_ID, DIV_ID, PRD_CDE, YEAR, 
MM, DAY, SOURCE, REPORTING_CODE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_ASO TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BILLING_ASO TO PRODDBLINK;

