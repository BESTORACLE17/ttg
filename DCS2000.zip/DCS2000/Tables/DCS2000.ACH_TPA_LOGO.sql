/* Version 3.0.0 
 Satya sai
 SR 10340.01.VA
*/
CREATE TABLE DCS2000.ACH_TPA_LOGO
      ( CREATED_BY                 VARCHAR2(30 ),
        CREATED_ON                 DATE,
        UPDATED_ON                 DATE,
        UPDATED_BY                 VARCHAR2(12),
        MAINT_CODE                 NUMBER(4),
        ACTION_BY                  VARCHAR2(30),
        ACTION_ON                  DATE,
        ACTION_CODE                VARCHAR2(1),
        TPA_LOGO_PK                NUMBER(12),
        TPA_ID                     NUMBER(4),
        IMAGE_TYPE                 NUMBER(2),
        IMAGE_ID                   NUMBER(4),
        LOGO_INDENT_FLAG           VARCHAR2(1 ),
        SHOW_TPA_NAME_FLAG         VARCHAR2(1 )
      );
GRANT SELECT ON DCS2000.ACH_TPA_LOGO TO DCSREPORTS WITH GRANT OPTION;

GRANT DELETE, INSERT, SELECT, UPDATE ON DCS2000.ACH_TPA_LOGO TO DCS_USERS_ALL;
