/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_COMMENTS  (Table) 
--
CREATE TABLE DCS2000.ACH_COMMENTS
(
  SUBR_ID                 VARCHAR2(9 BYTE),
  INDV_ID                 NUMBER(2),
  GRP_ID                  VARCHAR2(9 BYTE),
  SUBLOC_ID               VARCHAR2(8 BYTE),
  DIV_ID                  VARCHAR2(4 BYTE),
  CLAIM_NO                VARCHAR2(14 BYTE),
  PRV_ID                  VARCHAR2(11 BYTE),
  LOC                     NUMBER(4),
  TAX_ID                  VARCHAR2(9 BYTE),
  COMMENT_SOURCE          NUMBER(2),
  COMMENT_INQUIRY_TYPE    NUMBER(2),
  COMMENT_RECEIPT_DTE     DATE,
  COMMENT_INQUIRY         NUMBER(2),
  COMMENT_DTE             DATE,
  COMMENT_TEXT            VARCHAR2(2000 BYTE),
  COMMENT_INQUIRY_STATUS  NUMBER(2),
  COMPLETED_DTE           DATE,
  CALL_BACK               NUMBER(1),
  CALL_BACK_DTE           DATE,
  ADD_OP                  VARCHAR2(12 BYTE),
  MAINT_CODE              NUMBER(4),
  MOD_DTE                 DATE,
  MOD_OP                  VARCHAR2(12 BYTE),
  COMMENT_TYPE_CDE        NUMBER(4),
  ERROR_TYPE_CDE          NUMBER(4)
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_COMMENTS MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_COMMENTS TO DCS_USERS_ALL;

-- Added for SR 07121.01.ALL 12 Digit License Number
ALTER TABLE	DCS2000.ACH_COMMENTS	MODIFY (PRV_ID VARCHAR2(32) );  