/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_ACTIVE_SUBR  (Table) 
--
CREATE TABLE DCS2000.TBL_ACTIVE_SUBR
(
  GRP_ID             VARCHAR2(9 BYTE),
  SUBLOC_ID          VARCHAR2(8 BYTE),
  DIV_ID             VARCHAR2(4 BYTE),
  PRD_CDE            NUMBER(4),
  PLN_CDE            NUMBER(4),
  SUBR_ID            VARCHAR2(9 BYTE),
  INDV_ID            NUMBER(2),
  RTE_CDE            NUMBER(2),
  RELSHP_CDE         NUMBER(2),
  DOB                NUMBER(8),
  SUBR_FNME          VARCHAR2(30 BYTE),
  SUBR_LNME          VARCHAR2(30 BYTE),
  INDV_EFF_DTE       NUMBER(8),
  TRM_DTE            NUMBER(8),
  ADDR1              VARCHAR2(30 BYTE),
  ADDR2              VARCHAR2(30 BYTE),
  CITY               VARCHAR2(30 BYTE),
  STATE              VARCHAR2(2 BYTE),
  ZIP                NUMBER(5),
  SELECT_PRV_ID      VARCHAR2(11 BYTE),
  SELECT_PRV_LOC     NUMBER(4),
  SELECT_PRV_TAX_ID  VARCHAR2(9 BYTE),
  FAC_STATE          VARCHAR2(2 BYTE),
  PRV_ST_LIC         VARCHAR2(9 BYTE),
  PRV_NAME           VARCHAR2(30 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          5040K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ACTIVE_SUBR_IX  (Index) 
--
CREATE INDEX DCS2000.ACTIVE_SUBR_IX ON DCS2000.TBL_ACTIVE_SUBR
(SUBR_ID, INDV_ID)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_ACTIVE_SUBR MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ACTIVE_SUBR TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ACTIVE_SUBR TO PRODDBLINK;

-- Added for SR07121.01.ALL
ALTER TABLE	DCS2000.TBL_ACTIVE_SUBR	MODIFY (SELECT_PRV_ID  VARCHAR2(32) );