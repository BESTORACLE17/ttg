/* VERSION: 3.1.1 */ 
--
-- TBL_CODE_BILLING_DISTR  (Table) 
--
CREATE TABLE DCS2000.TBL_CODE_BILLING_DISTR
(
  MAINT_CODE   NUMBER(4),
  MOD_DTE      DATE,
  MOD_OP       VARCHAR2(12 BYTE),
  CODE         NUMBER(2)                        NOT NULL,
  DESCRIPTION  VARCHAR2(50 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_CODE_BILL_DISTR  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_CODE_BILL_DISTR ON DCS2000.TBL_CODE_BILLING_DISTR
(CODE)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CODE_BILLING_DISTR TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CODE_BILLING_DISTR TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_CODE_BILLING_DISTR 
-- 
ALTER TABLE DCS2000.TBL_CODE_BILLING_DISTR ADD (
  CONSTRAINT PK_CODE_BILL_DISTR PRIMARY KEY (CODE)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          16K
                NEXT             8K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


