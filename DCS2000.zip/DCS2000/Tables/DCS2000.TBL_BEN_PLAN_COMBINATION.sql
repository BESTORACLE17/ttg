/* VERSION: 3.1.1 */ 
--
-- TBL_BEN_PLAN_COMBINATION  (Table) 
--
CREATE TABLE DCS2000.TBL_BEN_PLAN_COMBINATION
(
  BEN_KEY              NUMBER(8)                NOT NULL,
  BEN_COMBINATION_KEY  NUMBER(8)                NOT NULL,
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          200K
            NEXT             24K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- PK_BEN_PLAN_COMBINATION  (Index) 
--
CREATE UNIQUE INDEX DCS2000.PK_BEN_PLAN_COMBINATION ON DCS2000.TBL_BEN_PLAN_COMBINATION
(BEN_KEY, BEN_COMBINATION_KEY)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          120K
            NEXT             104K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BEN_PLAN_COMBINATION TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_BEN_PLAN_COMBINATION TO PRODDBLINK;

-- 
-- Non Foreign Key Constraints for Table TBL_BEN_PLAN_COMBINATION 
-- 
ALTER TABLE DCS2000.TBL_BEN_PLAN_COMBINATION ADD (
  CONSTRAINT PK_BEN_PLAN_COMBINATION PRIMARY KEY (BEN_KEY, BEN_COMBINATION_KEY)
    USING INDEX 
    TABLESPACE PRODIX
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          120K
                NEXT             104K
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ));


