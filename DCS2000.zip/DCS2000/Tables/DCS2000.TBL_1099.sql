DROP TABLE DCS2000.TBL_1099;

CREATE TABLE TBL_1099
(
  REPORTING_YEAR                      NUMBER(4) NOT NULL
 ,PAYOR_COMPANY_ID                    NUMBER(4) NOT NULL
 ,PAYMENT_TYPE_CODE                   NUMBER(4) NOT NULL  
 ,PAYEE_TAX_ID                        VARCHAR2(11) -- Store formatted Numbers.
 ,PAYEE_TIN_TYPE                      VARCHAR2(1)
 ,PAYEE_NAME                          VARCHAR2(40)
 ,PAYEE_ADDRESS_1                     VARCHAR2(30)
 ,PAYEE_ADDRESS_2                     VARCHAR2(30)
 ,PAYEE_ADDRESS_3                     VARCHAR2(30)
 ,PAYEE_CITY                          VARCHAR2(30)
 ,PAYEE_STATE                         VARCHAR2(2)
 ,PAYEE_ZIP                           VARCHAR2(5)
 ,MEDICAL_HEALTH_AMT                  NUMBER(10,2)
 ,NONEMP_COMPENSATION_AMT             NUMBER(10,2)
 ,MAINT_CODE                          NUMBER(2)
 ,MOD_OP                              VARCHAR2(30)
 ,MOD_DTE                             DATE 
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          2M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE INDEX N1_1099 ON TBL_1099
(REPORTING_YEAR)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          2M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;   

ALTER TABLE DCS2000.TBL_1099
   ADD CONSTRAINT FK1_1099 FOREIGN KEY ( PAYMENT_TYPE_CODE )
      REFERENCES TBL_CODE_1099_PAYMENT_TYPE ( CODE);
      
GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_1099 TO DCS_USERS_ALL, DCSLOAD;

-- 02/23/05 DKM
ALTER TABLE DCS2000.TBL_1099
   ADD    
   a.prv_id 
            ,a.prv_tax_id 
            ,a.prv_loc 
            ,a.fac_state 


-- 
-- SR #05068.01.VA ADD COMPANY ID IN W9 RECORD 
-- Russell Hertzberg 03/14/2005 - added ADDL_INFO_N columns 
-- 
alter table DCS2000.tbl_1099 add
   (ADDL_INFO_1  VARCHAR2(100)
   ,ADDL_INFO_2  VARCHAR2(100)
   ,ADDL_INFO_3  VARCHAR2(100)
   ,ADDL_INFO_4  VARCHAR2(100)
   ,ADDL_INFO_5  VARCHAR2(100));

-- satya sai NPF 2010 March release  SR 09336.02.ALL
alter table DCS2000.tbl_1099 modify 
  (PAYEE_ADDRESS_1    VARCHAR2(64 ),
   PAYEE_ADDRESS_2    VARCHAR2(64 ),
   PAYEE_ADDRESS_3    VARCHAR2(64 )
  );
/