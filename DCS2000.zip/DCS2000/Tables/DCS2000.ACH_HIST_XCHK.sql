-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
--  Revision Type: Enhancement
--  SR No:         07106.01.AR
--  Version:       3.1.1
--  Developer(s):  Sanjay Mudaliar
--  Revised:       06/27/2008
--  Description:   Added Columns SURFACE_GROUPING_CLAIM and SURFACE_GROUPING_HIST
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
--  Revision Type: Enhancement
--  SR No:         10067.02.VA Multi Products 
--  Version:       3.1.2
--  Developer(s):  Satya Sai
--  Revised:       06/14/2010
--  Description:   Added Columns product_line_code
-- +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

CREATE TABLE DCS2000.ach_hist_xchk
(
  HIST_XCHK_SET_NBR         NUMBER(8),
  RULE_NBR                  NUMBER(8),
  SEQUENCE_NBR              NUMBER(10),
  GRP_ID                    VARCHAR2(9 BYTE),
  SUBLOC_ID                 VARCHAR2(8 BYTE),
  DIV_ID                    VARCHAR2(4 BYTE),
  PRD_CDE                   NUMBER(4),
  PLN_CDE                   NUMBER(4),
  DESCRIPTION               VARCHAR2(100 BYTE),
  PROCEDURE_GROUPING_CLAIM  NUMBER(4),
  TOOTH_GROUPING_CLAIM      NUMBER(4),
  PROCEDURE_GROUPING_HIST   NUMBER(4),
  TOOTH_GROUPING_HIST       NUMBER(4),
  VIOLATION_FREQUENCY       NUMBER(4),
  TIME_SPAN                 NUMBER(4),
  TIME_SPAN_INDICATOR       VARCHAR2(2 BYTE),
  PROCESSING_POLICY         NUMBER(4),
  DELIMITER_CODE            NUMBER(4),
  ERROR_NUMBER              NUMBER(4),
  NEGATIVE_CHECK            NUMBER(1),
  SURFACE_MATCH             NUMBER(1),
  PRV_MATCH                 NUMBER(1),
  RELSHP_CDE                NUMBER(2),
  EFF_DTE                   NUMBER(8),
  TRM_DTE                   NUMBER(8),
  MAINT_CODE                NUMBER(4),
  MOD_DTE                   DATE,
  MOD_OP                    VARCHAR2(12 BYTE),
  PROCESS_ORDER             NUMBER(4),
  PROCESS_POLICY_SET        NUMBER(4)           DEFAULT 1,
  ins_upd_flag              VARCHAR2(1),
  POD_PRINT_LIMITATION      VARCHAR2(1) CHECK (UPPER(POD_PRINT_LIMITATION) IN ('Y', 'N')),
  PRINT_ORDER               NUMBER(10),
  POD_DESCRIPTION           VARCHAR2(200)  
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          3080K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;




GRANT INSERT, SELECT, UPDATE ON  DCS2000.ach_hist_xchk TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.ach_hist_xchk TO DCSREPORTS;

GRANT SELECT ON  DCS2000.ach_hist_xchk TO PRODDBLINK;

GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG ON  DCS2000.ach_hist_xchk TO DCSADMIN WITH GRANT OPTION;

ALTER TABLE DCS2000.ACH_HIST_XCHK
 ADD (surface_grouping_claim  NUMBER(4))
/

ALTER TABLE DCS2000.ACH_HIST_XCHK
 ADD (surface_grouping_hist  NUMBER(4))
/

ALTER TABLE DCS2000.ACH_HIST_XCHK
 ADD (PRODUCT_LINE_CODE  NUMBER(4)); --3.1.2
/
