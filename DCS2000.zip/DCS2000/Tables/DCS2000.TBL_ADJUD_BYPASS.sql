/* VERSION: 3.1.1 */ 
--
-- TBL_ADJUD_BYPASS  (Table) 
--
CREATE TABLE DCS2000.TBL_ADJUD_BYPASS
(
  MAINT_CODE       NUMBER(4),
  MOD_DTE          DATE,
  MOD_OP           VARCHAR2(12 BYTE),
  ERROR_NO         NUMBER(4)                    NOT NULL,
  BYPASS_ERROR_NO  NUMBER(4)                    NOT NULL
)
TABLESPACE RAW_DATA
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1040K
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- ADJUD_BYPASS_ERROR_NO_IX  (Index) 
--
CREATE INDEX DCS2000.ADJUD_BYPASS_ERROR_NO_IX ON DCS2000.TBL_ADJUD_BYPASS
(ERROR_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

--
-- BYPASS_ERROR_IX  (Index) 
--
CREATE INDEX DCS2000.BYPASS_ERROR_IX ON DCS2000.TBL_ADJUD_BYPASS
(BYPASS_ERROR_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_ADJUD_BYPASS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_ADJUD_BYPASS TO PRODDBLINK;

