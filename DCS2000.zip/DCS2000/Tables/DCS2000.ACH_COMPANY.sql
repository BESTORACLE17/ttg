/* VERSION: 2.1.2 */ 
--
-- ACH_COMPANY  (Table) 
--
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 2.1.2 
|| Service Request: S/R #05068.01.VA Add Company ID in W9 Record 
|| Revision By    : Russell Hertzberg 
|| Revision Date  : 03/08/2005 
|| Revision Desc  : Added PRV_LOC_RANGE and PRV_LOC_RANGE_END columns   
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
CREATE TABLE DCS2000.ACH_COMPANY
(
  MAINT_CODE                NUMBER(4),
  MOD_DTE                   DATE,
  MOD_OP                    VARCHAR2(12 BYTE),
  COMPANY_ID                NUMBER(4),
  PARENT_ID                 NUMBER(4),
  COMPANY_NAME              VARCHAR2(200 BYTE),
  SHORT_NAME                VARCHAR2(200 BYTE),
  NAIC                      VARCHAR2(20 BYTE),
  TIN                       VARCHAR2(9 BYTE),
  COMPANY_TYPE_CDE          NUMBER(4),
  COMPANY_SEGMENT_VALUE_ID  NUMBER(12),
  WEBSITE                   VARCHAR2(1000 BYTE),
  INS_UPD_FLAG              CHAR(1 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

GRANT DELETE, INSERT, SELECT, UPDATE ON  DCS2000.ACH_COMPANY TO DCS_USERS_ALL;

-- 
-- S/R #05068.01.VA - Russell J Hertzberg; 04/07/2005
-- Added PRV_LOC_RANGE, PRV_LOC_RANGE_END and BRAND_CODE columns 
-- 
ALTER TABLE DCS2000.ACH_COMPANY ADD (PRV_LOC_RANGE NUMBER(4), PRV_LOC_RANGE_END NUMBER(4), BRAND_CODE NUMBER(4));

--
-- .NET Column Changes
--
ALTER TABLE DCS2000.ACH_COMPANY RENAME COLUMN MOD_DTE TO UPDATED_ON;
ALTER TABLE DCS2000.ACH_COMPANY RENAME COLUMN MOD_OP  TO UPDATED_BY;
ALTER TABLE DCS2000.ACH_COMPANY RENAME COLUMN INS_UPD_FLAG TO ACTION_CODE;
ALTER TABLE DCS2000.ACH_COMPANY ADD CREATED_BY VARCHAR2(30);
COMMENT ON COLUMN ACH_COMPANY.CREATED_BY IS 'Refer To Production Table';
ALTER TABLE DCS2000.ACH_COMPANY ADD CREATED_ON DATE;
COMMENT ON COLUMN ACH_COMPANY.CREATED_ON IS 'Refer To Production Table';
ALTER TABLE DCS2000.ACH_COMPANY ADD ACTION_BY VARCHAR2(30);
COMMENT ON COLUMN ACH_COMPANY.ACTION_BY IS 'User ID of user who performed an action on the production record that caused old maintenance record to be archived.';
ALTER TABLE DCS2000.ACH_COMPANY ADD ACTION_ON DATE;
COMMENT ON COLUMN ACH_COMPANY.ACTION_ON IS 'Date on which user performed an action on the production record that caused old maintenance record to be archived.';
