/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: 07250.01.VA - Automate Ortho
|| Revision By    : Jeff Reynolds
|| Revision Date  : 07/15/2008.
|| Revision Desc  : Added ortho_payments
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_CDE_E35_RCDS  (Table) 
--
CREATE TABLE DCS2000.TBL_CDE_E35_RCDS
(
  RECORD_TYPE     CHAR(2 BYTE),
  BATCH_DATE      VARCHAR2(8 BYTE),
  BATCH_TYPE      CHAR(2 BYTE),
  CLAIM_TYPE      CHAR(1 BYTE),
  BATCH_NO        CHAR(4 BYTE),
  REEL_NO         CHAR(1 BYTE),
  SUFFIX          CHAR(2 BYTE),
  JULIAN_DATE     VARCHAR2(7 BYTE),
  CLAIM_NO        VARCHAR2(5 BYTE),
  CLAIM_NBR       VARCHAR2(5 BYTE),
  PAT_FNAME       VARCHAR2(10 BYTE),
  SEX             CHAR(1 BYTE),
  BIRTH_DATE      VARCHAR2(8 BYTE),
  SUB_FNAME       VARCHAR2(10 BYTE),
  SUB_LNAME       VARCHAR2(15 BYTE),
  SSN             VARCHAR2(9 BYTE),
  REL_CDE         VARCHAR2(2 BYTE),
  ADDR1           VARCHAR2(25 BYTE),
  CITY            VARCHAR2(17 BYTE),
  STATE           VARCHAR2(2 BYTE),
  ZIP             VARCHAR2(5 BYTE),
  DUAL            CHAR(1 BYTE),
  OUT             CHAR(1 BYTE),
  XRAY            CHAR(1 BYTE),
  PRV_SGN         CHAR(1 BYTE),
  AUTHORIZATION   CHAR(1 BYTE),
  RESUBMIT        CHAR(1 BYTE),
  PROCESS_STATUS  NUMBER(1),
  MAINT_CODE      NUMBER(4),
  MOD_DTE         DATE,
  MOD_OP          VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          2496K
            NEXT             8K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

--
-- IX_CDE_E35_RCDS  (Index) 
--
CREATE INDEX DCS2000.IX_CDE_E35_RCDS ON DCS2000.TBL_CDE_E35_RCDS
(JULIAN_DATE, CLAIM_NO)
LOGGING
TABLESPACE PRODIX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          600K
            NEXT             120K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_CDE_E35_RCDS TO DCS_USERS_ALL;

GRANT SELECT ON  DCS2000.TBL_CDE_E35_RCDS TO PRODDBLINK;

GRANT INSERT, SELECT ON  DCS2000.TBL_CDE_E35_RCDS TO DATAENTRY;

-- Changes for SR#05208.01.ALL
ALTER TABLE DCS2000.TBL_CDE_E35_RCDS MODIFY SSN VARCHAR2(30);

-- Changes for SR#06214.01.ALL
ALTER TABLE DCS2000.TBL_CDE_E35_RCDS ADD  ( PAT_LNAME     VARCHAR2(30) );

-- Changes for SR07250.01.VA
ALTER TABLE DCS2000.TBL_CDE_E35_RCDS ADD (
    ortho_payments   NUMBER(3,0));
                                          
