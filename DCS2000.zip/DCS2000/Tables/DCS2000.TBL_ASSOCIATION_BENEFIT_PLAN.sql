--=========================================
-- 06156.02.VA INDV Association Business  
-- 05/01/2013
-- SATYA SAI
--========================================
CREATE TABLE DCS2000.TBL_ASSOCIATION_BENEFIT_PLAN
( TABLE_ID                      NUMBER(2)     NOT NULL,
  DESCRIPTION                   VARCHAR2(100) NOT NULL,
  STATE_CODE                    VARCHAR2(2)   NOT NULL,
  DISPLAY_ORDER                 NUMBER(2)     NOT NULL,
  BENEFIT_CODE                  NUMBER(6)     NOT NULL,
  CREATED_BY                    VARCHAR2(30)  NOT NULL,
  CREATED_ON                    DATE          NOT NULL,
  UPDATED_BY                    VARCHAR2(30)  NOT NULL,
  UPDATED_ON                    DATE          NOT NULL,
  MAINT_CODE                    NUMBER(4)     NOT NULL,
  PARENT_ID                     NUMBER(4)     NOT NULL
)
TABLESPACE PROD;
/
GRANT SELECT,INSERT,UPDATE,DELETE ON DCS2000.TBL_ASSOCIATION_BENEFIT_PLAN TO DCS_USERS_ALL,SECURITY;
/