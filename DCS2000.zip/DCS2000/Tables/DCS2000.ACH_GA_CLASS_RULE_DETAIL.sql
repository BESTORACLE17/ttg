--********************
-- ACH_GA_CLASS_RULE_DETAIL
-- SR - 07109.01.VA
-- version 2.1.1
--********************
----------------------------------------------------------------------------
-- Version        : 2.1.2
-- Revision Type  : Enhancement
-- Service Request: SR07318.02.KY - TOYOTA onsite clinic - Phase II
-- Revision By    : Sanjay Mudaliar
-- Revision Date  : 06/27/2008
-- Revision Desc  : Added column for product_tier_code
----------------------------------------------------------------------------
CREATE TABLE DCS2000.ACH_GA_CLASS_RULE_DETAIL
(
  CREATED_BY                  VARCHAR2(12 BYTE),
  CREATED_ON                  DATE,   
  UPDATED_BY                  VARCHAR2(12 BYTE),
  UPDATED_ON                  DATE,    
  MAINT_CODE                  NUMBER(4),
  USER_DEFINED_FIELD1         VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD2         VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD3         VARCHAR2(100 BYTE),
  USER_DEFINED_FIELD4         VARCHAR2(100 BYTE),
  ACTION_CODE                 VARCHAR2(1 BYTE),
  ACTION_BY                   VARCHAR2(30 BYTE),
  ACTION_ON                   DATE,   
  CLASS_RULE_DETAIL_PK        NUMBER(9),
  CLASS_RULE_HEADER_PK        NUMBER(9),
  BEN_CLASS_CODE              NUMBER(4),
  PAR_NPAR_PRV_IND            NUMBER(1),
  RELATIONSHIP_CODE           NUMBER(4),
  EFF_DATE                    DATE, 
  TERM_DATE                   DATE,
  TERM_REASON_CODE				NUMBER(4),
  COMMENTS                    VARCHAR2(200 BYTE),
  NOTES								VARCHAR2(200 BYTE),
  COPAY_PERCENT               NUMBER(5,2),
  CLAIM_WAIT_PERIOD           NUMBER(4),
  WAIVE_CLAIM_WAIT_PERIOD     NUMBER(1),
  DED_PROCESSING_SEQUENCE     NUMBER(2),
  LATE_ENTRANTS_MONTHS        NUMBER(2),
  PRORATE_FLAG                VARCHAR2(1 BYTE),
  COPAY_TYPE                  NUMBER(4),
  MAX_COPAY_PERCENT           NUMBER(5,2),
  COPAY_INCREMENT             NUMBER(5,2),
  COPAY_INCREMENT2            NUMBER(5,2),
  COPAY_INCREMENT3            NUMBER(5,2),
  COPAY_INCREMENT4            NUMBER(5,2),
  COPAY_INCREMENT5            NUMBER(5,2),
  FEES_ZIP_SET                NUMBER(4),
  FEES_ZIP_PAR_PCT            NUMBER(4),
  FEES_ZIP_NONPAR_PCT         NUMBER(4),
  DISPLAY_ON_WEB              NUMBER(1),
  WAIT_PERIOD_ELIG_ONLY       NUMBER(4)   
);

ALTER TABLE DCS2000.ACH_GA_CLASS_RULE_DETAIL
  ADD (PRODUCT_TIER_CODE    NUMBER(4)); --2.1.2