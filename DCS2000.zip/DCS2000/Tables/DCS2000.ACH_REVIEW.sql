/* VERSION: 3.1.4 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/14/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.3
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement - Phase II
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 11/27/2006.
|| Revision Desc  : Added new column DCS_INDIVIDUAL_IDENTIFIER.
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.4
|| Service Request: 10067.02.VA MULTI PRODUCTS
|| Revision By    : Satya Sai
|| Revision Date  : 06/18/2010
|| Revision Desc  : Added new column Product_line_code.
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- ACH_REVIEW  (Table) 
--
CREATE TABLE DCS2000.ACH_REVIEW
(
  SUBR_ID              VARCHAR2(9 BYTE),
  INDV_ID              NUMBER(2),
  PRV_ID               VARCHAR2(11 BYTE),
  LOC                  NUMBER(4),
  TAX_ID               VARCHAR2(9 BYTE),
  FAC_STATE            VARCHAR2(2 BYTE),
  PRV_STATE            VARCHAR2(2 BYTE),
  PRV_PARTICIPATION    NUMBER(1),
  ASO_RISK_TYPE        NUMBER(2),
  GRP_ID               VARCHAR2(9 BYTE),
  SUBLOC_ID            VARCHAR2(8 BYTE),
  DIV_ID               VARCHAR2(4 BYTE),
  PRD_CDE              NUMBER(4),
  PLN_CDE              NUMBER(4),
  REVIEW_EFF_DTE       NUMBER(8),
  REVIEW_TRM_DTE       NUMBER(8),
  REVIEW_ERROR_CDE     NUMBER(4),
  PRC_CDE              VARCHAR2(4000 BYTE),
  BEN_CLASS_CDE        NUMBER(4),
  NOTES_REASONS_FIELD  VARCHAR2(2000 BYTE),
  MAINT_CODE           NUMBER(4),
  MOD_DTE              DATE,
  MOD_OP               VARCHAR2(12 BYTE)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          5200K
            NEXT             1M
            MINEXTENTS       3
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.ACH_REVIEW MODIFY SUBR_ID VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.ACH_REVIEW TO DCS_USERS_ALL;

-- Added with SR# 05208.01.ALL - Phase II
ALTER TABLE DCS2000.ACH_REVIEW ADD DCS_INDIVIDUAL_IDENTIFIER VARCHAR2(30);


-- SR 06214.01.ALL Phase II
-- 03/07/2007
--Suresh Vadapalli

alter table dcs2000.ach_review add( provider_npi number(10));

alter table dcs2000.ach_review add( facility_npi number(10));

-- Added for SR07121.01.ALL
ALTER TABLE	DCS2000.ACH_REVIEW	MODIFY (PRV_ID   VARCHAR2(32) ); 
-- 3.1.4
ALTER TABLE	DCS2000.ACH_REVIEW add (PRODUCT_LINE_CODE NUMBER(4) ); 
/
