/* version 2.1.1 
   SR 04138.01.NE 
   mark stock 
   9/19/2005 
   1/10/2006 -- fixed table comment

   version 2.1.2
   SR 04138.01.NE
   mark stock
   3/22/2006 -- removed PROCESS_POLICY_CDE from PK

--
-- TBL_ADJUD_ERROR_PP  (Table) 
--
CREATE TABLE DCS2000.TBL_ADJUD_ERROR_PP
(
  PROCESS_POLICY_SET  NUMBER(4)                 NOT NULL,
  PROCESS_POLICY_CDE  NUMBER(4)                 NOT NULL,
  ERROR_NO            NUMBER(4)                 NOT NULL,
  DELIMITER_CDE       NUMBER(4),
  MAINT_CODE          NUMBER(4)                 NOT NULL,
  MOD_DTE             DATE                      NOT NULL,
  MOD_OP              VARCHAR2(12)              NOT NULL
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL
/

comment on table dcs2000.TBL_ADJUD_ERROR_PP is
'Maps an Adjudication Error to a specific Process Policy within a specific Process Policy Set, with an optional Delimiter Code.
Detail table to TBL_ADJUDICATION_ERROR_DEF so that each Process Policy Set can have a different Process Policy and (Delimiter Code) defined for a specific Adjudication Error.
Originally populated from TBL_ADJUDICATION_ERROR_DEF.
Created for SR04138.01.NE/SR04287.01.NE.'
;


--
-- PK_ADJUD_ERROR_PP  (Index) 
--
-- 3/22/2006 revised PK
CREATE UNIQUE INDEX DCS2000.PK_ADJUD_ERROR_PP ON DCS2000.TBL_ADJUD_ERROR_PP
(ERROR_NO, PROCESS_POLICY_SET)
LOGGING
TABLESPACE PROD
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          1M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL
/


-- 
-- Non Foreign Key Constraints for Table TBL_ADJUD_ERROR_PP 
-- 
-- 3/22/2006 revised PK
ALTER TABLE DCS2000.TBL_ADJUD_ERROR_PP ADD (
  CONSTRAINT PK_ADJUD_ERROR_PP PRIMARY KEY (ERROR_NO, PROCESS_POLICY_SET)
)
    USING INDEX 
    TABLESPACE PROD
    PCTFREE    10
    INITRANS   2
    MAXTRANS   255
    STORAGE    (
                INITIAL          1M
                NEXT             1M
                MINEXTENTS       1
                MAXEXTENTS       2147483645
                PCTINCREASE      0
                FREELISTS        1
                FREELIST GROUPS  1
               ))
/


-- 
-- Foreign Key Constraints for Table TBL_ADJUD_ERROR_PP 
-- 
ALTER TABLE DCS2000.TBL_ADJUD_ERROR_PP ADD (
  CONSTRAINT FK_ADJUD_ERR_PP_2_ADJ_ERR FOREIGN KEY (ERROR_NO) 
    REFERENCES DCS2000.TBL_ADJUDICATION_ERROR_DEF (ERROR_NO)
    ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED)
/

ALTER TABLE DCS2000.TBL_ADJUD_ERROR_PP ADD (
  CONSTRAINT FK_ADJUD_ERR_PP_2_DELIMITER FOREIGN KEY (DELIMITER_CDE) 
    REFERENCES DCS2000.TBL_CODE_DELIMITER (CODE))
/

ALTER TABLE DCS2000.TBL_ADJUD_ERROR_PP ADD (
  CONSTRAINT FK_ADJUD_ERR_PP_2_PP FOREIGN KEY (PROCESS_POLICY_SET, PROCESS_POLICY_CDE) 
    REFERENCES DCS2000.TBL_CODE_PROCESS_POLICY (PROCESS_POLICY_SET,CODE))
/
