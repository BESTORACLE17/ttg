/* VERSION: 3.1.2 */ 
/*
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|| Revision Type  : Enhancement 
|| Version #      : 3.1.2 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Sudeep Prabhakaran.
|| Revision Date  : 07/17/2006.
|| Revision Desc  : Altered table's column subr_id from 9 to 30
|| 
|| Service Request: SR# 05208.01.ALL - Alternate ID Enhancement
|| Revision By    : Eric Lichtman.
|| Revision Date  : 11/03/2006.
|| Revision Desc  : Altered table added column ssn.
|| 
|| Production Date: 
|| Production By  : 
|| Dependencies   : 
|| Limitations    : 
|| +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/
--
-- TBL_BILLING_COUPONS  (Table) 
--
CREATE TABLE DCS2000.TBL_BILLING_COUPONS
(
  MAINT_CODE   NUMBER(4)                        NOT NULL,
  MOD_DTE      DATE                             NOT NULL,
  MOD_OP       VARCHAR2(12 BYTE)                NOT NULL,
  CUSTNO       VARCHAR2(9 BYTE)                 NOT NULL,
  CUSTNAME     VARCHAR2(40 BYTE)                NOT NULL,
  INVOICENO    VARCHAR2(14 BYTE),
  INVOICEDATE  VARCHAR2(10 BYTE)                NOT NULL,
  INVOICEAMT   NUMBER(9,2)                      NOT NULL,
  DATEPAID     VARCHAR2(10 BYTE),
  COMPANY_ID   VARCHAR2(4 BYTE),
  SCAN_CUSTNO  VARCHAR2(14 BYTE),
  SCAN_AMT     VARCHAR2(11 BYTE),
  SCAN_DATE    NUMBER(9)
)
TABLESPACE PROD
PCTUSED    40
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          256K
            NEXT             256K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;

-- Added with SR# 05208.01.ALL
ALTER TABLE DCS2000.TBL_BILLING_COUPONS MODIFY CUSTNO VARCHAR2(30);
ALTER TABLE DCS2000.TBL_BILLING_COUPONS MODIFY SCAN_CUSTNO VARCHAR2(30);

-- Added with SR# 05208.01.ALL Eric Lichtman
ALTER TABLE DCS2000.TBL_BILLING_COUPONS ADD SSN VARCHAR2(30);

GRANT INSERT, SELECT, UPDATE ON  DCS2000.TBL_BILLING_COUPONS TO DCS_USERS_ALL;

