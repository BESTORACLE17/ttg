/* VERSION 2.1.1 */
BEGIN 
dbms_aqadm.create_queue(queue_name=> 'DCS2000.ADJUD_PROCESS_009', queue_table=> 'DCS2000.TBL_ADJUD_AQ', queue_type=> DBMS_AQADM.NORMAL_QUEUE, max_retries=> '5', retry_delay=> '0', retention_time=> '0', COMMENT=> '');
END;
BEGIN 
  dbms_aqadm.start_queue('ADJUD_PROCESS_009', TRUE, TRUE);
END;
/