/* VERSION 2.1.1 */
BEGIN 
dbms_aqadm.create_queue(queue_name=> 'DCS2000.AQ$_TBL_ADJUD_AQ_E', queue_table=> 'DCS2000.TBL_ADJUD_AQ', queue_type=> DBMS_AQADM.EXCEPTION_QUEUE, max_retries=> '0', retry_delay=> '0', retention_time=> '0', COMMENT=> 'exception queue');
END;
/