/* VERSION 2.1.1 */
BEGIN 
dbms_aqadm.create_queue_table( queue_table=> 'DCS2000.TBL_ADJUD_AQ', queue_payload_type=> 'DCS2000.OBJ_ADJUD_PROCESS_MSG', sort_list=> 'PRIORITY,ENQ_TIME', COMMENT=> 'adjudication processes', multiple_consumers=> FALSE, message_grouping=> DBMS_AQADM.NONE, storage_clause=> '	PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255
	STORAGE(
		INITIAL 1024 K
		NEXT 1024 K
		MINEXTENTS 1
		MAXEXTENTS UNLIMITED
		PCTINCREASE 0
		FREELISTS 1
		FREELIST GROUPS 1
		BUFFER_POOL DEFAULT
		)
TABLESPACE PROD LOGGING
', compatible=> '8.0', primary_instance=> '0', secondary_instance=> '0' ); 
COMMIT;
END;
/