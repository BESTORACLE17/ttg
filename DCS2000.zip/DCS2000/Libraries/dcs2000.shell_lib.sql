-- Create library 
create or replace library SHELL_LIB
  as '/scripts/oracle/lib/extproc1.so';
